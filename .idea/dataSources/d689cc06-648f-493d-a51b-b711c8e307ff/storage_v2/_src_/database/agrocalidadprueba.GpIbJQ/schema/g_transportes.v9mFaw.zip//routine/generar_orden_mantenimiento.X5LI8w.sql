create function generar_orden_mantenimiento() returns trigger
    language plpgsql
as
$$
 
DECLARE _valor INTEGER;
DECLARE _incremento INTEGER;
DECLARE _numero CHARACTER VARYING;

BEGIN
_valor:=5000; 
_incremento:=1;
	IF (NEW.kilometraje_actual >= (_valor + NEW.kilometraje_inicial))
	THEN
		_numero:= (SELECT g_transportes.crear_codigo(NEW.localizacion));
		PERFORM g_transportes.crearmantenimiento(_numero,OLD.placa,NEW.kilometraje_actual, NEW.localizacion, NEW.id_vehiculo);
		UPDATE g_transportes.vehiculos SET kilometraje_inicial = NEW.kilometraje_actual, estado = 2 WHERE placa = NEW.placa;
	END IF;
	RETURN NEW;
	END; 
	
$$;

alter function generar_orden_mantenimiento() owner to postgres;

