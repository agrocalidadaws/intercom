create view vista_busqueda_murcielagos_hematofagos
            (id_murcielagos_hematofagos, identificador, fecha_creacion, num_solicitud, fecha, nombre_predio,
             nombre_propietario, persona_refugio, id_tipo_refugio, tipo_refugio, id_provincia, provincia, id_canton,
             canton, id_parroquia, parroquia, sitio, id_oficina, oficina, utm_x, utm_y, utm_z, altitud, latitud,
             longitud, zona, estado, identificador_modificacion, fecha_modificacion, nueva_inspeccion,
             fecha_nueva_inspeccion, identificador_cierre, fecha_cierre, imagen_mapa, ruta_informe)
as
SELECT DISTINCT mh.id_murcielagos_hematofagos,
                mh.identificador,
                mh.fecha_creacion,
                mh.num_solicitud,
                mh.fecha,
                mh.nombre_predio,
                mh.nombre_propietario,
                mh.persona_refugio,
                mh.id_tipo_refugio,
                mh.tipo_refugio,
                mh.id_provincia,
                mh.provincia,
                mh.id_canton,
                mh.canton,
                mh.id_parroquia,
                mh.parroquia,
                mh.sitio,
                mh.id_oficina,
                mh.oficina,
                mh.utm_x,
                mh.utm_y,
                mh.utm_z,
                mh.altitud,
                mh.latitud,
                mh.longitud,
                mh.zona,
                mh.estado,
                mh.identificador_modificacion,
                mh.fecha_modificacion,
                mh.nueva_inspeccion,
                mh.fecha_nueva_inspeccion,
                mh.identificador_cierre,
                mh.fecha_cierre,
                mh.imagen_mapa,
                mh.ruta_informe
FROM g_programas_control_oficial.murcielagos_hematofagos mh;

alter table vista_busqueda_murcielagos_hematofagos
    owner to postgres;

