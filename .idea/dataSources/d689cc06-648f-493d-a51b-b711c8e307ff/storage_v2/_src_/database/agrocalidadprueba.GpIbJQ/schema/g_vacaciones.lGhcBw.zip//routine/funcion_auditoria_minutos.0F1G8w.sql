create function funcion_auditoria_minutos() returns trigger
    language plpgsql
as
$$ 
BEGIN
	IF (TG_OP = 'INSERT') THEN
		PERFORM g_vacaciones.funcion_insertar_minutos_auditoria(NEW.identificador, 0, NEW.minutos_disponibles, NEW.anio, NEW.observacion);	
	ELSE 
		PERFORM g_vacaciones.funcion_insertar_minutos_auditoria(NEW.identificador, OLD.minutos_disponibles, NEW.minutos_disponibles, NEW.anio, NEW.observacion);	
	
	END IF;
	RETURN NEW;
	END; 
	
$$;

alter function funcion_auditoria_minutos() owner to postgres;

