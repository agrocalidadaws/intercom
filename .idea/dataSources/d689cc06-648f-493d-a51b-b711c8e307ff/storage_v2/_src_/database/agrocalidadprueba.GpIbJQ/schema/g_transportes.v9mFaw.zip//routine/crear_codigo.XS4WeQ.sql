create function crear_codigo(localizacion text) returns text
    language plpgsql
as
$$
DECLARE
  DECLARE _codigo text;
  DECLARE _numero int;
  DECLARE _ceros int;
BEGIN
	_codigo := (SELECT codigo FROM g_catalogos.localizacion l WHERE l.nombre = $1);
	_numero:= (SELECT max(split_part(id_mantenimiento, 'MAN-'||_codigo||'-' , 2)::int) as numero FROM g_transportes.mantenimientos WHERE id_mantenimiento LIKE '%MAN-'||_codigo||'%');
	_numero := _numero + 1;
	_ceros := 8 - length(''||_numero||'');
 
RETURN 'MAN-'||_codigo ||'-'||repeat('0', _ceros)||_numero;
  
END
$$;

alter function crear_codigo(text) owner to postgres;

