create function comma_cat(text, text) returns text
    language sql
as
$$select case
WHEN $2 is null or $2 = '' THEN $1
WHEN $1 is null or $1 = '' THEN $2
ELSE $1 || ', ' || $2
END$$;

alter function comma_cat(text, text) owner to postgres;

