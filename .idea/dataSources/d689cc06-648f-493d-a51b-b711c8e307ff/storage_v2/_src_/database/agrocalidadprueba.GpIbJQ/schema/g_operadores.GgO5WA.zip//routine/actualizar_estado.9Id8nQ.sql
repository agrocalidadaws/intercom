create function actualizar_estado() returns trigger
    language plpgsql
as
$$ 
BEGIN
	IF (NEW.estado != OLD.estado)
	THEN
		UPDATE g_operadores.operaciones SET estado = NEW.estado, observacion = NEW.observacion  WHERE id_operacion = NEW.id_operacion;
	END IF;
	RETURN NEW;
	END; 
	
$$;

alter function actualizar_estado() owner to postgres;

