create function mostrar_combustibles_general(_placa text, _fecha_inicio date, _fecha_fin date, _localizacion text, _cantidad integer) returns SETOF g_transportes.combustible_general
    language plpgsql
as
$$
DECLARE
	query text;
BEGIN	
	return query EXECUTE '
			SELECT 
				SUM(c.valor_liquidacion) valor,
				v.placa,
				v.localizacion,
				v.marca,
				v.modelo
			FROM 
				g_transportes.combustible c,
				g_transportes.vehiculos v
			WHERE
				c.placa = v.placa and
				($1 is NULL or c.placa like $1) and 
				($2 is NULL or  c.fecha_despacho >= $2) and 
				($3 is NULL or  c.fecha_despacho <= $3) and
				($4 is NULL or $4 = v.localizacion)and
				c.estado = 3
			GROUP BY 
				v.placa,
				v.localizacion,
				v.marca,
				v.modelo
			ORDER BY valor desc
			LIMIT $5'
			
		using _placa,_fecha_inicio,_fecha_fin,_localizacion,_cantidad;
	
END;
$$;

alter function mostrar_combustibles_general(text, date, date, text, integer) owner to postgres;

