create procedure sp_envio_correo_orden_pago(INOUT json_parametro json)
    language plpgsql
as
$$
/*
-------------------------------------------------------------------------
--  [g_financiero.sp_envio_correo_orden_pago]
--               
--  procedimiento que se encarga de enviar las ordenes de pago a los correos,
--  de los clientes
--
--  VERSION		AUTOR					FECHA			HU			                           
--	1			Kleber Armijos		03-09-2024	 Control de cambios funcional interconexion 
--				Milton Nivelo				     refactoracion financiero pry-banred
-------------------------------------------------------------------------
*/
DECLARE
	
	--Variables JSON
    v_da JSON; 
	
	--Variables datos generales--
	v_id_pago INTEGER;
	v_tipo_solicitud  TEXT;
	v_numero_solicitud TEXT;
	v_razon_social TEXT;
	v_correo_cliente TEXT;
	v_ruta_orden_pago TEXT;
	
	--Variables correo--
	v_id_correo INTEGER;
    v_asunto TEXT;
	v_cuerpo TEXT;
    
BEGIN	

	v_da := json_parametro;

	--Datos generales--
	v_id_pago := v_da->>'idPago';
	v_tipo_solicitud := v_da->>'tipoSolicitud';
	v_numero_solicitud := v_da->>'numeroSolicitud';
	v_razon_social := v_da->>'razonSocial';
	v_correo_cliente := v_da->>'correoCliente'; 
	v_ruta_orden_pago := v_da->>'rutaOrdenPago';
	
	IF v_tipo_solicitud NOT IN ('certificadoZooExportacion') THEN

		v_asunto := 'Orden de Pago '|| v_numero_solicitud;
		v_cuerpo := '<tr>
					<td style="font-family:"Text Me One", 
					 "Segoe UI", "Tahoma", "Helvetica", "freesans", "sans-serif2; padding-top:25px; font-size:14px;color:#2a2a2a; width: 80%; text-align:justify;">'
					 ||'Estimado Sr. <font color="green">' || v_razon_social || '</font>,<br/><br/>'
					 ||'Por medio de la presente se comunica que la orden de pago con, Nro. <font color="green">' || v_numero_solicitud ||'</font>'||
					 ' ha sido Generada .<br/><br/>'
					 ||'Saludos Cordiales.
					</td>
				 </tr>';
		 INSERT INTO 
					g_correos.correos(
									   asunto,
									   cuerpo,
									   estado,
									   codigo_modulo,
									   tabla_modulo,
									   id_solicitud_tabla	   
									  )
		VALUES (v_asunto, 
				v_cuerpo,
				'Por enviar',
				'PRG_FINANCIERO',
				'g_financiero.orden_pago',
				v_id_pago
			   )				   
		RETURNING id_correo INTO v_id_correo; 
		
		INSERT INTO 
			g_correos.destinatarios(id_correo,destinatario_correo)
		VALUES
			(v_id_correo, v_correo_cliente);
		
		INSERT INTO  g_correos.documentos_adjuntos (id_correo, ruta_documento_adjunto)
		VALUES (v_id_correo, v_ruta_orden_pago);
		
	END IF;
		
END;
$$;

alter procedure sp_envio_correo_orden_pago(inout json) owner to postgres;

