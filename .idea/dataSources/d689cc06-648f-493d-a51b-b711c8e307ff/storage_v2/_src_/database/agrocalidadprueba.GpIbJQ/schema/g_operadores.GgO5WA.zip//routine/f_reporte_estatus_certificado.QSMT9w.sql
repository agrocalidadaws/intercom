create function f_reporte_estatus_certificado()
    returns TABLE(id_area integer, id_historial_operacion integer, identificador character varying, razon_social character varying, nombre_representante text, provincia character varying, canton character varying, direccion character varying, telefono_uno character varying, celular_uno character varying, correo character varying, tipo_actividad character varying, codigo_poa character varying, estado_codigo text, subcodigo_poa character varying, estado_subcodigo text, nombre_area character varying, estado_area text, nombre character varying, organismo_certificador text, estatus text, superficie numeric, numero_productores bigint, num_prod_info integer, numero_certificado character varying, fecha_ultima_inspeccion date, fecha_certificado date, fecha_primera_inspeccion date, fecha_caducidad date, otras_certificaciones character varying, fecha_registro timestamp without time zone, fecha_vigilancia character varying, fecha_renovacion character varying, tipo_certificado text)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    WITH organicos AS (
        SELECT 
            oo.id_historial_operacion,
            oo.id_subcodigo_poa,
            string_agg(DISTINCT tt.nombre_tipo_transicion, ',') AS estatus, 
            rtrim(array_to_string(array_agg(DISTINCT ac.nombre_agencia_certificadora), ', '), ', ') AS agencia
        FROM 
            g_operadores.operaciones_organico oo
        INNER JOIN 
            g_catalogos.tipo_transicion tt ON oo.id_tipo_transicion = tt.id_tipo_transicion
        INNER JOIN 
            g_catalogos.agencia_certificadora ac ON oo.id_agencia_certificadora = ac.id_agencia_certificadora
        GROUP BY 
            oo.id_historial_operacion, oo.id_subcodigo_poa
    ),
    rendimiento AS (
        SELECT 
            dma.id_area,
            COUNT(DISTINCT ma.identificador_miembro_asociacion) AS numero_productores,
            SUM(dma.superficie_miembro::DECIMAL) AS superficie
        FROM 
            g_operadores.miembros_asociacion ma
        INNER JOIN 
            g_operadores.detalle_miembros_asociacion dma ON ma.id_miembro_asociacion = dma.id_miembro_asociacion
        GROUP BY 
            dma.id_area
    ),
    ico AS (
        SELECT  
            ico.id_historial_operacion, 
            ico.id_informacion, 
            ico.numero_productores AS num_prod_info, 
            ico.numero_certificado, 
            ico.fecha_ultima_inspeccion, 
            ico.fecha_certificado, 
            ico.fecha_registro, 
            ico.fecha_primera_inspeccion, 
            ico.fecha_caducidad, 
            ico.otras_certificaciones, 
            ico.fecha_vigilancia, 
            ico.fecha_renovacion, 
            STRING_AGG(doceor.tipo, ', ') AS tipo_certificado
        FROM 
            g_operadores.informacion_certificado_organico ico 
        LEFT JOIN  
            g_operadores.documento_certificado_organico doceor ON doceor.id_informacion = ico.id_informacion
        GROUP BY 
            ico.id_historial_operacion, 
            ico.id_informacion, 
            ico.numero_productores, 
            ico.numero_certificado, 
            ico.fecha_ultima_inspeccion, 
            ico.fecha_certificado, 
            ico.fecha_registro, 
            ico.fecha_primera_inspeccion, 
            ico.fecha_caducidad, 
            ico.otras_certificaciones, 
            ico.fecha_vigilancia, 
            ico.fecha_renovacion
    )
    SELECT DISTINCT 
        pao.id_area, 
        op.id_historial_operacion,
        o.identificador, 
        o.razon_social, 
        o.nombre_representante || ' ' || o.apellido_representante AS nombre_representante,
        o.provincia, 
        o.canton, 
        o.direccion, 
        o.telefono_uno, 
        o.celular_uno, 
        o.correo, 
        o.tipo_actividad,
        copo.codigo_poa,  
        CASE 
            WHEN copo.estado = 'activo' THEN 'Activo' 
            ELSE 'Cancelado' 
        END AS estado_codigo,
        subco.subcodigo_poa, 
        CASE 
            WHEN subco.estado = 'habilitado' THEN 'Activo' 
            ELSE 'Cancelado' 
        END AS estado_subcodigo,
        a.nombre_area, 
		CASE 
            WHEN a.estado = 'creado' THEN 'Activo' 
            ELSE 'Inactivo' 
        END AS estado_area,
        tipo.nombre, 
        organicos.agencia AS organismo_certificador,
        organicos.estatus, 
        rendimiento.superficie,
        rendimiento.numero_productores,
        ico.num_prod_info,
        ico.numero_certificado, 
        ico.fecha_ultima_inspeccion, 
        ico.fecha_certificado, 
        ico.fecha_primera_inspeccion,
        ico.fecha_caducidad, 
        ico.otras_certificaciones, 
        ico.fecha_registro, 
        ico.fecha_vigilancia, 
        ico.fecha_renovacion, 
        ico.tipo_certificado
    FROM 
        g_operadores.operadores o
    INNER JOIN 
        g_operadores.operaciones op ON o.identificador = op.identificador_operador
    INNER JOIN 
        g_operadores.productos_areas_operacion pao ON op.id_operacion = pao.id_operacion
    INNER JOIN 
        g_operadores.areas a ON a.id_area = pao.id_area
    INNER JOIN 
        g_catalogos.tipos_operacion tipo ON tipo.id_tipo_operacion = op.id_tipo_operacion
    INNER JOIN 
        organicos ON organicos.id_historial_operacion = op.id_historial_operacion
    INNER JOIN 
        g_operadores.subcodigos_poa subco ON subco.id_subcodigo_poa = organicos.id_subcodigo_poa
    INNER JOIN 
        g_operadores.codigos_poa copo ON copo.id_codigo_poa = subco.id_codigo_poa 
    LEFT JOIN 
        rendimiento ON rendimiento.id_area = pao.id_area
    LEFT JOIN 
        ico ON ico.id_historial_operacion = op.id_historial_operacion
    WHERE 
        tipo.id_area = 'AI' 
        AND tipo.codigo IN ('COM', 'PRO', 'PRC', 'REC')
    ORDER BY 
        o.razon_social, 
        copo.codigo_poa, 
        subco.subcodigo_poa;
END;
$$;

alter function f_reporte_estatus_certificado() owner to postgres;

