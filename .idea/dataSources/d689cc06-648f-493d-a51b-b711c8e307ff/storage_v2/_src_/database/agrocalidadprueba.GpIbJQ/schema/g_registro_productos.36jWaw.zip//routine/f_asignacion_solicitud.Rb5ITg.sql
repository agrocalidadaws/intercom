create function f_asignacion_solicitud() returns trigger
    language plpgsql
as
$$
	DECLARE
		perfil text;
	BEGIN

			CASE 
				WHEN NEW.tipo_solicitud = 'fertilizantes' THEN 
					perfil = 'PFL_TEC_RFE_PRO';
				WHEN NEW.tipo_solicitud = 'bioplaguicidas' THEN 
					perfil = 'PFL_TEC_RBP_PRO';
				WHEN NEW.tipo_solicitud = 'clonesfertilizantes' THEN 
					perfil = 'PFL_TEC_RCF_PRO';
				WHEN NEW.tipo_solicitud = 'clonesplaguicidas' THEN 
					perfil = 'PFL_TEC_RCP_PRO';
			END CASE;

			INSERT INTO 
				g_asignacion_solicitudes.solicitudes
					(nombre_tabla_origen, nombre_campo_identificar_tabla_origen, id_tabla_origen, nombre_campo_estado_tabla_origen, 
					 estado_tabla_origen, codificacion_perfil, nombre_campo_identificador_tabla_origen) 
			VALUES 
			('g_registro_productos.solicitudes_registro_productos', 'id_solicitud_registro_producto', NEW.id_solicitud_registro_producto, 'estado',
			'asignadoInspeccion', perfil, 'identificador_revisor');
		
		RETURN NEW;
	END; 
		
	$$;

alter function f_asignacion_solicitud() owner to postgres;

