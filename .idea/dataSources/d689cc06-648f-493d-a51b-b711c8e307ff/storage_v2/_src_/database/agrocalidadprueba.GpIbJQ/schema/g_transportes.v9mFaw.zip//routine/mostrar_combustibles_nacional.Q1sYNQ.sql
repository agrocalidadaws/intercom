create function mostrar_combustibles_nacional(_placa text, _fecha_inicio date, _fecha_fin date) returns SETOF g_transportes.combustible_nacional
    language plpgsql
as
$$
DECLARE
	query text;
BEGIN	
	return query EXECUTE '
			SELECT 
			COUNT(c.id_combustible) numero,
			
			(SELECT SUM(valor_liquidacion) FROM g_transportes.combustible WHERE (fecha_solicitud >= $2) and 
			(fecha_solicitud <= $3) and estado = 3 and placa=c.placa) suma_total,
			
			(SELECT SUM(cantidad_galones) FROM g_transportes.combustible WHERE (fecha_solicitud >= $2) and 
			(fecha_solicitud <= $3) and estado = 3 and placa=c.placa) galones_total,
			
			(SELECT SUM(valor_liquidacion) FROM g_transportes.combustible WHERE (fecha_solicitud >= $2) and 
			(fecha_solicitud <= $3) and tipo_combustible like ''%Super%'' and estado = 3 and placa=c.placa) suma_super,
			
			(SELECT COUNT(id_combustible) FROM g_transportes.combustible WHERE (fecha_solicitud >= $2) and 
			(fecha_solicitud <= $3) and tipo_combustible like ''%Super%'' and estado = 3 and placa=c.placa) numero_super,
			
			(SELECT SUM(cantidad_galones) FROM g_transportes.combustible WHERE (fecha_solicitud >= $2) and 
			(fecha_solicitud <= $3) and tipo_combustible like ''%Super%'' and estado = 3 and placa=c.placa) galones_super,
			
			(SELECT SUM(valor_liquidacion) FROM g_transportes.combustible WHERE (fecha_solicitud >= $2) and 
			(fecha_solicitud <= $3) and tipo_combustible like ''%Diesel%'' and estado = 3 and placa=c.placa) suma_diesel,
			
			(SELECT COUNT(id_combustible) FROM g_transportes.combustible WHERE (fecha_solicitud >= $2) and 
			(fecha_solicitud <= $3) and tipo_combustible like ''%Diesel%'' and estado = 3 and placa=c.placa) numero_diesel,
			
			(SELECT SUM(cantidad_galones) FROM g_transportes.combustible WHERE (fecha_solicitud >= $2) and 
			(fecha_solicitud <= $3) and tipo_combustible like ''%Diesel%'' and estado = 3 and placa=c.placa) galones_diesel,
			
			(SELECT SUM(valor_liquidacion) FROM g_transportes.combustible WHERE (fecha_solicitud >= $2) and 
			(fecha_solicitud <= $3) and tipo_combustible like ''%Extra%'' and estado = 3 and placa=c.placa) suma_extra,
			
			(SELECT COUNT(id_combustible) FROM g_transportes.combustible WHERE (fecha_solicitud >= $2) and 
			(fecha_solicitud <= $3) and tipo_combustible like ''%Extra%'' and estado = 3 and placa=c.placa) numero_extra,
			
			(SELECT SUM(cantidad_galones) FROM g_transportes.combustible WHERE (fecha_solicitud >= $2) and 
			(fecha_solicitud <= $3) and tipo_combustible like ''%Extra%'' and estado = 3 and placa=c.placa) galones_extra,

			(SELECT SUM(valor_liquidacion) FROM g_transportes.combustible WHERE (fecha_solicitud >= $2) and 
			(fecha_solicitud <= $3) and tipo_combustible like ''%Ecopais%'' and estado = 3 and placa=c.placa) suma_ecopais,
			
			(SELECT COUNT(id_combustible) FROM g_transportes.combustible WHERE (fecha_solicitud >= $2) and 
			(fecha_solicitud <= $3) and tipo_combustible like ''%Ecopais%'' and estado = 3 and placa=c.placa) numero_ecopais,
			
			(SELECT SUM(cantidad_galones) FROM g_transportes.combustible WHERE (fecha_solicitud >= $2) and 
			(fecha_solicitud <= $3) and tipo_combustible like ''%Ecopais%'' and estado = 3 and placa=c.placa) galones_ecopais,


			(SELECT COUNT(id_combustible) FROM g_transportes.combustible WHERE (fecha_solicitud >= $2) and 
			(fecha_solicitud <= $3) and estado in (1, 2) and placa=c.placa) numero_pendientes,
			
			(SELECT COUNT(id_combustible) FROM g_transportes.combustible WHERE (fecha_solicitud >= $2) and 
			(fecha_solicitud <= $3) and estado = 9 and placa=c.placa) numero_eliminados,
			c.placa
		FROM
			g_transportes.combustible c,
			g_transportes.gasolineras g
		WHERE
			c.gasolinera = g.id_gasolinera and
			($2 is NULL or  c.fecha_solicitud >= $2) and 
			($3 is NULL or  c.fecha_solicitud <= $3) and
			$1 is NULL or c.placa like $1
		GROUP BY 
			c.placa
		order by 
		c.placa asc'

		using _placa,_fecha_inicio,_fecha_fin;
	
END;
$$;

alter function mostrar_combustibles_nacional(text, date, date) owner to postgres;

