create function f_agregar_descontar_saldo_inspeccion(p_tipo_transaccion text, p_id_total_inspeccion double precision, p_cantidad_ingreso double precision, p_peso_ingreso double precision, lcantidadegreso double precision, p_peso_egreso double precision) returns boolean
    language plpgsql
as
$$
		DECLARE

		resultado boolean := true;

		BEGIN

			IF p_tipo_transaccion = 'ingreso' THEN
			
				PERFORM * FROM g_inspeccion_fitosanitaria.total_inspeccion_fitosanitaria WHERE id_total_inspeccion_fitosanitaria = p_id_total_inspeccion and total_cantidad_aprobada <= cantidad_aprobada and total_peso_aprobado <= peso_aprobado;-- FOR UPDATE;
				
			ELSEIF p_tipo_transaccion = 'egreso' THEN
			
				PERFORM * FROM g_inspeccion_fitosanitaria.total_inspeccion_fitosanitaria WHERE id_total_inspeccion_fitosanitaria = p_id_total_inspeccion and total_cantidad_aprobada > 0 and total_peso_aprobado > 0;-- FOR UPDATE;
			
			END IF;

			IF FOUND THEN
				--RAISE NOTICE '% ', 'SI';
				UPDATE g_inspeccion_fitosanitaria.total_inspeccion_fitosanitaria 
					SET cantidad_aprobada_ingreso = p_cantidad_ingreso, 
					cantidad_aprobada_egreso = lcantidadegreso, 
					total_cantidad_aprobada = ROUND(CAST((total_cantidad_aprobada + p_cantidad_ingreso - lcantidadegreso) AS NUMERIC), 2),
					peso_aprobado_ingreso = p_peso_ingreso, 
					peso_aprobado_egreso = p_peso_egreso, 
					total_peso_aprobado = ROUND(CAST((total_peso_aprobado + p_peso_ingreso - p_peso_egreso) AS NUMERIC), 2)
					WHERE id_total_inspeccion_fitosanitaria = p_id_total_inspeccion;
			ELSE
				--RAISE NOTICE '% ', 'NO posee saldo';
				resultado := false;
			END IF;
			
		RETURN resultado;
		
		END	
			
	
$$;

alter function f_agregar_descontar_saldo_inspeccion(text, double precision, double precision, double precision, double precision, double precision) owner to postgres;

