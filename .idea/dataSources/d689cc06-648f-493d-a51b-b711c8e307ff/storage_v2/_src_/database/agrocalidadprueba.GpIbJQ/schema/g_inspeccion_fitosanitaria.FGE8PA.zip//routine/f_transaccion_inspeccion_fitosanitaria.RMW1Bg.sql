create function f_transaccion_inspeccion_fitosanitaria() returns trigger
    language plpgsql
as
$$

		BEGIN

				INSERT INTO 
					g_inspeccion_fitosanitaria.transaccion_inspeccion_fitosanitaria
					(id_total_inspeccion_fitosanitaria, cantidad_aprobada_ingreso, cantidad_aprobada_egreso, total_cantidad_aprobada
					, peso_aprobado_ingreso, peso_aprobado_egreso, total_peso_aprobado) 
				VALUES 
				(NEW.id_total_inspeccion_fitosanitaria, NEW.cantidad_aprobada_ingreso, NEW.cantidad_aprobada_egreso, NEW.total_cantidad_aprobada
				, NEW.peso_aprobado_ingreso, NEW.peso_aprobado_egreso, NEW.total_peso_aprobado);
					
			RETURN NEW;
		END; 		
		
	$$;

alter function f_transaccion_inspeccion_fitosanitaria() owner to postgres;

