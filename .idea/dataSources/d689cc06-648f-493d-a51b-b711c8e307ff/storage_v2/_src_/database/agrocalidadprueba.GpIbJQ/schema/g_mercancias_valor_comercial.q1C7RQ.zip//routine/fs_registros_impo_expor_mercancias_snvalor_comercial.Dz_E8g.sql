create function fs_registros_impo_expor_mercancias_snvalor_comercial(pid_registro integer) returns json
    language plpgsql
as
$$

/*
-------------------------------------------------------------------------
--  [g_mercancias_valor_comercial.fs_registros_impo_expor_mercancias_snvalor_comercial]
--               
--  Esta funcion retorna json de los registros de las solicitudes de exportacion e importacion 
--  De mercancias sin valor comercial
--
--  VERSION		AUTOR					FECHA			HU	
--	1			Kleber Armijos		25-01-2024	  Funcion retorna registros de mercancias sin valor comercial 
--												  
-------------------------------------------------------------------------
*/
declare 
solicitud_exportacion_importacion json;

BEGIN	

 select     json_build_object(
'solicitud',json_build_object(
'id_solicitud',sol.id_solicitud ,
     'fecha_solicitud',sol.fecha_solicitud ,
     'identificador_operador',sol.identificador_operador, 
     'tipo_solicitud',sol.tipo_solicitud ,
     'nombre_propietario',sol.nombre_propietario ,
     'identificador_propietario',sol.identificador_propietario, 
     'direccion_propietario',sol.direccion_propietario ,
     'nombre_destinatario',sol.nombre_destinatario ,
     'direccion_destinatario',sol.direccion_destinatario, 
     'id_localizacion_origen_destino',sol.id_localizacion_origen_destino ,
     'pais_origen_destino',sol.pais_origen_destino ,
     'id_uso',sol.id_uso ,
     'nombre_uso',sol.nombre_uso ,
     'id_puerto',sol.id_puerto ,
     'nombre_puerto',sol.nombre_puerto ,
     'direccion_ecuador',sol.direccion_ecuador ,
     'fecha_embarque',sol.fecha_embarque ,
     'id_lugar_control',sol.id_lugar_control, 
     'puesto_control',sol.puesto_control ,
     'id_pronvincia_control',sol.id_pronvincia_control ,
     'nombre_provincia_control',sol.nombre_provincia_control ,
     'id_medios_transporte',sol.id_medios_transporte ,
	 'estado',sol.estado,
     'observacion',sol.observacion ,
     'tipo_identificacion_propietario',sol.tipo_identificacion_propietario ,
     'telefono_propietario',sol.telefono_propietario,
     'correo_propietario',sol.correo_propietario ,
     'id_oficina_atencion',sol.id_oficina_atencion ,
	 'nombre_oficina_atencion',ofi_atencion.nombre_oficina_atencion ,
     'temperatura_mascota',sol.temperatura_mascota ,
     'frecuencia_cardiaca',sol.frecuencia_cardiaca, 
     'frecuencia_respiratoria',sol.frecuencia_respiratoria ,
     'gusano_barrenador',sol.gusano_barrenador ,
     'parasito_externo',sol.parasito_externo ,
     'verificacion_edad',sol.verificacion_edad ,
     'fecha_valoracion_clinica',sol.fecha_valoracion_clinica ,
     'fecha_toma_muestras_anticuerpos',sol.fecha_toma_muestras_anticuerpos ,
     'fecha_resultados_anticuerpo',sol.fecha_resultados_anticuerpo ,
     'resultado_anticuerpos',sol.resultado_anticuerpos ,
     'cze_envio_muestra',sol.cze_envio_muestra ,
     'id_localizacion_transito',sol.id_localizacion_transito ,
     'nombre_pais_transito',sol.nombre_pais_transito ,
     'observacion_informacion_solicitud',sol.observacion_informacion_solicitud,
     'ruta_orden_pago',ord_p.orden_pago,
     'ruta_factura',ord_p.comprobante_factura
),
'mascotas', (
    SELECT JSON_AGG(
        JSON_BUILD_OBJECT(
 	'id_producto_solicitud',sol_prod.id_producto_solicitud ,
	'id_tipo_producto',sol_prod.id_tipo_producto,
     'nombre_tipo',sol_prod.nombre_tipo ,
     'id_subtipo_producto',sol_prod.id_subtipo_producto ,
     'nombre_subtipo',sol_prod.nombre_subtipo ,
    'id_producto', sol_prod.id_producto ,
    'nombre_producto', sol_prod.nombre_producto ,
    'sexo', sol_prod.sexo ,
    'raza', sol_prod.raza ,
    'edad', sol_prod.edad ,
    'color', sol_prod.color ,
    'identificacion_producto', sol_prod.identificacion_producto ,
    'nombre_mascota', sol_prod.nombre_mascota ,
    'peso_mascota', sol_prod.peso_mascota,
    'numero_chip', sol_prod.numero_chip ,
    'fecha_aplicacion_chip', sol_prod.fecha_aplicacion_chip ,
   'esterilizado',  sol_prod.esterilizado ,
    'fecha_esterilizacion', sol_prod.fecha_esterilizacion 
        )
    ) AS mascotas
    FROM g_mercancias_valor_comercial.producto_solicitudes sol_prod
    WHERE sol_prod.id_solicitud = sol.id_solicitud
),
'documentos', (
    SELECT JSON_AGG(
        JSON_BUILD_OBJECT(
            'id_documento', sol_doc.id_documento,
            'ruta_vacuna', sol_doc.ruta_vacuna,
            'ruta_veterinario', sol_doc.ruta_veterinario,
            'ruta_anticuerpo', sol_doc.ruta_anticuerpo,
            'ruta_zoosanitario', sol_doc.ruta_zoosanitario,
            'ruta_autorizacion_min_ambiente', sol_doc.ruta_autorizacion_min_ambiente,
            'ruta_zoosanitario_exp', sol_doc.ruta_zoosanitario_exp,
            'ruta_comprobante_veterinario', sol_doc.ruta_comprobante_veterinario
        )
    ) AS documentos
    FROM g_mercancias_valor_comercial.documentos_adjuntos sol_doc
    WHERE sol_doc.id_solicitud = sol.id_solicitud
),
'vacunas', (
 SELECT jsonb_agg(
               jsonb_build_object(
  		'id_vacuna_desparasitacion',vac_des.id_vacuna_desparasitacion ,
      'enfermedad',vac_des.enfermedad ,
      'nombre_vacuna',vac_des.nombre_vacuna,
     'fecha_vacunacion', vac_des.fecha_vacunacion ,
      'fecha_revacunacion',vac_des.fecha_revacunacion ,
      'fecha_expiracion_farmaco',vac_des.fecha_expiracion_farmaco ,
      'lote',vac_des.lote ,
      'numero_registro',vac_des.numero_registro ,
      'laboratorio',vac_des.laboratorio ,
      'tipo_registro',vac_des.tipo_registro ,
     'tipo_desparasitacion', vac_des.tipo_desparasitacion ,
     'fecha_aplicacion_desparasitacion',vac_des.fecha_aplicacion_desparasitacion ,
      'hora_aplicacion_desparasitante',vac_des.hora_aplicacion_desparasitante ,
      'nombre_comercial',vac_des.nombre_comercial ,
      'fabricante_producto',vac_des.fabricante_producto ,
      'principio_activo',vac_des.principio_activo ,
      'dosis_aplicada',vac_des.dosis_aplicada 
                    )
                )
                FROM g_mercancias_valor_comercial.vacunas_deparasitacion vac_des
                WHERE vac_des.tipo_registro = 0 AND vac_des.id_producto_solicitud = sol_prod.id_producto_solicitud
            ),

'desparasitacion', (
 SELECT jsonb_agg(
               jsonb_build_object(
  		'id_vacuna_desparasitacion',vac_des.id_vacuna_desparasitacion ,
      'enfermedad',vac_des.enfermedad ,
      'nombre_vacuna',vac_des.nombre_vacuna,
     'fecha_vacunacion', vac_des.fecha_vacunacion ,
      'fecha_revacunacion',vac_des.fecha_revacunacion ,
      'fecha_expiracion_farmaco',vac_des.fecha_expiracion_farmaco ,
      'lote',vac_des.lote ,
      'numero_registro',vac_des.numero_registro ,
      'laboratorio',vac_des.laboratorio ,
      'tipo_registro',vac_des.tipo_registro ,
     'tipo_desparasitacion', vac_des.tipo_desparasitacion ,
     'fecha_aplicacion_desparasitacion',vac_des.fecha_aplicacion_desparasitacion ,
      'hora_aplicacion_desparasitante',vac_des.hora_aplicacion_desparasitante ,
      'nombre_comercial',vac_des.nombre_comercial ,
      'fabricante_producto',vac_des.fabricante_producto ,
      'principio_activo',vac_des.principio_activo ,
      'dosis_aplicada',vac_des.dosis_aplicada 
                    )
                )
                FROM g_mercancias_valor_comercial.vacunas_deparasitacion vac_des
                WHERE vac_des.tipo_registro = 1 AND vac_des.id_producto_solicitud = sol_prod.id_producto_solicitud
            )

)into solicitud_exportacion_importacion 
	from g_mercancias_valor_comercial.solicitudes sol
	inner join g_mercancias_valor_comercial.producto_solicitudes sol_prod on 
	sol.id_solicitud = sol_prod.id_solicitud inner join 
g_mercancias_valor_comercial.documentos_adjuntos sol_doc on sol.id_solicitud = sol_doc.id_solicitud
inner join g_mercancias_valor_comercial.vacunas_deparasitacion vac_des on sol_prod.id_producto_solicitud=vac_des.id_producto_solicitud
inner join g_catalogos.oficina_atencion ofi_atencion on sol.id_oficina_atencion = ofi_atencion.id_oficina_atencion
left join g_financiero.orden_pago ord_p on sol.id_solicitud::integer=ord_p.id_solicitud::integer 
AND ord_p.tipo_solicitud='certificadoZooExportacion' AND ord_p.metodo_pago='saldo'
where sol.id_solicitud=$1 
group by sol.id_solicitud,
sol_prod.id_producto_solicitud,
ord_p.orden_pago,
ord_p.comprobante_factura,
ofi_atencion.id_oficina_atencion;
return solicitud_exportacion_importacion;
END;
$$;

alter function fs_registros_impo_expor_mercancias_snvalor_comercial(integer) owner to postgres;

