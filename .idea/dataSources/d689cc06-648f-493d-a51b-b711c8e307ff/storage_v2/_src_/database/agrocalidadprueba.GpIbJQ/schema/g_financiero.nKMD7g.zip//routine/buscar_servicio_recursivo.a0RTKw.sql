create function buscar_servicio_recursivo(_id integer) returns SETOF g_financiero.servicios_recursivo
    language plpgsql
as
$$
declare resultado record;
         hijo record;
         temp record;
 begin
  select into resultado id_servicio, concepto, codigo, id_categoria_servicio, valor, iva, unidad_medida, subsidio from g_financiero.servicios where id_servicio = $1 and estado = 'activo';
  if found then
    return next resultado;
    for hijo in select id_servicio from g_financiero.servicios where id_servicio_padre = $1 and estado = 'activo'
      loop
        for temp in select id_servicio, concepto, codigo, id_categoria_servicio, valor, iva, unidad_medida, subsidio from g_financiero.buscar_servicio_recursivo(hijo.id_servicio)
        loop
          return next temp;
        end loop;
      end loop;
  end if;
  return ;
end;
$$;

alter function buscar_servicio_recursivo(integer) owner to postgres;

