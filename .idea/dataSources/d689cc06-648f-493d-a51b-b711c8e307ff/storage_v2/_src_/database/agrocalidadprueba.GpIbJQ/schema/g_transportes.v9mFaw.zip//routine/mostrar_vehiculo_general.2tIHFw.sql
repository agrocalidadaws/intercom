create function mostrar_vehiculo_general(_placa text, _localizacion text, _cantidad integer) returns SETOF g_transportes.vehiculo_registrado
    language plpgsql
as
$$
DECLARE
	query text;
BEGIN	
	return query EXECUTE '
			SELECT 
				kilometraje_actual,
				placa,
				localizacion,
				marca,
				modelo
			FROM 
				g_transportes.vehiculos
			WHERE
				($1 is NULL or placa like $1) and 
				($2 is NULL or $2 = localizacion) and
				estado != 9
			ORDER BY kilometraje_actual desc
			LIMIT $3'
			
		using _placa,_localizacion,_cantidad;
	
END;
$$;

alter function mostrar_vehiculo_general(text, text, integer) owner to postgres;

