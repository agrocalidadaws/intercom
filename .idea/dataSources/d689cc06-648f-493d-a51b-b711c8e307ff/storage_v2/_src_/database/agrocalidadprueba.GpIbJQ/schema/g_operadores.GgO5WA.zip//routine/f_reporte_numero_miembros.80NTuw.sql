create function f_reporte_numero_miembros()
    returns TABLE(identificador character varying, nombre_razon_social character varying, representante_legal text, codigo_poa character varying, tipo_operador character varying, numero_miembros bigint)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT
        o.identificador,
        CASE 
            WHEN o.razon_social = '' THEN o.nombre_representante || ' ' || o.apellido_representante 
            ELSE o.razon_social 
        END AS nombre_razon_social,
        o.apellido_representante || ' ' || o.nombre_representante AS representante_legal,
        cp.codigo_poa,
        o.tipo_actividad AS tipo_operador,
        COUNT(DISTINCT identificador_miembro_asociacion) AS numero_miembros
    FROM g_operadores.operaciones op
    INNER JOIN g_operadores.productos_areas_operacion pao ON op.id_operacion = pao.id_operacion
    INNER JOIN g_operadores.areas a ON pao.id_area = a.id_area
    INNER JOIN g_operadores.sitios s ON a.id_sitio = s.id_sitio
    INNER JOIN g_operadores.operadores o ON op.identificador_operador = o.identificador
    INNER JOIN g_catalogos.tipos_operacion t ON t.id_tipo_operacion = op.id_tipo_operacion 
        AND t.id_area || '-' || t.codigo IN ('AI-PRO', 'AI-PRC', 'AI-COM', 'AI-REC')
    LEFT JOIN g_operadores.codigos_poa cp ON op.identificador_operador = cp.identificador_operador
    LEFT JOIN (
        SELECT dma.id_area, ma.identificador_miembro_asociacion 
        FROM g_operadores.miembros_asociacion ma 
        INNER JOIN g_operadores.detalle_miembros_asociacion dma ON ma.id_miembro_asociacion = dma.id_miembro_asociacion
    ) AS tma ON a.id_area = tma.id_area
    GROUP BY 1,2,3,4
    ORDER BY 1 DESC;
END;
$$;

alter function f_reporte_numero_miembros() owner to postgres;

