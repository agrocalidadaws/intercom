create function notificar_tramite() returns trigger
    language plpgsql
as
$$
DECLARE
    vcorreo character varying;
    vcoordinacion character varying;
    vdireccion character varying;
    vtramite character varying;
    vasuntoproducto character varying;
    vid_correo integer;
    vasunto character varying;
    vcuerpo character varying;
BEGIN
    -- Obtener el correo del operador
    SELECT correo 
    INTO vcorreo 
    FROM g_operadores.operadores 
    WHERE identificador = NEW.identificador_operador;
    
    -- Obtener los datos adicionales del trámite
    SELECT 
        co.nombre AS nombre_coordinaciones_distritales,
        di.nombre AS nombre_direcciones_oficinas,
        ca.tramite AS nombre_catalogo,
        tr.asunto_producto
    INTO vcoordinacion, vdireccion, vtramite, vasuntoproducto
    FROM 
        g_tramites.tramite tr
    INNER JOIN g_tramites.catalogo ca ON tr.id_catalogo = ca.id_catalogo
    INNER JOIN (SELECT id_area, nombre FROM g_estructura.area WHERE estado = 1 AND categoria_area > 2) co ON tr.coordinaciones_distritales = co.id_area
    INNER JOIN (SELECT id_area, nombre FROM g_estructura.area WHERE estado = 1 AND categoria_area > 2) di ON tr.direcciones_oficinas = di.id_area
    LEFT JOIN (SELECT id_area, nombre FROM g_estructura.area WHERE estado = 1 AND categoria_area > 2 ) gu ON tr.gestiones_unidades = gu.id_area
    LEFT JOIN g_uath.ficha_empleado fe ON tr.identificador_tecnico = fe.identificador 
    WHERE tr.id_tramite = NEW.id_tramite;

    -- Construir el asunto del correo
    vasunto := 'Notificación del trámite Nro. ' || NEW.numero_tramite;

    -- Construir el cuerpo del correo
    vcuerpo := '<tr>' ||
               '<td style="font-family:"Text Me One", "Segoe UI", "Tahoma", "Helvetica", "freesans", "sans-serif"; padding-top:25px; font-size:14px; color:#2a2a2a; width: 80%; text-align:justify;">' ||
                   'Estimado usuario, <br><br>' ||
                   'Por medio de la presente se comunica que su trámite Nro. <font color="green">' || NEW.numero_tramite || '</font> se encuentra en el estado <font color="blue">"' || NEW.estado || '"</font>.<br><br>' ||
                   'Coordinación: ' || vcoordinacion ||'<br>' ||
                   'Dirección: ' || vdireccion ||'<br>' ||
                   'Tipo de trámite: ' || vtramite || '<br>' ||
                   'Asunto/producto: ' || vasuntoproducto || '<br><br>' ||
                   'Por favor ingresar a su perfil del Sistema GUIA y revisar con mejor detalle su trámite.<br><br>' ||
                   'NOTA: Este correo fue generado automáticamente por el sistema GUIA, por favor no responder a este mensaje.<br><br>' ||
                   'Saludos Cordiales.' ||
               '</td>' ||
               '</tr>';

    -- Insertar el correo en la tabla g_correos.correos
    INSERT INTO g_correos.correos (asunto, cuerpo, estado, codigo_modulo, tabla_modulo, id_solicitud_tabla)
    VALUES (vasunto, vcuerpo, 'Por enviar', 'PRG_INGR_TRAM', 'g_tramites.tramite', NEW.id_tramite)
    RETURNING id_correo INTO vid_correo;

    -- Insertar el destinatario en la tabla g_correos.destinatarios
    INSERT INTO g_correos.destinatarios (id_correo, destinatario_correo)
    VALUES (vid_correo, vcorreo);

    RETURN NEW;
END;
$$;

alter function notificar_tramite() owner to postgres;

