create function procedimiento_actualizar_cantidad_suero() returns trigger
    language plpgsql
as
$$ 
BEGIN
	IF (TG_OP = 'UPDATE') THEN
		PERFORM g_movilizacion_suero.funcion_actualizar_cantidad_suero(NEW.cantidad_suero_utilizado, OLD.cantidad_suero_restante, OLD.id_detalle_consumo_suero, NEW.id_movilizacion);	
	END IF;
	RETURN NEW;
	END; 
	
$$;

alter function procedimiento_actualizar_cantidad_suero() owner to postgres;

