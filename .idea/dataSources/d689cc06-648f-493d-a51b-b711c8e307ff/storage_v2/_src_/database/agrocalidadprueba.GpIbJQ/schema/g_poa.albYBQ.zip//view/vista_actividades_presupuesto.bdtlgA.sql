create view vista_actividades_presupuesto
            (id_area, area, objetivo, id_objetivo, proceso, id_proceso, subproceso, id_subproceso, actividad,
             id_actividad, identificar_usuario, nombre, apellido, id_item, anio)
as
SELECT a.id_area,
       a.nombre       AS area,
       o.descripcion  AS objetivo,
       o.id_objetivo,
       p.descripcion  AS proceso,
       p.id_proceso,
       s.descripcion  AS subproceso,
       s.id_subproceso,
       ac.descripcion AS actividad,
       ac.id_actividad,
       pl.identificar_usuario,
       fe.nombre,
       fe.apellido,
       pl.id_item,
       pl.anio
FROM g_poa.planta pl,
     g_estructura.funcionarios f,
     g_estructura.area a,
     g_poa.procesos p,
     g_poa.subprocesos s,
     g_poa.objetivos_estrategicos o,
     g_poa.actividades ac,
     g_uath.ficha_empleado fe
WHERE pl.identificar_usuario::text = f.identificador::text
  AND f.id_area::text = a.id_area::text
  AND pl.estado = 4
  AND pl.id_proceso = p.id_proceso
  AND pl.id_subproceso = s.id_subproceso
  AND pl.id_objetivo = o.id_objetivo
  AND pl.id_actividad = ac.id_actividad
  AND (pl.id_item IN (SELECT DISTINCT mp.id_item_planta
                      FROM g_poa.matriz_presupuesto mp
                      WHERE NOT (mp.id_item_planta IN (SELECT DISTINCT mpo.id_item_poa
                                                       FROM g_poa.matriz_poa mpo
                                                       ORDER BY mpo.id_item_poa))
                      ORDER BY mp.id_item_planta))
  AND fe.identificador::text = pl.identificar_usuario::text;

alter table vista_actividades_presupuesto
    owner to postgres;

