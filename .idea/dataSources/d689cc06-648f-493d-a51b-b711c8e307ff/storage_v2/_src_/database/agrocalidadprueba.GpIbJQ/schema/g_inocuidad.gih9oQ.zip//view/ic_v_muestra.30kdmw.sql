create view ic_v_muestra
            (provincia, canton, parroquia, origen_muestra, empresa, finca, pais_procedencia, tecnico_responsable,
             tipo_muestra, fecha_muestreo, codigo_muestras, canton_id, parroquia_id, tipo_empresa, finca_id, utm_x,
             utm_y, registro_importador, permiso_fitosanitario, tecnico_id, ic_resultado_decision_id, activo, estado,
             provincia_id, origen_muestra_id, nombre_rep_legal, pais_procedencia_id, tipo_muestra_id,
             ic_requerimiento_id, ic_muestra_id, ultimo_insumo, tecnica, medio, fecha_envio_lab, cantidad_muestras_lab,
             cantidad_contra_muestra, ultimo_insumo_aplicado_id, produccion_estimada, fecha_ultima_aplicacion,
             tecnica_muestreo, medio_refrigeracion, observaciones, nombre_establecimiento, certificacion_zoosanitario,
             razon_social_importador, pais_origen, direccion_establecimiento, certificacion_sanitaria)
as
SELECT (SELECT loc.nombre
        FROM g_catalogos.localizacion loc
        WHERE loc.id_localizacion::numeric = ic_muestra.provincia_id)                 AS provincia,
       (SELECT loc.nombre
        FROM g_catalogos.localizacion loc
        WHERE loc.id_localizacion::numeric = ic_muestra.canton_id)                    AS canton,
       (SELECT loc.nombre
        FROM g_catalogos.localizacion loc
        WHERE loc.id_localizacion::numeric = ic_muestra.parroquia_id)                 AS parroquia,
       g_inocuidad.nombre_catalogo(ic_muestra.origen_muestra_id)                      AS origen_muestra,
       CASE
           WHEN ic_muestra.tipo_empresa::text = 'IM'::text THEN 'Importación'::text
           ELSE 'Nacional'::text
           END                                                                        AS empresa,
       (SELECT (sitios.nombre_lugar::text || ' - '::text) || sitios.referencia::text
        FROM g_operadores.sitios
        WHERE ic_muestra.finca_id = sitios.id_sitio::numeric)                         AS finca,
       (SELECT loc.nombre
        FROM g_catalogos.localizacion loc
        WHERE loc.id_localizacion::numeric = ic_muestra.pais_procedencia_id)          AS pais_procedencia,
       (SELECT (op.apellido::text || ' '::text) || op.nombre::text
        FROM g_uath.ficha_empleado op
        WHERE op.identificador::text = ic_muestra.tecnico_id::text)                   AS tecnico_responsable,
       g_inocuidad.nombre_catalogo(ic_muestra.tipo_muestra_id)                        AS tipo_muestra,
       ic_muestra.fecha_muestreo,
       ic_muestra.codigo_muestras,
       ic_muestra.canton_id,
       ic_muestra.parroquia_id,
       ic_muestra.tipo_empresa,
       ic_muestra.finca_id,
       ic_muestra.utm_x,
       ic_muestra.utm_y,
       ic_muestra.registro_importador,
       ic_muestra.permiso_fitosanitario,
       ic_muestra.tecnico_id,
       ic_muestra.ic_resultado_decision_id,
       ic_muestra.activo,
       ic_muestra.estado,
       ic_muestra.provincia_id,
       ic_muestra.origen_muestra_id,
       ic_muestra.nombre_rep_legal,
       ic_muestra.pais_procedencia_id,
       ic_muestra.tipo_muestra_id,
       ic_muestra.ic_requerimiento_id,
       ic_muestra.ic_muestra_id,
       (SELECT ic_insumo.nombre
        FROM g_inocuidad.ic_insumo
        WHERE ic_insumo.ic_insumo_id::numeric = ic_muestra.ultimo_insumo_aplicado_id) AS ultimo_insumo,
       g_inocuidad.nombre_catalogo(ic_muestra.tecnica_muestreo::numeric)              AS tecnica,
       g_inocuidad.nombre_catalogo(ic_muestra.medio_refrigeracion::numeric)           AS medio,
       ic_muestra.fecha_envio_lab,
       ic_muestra.cantidad_muestras_lab,
       ic_muestra.cantidad_contra_muestra,
       ic_muestra.ultimo_insumo_aplicado_id,
       ic_muestra.produccion_estimada,
       ic_muestra.fecha_ultima_aplicacion,
       ic_muestra.tecnica_muestreo,
       ic_muestra.medio_refrigeracion,
       ic_muestra.observaciones,
       ic_muestra.nombre_establecimiento,
       ic_muestra.certificacion_zoosanitario,
       ic_muestra.razon_social_importador,
       ic_muestra.pais_origen,
       ic_muestra.direccion_establecimiento,
       ic_muestra.certificacion_sanitaria
FROM g_inocuidad.ic_muestra;

alter table ic_v_muestra
    owner to postgres;

