create function f_transaccion_cupo_movilizacion(p_id_sitio integer, p_id_area integer, p_id_producto integer, p_id_unidad_medida integer, p_lote text, p_cupo_asignado double precision, p_cupo_adicional double precision, p_anio_asignacion_cupo integer, p_identificador_responsable text, p_tipo_transaccion_cupo integer, p_id_asignacion_cupo integer) returns jsonb
    language plpgsql
as
$$

DECLARE

--Variables--
v_nombre_responsable text;
v_estado_asignacion_cupo text;
v_cantidad_ingreso_cupo double precision;
v_cantidad_egreso_cupo double precision;
v_cantidad_total_cupo double precision;
v_id_tabla_origen integer;
v_tabla_origen text;
v_cupo_disponible double precision;
v_id_asignacion_cupo integer;
v_tipo_transaccion_cupo_auxiliar integer;

--Bandera--
bandera_asignacion_cupo boolean := false;

--Retorno--
resultado text := 'fallo';
mensaje text;

BEGIN

    IF (p_tipo_transaccion_cupo = 1 OR p_tipo_transaccion_cupo = 2 OR p_tipo_transaccion_cupo = 5 OR p_tipo_transaccion_cupo = 7 OR p_tipo_transaccion_cupo = 8) THEN

        SELECT 
            nombre || ' ' || apellido AS nombre
        FROM
            g_uath.ficha_empleado fe
        INNER JOIN g_uath.datos_contrato dc ON dc.identificador = fe.identificador
        WHERE
            dc.estado = 1 
        AND fe.identificador = p_identificador_responsable INTO v_nombre_responsable;

    ELSIF (p_tipo_transaccion_cupo = 3 OR p_tipo_transaccion_cupo = 4) THEN

        SELECT 
            nombre || ' ' || apellido AS nombre
        FROM
            g_uath.ficha_empleado fe
        INNER JOIN g_uath.datos_contrato dc ON dc.identificador = fe.identificador
        WHERE
            dc.estado = 1 
        AND fe.identificador = p_identificador_responsable
        UNION
        SELECT
            CASE WHEN razon_social = '' THEN nombre_representante ||' '|| apellido_representante ELSE razon_social END nombre
        FROM
            g_operadores.operadores
        WHERE
            identificador = p_identificador_responsable	INTO v_nombre_responsable;							

    END IF;

    IF (p_tipo_transaccion_cupo = 1) THEN --1. Ingreso - Asignacion de cupo

        --RAISE NOTICE '%', 'GUARDAR';

        v_estado_asignacion_cupo := 'Activo';
        v_tabla_origen := 'g_movilizacion_vegetal.asignacion_cupo';

        v_cantidad_ingreso_cupo := p_cupo_asignado;
        v_cantidad_egreso_cupo := 0;
        v_cantidad_total_cupo := p_cupo_asignado;

        PERFORM 
            id_asignacion_cupo
        FROM 
            g_movilizacion_vegetal.asignacion_cupo 
        WHERE 
            id_area = p_id_area 
            AND id_producto = p_id_producto
            AND anio_asignacion_cupo = p_anio_asignacion_cupo
            AND estado_asignacion_cupo = 'Activo' FOR UPDATE;

        IF NOT FOUND THEN

            PERFORM 
                id_asignacion_cupo
            FROM 
                g_movilizacion_vegetal.asignacion_cupo 
            WHERE 
                id_area = p_id_area 
                AND id_producto = p_id_producto
                AND estado_asignacion_cupo = 'Activo' FOR UPDATE;

            IF NOT FOUND THEN	

                    INSERT INTO g_movilizacion_vegetal.asignacion_cupo(
                                id_sitio, id_area, id_producto, id_unidad_medida, lote, cupo_asignado, cupo_disponible
                                , anio_asignacion_cupo, estado_asignacion_cupo, identificador_responsable)
                                VALUES (p_id_sitio, p_id_area, p_id_producto, p_id_unidad_medida, p_lote, p_cupo_asignado, p_cupo_asignado
                                , p_anio_asignacion_cupo, v_estado_asignacion_cupo, p_identificador_responsable) RETURNING id_asignacion_cupo INTO v_id_tabla_origen;

                    v_id_asignacion_cupo := v_id_tabla_origen;

                    bandera_asignacion_cupo := true;

                    mensaje := 'Los datos fueron registrados con éxito.';

            ELSE

                mensaje := 'Ya se realizó una asignación de cupo para el área y producto seleccionado, solicite inactivación.';

            END IF;

        ELSE

            SELECT 
                id_asignacion_cupo
            FROM 
                g_movilizacion_vegetal.asignacion_cupo 
            WHERE 
                id_area = p_id_area 
                AND id_producto = p_id_producto
                AND anio_asignacion_cupo = p_anio_asignacion_cupo
                AND estado_asignacion_cupo = 'Activo' 
                AND cupo_asignado = 0 FOR UPDATE INTO v_id_asignacion_cupo;

            IF FOUND THEN

                v_id_tabla_origen := v_id_asignacion_cupo;

                UPDATE 
                    g_movilizacion_vegetal.asignacion_cupo
                SET 
                        cupo_disponible = ROUND(CAST((cupo_disponible + v_cantidad_ingreso_cupo) AS NUMERIC), 2)
                        , fecha_actualizacion = now()
                        , cupo_asignado = v_cantidad_ingreso_cupo
                WHERE 
                    id_asignacion_cupo = v_id_asignacion_cupo RETURNING cupo_disponible INTO v_cupo_disponible;

                    v_cantidad_total_cupo = v_cupo_disponible;

                    bandera_asignacion_cupo := true;

                    mensaje := 'Los datos fueron actualizados con éxito.';

            ELSE

                mensaje := 'Ya se realizó una asignación de cupo para el área y producto seleccionado en el año actual.';

            END IF;

        END IF;

    ELSIF (p_tipo_transaccion_cupo = 2) THEN --2. Ingreso - Cupo adicional

        v_tabla_origen := 'g_movilizacion_vegetal.asignacion_cupo';	

        v_cantidad_ingreso_cupo := p_cupo_adicional;
        v_cantidad_egreso_cupo := 0;			
        v_id_tabla_origen := p_id_asignacion_cupo;
        v_id_asignacion_cupo := v_id_tabla_origen;

        PERFORM 
            id_asignacion_cupo
        FROM 
            g_movilizacion_vegetal.asignacion_cupo 
        WHERE 
            id_asignacion_cupo = v_id_tabla_origen FOR UPDATE;

        UPDATE 
            g_movilizacion_vegetal.asignacion_cupo
        SET 
            cupo_disponible = ROUND(CAST((cupo_disponible + p_cupo_adicional) AS NUMERIC), 2)
            , fecha_actualizacion = now()
        WHERE id_asignacion_cupo = v_id_tabla_origen RETURNING cupo_disponible INTO v_cupo_disponible;

        v_cantidad_total_cupo = v_cupo_disponible;

        bandera_asignacion_cupo := true;

        mensaje := 'Los datos fueron actualizados con éxito.';

    ELSIF (p_tipo_transaccion_cupo = 3) THEN --3. Egreso - Emision de permiso

        v_tabla_origen := 'g_movilizacion_vegetal.movilizacion';						

        v_cantidad_ingreso_cupo := 0;
        v_cantidad_egreso_cupo := p_cupo_asignado;			
        v_id_tabla_origen := p_id_asignacion_cupo;

        SELECT 
            id_asignacion_cupo
        FROM 
            g_movilizacion_vegetal.asignacion_cupo 
        WHERE 
            id_area = p_id_area 
            AND id_producto = p_id_producto
            AND anio_asignacion_cupo = p_anio_asignacion_cupo
            AND estado_asignacion_cupo = 'Activo' FOR UPDATE INTO v_id_asignacion_cupo;

        UPDATE 
            g_movilizacion_vegetal.asignacion_cupo
        SET 
            cupo_disponible = ROUND(CAST((cupo_disponible - v_cantidad_egreso_cupo) AS NUMERIC), 2)
            , fecha_actualizacion = now()
        WHERE id_asignacion_cupo = v_id_asignacion_cupo RETURNING cupo_disponible INTO v_cupo_disponible;

        v_cantidad_total_cupo = v_cupo_disponible;

        bandera_asignacion_cupo := true;

        mensaje := 'Los datos fueron actualizados con éxito.';

    ELSIF (p_tipo_transaccion_cupo = 4) THEN --4. Ingreso - Recepción de producto

        SELECT 
            id_asignacion_cupo
        FROM 
            g_movilizacion_vegetal.asignacion_cupo 
        WHERE 
            id_area = p_id_area 
            AND id_producto = p_id_producto
            AND anio_asignacion_cupo = p_anio_asignacion_cupo
            AND estado_asignacion_cupo = 'Activo' FOR UPDATE INTO v_id_asignacion_cupo;

        IF NOT FOUND THEN

            v_estado_asignacion_cupo := 'Activo';
            v_tabla_origen := 'g_movilizacion_vegetal.asignacion_cupo';

            v_cantidad_ingreso_cupo := 0;
            v_cantidad_egreso_cupo := 0;
            v_cantidad_total_cupo := 0;						

            PERFORM 
                id_asignacion_cupo
            FROM 
                g_movilizacion_vegetal.asignacion_cupo 
            WHERE 
                id_area = p_id_area 
                AND id_producto = p_id_producto
                AND estado_asignacion_cupo = 'Activo' FOR UPDATE;

            IF NOT FOUND THEN

                    v_tipo_transaccion_cupo_auxiliar := 1;

                    INSERT INTO g_movilizacion_vegetal.asignacion_cupo(
                                id_sitio, id_area, id_producto, id_unidad_medida, lote, cupo_asignado, cupo_disponible
                                , anio_asignacion_cupo, estado_asignacion_cupo, identificador_responsable)
                                VALUES (p_id_sitio, p_id_area, p_id_producto, p_id_unidad_medida, p_lote, v_cantidad_ingreso_cupo, p_cupo_asignado
                                , p_anio_asignacion_cupo, v_estado_asignacion_cupo, p_identificador_responsable) RETURNING id_asignacion_cupo INTO v_id_tabla_origen;

                    v_id_asignacion_cupo := v_id_tabla_origen;

                    INSERT INTO 
                        g_movilizacion_vegetal.transaccion_cupo_movilizacion(
                        id_asignacion_cupo, id_tabla_origen, tabla_origen, cantidad_ingreso_cupo, cantidad_egreso_cupo, cantidad_total_cupo, tipo_transaccion_cupo
                        , identificador_responsable, nombre_responsable)
                    VALUES (v_id_asignacion_cupo, v_id_tabla_origen, v_tabla_origen, v_cantidad_ingreso_cupo, v_cantidad_egreso_cupo, v_cantidad_total_cupo, v_tipo_transaccion_cupo_auxiliar
                        , p_identificador_responsable, v_nombre_responsable);

                    bandera_asignacion_cupo := true;

                    mensaje := 'Los datos fueron registrados con éxito.';

                    RAISE NOTICE 'CUPO ASIGNADO';	
                    v_tabla_origen := 'g_movilizacion_vegetal.movilizacion';						

                    v_cantidad_ingreso_cupo := p_cupo_asignado;
                    v_cantidad_egreso_cupo := 0;			
                    v_id_tabla_origen := p_id_asignacion_cupo;

                    UPDATE 
                    g_movilizacion_vegetal.asignacion_cupo
                    SET 
                        cupo_disponible = ROUND(CAST((v_cantidad_ingreso_cupo) AS NUMERIC), 2)
                        , fecha_actualizacion = now()
                    WHERE id_asignacion_cupo = v_id_asignacion_cupo RETURNING cupo_disponible INTO v_cupo_disponible;

                    v_cantidad_total_cupo = v_cupo_disponible;

                    bandera_asignacion_cupo := true;

                    mensaje := 'Los datos fueron actualizados con éxito.';	

            ELSE

                mensaje := 'Ya se realizó una asignación de cupo para el área y producto seleccionado, solicite inactivación.';

            END IF;

        ELSE

            v_tabla_origen := 'g_movilizacion_vegetal.movilizacion';						

            v_cantidad_ingreso_cupo := p_cupo_asignado;
            v_cantidad_egreso_cupo := 0;			
            v_id_tabla_origen := p_id_asignacion_cupo;

            UPDATE 
            g_movilizacion_vegetal.asignacion_cupo
            SET 
                cupo_disponible = ROUND(CAST((cupo_disponible + v_cantidad_ingreso_cupo) AS NUMERIC), 2)
                , fecha_actualizacion = now()
            WHERE id_asignacion_cupo = v_id_asignacion_cupo RETURNING cupo_disponible INTO v_cupo_disponible;

            v_cantidad_total_cupo = v_cupo_disponible;

            bandera_asignacion_cupo := true;

            mensaje := 'Los datos fueron actualizados con éxito.';							

        END IF;						

    ELSIF (p_tipo_transaccion_cupo = 5) THEN --5. Egreso - Eliminacion de cupo

        v_id_tabla_origen := p_id_asignacion_cupo;
        v_id_asignacion_cupo := v_id_tabla_origen;

        PERFORM 
        COUNT(DISTINCT tabla_origen)
        FROM g_movilizacion_vegetal.transaccion_cupo_movilizacion
        WHERE
        id_asignacion_cupo = v_id_tabla_origen AND tipo_transaccion_cupo NOT IN (4,8)
        HAVING 
        COUNT(DISTINCT tabla_origen) = 1;

        IF FOUND THEN

            v_tabla_origen := 'g_movilizacion_vegetal.asignacion_cupo';	

            v_cantidad_ingreso_cupo := 0;			

            SELECT 
                SUM(cantidad_ingreso_cupo) 
            FROM 
                g_movilizacion_vegetal.transaccion_cupo_movilizacion
            WHERE
                id_asignacion_cupo = v_id_tabla_origen INTO v_cantidad_egreso_cupo;

            UPDATE 
                g_movilizacion_vegetal.asignacion_cupo
            SET 
                cupo_disponible = ROUND(CAST((cupo_disponible - v_cantidad_egreso_cupo) AS NUMERIC), 2)
                , estado_asignacion_cupo = 'Inactivo'
                , fecha_actualizacion = now()
            WHERE id_asignacion_cupo = v_id_tabla_origen RETURNING cupo_disponible INTO v_cupo_disponible;

            v_cantidad_total_cupo = v_cupo_disponible;

            bandera_asignacion_cupo := true;

            mensaje := 'Los datos fueron eliminados con éxito.';

        ELSE

            mensaje := 'No se puede eliminar la asignación de cupo';

        END IF;								

    ELSIF (p_tipo_transaccion_cupo = 6) THEN --6. Egreso - Cupo anual caducado

        --El proceso de caducidad de cupo anula es realizado por cron en la funcion g_movilizacion_vegetal.f_caducar_cupo_anual_movilizacion

    ELSIF (p_tipo_transaccion_cupo = 7) THEN --7. Egreso - Permiso anulado

        SELECT 
            id_asignacion_cupo
        FROM 
            g_movilizacion_vegetal.asignacion_cupo 
        WHERE 
            id_area = p_id_area 
            AND id_producto = p_id_producto
            AND anio_asignacion_cupo = p_anio_asignacion_cupo
            AND estado_asignacion_cupo = 'Activo' FOR UPDATE INTO v_id_asignacion_cupo;

        IF NOT FOUND THEN

            v_estado_asignacion_cupo := 'Activo';
            v_tabla_origen := 'g_movilizacion_vegetal.asignacion_cupo';

            v_cantidad_ingreso_cupo := 0;
            v_cantidad_egreso_cupo := 0;
            v_cantidad_total_cupo := 0;						

            PERFORM 
                id_asignacion_cupo
            FROM 
                g_movilizacion_vegetal.asignacion_cupo 
            WHERE 
                id_area = p_id_area 
                AND id_producto = p_id_producto
                AND estado_asignacion_cupo = 'Activo' FOR UPDATE;

            IF NOT FOUND THEN

                    v_tipo_transaccion_cupo_auxiliar := 1;

                    INSERT INTO g_movilizacion_vegetal.asignacion_cupo(
                                id_sitio, id_area, id_producto, id_unidad_medida, lote, cupo_asignado, cupo_disponible
                                , anio_asignacion_cupo, estado_asignacion_cupo, identificador_responsable)
                                VALUES (p_id_sitio, p_id_area, p_id_producto, p_id_unidad_medida, p_lote, v_cantidad_ingreso_cupo, p_cupo_asignado
                                , p_anio_asignacion_cupo, v_estado_asignacion_cupo, p_identificador_responsable) RETURNING id_asignacion_cupo INTO v_id_tabla_origen;

                    v_id_asignacion_cupo := v_id_tabla_origen;

                    INSERT INTO 
                        g_movilizacion_vegetal.transaccion_cupo_movilizacion(
                        id_asignacion_cupo, id_tabla_origen, tabla_origen, cantidad_ingreso_cupo, cantidad_egreso_cupo, cantidad_total_cupo, tipo_transaccion_cupo
                        , identificador_responsable, nombre_responsable)
                    VALUES (v_id_asignacion_cupo, v_id_tabla_origen, v_tabla_origen, v_cantidad_ingreso_cupo, v_cantidad_egreso_cupo, v_cantidad_total_cupo, v_tipo_transaccion_cupo_auxiliar
                        , p_identificador_responsable, v_nombre_responsable);

                    bandera_asignacion_cupo := true;

                    mensaje := 'Los datos fueron registrados con éxito.';

                    RAISE NOTICE 'PRIMER REGISTRO CUPO ASIGNADO ';	

                    v_tabla_origen := 'g_movilizacion_vegetal.fiscalizacion';						

                    v_cantidad_ingreso_cupo := p_cupo_asignado;
                    v_cantidad_egreso_cupo := 0;			
                    v_id_tabla_origen := p_id_asignacion_cupo;

                    UPDATE 
                        g_movilizacion_vegetal.asignacion_cupo
                    SET 
                        cupo_disponible = ROUND(CAST((v_cantidad_ingreso_cupo) AS NUMERIC), 2)
                        , fecha_actualizacion = now()
                    WHERE id_asignacion_cupo = v_id_asignacion_cupo RETURNING cupo_disponible INTO v_cupo_disponible;

                    v_cantidad_total_cupo = v_cupo_disponible;

                    bandera_asignacion_cupo := true;

                    mensaje := 'Los datos fueron actualizados con éxito.';	

            ELSE

                mensaje := 'Ya se realizó una asignación de cupo para el área y producto seleccionado, solicite inactivación.';

            END IF;

        ELSE
            RAISE NOTICE 'YA EXISTE CUPO ASIGNADO - NUEVOCUPO ASIGNADO';	
            v_tabla_origen := 'g_movilizacion_vegetal.fiscalizacion';						

            v_cantidad_ingreso_cupo := 0;
            v_cantidad_egreso_cupo := p_cupo_asignado;			
            v_id_tabla_origen := p_id_asignacion_cupo;

            UPDATE 
            g_movilizacion_vegetal.asignacion_cupo
            SET 
                cupo_disponible = ROUND(CAST((cupo_disponible - v_cantidad_egreso_cupo) AS NUMERIC), 2)
                , fecha_actualizacion = now()
            WHERE id_asignacion_cupo = v_id_asignacion_cupo RETURNING cupo_disponible INTO v_cupo_disponible;

            v_cantidad_total_cupo = v_cupo_disponible;

            bandera_asignacion_cupo := true;

            mensaje := 'Los datos fueron actualizados con éxito.';							

        END IF;		

    ELSIF (p_tipo_transaccion_cupo = 8) THEN --8. Ingreso - Permiso anulado

        v_tabla_origen := 'g_movilizacion_vegetal.fiscalizacion';						

        v_cantidad_ingreso_cupo := p_cupo_asignado;
        v_cantidad_egreso_cupo := 0;			
        v_id_tabla_origen := p_id_asignacion_cupo;

        SELECT 
            id_asignacion_cupo
        FROM 
            g_movilizacion_vegetal.asignacion_cupo 
        WHERE 
            id_area = p_id_area 
            AND id_producto = p_id_producto
            AND anio_asignacion_cupo = p_anio_asignacion_cupo
            AND estado_asignacion_cupo = 'Activo' FOR UPDATE INTO v_id_asignacion_cupo;

        UPDATE 
            g_movilizacion_vegetal.asignacion_cupo
        SET 
            cupo_disponible = ROUND(CAST((cupo_disponible + v_cantidad_ingreso_cupo) AS NUMERIC), 2)
            , fecha_actualizacion = now()
        WHERE id_asignacion_cupo = v_id_asignacion_cupo RETURNING cupo_disponible INTO v_cupo_disponible;

        v_cantidad_total_cupo = v_cupo_disponible;

        bandera_asignacion_cupo := true;

        mensaje := 'Los datos fueron actualizados con éxito.';

    END IF;

    IF (bandera_asignacion_cupo) THEN

        INSERT INTO 
            g_movilizacion_vegetal.transaccion_cupo_movilizacion(
            id_asignacion_cupo, id_tabla_origen, tabla_origen, cantidad_ingreso_cupo, cantidad_egreso_cupo, cantidad_total_cupo, tipo_transaccion_cupo
            , identificador_responsable, nombre_responsable)
        VALUES (v_id_asignacion_cupo, v_id_tabla_origen, v_tabla_origen, v_cantidad_ingreso_cupo, v_cantidad_egreso_cupo, v_cantidad_total_cupo, p_tipo_transaccion_cupo
            , p_identificador_responsable, v_nombre_responsable);

        resultado := 'exito';

    END IF;

    RETURN jsonb_build_object('resultado', resultado, 'mensaje', mensaje, 'id', v_id_tabla_origen);

END	

$$;

alter function f_transaccion_cupo_movilizacion(integer, integer, integer, integer, text, double precision, double precision, integer, text, integer, integer) owner to postgres;

