create function mostrar_documentos_filtrados(_identificador text, _archivo text, _asunto text, _fecha_inicio timestamp without time zone, _fecha_fin timestamp without time zone, _estado integer) returns SETOF g_documentacion.documentos_generados
    language plpgsql
as
$$
DECLARE
	query text;
BEGIN	
	return query EXECUTE '	
		SELECT
			*
		FROM 
			g_documentacion.documentos_generados
		WHERE 
			($1 is NULL or id_documento like $1) and 
			($2 is NULL or asunto like $2) and 
			($3 is NULL or estado = $3) and 
			($4 is NULL or fecha_creacion >= $4) and 
			($5 is NULL or fecha_creacion <= $5) and
			($6 is NULL or $6 = identificador)
		ORDER BY
			fecha_creacion'
		using _archivo,_asunto,_estado,_fecha_inicio,_fecha_fin,_identificador;
	
END;
$$;

alter function mostrar_documentos_filtrados(text, text, text, timestamp, timestamp, integer) owner to postgres;

