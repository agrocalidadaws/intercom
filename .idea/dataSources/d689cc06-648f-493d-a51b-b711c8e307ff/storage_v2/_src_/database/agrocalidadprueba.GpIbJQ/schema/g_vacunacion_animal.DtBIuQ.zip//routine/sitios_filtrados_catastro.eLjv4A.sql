create function sitios_filtrados_catastro(_identificador character varying, _nombre_lugar character varying, _codigo_area text, _estado character varying, _id_area character varying, _codigo_operacion character varying, _nombre_operador character varying) returns SETOF g_vacunacion_animal.sitios_filtrados_catastro
    language plpgsql
as
$$DECLARE
	query text;
BEGIN
	return query EXECUTE '
		select  distinct 
			
			s.id_sitio 
			,o.identificador identificador_operador
			, (o.nombre_representante ||'' ''|| o.apellido_representante)::character varying nombres
			,s.nombre_lugar granja
			, s.provincia
			
		from 
			 g_operadores.operadores o
			, g_operadores.sitios s
			, g_operadores.operaciones op
			, g_catalogos.tipos_operacion t
			, g_operadores.areas a
			,g_operadores.productos_areas_operacion pao
		where 
			o.identificador = op.identificador_operador
			and op.id_tipo_operacion = t.id_tipo_operacion
			and s.id_sitio = a.id_sitio
			and pao.id_area = a.id_area 
			and pao.id_operacion=op.id_operacion
			and ($1 is NULL or o.identificador = $1) 
			and ($2 is NULL or s.nombre_lugar ilike $2) 
			and ($3 is NULL or coalesce( o.identificador || ''.'' || s.codigo_provincia || s.codigo || a.codigo || 

a.secuencial   ) = $3) 
			and ( op.estado = $4) 
			and ( t.id_area = $5)
			and ( t.codigo = $6)
			and ( $7 is NULL or coalesce(o.nombre_representante ||'' ''|| o.apellido_representante ) ilike $7)										
			order by s.nombre_lugar asc
			'
	using  _identificador,_nombre_lugar ,_codigo_area,_estado,_id_area,  _codigo_operacion, _nombre_operador;
END;$$;

alter function sitios_filtrados_catastro(varchar, varchar, text, varchar, varchar, varchar, varchar) owner to postgres;

