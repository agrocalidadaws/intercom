create view ic_v_dashboard
            (nombre_programa, nombre_tipo_requerimiento, fecha_solicitud, estado, usuario, ic_requerimiento_id,
             ic_muestra_id, ic_analisis_muestra_id, ic_evaluacion_analisis_id, ic_evaluacion_comite_id, cancelado,
             motivo_cancelacion, provincia, inspector_id, tecnico_id)
as
SELECT (SELECT ic_catalogo.nombre
        FROM g_inocuidad.ic_catalogo
        WHERE ic_catalogo.ic_catalogo_id::numeric = c.programa_id)                                  AS nombre_programa,
       (SELECT ic_tipo_requerimiento.nombre
        FROM g_inocuidad.ic_tipo_requerimiento
        WHERE ic_tipo_requerimiento.ic_tipo_requerimiento_id =
              c.ic_tipo_requerimiento_id::numeric)                                                  AS nombre_tipo_requerimiento,
       c.fecha_solicitud,
       CASE
           WHEN ec.ic_evaluacion_comite_id IS NOT NULL AND ec.estado::text = 'Y'::text THEN 'Comité'::text
           WHEN ea.ic_evaluacion_analisis_id IS NOT NULL THEN 'Análisis'::text
           WHEN am.ic_analisis_muestra_id IS NOT NULL THEN 'Laboratorio'::text
           WHEN m.ic_muestra_id IS NOT NULL THEN 'Muestra'::text
           ELSE 'Caso'::text
           END                                                                                      AS estado,
       c.usuario_id                                                                                 AS usuario,
       c.ic_requerimiento_id,
       m.ic_muestra_id,
       am.ic_analisis_muestra_id,
       ea.ic_evaluacion_analisis_id,
       ec.ic_evaluacion_comite_id,
       c.cancelado,
       c.motivo_cancelacion,
       CASE
           WHEN c.provincia_id = 0::numeric THEN ('(EXT)'::text || (((SELECT localizacion.nombre
                                                                      FROM g_catalogos.localizacion
                                                                      WHERE localizacion.categoria = 0
                                                                        AND localizacion.id_localizacion::numeric = c.pais_notificacion_id))::text))::character varying
           ELSE (SELECT localizacion.nombre
                 FROM g_catalogos.localizacion
                 WHERE localizacion.categoria = 1
                   AND localizacion.id_localizacion::numeric = c.provincia_id)
           END                                                                                      AS provincia,
       c.inspector_id,
       m.tecnico_id
FROM g_inocuidad.ic_requerimiento c
         LEFT JOIN g_inocuidad.ic_muestra m ON c.ic_requerimiento_id::numeric = m.ic_requerimiento_id::numeric
         LEFT JOIN g_inocuidad.ic_analisis_muestra am ON m.ic_muestra_id::numeric = am.ic_muestra_id::numeric
         LEFT JOIN g_inocuidad.ic_evaluacion_analisis ea ON am.ic_muestra_id = ea.ic_muestra_id AND
                                                            am.ic_analisis_muestra_id::numeric =
                                                            ea.ic_analisis_muestra_id::numeric
         LEFT JOIN g_inocuidad.ic_evaluacion_comite ec
                   ON ec.ic_evaluacion_analisis_id::numeric = ea.ic_evaluacion_analisis_id::numeric
WHERE CASE
          WHEN am.ic_analisis_muestra_id IS NOT NULL THEN am.ic_analisis_muestra_id =
                                                          ((SELECT max(tmp.ic_analisis_muestra_id) AS max
                                                            FROM g_inocuidad.ic_analisis_muestra tmp
                                                            WHERE tmp.ic_muestra_id::numeric = m.ic_muestra_id::numeric))
          ELSE 1 = 1
    END
  AND CASE
          WHEN ec.ic_evaluacion_comite_id IS NOT NULL THEN ec.ic_evaluacion_comite_id =
                                                           ((SELECT max(tmp.ic_evaluacion_comite_id) AS max
                                                             FROM g_inocuidad.ic_evaluacion_comite tmp
                                                             WHERE tmp.ic_evaluacion_analisis_id::numeric =
                                                                   ea.ic_evaluacion_analisis_id::numeric))
          ELSE 1 = 1
    END
ORDER BY c.ic_requerimiento_id DESC;

alter table ic_v_dashboard
    owner to postgres;

