create function insertar_orden_opcion() returns trigger
    language plpgsql
as
$$ 

BEGIN
	NEW.orden = public.calcular_orden_siguiente('g_inspeccion.opciones', 'id_pregunta', NEW.id_pregunta);

	RETURN NEW;
	END; 
	
$$;

alter function insertar_orden_opcion() owner to postgres;

