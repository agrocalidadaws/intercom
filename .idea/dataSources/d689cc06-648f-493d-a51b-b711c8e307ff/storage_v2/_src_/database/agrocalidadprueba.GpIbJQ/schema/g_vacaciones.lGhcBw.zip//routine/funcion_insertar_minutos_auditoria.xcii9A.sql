create function funcion_insertar_minutos_auditoria(_identificador character varying, _minutos_actuales integer, _minutos_disponibles integer, _anio integer, _observacion character varying) returns void
    language plpgsql
as
$$
DECLARE _minutos INTEGER;
BEGIN
	_minutos:= 0;
	_minutos = _minutos_disponibles - _minutos_actuales;
	INSERT INTO g_vacaciones.auditoria_minutos(identificador, minutos_actuales, minutos_disponibles, minutos_agregados, anio, observacion)
		VALUES (_identificador, _minutos_actuales, _minutos_disponibles, _minutos, _anio, _observacion);
		
END;
$$;

alter function funcion_insertar_minutos_auditoria(varchar, integer, integer, integer, varchar) owner to postgres;

