create function funcion_ingreso() returns trigger
    language plpgsql
as
$$
BEGIN
   IF    ((NEW.identificador BETWEEN '0100000000' AND '0599999999') OR (NEW.identificador BETWEEN '0100000000001' AND '0599999999999')) THEN
      INSERT INTO g_auditoria.ingreso_01_05 VALUES (NEW.*);
   ELSIF ((NEW.identificador BETWEEN '0600000000' AND '0999999999') OR (NEW.identificador BETWEEN '0600000000001' AND '0999999999999')) THEN
      INSERT INTO g_auditoria.ingreso_06_09 VALUES (NEW.*);
   ELSIF ((NEW.identificador BETWEEN '1000000000' AND '1699999999') OR (NEW.identificador BETWEEN '1000000000001' AND '1699999999999')) THEN
      INSERT INTO g_auditoria.ingreso_10_16 VALUES (NEW.*);
   ELSIF ((NEW.identificador BETWEEN '1700000000' AND '1799999999') OR (NEW.identificador BETWEEN '1700000000001' AND '1799999999999')) THEN
      INSERT INTO g_auditoria.ingreso_17 VALUES (NEW.*);
   ELSIF ((NEW.identificador BETWEEN '1800000000' AND '2499999999') OR (NEW.identificador BETWEEN '1800000000001' AND '2499999999999')) THEN
      INSERT INTO g_auditoria.ingreso_18_24 VALUES (NEW.*);
   ELSE
      INSERT INTO g_auditoria.ingreso_otros VALUES (NEW.*);
   END IF;
   RETURN NULL;
END;
$$;

alter function funcion_ingreso() owner to postgres;

