create procedure sp_insertar_actividad_manejo_integrado(json_data json, INOUT insertado integer)
    language plpgsql
as
$$
/*
-------------------------------------------------------------------------
--  [f_inspeccion.sp_sert_actividad_manejo_integrado]
--               
--  procedimiento que se encarga de recibir un jsonobject e insertar en diferentes tablas
--
--  VERSION		AUTOR					FECHA			HU			                           
--	1			Kleber Armijos		27-06-2023	 Formulario manejo integrado activida
-------------------------------------------------------------------------
*/
DECLARE
  json_array_object json;
  key_json_array_object text;
  json_actividad_manejo JSON;
  id_manejo_integrado INTEGER;
  json_especie_hospedante JSON;
  json_medidascontrol_fuente_cantidad JSON;
  id_medidacontrol_fuente_cantidad INTEGER;
  json_medidascontrol_insumos JSON;
  no_error BOOLEAN ;
 
BEGIN

 BEGIN   -- inicio transanccion
	  -- se mantiene el principio de los json claves valor
	  no_error:=TRUE;
	  
	  FOR key_json_array_object,json_array_object IN  SELECT * FROM json_each(json_data)
  	  LOOP

		  FOR json_actividad_manejo IN SELECT  json_array_elements(json_array_object)
		  LOOP
		  INSERT INTO f_inspeccion.actividades_manejo_integrado (id_tablet, codigo_provincia,provincia,codigo_canton,canton,codigo_parroquia,parroquia,coordenada_x,
																coordenada_y,coordenada_z,fecha_registro_actividad,usuario_id,usuario,tablet_id,tablet_version_base,
																semana_actual,id_accion_mip,mtd_inicial,id_plaga_objetivo,id_escenario,id_especie_hortofruticola,
																superficie,mtd_final)
			  VALUES ((json_actividad_manejo->>'idTablet')::integer,
				  json_actividad_manejo->>'codigoProvincia',
				 json_actividad_manejo->>'provincia',
				 json_actividad_manejo->>'codigoCanton',
				 json_actividad_manejo->>'canton',
				 json_actividad_manejo->>'codigoParroquia',
				 json_actividad_manejo->>'parroquia',
				 json_actividad_manejo->>'coordenadaX',
				 json_actividad_manejo->>'coordenadaY',
				 json_actividad_manejo->>'coordenadaZ',
				 (json_actividad_manejo->>'fechaRegistroActividad')::timestamp without time zone,
				 json_actividad_manejo->>'usuarioId',
				 json_actividad_manejo->>'usuario',
				 json_actividad_manejo->>'tabletId',
				 json_actividad_manejo->>'tabletVersionBase',
				-- json_actividad_manejo->'actividades_manejo_integrado'->>'fecha_ingreso_guia',
				 (json_actividad_manejo->>'semanaActual')::integer,
				 (json_actividad_manejo->>'idAccionMip')::integer,
				 (json_actividad_manejo->>'mtdInicial')::numeric,
				 (json_actividad_manejo->>'idPlagaObjetivo')::integer,
				 (json_actividad_manejo->>'idEscenario')::integer,
				 (json_actividad_manejo->>'idEspecieHortofruticola')::integer,
				 (json_actividad_manejo->>'superficie')::numeric,
				 (json_actividad_manejo->>'mdtFinal')::numeric
				 )RETURNING id INTO id_manejo_integrado;
				 FOR json_especie_hospedante  IN SELECT *FROM json_array_elements(json_actividad_manejo->'especieHospedanteList')
				LOOP
					INSERT INTO f_inspeccion.actividadmanejointegrado_catalogoespeciehospedante (id_actividad_integrado ,id_catalogo_especie_hospedante)
					 VALUES (id_manejo_integrado,
							 (json_especie_hospedante->>'idCatalogoEspecieHospedante')::INTEGER);
				END LOOP;
				FOR  json_medidascontrol_fuente_cantidad IN SELECT *FROM json_array_elements(json_actividad_manejo->'mcInusmosCantidadFuente')
				LOOP
					INSERT INTO f_inspeccion.actividadmedidascontrol_catalogofuente_cantidad (id_manejo_integrado ,id_manejomedidascontrol_catalogofuente,
																							 id_manejomedidascontrol_catalogo_medidas_control,cantidad_medidas_control
																							 )
					 VALUES (id_manejo_integrado,
							 (json_medidascontrol_fuente_cantidad->>'mcFuente')::INTEGER,
							 (json_medidascontrol_fuente_cantidad->>'idMedidasControl')::INTEGER,
							 (json_medidascontrol_fuente_cantidad->>'mcCantidad')::NUMERIC
							)RETURNING id INTO id_medidacontrol_fuente_cantidad;
					FOR  json_medidascontrol_insumos IN SELECT *FROM json_array_elements(json_medidascontrol_fuente_cantidad->'insumoslista')
					LOOP
						INSERT INTO f_inspeccion.actividadmanejo_mcfc_catalogoinsumoactividad (idactividadintegrado_medidascontrol ,id_catalogo_insumos)
						VALUES (id_medidacontrol_fuente_cantidad,
						 (json_medidascontrol_insumos->>'idCatalogoInsumo')::INTEGER);
				END LOOP;

				END LOOP;

		  END LOOP;

		END LOOP;
		  EXCEPTION
    WHEN others THEN
      -- Rollback the transaction and raise the exception
	  no_error:=FALSE;
	  insertado:=0;
	 -- RAISE NOTICE 'hubo error: %',no_error;
      ROLLBACK;
      RAISE NOTICE 'ALGO SALIO MAL AL INSERTAR DATOS: %', SQLERRM;

  END ;
  	--RAISE NOTICE 'Datos insertados correctamente: %',existe_error;
	IF no_error THEN
		COMMIT;
		insertado:=1;
	   	RAISE NOTICE 'Datos insertados correctamente: %','OK';
 		ELSE
 	 	ROLLBACK   ;
	END IF;
  	
END;
$$;

alter procedure sp_insertar_actividad_manejo_integrado(json, inout integer) owner to postgres;

