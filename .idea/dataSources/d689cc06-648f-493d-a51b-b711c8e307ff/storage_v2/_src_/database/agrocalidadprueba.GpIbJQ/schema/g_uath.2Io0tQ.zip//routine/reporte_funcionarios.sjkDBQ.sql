create function reporte_funcionarios(_regimen_laboral text, _provincia text, _canton text, _oficina text, _coordinacion text, _direccion text, _gestion text, _estado_civil text, _genero text, _identificacion_etnica text, _discapacidad text) returns SETOF g_uath.vista_funcionario
    language plpgsql
as
$$
DECLARE
	query text;
BEGIN	
	return query EXECUTE 'SELECT
			*
		FROM 
			g_uath.vista_funcionario
		WHERE 
		        
			($1 is NULL or regimen_laboral = $1) and 
			($2 is NULL or provincia = $2) and
			($3 is NULL or canton = $3) and
			($4 is NULL or oficina = $4) and
			($5 is NULL or coordinacion = $5) and 
			($6 is NULL or direccion = $6) and 
			($7 is NULL or gestion = $7) and 
			($8 is NULL or estado_civil = $8) and 
			($9 is NULL or genero = $9) and 
			($10 is NULL or identificacion_etnica = $10) and
			($11 is NULL or tiene_discapacidad = $11)' 

		using _regimen_laboral, _provincia, _canton, _oficina, _coordinacion, _direccion, _gestion, _estado_civil, _genero, _identificacion_etnica, _discapacidad;

	
END;
$$;

alter function reporte_funcionarios(text, text, text, text, text, text, text, text, text, text, text) owner to postgres;

