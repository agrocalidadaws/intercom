create function enviar_correo_estado_certificado_exportacion() returns trigger
    language plpgsql
as
$$
/*
-------------------------------------------------------------------------
--  [g_mercancias_valor_comercial.enviar_correo_cambio_estado_exportacion()]
--               
--  Esta funcion Permite ingresar en el esquema g_correos.correos cada vez que las solicitudes de tipo exportacion cambien de estado
--
--  VERSION		AUTOR					FECHA			HU			                           CAMBIO
--	1			Kleber Armijos		17-03-2024			Actulizacion Exportacion Mascotas      
-------------------------------------------------------------------------
*/
DECLARE
vcorreo_operador character varying;
vnombre_operador character varying;
vid_correo integer;
vasunto character varying ;
vcuerpo character varying ;
BEGIN
	--
	vasunto:='Confirmación de atención de Certificado zoosanitario de exportación de mascotas – Solicitud Nro. '||new.id_solicitud;
	
             
    IF NEW.estado IN ('subsanacion','rechazado','pago') AND NEW.tipo_solicitud = 'Exportacion' AND NEW.forma_pago = 'saldo' THEN

    SELECT correo,CASE 
        WHEN razon_social IS NOT NULL THEN razon_social 
        ELSE nombre_representante || ' ' || apellido_representante 
    END AS nombre_operador INTO 
    vcorreo_operador,vnombre_operador
    FROM  g_operadores.operadores WHERE identificador=NEW.identificador_operador;
    vcuerpo:='<tr>
				<td style="font-family:"Text Me One", 
	             "Segoe UI", "Tahoma", "Helvetica", "freesans", "sans-serif2; padding-top:25px; font-size:14px;color:#2a2a2a; width: 80%; text-align:justify;">'
				 ||'Estimado Sr. <font color="green">' || vnombre_operador || '</font>,<br/><br/>'
				 ||'Por medio de la presente se comunica que la solicitud de certificado de exportación de mascotas, Nro. <font color="green">' ||new.id_solicitud ||'</font>'||
				 ' ha sido atendida.<br/><br/>' 
				 ||'Resultado de revisión técnica:<font color="green"> ' || CASE
                                                                            WHEN NEW.estado = 'pago' THEN 'Aprobado revisión Documental'
                                                                            WHEN NEW.estado = 'subsanacion' THEN NEW.estado
                                                                            ELSE NEW.estado
                                                                           END || '</font>, <br/><br/>'
                 ||'Observación del técnico de Agrocalidad: <font color="green"> ' || NEW.observacion || '</font>, <br/><br/>'
                 ||'Por favor ingresar al Sistema GUIA para revisar más detalles.<br/><br/>'
				 ||'Saludos Cordiales.
				</td>
			 </tr>';
    
        INSERT INTO g_correos.correos (
									   asunto,
									   cuerpo,
									   estado,
									   codigo_modulo,
									   tabla_modulo,
									   id_solicitud_tabla	   
									  )
        VALUES (vasunto, 
				vcuerpo,
			   	'Por enviar',
				'PRG_EXPO_IMPO_V2',
				'g_mercancias_valor_comercial.solicitudes',
				NEW.id_solicitud
			   )
		returning id_correo into vid_correo; -- Aquí coloca la dirección de correo electrónico a la que quieres enviar la notificación
		
		INSERT INTO g_correos.destinatarios(id_correo,destinatario_correo)
		values(vid_correo,vcorreo_operador);
       
		END if;
        RETURN NEW;

END;
$$;

alter function enviar_correo_estado_certificado_exportacion() owner to postgres;

