create function caducidad_contrato(_busqueda text) returns SETOF g_uath.caducidad_contrato
    language plpgsql
as
$$
	DECLARE
		identificadores record;
		retorno g_uath.caducidad_contrato;		
BEGIN

 
FOR identificadores in  EXECUTE 'select t1.identificador, fecha_inicio, fecha_fin,now()::date -fecha_inicio as diferencia from g_uath.datos_contrato as t1 where t1.fecha_fin =(Select max(fecha_fin) from  g_uath.datos_contrato as t2 where t1.identificador=t2.identificador) and t1.tipo_contrato IN (''Contrato Ocasionales'',''Contrato de Servicios Ocasionales'') and t1.contabilizar_dias = false and '||_busqueda||' order by t1.identificador'
	LOOP
        
		EXECUTE 'SELECT  dc.identificador, Sum(dc.fecha_fin-dc.fecha_inicio)+('||identificadores.diferencia||') as dias_trabajados,
  					REPLACE( REPLACE(  REPLACE( REPLACE( REPLACE( REPLACE(	AGE(now()::DATE,(now()::DATE)-(((Sum(dc.fecha_fin-dc.fecha_inicio))+('||identificadores.diferencia||'))*INTERVAL ''1 day''))::TEXT, ''years'',''Años''),
  					     ''year'',''Año''), ''mons'',''Meses''),''mon'',''Mes''),''days'',''Dias''),''day'',''Dia'') as tiempo,
  					 dc.provincia,dc.oficina,
  					(SELECT 
  							apellido||'' ''||nombre 
  					FROM 
  							g_uath.ficha_empleado as fe where fe.identificador=dc.identificador ) as apellido_nombre
				FROM 
  						g_uath.datos_contrato as dc	
				WHERE 
  						dc.contabilizar_dias = true 
  						and dc.identificador= '''||identificadores.identificador||'''
						group by dc.identificador, dc.provincia,dc.oficina
						order by identificador desc' INTO retorno;	
	
                        if retorno is not null then  
				return next  retorno;
			end if;
			
END LOOP;
		
END;
$$;

alter function caducidad_contrato(text) owner to postgres;

