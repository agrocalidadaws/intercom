create view vista_registros_poa
            (id_item, descripcion, meta1, meta2, meta3, meta4, subproceso, id_subproceso, fecha_creacion,
             identificar_usuario, estado, observaciones, revisado, anio)
as
SELECT p.id_item,
       a.descripcion,
       p.meta1,
       p.meta2,
       p.meta3,
       p.meta4,
       s.descripcion AS subproceso,
       s.id_subproceso,
       p.fecha_creacion,
       p.identificar_usuario,
       p.estado,
       p.observaciones,
       p.revisado,
       p.anio
FROM g_poa.planta p,
     g_poa.actividades a,
     g_poa.subprocesos s
WHERE a.id_actividad = p.id_actividad
  AND p.id_subproceso = s.id_subproceso;

alter table vista_registros_poa
    owner to postgres;

