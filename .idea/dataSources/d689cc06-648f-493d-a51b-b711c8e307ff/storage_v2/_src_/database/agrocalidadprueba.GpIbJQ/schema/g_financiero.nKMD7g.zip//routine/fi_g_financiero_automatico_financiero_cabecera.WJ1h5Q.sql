create function fi_g_financiero_automatico_financiero_cabecera() returns trigger
    language plpgsql
as
$$
/*
-------------------------------------------------------------------------
--  [g_financiero.fi_g_financiero_automatico_financiero_cabecera ]
--               
--  Esta funcion permite ingresar mediante tigers ciertos campos de g_financiero.orden_pago a g_financiero_automatico.financiero_cabecera
--  con la finalidad de poder pagar mediante el uso de banred,
--
--  VERSION		AUTOR					FECHA			HU			                           CAMBIO
--	1			Kleber Armijos		29-07-2024			PRY-BANRED      
                Milton Nivelo
-------------------------------------------------------------------------
*/
DECLARE
    vfecha_vigencia DATE;
    vdias_agregados INT := 0;
    vestado_transmision INT := 0;
    vid_vue TEXT := 'NA';
	vestado_factura TEXT default null;--default 'Atendida';--ACTUALIZAR CUANDO SE INTEGRE CON BANRED Y DEJARnull;
	vmetodo_pago TEXT default 'Orden Pago Banred';
	vtipo_proceso TEXT default 'Sistema Banred';

    --finacniero.detalle_pago->financiero_automatico.financiero_detalle
     vid_financiero_cabecera INTEGER;
	
BEGIN

    IF TG_OP = 'INSERT' AND NEW.tipo_solicitud NOT IN ('certificadoZooExportacion') THEN
       
	CASE WHEN NEW.tipo_solicitud IN ('Operadores', 'Emisión de Etiquetas', 'dossierPecuario', 'dossierFertilizantes', 'dossierPlaguicida', 'ensayoEficacia', 'modificacionProductoRia', 'registroProductoRia', 'lims', 'certificacionBPA','mercanciasSinValorComercialImportacion') THEN
	
		vid_vue := NEW.id_solicitud::TEXT;
	   
	WHEN NEW.tipo_solicitud = 'Importación' THEN

		SELECT 
			id_vue
		FROM 
			g_importaciones.importaciones
		WHERE
			id_importacion::TEXT = NEW.id_solicitud INTO vid_vue;

	WHEN NEW.tipo_solicitud = 'FitosanitarioExportacion' THEN
	
		SELECT 
			id_vue
		FROM
			g_fitosanitario_exportacion.fitosanitario_exportaciones
		WHERE
			id_fitosanitario_exportacion::TEXT = NEW.id_solicitud INTO vid_vue;
		
	WHEN NEW.tipo_solicitud = 'Fitosanitario' THEN
		
		SELECT 
			id_vue
		FROM
			g_fito_exportacion.fito_exportaciones
		WHERE
			id_fito_exportacion::TEXT = NEW.id_solicitud INTO vid_vue;
            
    WHEN NEW.tipo_solicitud = 'ImportacionMuestrasVUE' THEN
        
		SELECT 
			req_no
		FROM
            g_importacion_muestras.importacion_muestras
        WHERE
            id_importacion_muestras::TEXT = NEW.id_solicitud INTO vid_vue;

	WHEN NEW.tipo_solicitud = 'certificadoFito' THEN
		
		SELECT 
			codigo_certificado
		FROM
			g_certificado_fitosanitario.certificado_fitosanitario
		WHERE
			id_certificado_fitosanitario::TEXT = NEW.id_solicitud INTO vid_vue;
			
		IF NEW.metodo_pago = 'saldo' AND NEW.total_pagar > 0 THEN
			vestado_factura := 'Por atender';
			vtipo_proceso := 'factura';
			vestado_transmision := -1;
			vmetodo_pago := NEW.metodo_pago;
		END IF;
			
	WHEN NEW.tipo_solicitud IN ('Otros', 'recargaSaldo') THEN
		
		vid_vue := NEW.id_pago::TEXT;
			
	END CASE;

        vfecha_vigencia := CURRENT_DATE;
        WHILE vdias_agregados < 5 LOOP
            vfecha_vigencia := vfecha_vigencia + 1;
            IF EXTRACT(DOW FROM vfecha_vigencia) NOT IN (0, 6) THEN
                vdias_agregados := vdias_agregados + 1;
            END IF;
        END LOOP;
        IF NEW.total_pagar = 0 THEN
            vestado_transmision := -1;
			vestado_factura := 'Atendida';
        END IF;
        INSERT INTO g_financiero_automatico.financiero_cabecera(
            id_vue,
			tipo_solicitud,
			total_pagar,
            estado,
			estado_factura,
            id_orden_pago,
            tipo_proceso, 
            fecha_ingreso_cabcera,
            metodo_pago,
            estado_orden_pago,
            fecha_vigencia_pago,
            estado_transmision_banred,
            identificador_operador_orden_pago,
            id_solicitud_orden_pago,
            tipo_solicitud_orden_pago
        ) VALUES (
			vid_vue,
			NEW.tipo_solicitud,
            NEW.total_pagar,
            'Atendida',
			vestado_factura,
            NEW.id_pago,
			vtipo_proceso,
            now(),
            vmetodo_pago,
            NEW.estado,
            vfecha_vigencia,
            vestado_transmision,
            NEW.identificador_usuario,
            NEW.id_solicitud,
            NEW.tipo_solicitud
        );
        
       RETURN NEW;
    ELSIF TG_OP = 'UPDATE' THEN
      IF EXISTS (SELECT 1 FROM g_financiero_automatico.financiero_cabecera WHERE id_orden_pago = NEW.id_pago) THEN         
        IF NEW.ESTADO = 9 THEN
           
            UPDATE g_financiero_automatico.financiero_cabecera
            SET
				observacion = NEW.observacion_eliminacion,
                estado_orden_pago = NEW.ESTADO,
                estado_factura = 'Atendida',
                estado_transmision_banred = -1,
                fecha_vigencia_pago = NULL
            WHERE id_orden_pago = OLD.id_pago;
        ELSIF NEW.ESTADO = 3 THEN
           UPDATE g_financiero_automatico.financiero_cabecera
            SET
                total_pagar = NEW.total_pagar
            WHERE id_orden_pago = OLD.id_pago;
        END IF;
      END IF;
        RETURN NEW;
    END IF;

    RETURN NULL; 
END;
$$;

alter function fi_g_financiero_automatico_financiero_cabecera() owner to postgres;

