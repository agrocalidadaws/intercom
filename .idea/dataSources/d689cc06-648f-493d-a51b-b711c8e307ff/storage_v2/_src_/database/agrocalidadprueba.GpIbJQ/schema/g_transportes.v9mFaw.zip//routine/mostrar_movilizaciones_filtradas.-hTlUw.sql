create function mostrar_movilizaciones_filtradas(_localizacion text, _tipo text, _placa text, _fecha_inicio timestamp without time zone, _fecha_fin timestamp without time zone, _estado integer) returns SETOF g_transportes.movilizaciones
    language plpgsql
as
$$
DECLARE
	query text;
BEGIN	
	return query EXECUTE '	
		SELECT
			*
		FROM 
			g_transportes.movilizaciones m
		WHERE 
			($1 is NULL or tipo_movilizacion = $1) and 
			($2 is NULL or placa like $2) and
			($3 is NULL or estado = $3) and  
			($4 is NULL or fecha_solicitud >= $4) and 
			($5 is NULL or fecha_solicitud <= $5) and
			($6 is NULL or $6 = localizacion) 
			
		ORDER BY
			m.fecha_solicitud'
		using _tipo,_placa,_estado,_fecha_inicio,_fecha_fin,_localizacion;
	
END;
$$;

alter function mostrar_movilizaciones_filtradas(text, text, text, timestamp, timestamp, integer) owner to postgres;

