create function insertar_serie_aretes1(text[], observacion text) returns integer
    language plpgsql
as
$$
DECLARE identificadorreg ALIAS FOR $1;
_observacion ALIAS FOR $2;

BEGIN

	CREATE TEMP TABLE temp_aretes(testado text, tid_especie integer, tnumero_arete text, tfecha_registro date, tobservacion text) ON COMMIT DROP;  
  
	FOR I IN 1..(ARRAY_LENGTH(identificadorreg,1)) LOOP
    
    INSERT INTO g_catalogos.serie_aretes (estado, id_especie, numero_arete, fecha_registro, observacion)
    select 'creado'::text,6::int,identificadorreg[I]::text, now()::date, _observacion::text
    WHERE not exists(SELECT 
											numero_arete 
										FROM 
											g_catalogos.serie_aretes
										WHERE 
											identificadorreg[I] = serie_aretes.numero_arete);
    --SELECT testado, tid_especie, tnumero_arete, tfecha_registro, tobservacion
		--INSERT INTO temp_aretes(testado, tid_especie, tnumero_arete, tfecha_registro, tobservacion)values('creado', 6, identificadorreg[I], now(), _observacion);
	END LOOP;

-- 	INSERT INTO g_catalogos.serie_aretes (estado, id_especie, numero_arete, fecha_registro, observacion) SELECT testado, tid_especie, tnumero_arete, tfecha_registro, tobservacion
-- 	FROM temp_aretes WHERE not exists(SELECT 
-- 											numero_arete 
-- 										FROM 
-- 											g_catalogos.serie_aretes
-- 										WHERE 
-- 											temp_aretes.tnumero_arete = serie_aretes.numero_arete);

return 1;

END;
$$;

alter function insertar_serie_aretes1(text[], text) owner to postgres;

