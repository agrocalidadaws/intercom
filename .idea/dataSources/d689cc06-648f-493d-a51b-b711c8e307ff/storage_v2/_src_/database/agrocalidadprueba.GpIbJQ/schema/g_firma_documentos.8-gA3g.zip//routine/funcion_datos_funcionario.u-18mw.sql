create function funcion_datos_funcionario() returns trigger
    language plpgsql
as
$$
DECLARE 
	_datosFuncionario record;
BEGIN

	SELECT nombre ||' '|| apellido as nombre, provincia, telefono_institucional INTO _datosFuncionario FROM  g_uath.ficha_empleado fe INNER JOIN g_uath.datos_contrato dc ON fe.identificador = dc.identificador WHERE dc.estado = 1 and NEW.identificador = fe.identificador;
	
	NEW.nombre_firmante = _datosFuncionario.nombre;
	NEW.localizacion = _datosFuncionario.provincia;
	NEW.telefono = _datosFuncionario.telefono_institucional;

	
RETURN NEW;
END;
$$;

alter function funcion_datos_funcionario() owner to postgres;

