create function pg_relation_size(regclass) returns bigint
    strict
    parallel safe
    cost 1
    language sql
as
$$select pg_catalog.pg_relation_size($1, 'main')$$;

comment on function pg_relation_size(regclass) is 'disk space usage for the main fork of the specified table or index';

alter function pg_relation_size(regclass) owner to postgres;

