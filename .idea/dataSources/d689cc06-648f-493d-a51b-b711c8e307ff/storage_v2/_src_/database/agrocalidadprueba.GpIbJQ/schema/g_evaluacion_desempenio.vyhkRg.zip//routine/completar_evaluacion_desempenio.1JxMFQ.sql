create function completar_evaluacion_desempenio() returns trigger
    language plpgsql
as
$$ 
DECLARE
	_opcion g_evaluacion_desempenio.opciones;
BEGIN
	SELECT 
		* 
	INTO 
		_opcion 
	FROM 
		g_evaluacion_desempenio.opciones o 
	WHERE 
		o.id_opcion = NEW.id_opcion and 
		o.id_pregunta = NEW.id_pregunta;
	NEW.opcion_respuesta = _opcion.opcion;
	NEW.ponderacion = _opcion.ponderacion;
	NEW.fecha_respuesta = now();
	RETURN NEW;
END;
$$;

alter function completar_evaluacion_desempenio() owner to postgres;

