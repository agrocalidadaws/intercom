create function f_guardar_movilizacion(p_datos_movilizacion jsonb) returns jsonb
    language plpgsql
as
$$
DECLARE
--p_datos_movilizacion JSONB:= '{"cabecera":{"identificador":"1401230097","numero_permiso":"141713012432949","tipo_solicitud":"Fitosanitario","id_provincia_emision":"255","provincia_emision":"Morona Santiago","id_canton_emision":null,"canton_emision":null,"id_oficina_emision":null,"oficina_emision":null,"id_provincia_origen":"255","provincia_origen":"Morona Santiago","identificador_operador_origen":"1401230097","nombre_operador_origen":"CHILLOGALLO LUCERO DIANA PATRICIA","id_sitio_origen":"556628","sitio_origen":"FINCA SAMY","codigo_sitio_origen":"1401230097.1401","id_provincia_destino":"259","provincia_destino":"Pichincha","identificador_operador_destino":"1722551049","nombre_operador_destino":"AYALA ROSERO EDISON JAVIER","id_sitio_destino":"828822","sitio_destino":"La Guayaquile\u00f1ita","codigo_sitio_destino":"1722551049.1702","medio_transporte":"Terrestre","placa_transporte":"PDQ-4986","identificador_conductor":"1719724781","nombre_conductor":"Milton","fecha_inicio_movilizacion":"2024-01-12","hora_inicio_movilizacion":"17:50","observacion_transporte":"Observaci\u00f3n","ruta_certificado":"aplicaciones\/mvc\/modulos\/MovilizacionVegetal\/archivos\/certificado\/2024\/01\/13\/141713012432949.pdf","estado_movilizacion":"Vigente","estado_fiscalizacion":"No fiscalizado","fecha_fin_movilizacion":"2024-01-13","hora_fin_movilizacion":"17:50","secuencial_movilizacion":"32949","id_area_origen":"633986","area_origen":"CULTIVO DE PITAHAYA","codigo_area_origen":"1401230097.14010601","id_area_destino":"973594","area_destino":"yuly1","codigo_area_destino":"1722551049.17020801", "anio_actual":"2024"},"detalle":[{"id_area_origen":"633986","area_origen":"CULTIVO DE PITAHAYA","id_area_destino":"973594","area_destino":"yuly1","id_subtipo_producto":"24","subtipo_producto":"Fruta","id_producto":"16653","producto":"banano","unidad":"18","cantidad":"23","lote":"14","id_variedad":"1","variedad":"0001-Nacional"},{"id_area_origen":"633986","area_origen":"CULTIVO DE PITAHAYA","id_area_destino":"973594","area_destino":"yuly1","id_subtipo_producto":"24","subtipo_producto":"Fruta","id_producto":"2173","producto":"pitahaya","unidad":"55","cantidad":"444","lote":"14"}]}';

--VARIABLES--
cabecera_elemento JSONB;
detalle_elemento JSONB;
detalle_elemento_transaccion JSONB;
r_validar_cupo RECORD;
r_datos_tmp_movilizacion RECORD;
v_id_movilizacion INTEGER;

--VALIDACIONES--
v_bandera_validar_registro BOOLEAN := true;


-- RETORNAR --
	a_resultado JSONB;
	resultado TEXT := 'Exito';
	mensaje TEXT := 'Los datos fueron registrados con éxito';

BEGIN

	cabecera_elemento := p_datos_movilizacion->'cabecera';

    -- Recorrer todos los elementos del array "detalle"
    FOR detalle_elemento IN SELECT * FROM jsonb_array_elements(p_datos_movilizacion->'detalle')
    LOOP
        		
		PERFORM
			id_configuracion_producto_cupo
		FROM 
			g_movilizacion_vegetal.configuracion_producto_cupo
		WHERE
			id_producto = (detalle_elemento->>'id_producto')::INTEGER
			AND estado_configuracion_producto_cupo = 'Activo';
			
		IF FOUND THEN
		
			PERFORM
				id_unidad_fitosanitaria
			FROM
				g_catalogos.unidades_fitosanitarias
			WHERE
				id_unidad_fitosanitaria = (detalle_elemento->>'unidad')::INTEGER
				AND codigo_unidad_fitosanitaria = 'KGM';
			
			IF FOUND THEN
				
				SELECT 
					cupo_disponible
				FROM 
					g_movilizacion_vegetal.asignacion_cupo
				WHERE
					id_area = (detalle_elemento->>'id_area_origen')::INTEGER
					AND id_producto = (detalle_elemento->>'id_producto')::INTEGER
					AND estado_asignacion_cupo = 'Activo'
					AND anio_asignacion_cupo = (cabecera_elemento->>'anio_actual')::INTEGER INTO r_validar_cupo;
				
				IF FOUND THEN
				
					-- Validacion de cupos por id_area, id_producto --
					IF ((detalle_elemento->>'cantidad')::DOUBLE PRECISION > r_validar_cupo.cupo_disponible) THEN
					
						v_bandera_validar_registro := false;
						resultado := 'Fallo';
						mensaje := 'La cantidad del producto ' || (detalle_elemento->>'producto') || ' es mayor al del cupo disponible ' || (detalle_elemento->>'cantidad')::DOUBLE PRECISION || ' > ' || r_validar_cupo.cupo_disponible;
						EXIT;

					END IF;
					
				END IF;
				
			ELSE
			
				v_bandera_validar_registro := false;
				resultado := 'Fallo';
				mensaje := 'La unidad de medida del producto ' ||  (detalle_elemento->>'producto') || ' debe ser en kilogramos, producto configurado con cupo.';
				EXIT;
				
			END IF;
			
		END IF;

        -- Agregar más lógica según tus necesidades
    END LOOP;

	IF (v_bandera_validar_registro = true) THEN
	
		INSERT INTO 
			g_movilizacion_vegetal.movilizacion (identificador, numero_permiso, tipo_solicitud, id_provincia_emision, provincia_emision, id_canton_emision,
									canton_emision, id_oficina_emision, oficina_emision, id_provincia_origen, provincia_origen, identificador_operador_origen,
									nombre_operador_origen, id_sitio_origen, sitio_origen, codigo_sitio_origen, id_provincia_destino, provincia_destino,
									identificador_operador_destino, nombre_operador_destino, id_sitio_destino, sitio_destino, codigo_sitio_destino, medio_transporte,
									placa_transporte, identificador_conductor, nombre_conductor, fecha_inicio_movilizacion, hora_inicio_movilizacion, observacion_transporte, 
									ruta_certificado, estado_movilizacion, estado_fiscalizacion, fecha_fin_movilizacion, hora_fin_movilizacion, secuencial_movilizacion,
									id_area_origen, area_origen, codigo_area_origen, id_area_destino, area_destino, codigo_area_destino)
		VALUES (cabecera_elemento->>'identificador', cabecera_elemento->>'numero_permiso', cabecera_elemento->>'tipo_solicitud', (cabecera_elemento->>'id_provincia_emision')::INTEGER,
				cabecera_elemento->>'provincia_emision', (cabecera_elemento->>'id_canton_emision')::INTEGER, cabecera_elemento->>'canton_emision', (cabecera_elemento->>'id_oficina_emision')::INTEGER,
				cabecera_elemento->>'oficina_emision', (cabecera_elemento->>'id_provincia_origen')::INTEGER, cabecera_elemento->>'provincia_origen', cabecera_elemento->>'identificador_operador_origen',
				cabecera_elemento->>'nombre_operador_origen', (cabecera_elemento->>'id_sitio_origen')::INTEGER, cabecera_elemento->>'sitio_origen', cabecera_elemento->>'codigo_sitio_origen',
				(cabecera_elemento->>'id_provincia_destino')::INTEGER, cabecera_elemento->>'provincia_destino', cabecera_elemento->>'identificador_operador_destino', cabecera_elemento->>'nombre_operador_destino',
				(cabecera_elemento->>'id_sitio_destino')::INTEGER, cabecera_elemento->>'sitio_destino', cabecera_elemento->>'codigo_sitio_destino', cabecera_elemento->>'medio_transporte', cabecera_elemento->>'placa_transporte',
				cabecera_elemento->>'identificador_conductor', cabecera_elemento->>'nombre_conductor', (cabecera_elemento->>'fecha_inicio_movilizacion')::TIMESTAMP WITHOUT TIME ZONE,
				(cabecera_elemento->>'hora_inicio_movilizacion')::TIME WITHOUT TIME ZONE, cabecera_elemento->>'observacion_transporte', cabecera_elemento->>'ruta_certificado', cabecera_elemento->>'estado_movilizacion',
				cabecera_elemento->>'estado_fiscalizacion', (cabecera_elemento->>'fecha_fin_movilizacion')::DATE, (cabecera_elemento->>'hora_fin_movilizacion')::TIME WITHOUT TIME ZONE, cabecera_elemento->>'secuencial_movilizacion',
				(cabecera_elemento->>'id_area_origen')::INTEGER, cabecera_elemento->>'area_origen', cabecera_elemento->>'codigo_area_origen', (cabecera_elemento->>'id_area_destino')::INTEGER,
				cabecera_elemento->>'area_destino', cabecera_elemento->>'codigo_area_destino') 
		RETURNING 
			id_movilizacion 
		INTO 
			v_id_movilizacion;
			
			
		-- Recorrer todos los elementos del array "detalle"
		FOR detalle_elemento_transaccion IN SELECT * FROM jsonb_array_elements(p_datos_movilizacion->'detalle')
		LOOP
		
			INSERT INTO 
				g_movilizacion_vegetal.detalle_movilizacion(id_movilizacion
														, id_area_origen
														, area_origen
														, id_area_destino
														, area_destino
														, id_subtipo_producto
														, subtipo_producto
														, id_producto
														, producto
														, unidad
														, cantidad
														, lote
														, id_variedad
														, variedad)
			VALUES (v_id_movilizacion
					, (detalle_elemento_transaccion->>'id_area_origen')::INTEGER
					, detalle_elemento_transaccion->>'area_origen'
					, (detalle_elemento_transaccion->>'id_area_destino')::INTEGER
					, detalle_elemento_transaccion->>'area_destino'
					, (detalle_elemento_transaccion->>'id_subtipo_producto')::INTEGER
					, detalle_elemento_transaccion->>'subtipo_producto'
					, (detalle_elemento_transaccion->>'id_producto')::INTEGER
					, detalle_elemento_transaccion->>'producto'
					, (detalle_elemento_transaccion->>'unidad')::INTEGER
					, (detalle_elemento_transaccion->>'cantidad')::DOUBLE PRECISION
					, detalle_elemento_transaccion->>'lote'
					, (detalle_elemento_transaccion->>'id_variedad')::INTEGER
					, detalle_elemento_transaccion->>'variedad');
		
			--Valida si el producto esta configurado para cupo
			PERFORM
				id_configuracion_producto_cupo
			FROM 
				g_movilizacion_vegetal.configuracion_producto_cupo
			WHERE
			id_producto = (detalle_elemento_transaccion->>'id_producto')::INTEGER
			AND estado_configuracion_producto_cupo = 'Activo';
			
			IF FOUND THEN
			
				PERFORM 
					id_asignacion_cupo
				FROM 
					g_movilizacion_vegetal.asignacion_cupo
				WHERE
					id_area = (detalle_elemento_transaccion->>'id_area_origen')::INTEGER
					AND id_producto = (detalle_elemento_transaccion->>'id_producto')::INTEGER
					AND estado_asignacion_cupo = 'Activo'
					AND anio_asignacion_cupo = (cabecera_elemento->>'anio_actual')::INTEGER;
				
				IF FOUND THEN
			
					--3. Egreso - Emision de permiso (Movilizacion origen)		
					PERFORM 
						* 
					FROM 
						g_movilizacion_vegetal.f_transaccion_cupo_movilizacion((cabecera_elemento->>'id_sitio_origen')::INTEGER
																, (detalle_elemento_transaccion->>'id_area_origen')::INTEGER
																, (detalle_elemento_transaccion->>'id_producto')::INTEGER
																, (detalle_elemento_transaccion->>'unidad')::INTEGER
																, detalle_elemento_transaccion->>'lote'
																, (detalle_elemento_transaccion->>'cantidad')::DOUBLE PRECISION
																, 0
																, (cabecera_elemento->>'anio_actual')::INTEGER
																, cabecera_elemento->>'identificador'
																, 3
																, v_id_movilizacion);	

				END IF;
								
				----4. Ingreso - Recepción de producto (Movilizacion destino)
				PERFORM 
					* 
				FROM 
					g_movilizacion_vegetal.f_transaccion_cupo_movilizacion((cabecera_elemento->>'id_sitio_destino')::INTEGER
															, (detalle_elemento_transaccion->>'id_area_destino')::INTEGER
															, (detalle_elemento_transaccion->>'id_producto')::INTEGER
															, (detalle_elemento_transaccion->>'unidad')::INTEGER
															, detalle_elemento_transaccion->>'lote'
															, (detalle_elemento_transaccion->>'cantidad')::DOUBLE PRECISION
															, 0
															, (cabecera_elemento->>'anio_actual')::INTEGER
															, cabecera_elemento->>'identificador'
															, 4
															, v_id_movilizacion);
																
			END IF;		
		
		END LOOP;
	
	END IF;
	
	RETURN jsonb_build_object('resultado', resultado, 'mensaje', mensaje, 'contenido', jsonb_build_object('idMovilizacion', v_id_movilizacion, 'numeroPermiso', cabecera_elemento->>'numero_permiso', 'rutaCertificado', cabecera_elemento->>'ruta_certificado'));
	
END;
$$;

alter function f_guardar_movilizacion(jsonb) owner to postgres;

