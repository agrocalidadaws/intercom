create function fs_interconexion_dinarp_tranpsorte_leche(pidentificador character varying) returns json
    language plpgsql
as
$$

/*
-------------------------------------------------------------------------
--  [g_operadores.fs_interconexion_dinarp_tranpsorte_leche]
--               
--  Esta funcion retorna un json con los campos seleccionados de los operadores de transporte de leche que esten en estado registrado
--  Cabe recalcar que esta funcion es fundamental para la compartision de datos mediante ws a la dinarp
--
--  VERSION		AUTOR					FECHA			HU	
--	1			Kleber Armijos		06-08-2024	  Funcion retorna json de un operador de transporte de leche en especifico 
--												  
-------------------------------------------------------------------------
*/
declare 
operadores_tranpsote_leche_cruda json;
vid_producto integer :=33827; --para el producto leche
BEGIN	
        SELECT  json_agg(row_to_json(t))
        INTO operadores_tranpsote_leche_cruda
        FROM (
                WITH cte_tipos_tanque AS (
                    SELECT c.id_item, c.nombre
                    FROM g_administracion_catalogos.catalogos_negocio cn
                    JOIN g_administracion_catalogos.items_catalogo c ON cn.id_catalogo_negocios = c.id_catalogo_negocios
                    WHERE cn.codigo = 'COD-TANQU-IA' AND c.estado = 1
                ),
                cte_distinct_operadores AS (
                    SELECT 
                        o.identificador,
                        RTRIM(REPLACE(REPLACE(REPLACE(o.razon_social, chr(9), ''), chr(10), ''), chr(13), '')) as razon_social,
                        tp_pro.id_tipo_producto,
                        tp_pro.nombre as tipo_producto,
                        sub_pro.id_subtipo_producto,
                        sub_pro.nombre as subtipo_producto,
                        pr.id_producto,
                        REPLACE(REPLACE(REPLACE(pr.nombre_comun, chr(9), ''), chr(10), ''), chr(13), '') as nombre_producto,
                        o.identificador || '.' || s.codigo_provincia || s.codigo || a.codigo || a.secuencial as codigo_area,
                        op.estado as estado_operacion,
                        CASE WHEN op.estado = 'registrado' THEN op.fecha_aprobacion END as fecha_aprobacion,
                        op.fecha_finalizacion,
                        loc_prov.id_localizacion as id_provincia,
                        loc_prov.nombre as provincia,
                        loc_cant.id_localizacion as id_canton,
                        loc_cant.nombre as canton,
                        loc_parr.id_localizacion as id_parroquia,
                        loc_parr.nombre as parroquia,
                        dv.placa_vehiculo as placa,
                        dv.nombre_tipo_vehiculo as tipo_vehiculo,
                        dv.nombre_marca_vehiculo as marca_vehiculo,
                        dv.nombre_color_vehiculo as color,
                        dv.anio_vehiculo as anio,
                        tt.nombre AS tipo_tanque,
                        dv.capacidad_vehiculo,
                        dv.codigo_unidad_medida ,
                        REPLACE(REPLACE(REPLACE(o.correo, chr(9), ''), chr(10), ''), chr(13), '') as correo,
                        s.telefono as telefono,
                        o.telefono_uno as telefono_operador,
                        ROW_NUMBER() OVER (PARTITION BY o.identificador, s.codigo_provincia, s.codigo, a.codigo, a.secuencial, dv.placa_vehiculo ORDER BY op.fecha_aprobacion DESC) as row_num
                    FROM
                        g_operadores.operadores o 
                        INNER JOIN g_operadores.sitios s ON s.identificador_operador = o.identificador
                        INNER JOIN g_operadores.areas a ON a.id_sitio = s.id_sitio
                        INNER JOIN g_operadores.productos_areas_operacion pao ON pao.id_area = a.id_area
                        INNER JOIN g_operadores.operaciones op ON op.id_operacion = pao.id_operacion
                        INNER JOIN g_operadores.datos_vehiculos dv ON dv.id_area = a.id_area
                        INNER JOIN cte_tipos_tanque tt ON tt.id_item = dv.id_tipo_tanque_vehiculo
                        LEFT JOIN g_catalogos.productos pr ON pr.id_producto = op.id_producto
                        LEFT JOIN g_catalogos.subtipo_productos sub_pro ON sub_pro.id_subtipo_producto = pr.id_subtipo_producto
                        LEFT JOIN g_catalogos.tipo_productos tp_pro ON tp_pro.id_tipo_producto = sub_pro.id_tipo_producto
                        LEFT JOIN g_catalogos.localizacion loc_prov ON loc_prov.nombre = s.provincia AND loc_prov.id_localizacion_padre = 66
                        LEFT JOIN g_catalogos.localizacion loc_cant ON loc_cant.nombre = s.canton AND loc_cant.id_localizacion_padre = loc_prov.id_localizacion
                        LEFT JOIN g_catalogos.localizacion loc_parr ON loc_parr.nombre = s.parroquia AND loc_parr.id_localizacion_padre = loc_cant.id_localizacion
                    WHERE
                        o.identificador = $1 AND
                        op.id_tipo_operacion IN (104) AND
                        op.estado = 'registrado' AND
                        dv.estado_dato_vehiculo = 'activo' AND
                        pr.id_producto= vid_producto
                )
                SELECT  identificador,
                        razon_social,
                        id_tipo_producto,
                        tipo_producto,
                        id_subtipo_producto,
                        subtipo_producto,
                        id_producto,
                        nombre_producto,
                        codigo_area,
                        estado_operacion,
                        fecha_aprobacion,
                        fecha_finalizacion,
                        id_provincia,
                        provincia,
                        id_canton,
                        canton,
                        id_parroquia,
                        parroquia,
                        placa,
                        tipo_vehiculo,
                        marca_vehiculo,
                        color,
                        anio,
                        tipo_tanque,
                        capacidad_vehiculo,
                        codigo_unidad_medida,
                        correo,
                        telefono,
                        telefono_operador
                FROM cte_distinct_operadores
                WHERE row_num = 1
        ) t;
return operadores_tranpsote_leche_cruda;
END;
$$;

alter function fs_interconexion_dinarp_tranpsorte_leche(varchar) owner to postgres;

