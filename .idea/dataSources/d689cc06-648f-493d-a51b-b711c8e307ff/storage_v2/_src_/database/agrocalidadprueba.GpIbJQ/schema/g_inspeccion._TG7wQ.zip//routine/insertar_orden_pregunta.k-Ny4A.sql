create function insertar_orden_pregunta() returns trigger
    language plpgsql
as
$$ 

BEGIN
	NEW.orden = public.calcular_orden_siguiente('g_inspeccion.preguntas', 'id_categoria', NEW.id_categoria);

	RETURN NEW;
	END; 
	
$$;

alter function insertar_orden_pregunta() owner to postgres;

