create function insertar_orden_categoria() returns trigger
    language plpgsql
as
$$ 

BEGIN
	NEW.orden = public.calcular_orden_siguiente('g_inspeccion.categorias', 'id_formulario', NEW.id_formulario);

	RETURN NEW;
	END; 
	
$$;

alter function insertar_orden_categoria() owner to postgres;

