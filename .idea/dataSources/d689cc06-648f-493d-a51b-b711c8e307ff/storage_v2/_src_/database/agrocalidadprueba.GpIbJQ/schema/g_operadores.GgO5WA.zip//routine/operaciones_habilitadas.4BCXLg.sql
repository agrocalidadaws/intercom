create function operaciones_habilitadas(_identificador text, _area text, _sitio integer) returns SETOF g_catalogos.tipos_operacion
    language plpgsql
as
$$
	DECLARE
		operaciones record;
		areas record;
		areas_registradas record;
		contador int;
BEGIN
FOR operaciones in (SELECT * FROM g_catalogos.tipos_operacion WHERE estado=1 and id_area = _area) 
		LOOP
		contador = 0;
			FOR areas in (SELECT a.nombre, (SELECT count(*)FROM g_catalogos.areas_operacion a, g_catalogos.tipos_operacion t WHERE a.id_tipo_operacion = t.id_tipo_operacion and t.id_tipo_operacion  = operaciones.id_tipo_operacion) numero_areas
				      FROM  g_catalogos.areas_operacion a, g_catalogos.tipos_operacion t WHERE a.id_tipo_operacion = t.id_tipo_operacion and t.id_tipo_operacion = operaciones.id_tipo_operacion order by t.nombre) 
			LOOP
				FOR areas_registradas in (SELECT DISTINCT tipo_area FROM g_operadores.areas a, g_operadores.sitios s WHERE s.id_sitio = a.id_sitio and s.identificador_operador = _identificador and tipo_area = areas.nombre and s.id_sitio = _sitio) 
				LOOP
					contador = contador + 1;
					IF(areas.numero_areas = contador) THEN
						return next operaciones;
					END IF;			
				END LOOP;
			END LOOP;
		END LOOP;

END;
$$;

alter function operaciones_habilitadas(text, text, integer) owner to postgres;

