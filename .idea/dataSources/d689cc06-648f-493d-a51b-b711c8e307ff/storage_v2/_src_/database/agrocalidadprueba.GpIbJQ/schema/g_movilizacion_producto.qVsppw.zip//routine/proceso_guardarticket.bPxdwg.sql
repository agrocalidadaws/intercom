create function proceso_guardarticket(fnumero_certificado_movilizacion text, fid_detallemovilizacion integer) returns void
    language plpgsql
as
$$
begin

	INSERT INTO g_movilizacion_producto.ticket_movilizacion(numero_ticket, identificador_producto, id_detalle_movilizacion)
	SELECT (replace(identificador,'-','')||fnumero_certificado_movilizacion), identificador, id_detalle_movilizacion FROM g_movilizacion_producto.detalle_identificadores_movilizacion
	WHERE id_detalle_movilizacion = fid_detallemovilizacion;
   	EXCEPTION 
	WHEN others THEN
	INSERT INTO g_movilizacion_producto.log_exepcion_movilizacion (funcion_origen, error_excepcion, codigo_error, fecha_registro)
	VALUES('proceso_guardarticket', SQLERRM, SQLSTATE, now() );
end;
$$;

alter function proceso_guardarticket(text, integer) owner to postgres;

