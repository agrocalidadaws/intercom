create function mostrar_ficha_empleado(_identificador text, _nombre text, _apellido text) returns SETOF g_uath.ficha_empleado
    language plpgsql
as
$$
DECLARE
	query text;
BEGIN	
	return query EXECUTE 'SELECT
			*
		FROM 
			g_uath.ficha_empleado
		WHERE 
		        
			($1 is NULL or identificador = $1) and 
			($2 is NULL or upper(nombre) like $2) and 
			($3 is NULL or upper(apellido) like $3)' 
		using _identificador,_nombre,_apellido;
	
END;
$$;

alter function mostrar_ficha_empleado(text, text, text) owner to postgres;

