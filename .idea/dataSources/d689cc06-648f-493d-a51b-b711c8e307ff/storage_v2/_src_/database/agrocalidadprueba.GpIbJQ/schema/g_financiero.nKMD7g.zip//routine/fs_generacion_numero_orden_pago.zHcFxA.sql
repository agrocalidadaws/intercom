create function fs_generacion_numero_orden_pago() returns text
    language plpgsql
as
$$

/*
-------------------------------------------------------------------------
--  [g_financiero.fs_generacion_numero_orden_pago]
--               
--  Esta funcion retorna el numero_de secuencia en la orden de pago 
--
--  VERSION		AUTOR					FECHA			HU	
--	1			Kleber Armijos		  02-09-2024	  Funcion para generacion de numero de secuencia en la orden de pago
--				Milton Nivelo		             	  esta funcion se genera en el proyecto banred, misma que cada año se reinicia la secuencia a cero
--												 
-------------------------------------------------------------------------
*/	
    DECLARE
    v_numero_solicitud TEXT;
    v_anio_actual TEXT := EXTRACT(YEAR FROM CURRENT_DATE)::TEXT;  -- Año fijo para pruebas
    v_prefijo TEXT := 'AGR-' || v_anio_actual || '-';
    v_ultimo_anio TEXT := (v_anio_actual::INTEGER - 1)::TEXT;
    v_maximo_secuencial INTEGER;
BEGIN
    SELECT COALESCE(MAX(NULLIF(REGEXP_REPLACE(numero_solicitud, '^.*-(\d+)$', '\1'), '')::INTEGER), 0)
    INTO v_maximo_secuencial
    FROM g_financiero.orden_pago
    WHERE numero_solicitud LIKE v_prefijo || '%';

    IF v_maximo_secuencial = 0 THEN

        IF EXISTS (
            SELECT 1
            FROM g_financiero.orden_pago
            WHERE numero_solicitud LIKE 'AGR-' || v_ultimo_anio || '-%'
        ) THEN

            PERFORM setval('g_financiero.orden_pago_secuencia', 1, false);
        ELSE

            SELECT COALESCE(last_value, 0) INTO v_maximo_secuencial
            FROM g_financiero.orden_pago_secuencia;
        END IF;
    ELSE

        PERFORM setval('g_financiero.orden_pago_secuencia', v_maximo_secuencial, true);
    END IF;

    SELECT
        v_prefijo || LPAD(nextval('g_financiero.orden_pago_secuencia')::TEXT, 9, '0')
    INTO
        v_numero_solicitud;

    RETURN v_numero_solicitud;

END;
$$;

alter function fs_generacion_numero_orden_pago() owner to postgres;

