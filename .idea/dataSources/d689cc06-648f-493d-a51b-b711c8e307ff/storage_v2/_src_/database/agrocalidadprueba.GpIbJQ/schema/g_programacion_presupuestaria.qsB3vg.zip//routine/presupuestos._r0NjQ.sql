create function presupuestos(_n2 text, _n4 text, _gestion text, _proceso integer, _componente integer, _actividad integer, _tipo text, _provincia integer, _anio integer, _estado text) returns SETOF g_programacion_presupuestaria.vista_presupuesto
    language plpgsql
as
$$
DECLARE
	query text;
BEGIN	
	return query EXECUTE '	
		SELECT
			*
		FROM 
			g_programacion_presupuestaria.vista_presupuesto
		WHERE 		        
			($1 is NULL or id_area_n2 = $1) and 
			($2 is NULL or id_area_n4 = $2) and 
			($3 is NULL or id_area_unidad = $3) and 
			($4 is NULL or id_proceso_proyecto = $4) and 
			($5 is NULL or id_componente = $5) and
			($6 is NULL or id_actividad = $6) and
			($7 is NULL or tipo = $7) and
			($8 is NULL or id_provincia = $8) and
			($9 is NULL or anio = $9) and
			($10 is NULL or estado_presupuesto = $10)
			
		ORDER BY
			area_n2, area_n4, gestion, proceso_proyecto, componente, actividad'
			
		using _n2, _n4, _gestion, _proceso, _componente, _actividad, _tipo, _provincia, _anio, _estado;
	
END;
$$;

alter function presupuestos(text, text, text, integer, integer, integer, text, integer, integer, text) owner to postgres;

