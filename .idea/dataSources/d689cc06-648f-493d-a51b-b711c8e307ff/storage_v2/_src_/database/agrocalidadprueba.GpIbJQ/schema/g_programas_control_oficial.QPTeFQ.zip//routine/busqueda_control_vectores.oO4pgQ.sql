create function busqueda_control_vectores(_num_solicitud text, _fecha timestamp without time zone, _nombre_predio text, _nombre_propietario text, _id_provincia integer, _id_canton integer, _id_parroquia integer, _sitio text, _estado text) returns SETOF g_programas_control_oficial.vista_busqueda_control_vectores
    language plpgsql
as
$$
DECLARE
	query text;
BEGIN	
	return query EXECUTE '	
		SELECT
			*
		FROM 
			g_programas_control_oficial.vista_busqueda_control_vectores
		WHERE 		        
			($1 is NULL or num_solicitud ilike $1) and 
			($2 is NULL or fecha >= $2) and 
			($3 is NULL or nombre_predio ilike $3) and 
			($4 is NULL or nombre_propietario ilike $4) and 
			($5 is NULL or id_provincia = $5) and 
			($6 is NULL or id_canton = $6) and 
			($7 is NULL or id_parroquia = $7) and 
			($8 is NULL or sitio ilike $8) and
			($9 is NULL or estado = $9)
			
		ORDER BY
			num_solicitud, id_provincia, id_canton, id_parroquia, estado'
			
		using _num_solicitud, _fecha, _nombre_predio, _nombre_propietario, _id_provincia, _id_canton, _id_parroquia, _sitio, _estado;
	
END;
$$;

alter function busqueda_control_vectores(text, timestamp, text, text, integer, integer, integer, text, text) owner to postgres;

