CREATE RULE regla_monitoreo_crons_detalles_2024 AS
    ON INSERT TO g_monitoreos.crons_detalles
   WHERE new.fecha_ejecucion >= '2024-01-01 00:00:00'::timestamp without time zone AND new.fecha_ejecucion <= '2025-01-01 00:00:00'::timestamp without time zone DO INSTEAD  INSERT INTO g_monitoreos.crons_detalles_2024 (id_cron_detalle, id_cron, fecha_ejecucion, tipo_proceso, origen)
  VALUES (new.id_cron_detalle, new.id_cron, new.fecha_ejecucion, new.tipo_proceso, new.origen);

