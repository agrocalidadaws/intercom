create function mostrar_rendimiento_general(_placa text, _fecha_inicio timestamp without time zone, _fecha_fin date, _localizacion text, _cantidad integer) returns SETOF g_transportes.combustible_rendimiento
    language plpgsql
as
$$
DECLARE
	query text;
BEGIN	
	return query EXECUTE '
			SELECT 
				(max(kilometraje) - min(kilometraje))/SUM(cantidad_galones) as rendimiento,
				placa,
				localizacion
			FROM 
				g_transportes.combustible
			WHERE
				($1 is NULL or placa like $1) and 
				($2 is NULL or  fecha_despacho >= $2) and 
				($3 is NULL or  fecha_despacho <= $3) and
				($4 is NULL or $4 = localizacion)and 
				estado = 3
			GROUP BY 
				placa,
				localizacion
			ORDER BY rendimiento asc
			LIMIT $5'
			
		using _placa,_fecha_inicio,_fecha_fin,_localizacion,_cantidad;
	
END;
$$;

alter function mostrar_rendimiento_general(text, timestamp, date, text, integer) owner to postgres;

