create function funcion_auditoria_tipo_inspector() returns trigger
    language plpgsql
as
$$ 
BEGIN
	
	PERFORM g_centros_faenamiento.funcion_insertar_auditoria_tipo_inspector(NEW.id_tipo_inspector, NEW.resultado, NEW.tipo_inspector, NEW.observacion, NEW.identificador_registro);	
	IF (NEW.resultado = 'No habilitado') THEN
		UPDATE g_centros_faenamiento.centro_faenamiento_tipo_inspector SET estado = 'inactivo' WHERE id_tipo_inspector = NEW.id_tipo_inspector;
	END IF;
	
	
RETURN NEW;
END; 
$$;

alter function funcion_auditoria_tipo_inspector() owner to postgres;

