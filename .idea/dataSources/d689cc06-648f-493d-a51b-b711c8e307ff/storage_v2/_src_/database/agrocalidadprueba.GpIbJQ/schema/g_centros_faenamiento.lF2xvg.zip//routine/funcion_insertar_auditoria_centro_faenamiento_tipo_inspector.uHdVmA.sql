create function funcion_insertar_auditoria_centro_faenamiento_tipo_inspector(_id_centro_faenamiento_tipo_inspector integer, _id_centro_faenamiento integer, _id_tipo_inspector integer, _identificador_registro character varying, _estado character varying) returns void
    language plpgsql
as
$$
BEGIN
	INSERT INTO g_centros_faenamiento.auditoria_centro_faenamiento_tipo_inspector(id_centro_faenamiento_tipo_inspector, id_centro_faenamiento, id_tipo_inspector, identificador_registro, estado)
		VALUES (_id_centro_faenamiento_tipo_inspector, _id_centro_faenamiento, _id_tipo_inspector, _identificador_registro, _estado);
		
END;
$$;

alter function funcion_insertar_auditoria_centro_faenamiento_tipo_inspector(integer, integer, integer, varchar, varchar) owner to postgres;

