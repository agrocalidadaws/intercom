create function inactivarcatalgo(id integer[]) returns void
    language plpgsql
as
$$
DECLARE
 idc alias for $1;
 i int;
BEGIN
FOREACH i IN ARRAY $1 loop
 update g_administracion_catalogos.catalogos_negocio set estado=2 where id_catalogo_negocios = i;
 update g_administracion_catalogos.items_catalogo set estado=2 where id_catalogo_negocios = i;
END loop;
END;
$$;

alter function inactivarcatalgo(integer[]) owner to postgres;

