create function f_verificar_registros(pidsolicitud integer) returns integer
    language plpgsql
as
$$
		DECLARE
		tipomodificacion record;
		categoriatoxicologica record;
		periodoreingreso record;
		vidautil record;
		estadoregistro record;
		viaadministraciondosis record;
		periodoretiro record;
		nombrecomercial record;
		adicionpresentacion record;
		adicionpresentacionplagucida record;
		titularidadproducto record;
		fabricanteformulador record;
		uso record;
		manufacturador record;
		composicion record;
		solictudesproducto record;
		denominacionventa record;
		clasificacionproducto record;
		
		avalidacion int[] := null;
		resultado integer := 0;

		BEGIN

		FOR tipomodificacion in (SELECT 
									dsp.id_solicitud_producto
									, dsp.id_tipo_modificacion_producto
									, dsp.id_detalle_solicitud_producto
									, tmp.codigo_modificacion
										FROM 
									g_modificacion_productos.detalle_solicitudes_productos dsp
										INNER JOIN g_catalogos.tipo_modificacion_producto tmp ON tmp.id_tipo_modificacion_producto = dsp.id_tipo_modificacion_producto
									WHERE
										dsp.id_solicitud_producto = pidsolicitud) LOOP
									
										IF(tipomodificacion.codigo_modificacion = 'modificarCategoriaToxicologica') THEN

											SELECT 
												CASE WHEN (COUNT(ct.id_categoria_toxicologica) > 0) THEN 1 ELSE 0 END AS contador
											FROM 
												g_modificacion_productos.categorias_toxicologicas ct
											WHERE
												ct.id_detalle_solicitud_producto = tipomodificacion.id_detalle_solicitud_producto INTO categoriatoxicologica;

											 avalidacion := array_append(avalidacion, categoriatoxicologica.contador);

										END IF;
										
										IF(tipomodificacion.codigo_modificacion = 'modificarPeriodoReingreso') THEN

											SELECT 
												CASE WHEN (COUNT(pr.id_periodo_reingreso) > 0) THEN 1 ELSE 0 END AS contador
											FROM 
												g_modificacion_productos.periodos_reingresos pr
											WHERE
												pr.id_detalle_solicitud_producto = tipomodificacion.id_detalle_solicitud_producto INTO periodoreingreso;

											 avalidacion := array_append(avalidacion, periodoreingreso.contador);

										END IF;
										
										IF(tipomodificacion.codigo_modificacion = 'modificarVidaUtil') THEN

											SELECT 
												CASE WHEN (COUNT(vu.id_vida_util) > 0) THEN 1 ELSE 0 END AS contador
											FROM 
												g_modificacion_productos.vidas_utiles vu
											WHERE
												vu.id_detalle_solicitud_producto = tipomodificacion.id_detalle_solicitud_producto INTO vidautil;

											 avalidacion := array_append(avalidacion, vidautil.contador);

										END IF;
										
										IF(tipomodificacion.codigo_modificacion = 'modificarEstadoRegistro') THEN

											SELECT 
												CASE WHEN (COUNT(er.id_estado_registro) > 0) THEN 1 ELSE 0 END AS contador
											FROM 
												g_modificacion_productos.estados_registros er
											WHERE
												er.id_detalle_solicitud_producto = tipomodificacion.id_detalle_solicitud_producto INTO estadoregistro;

											 avalidacion := array_append(avalidacion, estadoregistro.contador);

										END IF;
										
										IF(tipomodificacion.codigo_modificacion = 'modificarViaAdmimistracionDosis') THEN

											SELECT 
												CASE WHEN (COUNT(vad.id_via_administracion_dosis) > 0) THEN 1 ELSE 0 END AS contador
											FROM 
												g_modificacion_productos.vias_administraciones_dosis vad
											WHERE
												vad.id_detalle_solicitud_producto = tipomodificacion.id_detalle_solicitud_producto INTO viaadministraciondosis;

											 avalidacion := array_append(avalidacion, viaadministraciondosis.contador);

										END IF;
										
										IF(tipomodificacion.codigo_modificacion = 'modificarPeriodoRetiro') THEN

											SELECT 
												CASE WHEN (COUNT(pr.id_periodo_retiro) > 0) THEN 1 ELSE 0 END AS contador
											FROM 
												g_modificacion_productos.periodos_retiros pr
											WHERE
												pr.id_detalle_solicitud_producto = tipomodificacion.id_detalle_solicitud_producto INTO periodoretiro;

											 avalidacion := array_append(avalidacion, periodoretiro.contador);

										END IF;
										
										IF(tipomodificacion.codigo_modificacion = 'modificarNombreComercial') THEN

											SELECT 
												CASE WHEN (COUNT(nc.id_nombre_comercial) > 0) THEN 1 ELSE 0 END AS contador
											FROM 
												g_modificacion_productos.nombres_comerciales nc
											WHERE
												nc.id_detalle_solicitud_producto = tipomodificacion.id_detalle_solicitud_producto INTO nombrecomercial;

											 avalidacion := array_append(avalidacion, nombrecomercial.contador);

										END IF;
										
										IF(tipomodificacion.codigo_modificacion = 'modificarAdicionPresentacion') THEN

											SELECT 
												CASE WHEN (COUNT(ap.id_adicion_presentacion) > 0) THEN 1 ELSE 0 END AS contador
											FROM 
												g_modificacion_productos.adiciones_presentaciones ap
											WHERE
												ap.id_detalle_solicitud_producto = tipomodificacion.id_detalle_solicitud_producto INTO adicionpresentacion;

											 avalidacion := array_append(avalidacion, adicionpresentacion.contador);

										END IF;
										
										IF(tipomodificacion.codigo_modificacion = 'modificarAdicionPresentacionPlaguicida') THEN

											SELECT 
												CASE WHEN (COUNT(app.id_adicion_presentacion_plaguicida) > 0) THEN 1 ELSE 0 END AS contador
											FROM 
												g_modificacion_productos.adiciones_presentaciones_plaguicidas app
											WHERE
												app.id_detalle_solicitud_producto = tipomodificacion.id_detalle_solicitud_producto INTO adicionpresentacionplagucida;

											 avalidacion := array_append(avalidacion, adicionpresentacionplagucida.contador);

										END IF;
										
										IF(tipomodificacion.codigo_modificacion = 'modificarTitularidadProducto') THEN

											SELECT 
												CASE WHEN (COUNT(tp.id_titular_producto) > 0) THEN 1 ELSE 0 END AS contador
											FROM 
												g_modificacion_productos.titulares_productos tp
											WHERE
												tp.id_detalle_solicitud_producto = tipomodificacion.id_detalle_solicitud_producto INTO titularidadproducto;

											 avalidacion := array_append(avalidacion, titularidadproducto.contador);

										END IF;
										
										IF(tipomodificacion.codigo_modificacion = 'modificarFabricanteFormulador') THEN

											SELECT 
												CASE WHEN (COUNT(ff.id_fabricante_formulador) > 0) THEN 1 ELSE 0 END AS contador
											FROM 
												g_modificacion_productos.fabricantes_formuladores ff
											WHERE
												ff.id_detalle_solicitud_producto = tipomodificacion.id_detalle_solicitud_producto INTO fabricanteformulador;

											 avalidacion := array_append(avalidacion, fabricanteformulador.contador);

										END IF;
										
										IF(tipomodificacion.codigo_modificacion = 'modificarUso') THEN

											SELECT 
												CASE WHEN (COUNT(u.id_uso) > 0) THEN 1 ELSE 0 END AS contador
											FROM 
												g_modificacion_productos.usos u
											WHERE
												u.id_detalle_solicitud_producto = tipomodificacion.id_detalle_solicitud_producto INTO uso;

											 avalidacion := array_append(avalidacion, uso.contador);

										END IF;
										
										IF(tipomodificacion.codigo_modificacion = 'modificarManufacturador') THEN

											SELECT 
												CASE WHEN (COUNT(m.id_manufacturador) > 0) THEN 1 ELSE 0 END AS contador
											FROM 
												g_modificacion_productos.manufacturadores m
											WHERE
												m.id_detalle_solicitud_producto = tipomodificacion.id_detalle_solicitud_producto INTO manufacturador;

											 avalidacion := array_append(avalidacion, manufacturador.contador);

										END IF;
										
										IF(tipomodificacion.codigo_modificacion = 'modificarComposicion') THEN

											SELECT 
												CASE WHEN (COUNT(c.id_composicion) > 0) THEN 1 ELSE 0 END AS contador
											FROM 
												g_modificacion_productos.composiciones c
											WHERE
												c.id_detalle_solicitud_producto = tipomodificacion.id_detalle_solicitud_producto INTO composicion;

											 avalidacion := array_append(avalidacion, composicion.contador);

										END IF;
										
										IF(tipomodificacion.codigo_modificacion = 'modificarEtiqueta') THEN

											SELECT 
												CASE WHEN (s.ruta_etiqueta_producto is not null) THEN 1 ELSE 0 END AS contador
											FROM 
												g_modificacion_productos.solicitudes_productos s
												INNER JOIN g_modificacion_productos.detalle_solicitudes_productos dsp 
												ON dsp.id_solicitud_producto = s.id_solicitud_producto
											WHERE
												dsp.id_detalle_solicitud_producto = tipomodificacion.id_detalle_solicitud_producto INTO solictudesproducto;

											 avalidacion := array_append(avalidacion, solictudesproducto.contador);

										END IF;
										
										IF(tipomodificacion.codigo_modificacion = 'modificarDeclaracionVenta') THEN

											SELECT 
												CASE WHEN (COUNT(dv.id_denominacion_venta) > 0) THEN 1 ELSE 0 END AS contador
											FROM 
												g_modificacion_productos.denominaciones_ventas dv
											WHERE
												dv.id_detalle_solicitud_producto = tipomodificacion.id_detalle_solicitud_producto INTO denominacionventa;

											 avalidacion := array_append(avalidacion, denominacionventa.contador);

										END IF;
										
										IF(tipomodificacion.codigo_modificacion = 'modificarClasificacionProducto') THEN

										SELECT 
											CASE WHEN (COUNT(cp.id_clasificacion_producto) > 0) THEN 1 ELSE 0 END AS contador
										FROM 
											g_modificacion_productos.clasificacion_producto cp
										WHERE
											cp.id_detalle_solicitud_producto = tipomodificacion.id_detalle_solicitud_producto INTO clasificacionproducto;

										 avalidacion := array_append(avalidacion, clasificacionproducto.contador);

									END IF;
									
									END LOOP;
									
									avalidacion := ARRAY (SELECT DISTINCT UNNEST(avalidacion));
						
									IF (array_length(avalidacion, 1) = 1) THEN				

										IF (1 = ANY (avalidacion)) THEN
											resultado := 1;
										ELSE
											resultado := 0;
										END IF;
										
									ELSE
						
										resultado := 0;
									
									END IF;
						
						RAISE NOTICE '%', resultado;
						
			RETURN resultado;

		END
		
	
$$;

alter function f_verificar_registros(integer) owner to postgres;

