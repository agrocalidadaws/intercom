create function proceso_migracion_catastro() returns integer
    language plpgsql
as
$$
DECLARE contador INTEGER:=0;
DECLARE identificadorvacuna record;
BEGIN
-- Crear catastro (C´) prima con solo los registros que cumplen esa fecha de nacimiento antes de 245 días
   CREATE TEMP TABLE tmp_catastro (id_catastro_tmp integer, fecha_nacimiento_tmp date) ON COMMIT DROP;
   INSERT INTO tmp_catastro SELECT c.id_catastro, c.fecha_nacimiento 
                            FROM g_catastro.catastros c 
                            WHERE to_char(c.fecha_nacimiento,'YYYY-MM-DD')::date < (current_date - interval '245 days');  

--Crear Detalle catastro (DC') prima con todos los registros
   DROP TABLE IF EXISTS g_catastro.log_detalle_catastros;
   CREATE TABLE g_catastro.log_detalle_catastros AS 
                SELECT id_detalle_catastro, id_catastro, identificador_producto, secuencial, identificador_unico_producto, estado_registro, observacion 
                FROM g_catastro.detalle_catastros;
	
   SELECT count(*) INTO contador FROM g_catastro.log_detalle_catastros;
   RAISE NOTICE 'TOTAL HISTORICA  ESPEJO %', contador;

   SELECT count(*) INTO contador FROM g_catastro.log_detalle_catastros  where estado_registro = 'eliminado';
   RAISE NOTICE 'TOTAL DE ELIMINADOS HISTORICA - ANTES DEL PROCESO %', contador;

   SELECT count(*) INTO contador FROM g_catastro.log_detalle_catastros where estado_registro = 'activo';
   RAISE NOTICE 'TOTAL DE ACTIVOS HISTORICA - ANTES DEL PROCESO %', contador;


--Actualizar en DC' los eliminados en base a C'
   UPDATE g_catastro.log_detalle_catastros SET estado_registro = 'eliminado' WHERE id_catastro in (SELECT tc.id_catastro_tmp FROM tmp_catastro tc); 
   SELECT count(*) INTO contador FROM g_catastro.log_detalle_catastros WHERE estado_registro = 'eliminado';
   RAISE NOTICE 'TOTAL DE ELIMINADOS DE TABLA HISTÓRICA - CON ACTUALIZACIÓN  MAYOR A 245 DIAS DE VIDA:  %', contador;

--Eliminar en DC' los estados activos
   SELECT count(*) INTO contador FROM g_catastro.log_detalle_catastros  WHERE estado_registro = 'activo';
   RAISE NOTICE 'TOTAL DE ACTIVOS DE TABLA HISTÓRICA - CON ACTUALIZACIÓN 245 DIAS: %', contador;
   DELETE FROM g_catastro.log_detalle_catastros WHERE estado_registro = 'activo';

  
-- actualización en detallecatastros   

   SELECT count(*) INTO contador FROM g_catastro.detalle_catastros;
    RAISE NOTICE 'TOTAL ORIGINAL - ANTES DEL PROCESO %', contador; 

   SELECT count(*) into contador FROM g_catastro.log_detalle_catastros;
   RAISE NOTICE 'TOTAL DE ELIMINADOS QUE VOY A BORRAR EN ORIGINAL %', contador;
   
    
   SELECT count(*) INTO contador FROM g_catastro.detalle_catastros where estado_registro = 'activo';
   RAISE NOTICE 'TOTAL DE ACTIVOS ORIGINAL - ANTES DEL PROCESO %', contador;  


   DELETE FROM g_catastro.detalle_catastros dc WHERE dc.estado_registro = 'eliminado';

   DELETE FROM g_catastro.detalle_catastros dc USING g_catastro.log_detalle_catastros ldc WHERE dc.id_detalle_catastro = ldc.id_detalle_catastro;
   SELECT count(*) INTO contador FROM g_catastro.detalle_catastros where estado_registro = 'activo';
   RAISE NOTICE 'TOTAL DE ACTIVOS ORIGINAL DESPUES DEL PROCESO %', contador;
 

RETURN contador;
  END;
$$;

alter function proceso_migracion_catastro() owner to postgres;

