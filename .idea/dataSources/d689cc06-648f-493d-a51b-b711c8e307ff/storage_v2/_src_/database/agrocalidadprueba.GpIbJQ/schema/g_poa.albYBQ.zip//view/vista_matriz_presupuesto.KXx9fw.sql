create view vista_matriz_presupuesto
            (objetivo, id_objetivo, proceso, id_proceso, subproceso, id_subproceso, actividad, codigo_actividad,
             fecha_creacion, id_area, nombre, codigo_item, nombreitem, detalle_gasto, estado, enero, febrero, marzo,
             abril, mayo, junio, julio, agosto, septiembre, octubre, noviembre, diciembre, id_item, anio)
as
SELECT ob.descripcion AS objetivo,
       pl.id_objetivo,
       pr.descripcion AS proceso,
       pl.id_proceso,
       su.descripcion AS subproceso,
       pl.id_subproceso,
       ac.descripcion AS actividad,
       pl.codigo_actividad,
       mp.fecha_creacion,
       fu.id_area,
       ar.nombre,
       mp.codigo_item,
       ip.descripcion AS nombreitem,
       mp.detalle_gasto,
       mp.estado,
       mp.enero,
       mp.febrero,
       mp.marzo,
       mp.abril,
       mp.mayo,
       mp.junio,
       mp.julio,
       mp.agosto,
       mp.septiembre,
       mp.octubre,
       mp.noviembre,
       mp.diciembre,
       pl.id_item,
       pl.anio
FROM g_poa.planta pl,
     g_poa.objetivos_estrategicos ob,
     g_poa.procesos pr,
     g_poa.subprocesos su,
     g_poa.actividades ac,
     g_estructura.funcionarios fu,
     g_estructura.area ar,
     g_poa.matriz_presupuesto mp,
     g_poa.item_presupuestario ip
WHERE pl.id_objetivo = ob.id_objetivo
  AND pl.id_proceso = pr.id_proceso
  AND pl.id_subproceso = su.id_subproceso
  AND pl.id_actividad = ac.id_actividad
  AND pl.identificar_usuario::text = fu.identificador::text
  AND fu.id_area::text = ar.id_area::text
  AND mp.id_item_planta = pl.id_item
  AND mp.codigo_item::text = ip.codigo::text
  AND (mp.estado = ANY (ARRAY [1, 2, 3, 4]))
  AND pl.estado = 4;

alter table vista_matriz_presupuesto
    owner to postgres;

