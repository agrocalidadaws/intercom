create function funcion_agregar_cantidad_suero() returns trigger
    language plpgsql
as
$$ 
BEGIN
	IF (TG_OP = 'INSERT') THEN
		PERFORM g_movilizacion_suero.funcion_insertar_cantidad_suero(NEW.id_produccion, NEW.cantidad_suero_produccion);	
	END IF;
	RETURN NEW;
	END; 
	
$$;

alter function funcion_agregar_cantidad_suero() owner to postgres;

