create function codigositio() returns text
    language plpgsql
as
$$
DECLARE
  sitio record;
  _secuencial character varying;
BEGIN
FOR sitio in (SELECT * FROM g_operadores.sitios) 
	LOOP
		_secuencial := (SELECT COALESCE(MAX(CAST(codigo as  numeric(5))),0)+1 valor FROM g_operadores.sitios s WHERE s.identificador_operador = sitio.identificador_operador and upper(s.provincia) = upper(sitio.provincia));

		_secuencial = lpad(_secuencial,2,'0');
		UPDATE g_operadores.sitios set codigo = _secuencial WHERE id_sitio = sitio.id_sitio;		
	END LOOP;
	RETURN sitio;
END
$$;

alter function codigositio() owner to postgres;

