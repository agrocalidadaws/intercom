create function planificacion_anual(_objetivo_estrategico integer, _n2 text, _objetivo_especifico integer, _n4 text, _objetivo_operativo integer, _gestion text, _proceso integer, _componente integer, _actividad integer, _provincia integer, _anio integer, _estado text, _tipo text) returns SETOF g_programacion_presupuestaria.vista_planificacion_anual
    language plpgsql
as
$$
DECLARE
	query text;
BEGIN	
	return query EXECUTE '	
		SELECT
			*
		FROM 
			g_programacion_presupuestaria.vista_planificacion_anual
		WHERE 		        
			($1 is NULL or id_objetivo_estrategico = $1) and 
			($2 is NULL or id_area_n2 = $2) and 
			($3 is NULL or id_objetivo_especifico = $3) and 
			($4 is NULL or id_area_n4 = $4) and 
			($5 is NULL or id_objetivo_operativo = $5) and 
			($6 is NULL or id_area_unidad = $6) and 
			($7 is NULL or id_proceso_proyecto = $7) and 
			($8 is NULL or id_componente = $8) and
			($9 is NULL or id_actividad = $9) and
			($10 is NULL or id_provincia = $10) and
			($11 is NULL or anio = $11) and
			($12 is NULL or estado = $12) and
			($13 is NULL or tipo = $13)
			
		ORDER BY
			area_n2, area_n4, gestion, proceso_proyecto, componente, actividad'
			
		using _objetivo_estrategico, _n2, _objetivo_especifico, _n4,_objetivo_operativo, _gestion,_proceso, _componente, _actividad, _provincia, _anio, _estado, _tipo;
	
END;
$$;

alter function planificacion_anual(integer, text, integer, text, integer, text, integer, integer, integer, integer, integer, text, text) owner to postgres;

