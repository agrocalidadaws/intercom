create function serie_arete(integer, integer, integer, timestamp without time zone, timestamp without time zone) returns integer
    language plpgsql
as
$$
  DECLARE
     
     -- Declare aliases for function arguments.
	id_vacuna_animal ALIAS FOR $1;
	serie_inicio ALIAS FOR $2;
	serie_fin ALIAS FOR $3;
	fecha_vacunacion ALIAS FOR $4;
	fecha_vencimiento ALIAS FOR $5;
 
  BEGIN
     
     -- Add one to the variable result until the value of result is
     -- equal to high_number.
    WHILE serie_inicio <= serie_fin LOOP
       INSERT INTO g_vacunacion_animal.vacuna_animal_aretes(
            id_vacuna_animal, serie, fecha_vacunacion, 
            fecha_vencimiento)
    VALUES (id_vacuna_animal, serie_inicio,fecha_vacunacion,fecha_vencimiento);
      serie_inicio := serie_inicio + 1;
    END LOOP;
    
    RETURN serie_inicio;
  END;
$$;

alter function serie_arete(integer, integer, integer, timestamp, timestamp) owner to postgres;

