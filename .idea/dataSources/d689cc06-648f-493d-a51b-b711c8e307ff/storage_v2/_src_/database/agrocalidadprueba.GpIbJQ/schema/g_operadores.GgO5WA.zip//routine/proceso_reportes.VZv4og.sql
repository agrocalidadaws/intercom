create function proceso_reportes() returns integer
    language plpgsql
as
$$
DECLARE contador INTEGER:=0;
DECLARE identificadorreg record;
BEGIN
-- Crear catastro (C´) prima con solo los registros que cumplen esa fecha de nacimiento antes de 245 días
   CREATE TEMP TABLE tmp_reporte (identificador_operador character varying , nombre_operador character varying, provincia character varying, canton character varying, parroquia character varying, 
				correo character varying, telefono character varying, celular character varying, id_area character varying, tipo_operacion character varying, id_tipo_operacion integer, nombre_producto character varying); --ON COMMIT DROP;
   INSERT INTO tmp_reporte SELECT distinct o.identificador, case when o.razon_social = '' then o.nombre_representante ||' '|| o.apellido_representante else RTRIM(REPLACE(REPLACE(REPLACE(o.razon_social,chr(9),''),chr(10),''),chr(13),'')) end nombre_operador,
				o.provincia, 	o.canton,	o.parroquia,	o.correo,	o.telefono_uno ||'-'|| o.telefono_dos as telefonos,	o.celular_uno ||'-'||o.celular_dos as celulares,tp1.id_area, tp1.nombre, tp1.id_tipo_operacion
                           FROM g_operadores.operadores o 
				--INNER JOIN g_operadores.sitios s ON s.identificador_operador = o.identificador
				--INNER JOIN g_operadores.areas a ON a.id_sitio = s.id_sitio
				--INNER JOIN g_operadores.productos_areas_operacion pao ON pao.id_area = a.id_area
				INNER JOIN g_operadores.operaciones op1 ON op1.identificador_operador = o.identificador
				INNER JOIN g_catalogos.tipos_operacion tp1 ON tp1.id_tipo_operacion = op1.id_tipo_operacion
                           WHERE
				op1.estado = 'registrado'
				and tp1.id_area IN ('IAV','IAP','IAF','CGRIA','SA','SV')
				and tp1.codigo = 'PRO';
				--and op1.identificador_operador = '1790319857001';

			FOR identificadorreg in (SELECT identificador_operador, id_area, id_tipo_operacion from tmp_reporte)
			   LOOP
			     
			   UPDATE tmp_reporte SET
				nombre_producto = (
						SELECT 
						array_to_string(array_agg(distinct pr.nombre_comun),', ') as nombre_producto
						FROM
						g_operadores.operaciones op 
						INNER JOIN g_catalogos.productos pr ON pr.id_producto = op.id_producto
						INNER JOIN g_catalogos.tipos_operacion top ON top.id_tipo_operacion = op.id_tipo_operacion
						WHERE 
						op.id_tipo_operacion = identificadorreg.id_tipo_operacion
						and op.identificador_operador = identificadorreg.identificador_operador
						and top.id_area = identificadorreg.id_area)
			WHERE identificador_operador = identificadorreg.identificador_operador
			and id_tipo_operacion = identificadorreg.id_tipo_operacion
			and id_area = identificadorreg.id_area;
			    
							      
			   END LOOP;
			

 RETURN contador;
  END;
$$;

alter function proceso_reportes() owner to postgres;

