create function mostrar_consolidado(_localizacion text, _placa text, _fecha_inicio timestamp without time zone, _fecha_fin timestamp without time zone) returns SETOF g_transportes.consolidado
    language plpgsql
as
$$
DECLARE
	query text;
BEGIN	
	return query EXECUTE '

			SELECT 
				v.placa,
				v.numero_motor,
				v.numero_chasis,
				coalesce((SELECT 
						SUM(c.valor_liquidacion) 
					FROM 
						g_transportes.combustible c 
					WHERE 
						v.placa = c.placa
						and ($1 is NULL or c.placa like $1)
						and ($2 is NULL or c.fecha_solicitud >= $2)  
						and ($3 is NULL or c.fecha_solicitud <= $3)
						and ($4 is NULL or $4 = c.localizacion)),0) as valorCombustible,
				coalesce((SELECT 
						SUM(m.valor_liquidacion) 
					FROM 
						g_transportes.mantenimientos m 
					WHERE 
						v.placa = m.placa
						and ($1 is NULL or m.placa like $1)
						and ($2 is NULL or m.fecha_solicitud >= $2)  
						and ($3 is NULL or m.fecha_solicitud <= $3) 
						and ($4 is NULL or $4 = m.localizacion)),0) as valorMantenimiento
			FROM 
				g_transportes.vehiculos v
			WHERE 
				($1 is NULL or v.placa like $1)
			GROUP BY
				v.placa
			ORDER BY
				v.placa'
			
		using _placa,_fecha_inicio,_fecha_fin,_localizacion;
	
END;
$$;

alter function mostrar_consolidado(text, text, timestamp, timestamp) owner to postgres;

