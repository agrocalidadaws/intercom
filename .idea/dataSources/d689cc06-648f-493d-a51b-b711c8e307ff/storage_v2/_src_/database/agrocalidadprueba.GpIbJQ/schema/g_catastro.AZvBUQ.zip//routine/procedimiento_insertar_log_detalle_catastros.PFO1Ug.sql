create function procedimiento_insertar_log_detalle_catastros() returns trigger
    language plpgsql
as
$$ 
BEGIN
	
	PERFORM g_catastro.funcion_insertar_log_detalle_catastros(NEW.id_detalle_catastro, NEW.id_catastro, NEW.identificador_producto, NEW.secuencial, NEW.identificador_unico_producto, NEW.estado_registro, NEW.observacion);	
	
RETURN NEW;
END; 

	
$$;

alter function procedimiento_insertar_log_detalle_catastros() owner to postgres;

