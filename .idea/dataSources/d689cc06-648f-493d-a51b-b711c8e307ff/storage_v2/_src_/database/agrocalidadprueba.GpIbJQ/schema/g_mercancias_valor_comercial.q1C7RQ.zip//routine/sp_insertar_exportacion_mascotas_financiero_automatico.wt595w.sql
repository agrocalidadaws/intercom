create procedure sp_insertar_exportacion_mascotas_financiero_automatico(INOUT json_parametro json)
    language plpgsql
as
$$
/*
-------------------------------------------------------------------------
--  [g_mercancias_valor_comercial.sp_insertar_exportacion_mascotas_financiero_automatico]
--               
--  procedimiento que se encarga de realizar el proceso de ingreso las solicitudes de exportacion 
--  de mascotas mercancia sin valor comercial en el financiero_automatico, cabecera detalle
--
--  VERSION		AUTOR					FECHA			HU			                           
--	1			Kleber Armijos		25-01-2024	 Control de cambios funcional Exportación e Importación de 
--												 de mascotas edición N°5
-------------------------------------------------------------------------
*/
DECLARE
	tipo_solicitud_parametro VARCHAR := json_parametro->>'tipo_solicitud';
    estado_parametro VARCHAR := json_parametro->>'estado';
	rcrd_solicitudes_exportacion_pago record;
	ids_solicitudes INT[];
  	cursor_solicitudes  CURSOR  For
       SELECT 
   		id_solicitud,
   		tipo_solicitud,
   		estado,
   		identificador_operador,
  		forma_pago
   	FROM g_mercancias_valor_comercial.solicitudes
   	WHERE 
   		tipo_solicitud= json_parametro->>'tipo_solicitud'
   		AND estado = json_parametro->>'estado'
		AND forma_pago ='saldo';
	vvalor_servicio NUMERIC;
	vconcepto_servicio VARCHAR;
	vid_servicio INTEGER;
	vid_financiero_cabecera INTEGER;
	vtipo_solicitud_nuevo_nombre VARCHAR;
  no_error BOOLEAN ;
  vSQLERRM text;
 
BEGIN
	
 BEGIN   -- inicio transanccion
	  no_error:=TRUE;
			--RAISE NOTICE 'El valor de clave_a_mostrar es: %',json_data;
			--1.- seleccionar todas las solicitudes de exportacion de mascotas que esten en estado pago.
			--2.-luego actualizo el estado de todas las solicitudes a generarOrden
			--3.- Obtengo el tarifario de la tabla g_financiero.servicios con el codigo y el idArea est mando quemado
			--4.- luego envio a guardar a g_financiero_automatico.financiero_cabecera 
			--5.- luego envio a guardar a g_financiero_automatico.financiero_detalle
			IF json_parametro->>'tipoAccion' = 'procesoMascota' THEN
			
				SELECT ARRAY_AGG(id_solicitud)--la logica es seleccionar los ids que cumplen esa condicion 
					INTO ids_solicitudes
				FROM g_mercancias_valor_comercial.solicitudes
				WHERE 
				tipo_solicitud = json_parametro->>'tipo_solicitud'
				AND estado = json_parametro->>'estado'
				AND forma_pago='saldo';
				SELECT valor ,concepto,id_servicio
				INTO vvalor_servicio,vconcepto_servicio,vid_servicio
				FROM g_financiero.servicios
				WHERE codigo=  json_parametro->>'codigoTarifario'
				AND id_area= json_parametro->>'idArea';
				
				vtipo_solicitud_nuevo_nombre:= json_parametro->>'tipo_solicitud_nuevo_nombre';
				
 				OPEN cursor_solicitudes; --abro el cursor
 					LOOP
 					   FETCH   FROM cursor_solicitudes INTO rcrd_solicitudes_exportacion_pago;
						EXIT WHEN NOT FOUND;	 
   						INSERT INTO g_financiero_automatico.financiero_cabecera --INSERTO PAPA
   						  (total_pagar, id_vue, tipo_solicitud, metodo_pago,estado,tipo_proceso)
   						VALUES
   						  (
   						  vvalor_servicio,
   						  rcrd_solicitudes_exportacion_pago.id_solicitud,
   						  vtipo_solicitud_nuevo_nombre,
   						  rcrd_solicitudes_exportacion_pago.forma_pago,
   						  'Por atender',
   						  'factura'
   						  )RETURNING id_financiero_cabecera INTO vid_financiero_cabecera ;
						  
   						INSERT INTO g_financiero_automatico.financiero_detalle --INSERTO HIJO
   						  (id_financiero_cabecera, id_servicio, concepto_orden,  
   						  cantidad, precio_unitario, descuento, iva, total)
   						VALUES
   						  (
   							vid_financiero_cabecera,
   							vid_servicio,
   							vconcepto_servicio,
   							1,
   							vvalor_servicio,
   							0,
   							0,
   					        vvalor_servicio);
							--actualizo controladamente
						UPDATE g_mercancias_valor_comercial.solicitudes 
  							SET estado = json_parametro->>'estadoNuevo'
  							WHERE id_solicitud = rcrd_solicitudes_exportacion_pago.id_solicitud;
 					END LOOP;
 				CLOSE cursor_solicitudes;--cierro el cursos u cursos abierto siempre se debe de cerrar
				
                 IF ids_solicitudes IS NOT NULL AND array_length(ids_solicitudes, 1) IS NOT NULL THEN
                 json_parametro =( 
 						   SELECT concat('{"Error":"0",
										   "Mensaje":"Datos Procesados correctamente!!",
										   "DatoProcesados":"Estas solicitudes fueron Procesadas', array_to_json(ids_solicitudes),'"
										 }
										')::json);
                 ELSE
                 json_parametro =( 
 						   SELECT concat('{"Error":"0",
										   "Mensaje":"Datos Procesados correctamente!!",
										   "DatoProcesados":"Ninguno"
										 }
										')::json);
                 END IF;
			ELSE						--queda abierto para otro proceso
			END IF;-- fin SP
			
			
		  EXCEPTION
		 
    WHEN others THEN
	  no_error:=FALSE;
      ROLLBACK;
  vSQLERRM :=SQLERRM;
  END ;
  	--RAISE NOTICE 'Datos insertados correctamente: %',existe_error;
	IF no_error THEN
		COMMIT;
 		ELSE
		  json_parametro := (
			  SELECT 
				CASE 
				  WHEN vSQLERRM IS NULL OR vSQLERRM = '' THEN
					concat('{"Error":"1", "Mensaje":"Error Datos No Registrados!!","Valor": "', vSQLERRM,'"}')::json
				END
   		 );
		RAISE NOTICE 'ingreso por el else rolback: %','OK';
		json_parametro := (
			  SELECT 
				CASE 
				  WHEN vSQLERRM IS NULL OR vSQLERRM = '' THEN
					concat('{"Error":"1", "Mensaje":"Error Datos No Registrados!!","Valor": "', vSQLERRM,'"}')::json
			else
			concat('{"Error":"1", "Mensaje":"Error Datos No Registradoselse !!","Valor": "', vSQLERRM,'"}')::json
				END
   		 );
 	 	ROLLBACK   ;
	END IF;
  	
END;
$$;

alter procedure sp_insertar_exportacion_mascotas_financiero_automatico(inout json) owner to postgres;

