create function fs_reporte_centros_acopio(pfecha_inicio date, pfecha_inicio2 date) returns SETOF json
    language plpgsql
as
$$
/*
-------------------------------------------------------------------------
--  [g_operadores.fs_reporte_centros_acopio]
--               
--  Esta funcion se encarga de devolver un json en un formato especifico GeoJson
--
--  VERSION		AUTOR					FECHA			HU			                           
--	1			Kleber Armijos		01-30-2024			MAG-CGINA-2024-0005-OF             
-------------------------------------------------------------------------
*/
BEGIN
return query
	WITH OperadorInfo AS (
    SELECT
        o.identificador,
        RTRIM(REPLACE(REPLACE(REPLACE(o.razon_social, CHR(9), ''), CHR(10), ''), CHR(13), '')) AS razon_social,
        o.nombre_representante || ' ' || o.apellido_representante AS nombre_representante,
        o.telefono_uno || '-' || o.telefono_dos AS telefonos,
        o.celular_uno || '-' || o.celular_dos AS celulares,
        REPLACE(REPLACE(REPLACE(o.correo, CHR(9), ''), CHR(10), ''), CHR(13), '') AS correo,
        REPLACE(REPLACE(REPLACE(pr.nombre_comun, CHR(9), ''), CHR(10), ''), CHR(13), '') AS nombre_comun,
        stp.nombre AS subtipo_producto,
        tpr.nombre AS tipo_producto,
        REPLACE(REPLACE(REPLACE(tp.nombre, CHR(9), ''), CHR(10), ''), CHR(13), '') AS tipo_operacion,
        op.fecha_creacion,
        a.superficie_utilizada || ' ' || ap.unidad_medida AS superficie_utilizada,
        REPLACE(REPLACE(REPLACE(s.direccion, CHR(9), ''), CHR(10), ''), CHR(13), '') AS direccion_sitio,
        REPLACE(REPLACE(REPLACE(s.telefono, CHR(9), ''), CHR(10), ''), CHR(13), '') AS telefono,
        REPLACE(REPLACE(REPLACE(s.referencia, CHR(9), ''), CHR(10), ''), CHR(13), '') AS referencia,
        s.parroquia,
        s.canton,
        s.provincia,
        s.latitud,
        s.longitud,
        s.superficie_total || ' ' || 'm2' AS superficie_total
    FROM
        g_operadores.operadores o
        INNER JOIN g_operadores.sitios s ON s.identificador_operador = o.identificador
        INNER JOIN g_operadores.areas a ON a.id_sitio = s.id_sitio
        INNER JOIN g_operadores.productos_areas_operacion pao ON pao.id_area = a.id_area
        INNER JOIN g_operadores.operaciones op ON op.id_operacion = pao.id_operacion
        INNER JOIN g_catalogos.tipos_operacion tp ON tp.id_tipo_operacion = op.id_tipo_operacion
        INNER JOIN g_catalogos.areas_operacion ap ON ap.id_tipo_operacion = tp.id_tipo_operacion
        LEFT JOIN g_catalogos.productos pr ON pr.id_producto = op.id_producto
        LEFT JOIN g_catalogos.subtipo_productos stp ON stp.id_subtipo_producto = pr.id_subtipo_producto
        LEFT JOIN g_catalogos.tipo_productos tpr ON tpr.id_tipo_producto = stp.id_tipo_producto
    WHERE
        tp.id_area || tp.codigo IN ('SVACO')
        AND op.estado NOT IN ('noHabilitado')
        AND op.fecha_creacion BETWEEN $1 and $2 --'2023-01-01 00:00:00' AND '2023-01-31 23:59:59'
)
SELECT json_agg(json_build_object(
    'identificador', identificador,
    'razon_social', razon_social,
    'nombre_representante', nombre_representante,
    'telefonos', telefonos,
    'celulares', celulares,
    'correo', correo,
    'nombre_comun', nombre_comun,
    'subtipo_producto', subtipo_producto,
    'tipo_producto', tipo_producto,
    'tipo_operacion', tipo_operacion,
    'fecha_creacion', fecha_creacion,
    'superficie_utilizada', superficie_utilizada,
    'direccion_sitio', direccion_sitio,
    'telefono', telefono,
    'referencia', referencia,
    'parroquia', parroquia,
    'canton', canton,
    'provincia', provincia,
    'latitud', latitud,
    'longitud', longitud,
    'superficie_total', superficie_total
)) AS resultado_json
FROM OperadorInfo;

END;
$$;

alter function fs_reporte_centros_acopio(date, date) owner to postgres;

