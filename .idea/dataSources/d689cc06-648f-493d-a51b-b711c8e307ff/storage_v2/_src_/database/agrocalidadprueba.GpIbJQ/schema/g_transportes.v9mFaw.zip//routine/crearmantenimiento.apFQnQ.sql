create function crearmantenimiento(_numero character varying, _placa text, _kilometraje_actual double precision, _localizacion text, _id_vehiculo integer) returns void
    language plpgsql
as
$$
DECLARE
BEGIN
	INSERT INTO g_transportes.mantenimientos(id_mantenimiento, motivo,fecha_solicitud, placa,kilometraje,estado,localizacion,tipo, id_vehiculo)
		VALUES (_numero, 'Mantenimiento de los:'|| to_char(_kilometraje_actual, 'FM999999999') , now(), _placa,_kilometraje_actual,1,_localizacion,'Mantenimiento-Preventivo', _id_vehiculo);
		
END;
$$;

alter function crearmantenimiento(varchar, text, double precision, text, integer) owner to postgres;

