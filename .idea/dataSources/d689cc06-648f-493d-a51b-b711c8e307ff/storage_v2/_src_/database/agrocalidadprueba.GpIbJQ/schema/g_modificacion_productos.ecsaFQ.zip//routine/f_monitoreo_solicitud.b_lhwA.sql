create function f_monitoreo_solicitud() returns trigger
    language plpgsql
as
$$
DECLARE _id_solicitud_destino INTEGER;
BEGIN

	IF (NEW.estado_solicitud_producto = OLD.estado_solicitud_producto) THEN
		DELETE FROM 
			g_monitoreo_solicitudes.solicitudes
		WHERE
			nombre_tabla_origen = 'g_modificacion_productos.solicitudes_productos'
			and nombre_campo_identificar_tabla_origen = 'id_solicitud_producto'
			and id_tabla_origen = NEW.id_solicitud_producto
			and estado_tabla_origen = 'Rechazado';
	END IF;

	IF (NEW.estado_solicitud_producto = 'verificacion') THEN
		_id_solicitud_destino:= (SELECT max(id_pago) FROM g_financiero.orden_pago 
								 WHERE id_solicitud = NEW.id_solicitud_producto::character varying and tipo_solicitud = 'modificacionProductoRia' and estado = '3');

		INSERT INTO 
			g_monitoreo_solicitudes.solicitudes
				(nombre_tabla_origen, nombre_campo_identificar_tabla_origen, id_tabla_origen, nombre_campo_estado_tabla_origen, 
				 estado_tabla_origen, nombre_campo_observacion_tabla_origen, observacion_tabla_origen, nombre_tabla_destino, 
				 nombre_campo_identificador_tabla_destino, id_tabla_destino, nombre_campo_estado_tabla_destino, estado_tabla_destino, 
				 nombre_campo_observacion_tabla_destino, observacion_tabla_destino, fecha_finalizacion) 
		VALUES 
		('g_modificacion_productos.solicitudes_productos', 'id_solicitud_producto', NEW.id_solicitud_producto, 'estado_solicitud_producto',
		'Rechazado', 'observacion', 'Registro en estado rechazado por falta de pago proceso automático', 'g_financiero.orden_pago',
		'id_pago', _id_solicitud_destino, 'estado', '9','observacion_eliminacion', 'Registro en estado eliminado por falta de pago proceso automático',
		 CURRENT_TIMESTAMP + CAST('30 days' AS INTERVAL));
	ELSEIF(NEW.estado_solicitud_producto = 'inspeccion') THEN
		UPDATE g_monitoreo_solicitudes.solicitudes 
		SET estado = 'Atendida'
		WHERE
			estado = 'Por atender' and 
			nombre_tabla_origen = 'g_modificacion_productos.solicitudes_productos' and
			nombre_campo_identificar_tabla_origen = 'id_solicitud_producto' and 
			id_tabla_origen = NEW.id_solicitud_producto;
	END IF;	
	
	RETURN NEW;
END; 
	
$$;

alter function f_monitoreo_solicitud() owner to postgres;

