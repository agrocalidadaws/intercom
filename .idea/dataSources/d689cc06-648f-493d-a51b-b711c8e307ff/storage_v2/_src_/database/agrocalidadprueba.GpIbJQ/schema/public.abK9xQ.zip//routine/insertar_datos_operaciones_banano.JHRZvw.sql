create function insertar_datos_operaciones_banano() returns trigger
    language plpgsql
as
$$

		BEGIN
		
 				INSERT INTO 
 					public.auditoria_operaciones_banano
 					(id,identificador, nombre_sitio, superficie_total, provincia, canton, parroquia,
 					 direccion, telefono, latitud, longitud, tipo_area, superficie_utilizada, nombre_area,
 					 tipo_operacion, producto, estado, codigo_hacienda, fecha_actualizacion,estado_registro)
	 
 				VALUES 
 				(OLD.id, OLD.identificador, OLD.nombre_sitio, OLD.superficie_total, OLD.provincia, OLD.canton, OLD.parroquia,
 					 OLD.direccion, OLD.telefono, OLD.latitud, OLD.longitud, OLD.tipo_area, OLD.superficie_utilizada, OLD.nombre_area,
 					 OLD.tipo_operacion, OLD.producto, OLD.estado, OLD.codigo_hacienda, OLD.fecha_actualizacion,'activo')
    ON CONFLICT (id) DO UPDATE 	SET
	id=OLD.id, identificador=OLD.identificador, nombre_sitio=OLD.nombre_sitio, 
 	superficie_total=OLD.superficie_total,provincia=OLD.provincia, canton=OLD.canton, 
 	parroquia=OLD.parroquia, direccion=OLD.direccion, telefono=OLD.telefono, latitud=OLD.latitud, 
 	longitud=OLD.longitud, tipo_area=OLD.tipo_area, superficie_utilizada=OLD.superficie_utilizada, nombre_area=OLD.nombre_area, 
 	tipo_operacion=OLD.tipo_operacion, producto=OLD.producto, estado=OLD.estado,
 	codigo_hacienda=OLD.codigo_hacienda, fecha_actualizacion=OLD.fecha_actualizacion, estado_registro = 'activo';
	
	RETURN NEW;
END; 		
	
$$;

alter function insertar_datos_operaciones_banano() owner to postgres;

