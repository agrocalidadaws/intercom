create view vista_funcionario
            (identificador, nombre, apellido, genero, estado_civil, cedula_militar, fecha_nacimiento, edad, tipo_sangre,
             identificacion_etnica, nacionalidad_indigena, tiene_discapacidad, carnet_conadis_empleado,
             representante_familiar_discapacidad, carnet_conadis_familiar, tiene_enfermedad_catastrofica,
             nombre_enfermedad_catastrofica, nacionalidad, provincia, canton, domicilio, convencional, celular,
             mail_personal, regimen_laboral, tipo_contrato, coordinacion, direccion, gestion, oficina, nombre_puesto,
             mail_institucional, extension_magap, fecha_inicio, fecha_fin)
as
SELECT DISTINCT fe.identificador,
                fe.nombre,
                fe.apellido,
                fe.genero,
                fe.estado_civil,
                fe.cedula_militar,
                fe.fecha_nacimiento,
                fe.edad,
                fe.tipo_sangre,
                fe.identificacion_etnica,
                fe.nacionalidad_indigena,
                fe.tiene_discapacidad,
                fe.carnet_conadis_empleado,
                fe.representante_familiar_discapacidad,
                fe.carnet_conadis_familiar,
                fe.tiene_enfermedad_catastrofica,
                fe.nombre_enfermedad_catastrofica,
                fe.nacionalidad,
                dc.provincia,
                dc.canton,
                fe.domicilio,
                fe.convencional,
                fe.celular,
                fe.mail_personal,
                dc.regimen_laboral,
                dc.tipo_contrato,
                dc.coordinacion,
                dc.direccion,
                dc.gestion,
                dc.oficina,
                dc.nombre_puesto,
                fe.mail_institucional,
                fe.extension_magap,
                dc.fecha_inicio,
                dc.fecha_fin
FROM g_uath.ficha_empleado fe,
     g_uath.datos_contrato dc,
     g_estructura.funcionarios f
WHERE fe.identificador::text = dc.identificador::text
  AND dc.estado = 1
  AND fe.identificador::text = f.identificador::text;

alter table vista_funcionario
    owner to postgres;

