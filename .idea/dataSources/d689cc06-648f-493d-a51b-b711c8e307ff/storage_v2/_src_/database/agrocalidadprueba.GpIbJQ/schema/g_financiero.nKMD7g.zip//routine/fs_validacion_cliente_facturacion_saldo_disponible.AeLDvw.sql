create function fs_validacion_cliente_facturacion_saldo_disponible(pidentificador_usuario character varying, parea character varying, pcodigotarifario character varying) returns json
    language plpgsql
as
$$

/*
-------------------------------------------------------------------------
--  [g_financiero.fs_validacion_correo_facturacion_saldo_disponible]
--               
--  Esta funcion retorna json mismo que contiene mensaje,saldo, detalle
--
--  VERSION		AUTOR					FECHA			HU	
--	1			Kleber Armijos		25-01-2024	  Funcion generica disponibilidad de saldo
--												  se crea por el funcional funcional Exportación e Importación de 
--												 de mascotas edición N°5
-------------------------------------------------------------------------
*/
DECLARE
	v_resultado json;
BEGIN	

-- paso 1 consulto si el cliente existe
-- paso 2 verifico su estado
-- paso 3 comparo que sea el saldo mayo al estipulado en el tarifario
-- paso 4 armo un json que retorne 
--	1. si el cliente existe
--	2. el saldo que posee es mayor al del tarifario que usa
		
	WITH cte_clientes(identificador_cliente, correo_cliente) AS (
  SELECT identificador, correo 
  FROM g_financiero.clientes
  WHERE identificador =$1--'0992677783001'
) ,
cte_consulta_saldo (identificador, saldo_disponible,id_pago) AS (
  SELECT  identificador_operador,saldo_disponible,    
         MAX(s.id_saldo) OVER (ORDER BY s.id_saldo DESC) 
  FROM g_financiero.saldos s
  WHERE identificador_operador =$1-- '0992677783001'
  LIMIT 1
),cte_consulta_tarifario(valor)as(
select valor from g_financiero.servicios
	where id_area =$2 and codigo=$3 -- pretendo enviar el parametro SA 02.02.006
)
SELECT  
  CASE
    WHEN NOT EXISTS (SELECT *FROM cte_clientes) THEN 
		json_build_object('mensaje', 'Cliente no registrado',
						  'saldo','No tiene',
						  'detalle','Favor Registrarse...!'
						 )
    WHEN (SELECT saldo_disponible FROM cte_consulta_saldo) < (select valor FROM cte_consulta_tarifario )THEN
		  json_build_object('mensaje', 'Cliente encontrado',
							'saldo','Insuficiente',
							'detalle', (SELECT saldo_disponible FROM cte_consulta_saldo))::json
	WHEN NOT EXISTS(SELECT *FROM cte_consulta_saldo) THEN
	json_build_object('mensaje', 'Cliente encontrado',
							'saldo','No',
							'detalle', 'Favor Realizar Su Primera Recarga de Saldo!!')::json
	ELSE
	json_build_object('mensaje', 'Cliente encontrado',
					  'saldo','Suficiente',
					 'detalle', (SELECT saldo_disponible FROM cte_consulta_saldo)
					 )
  END into  v_resultado ;
  return v_resultado;

END;
$$;

alter function fs_validacion_cliente_facturacion_saldo_disponible(varchar, varchar, varchar) owner to postgres;

