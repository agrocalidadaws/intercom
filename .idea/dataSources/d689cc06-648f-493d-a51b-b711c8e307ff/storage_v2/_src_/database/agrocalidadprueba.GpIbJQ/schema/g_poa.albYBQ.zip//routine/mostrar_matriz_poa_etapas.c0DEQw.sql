create function mostrar_matriz_poa_etapas(_area text, _objetivo integer, _proceso integer, _subproceso integer, _actividad text, _estado integer, _anio integer) returns SETOF g_poa.vista_matriz_poa_etapas
    language plpgsql
as
$$
DECLARE
	query text;
BEGIN	
	return query EXECUTE '	
		SELECT
			*
		FROM 
			g_poa.vista_matriz_poa_etapas
		WHERE 
		        
			($1 is NULL or id_area = $1) and 
			($2 is NULL or id_objetivo = $2) and 
			($3 is NULL or id_proceso = $3) and 
			($4 is NULL or id_subproceso = $4) and  
			($5 is NULL or codigo_actividad like $5) and 
			($6 is NULL or estado = $6) and
			($7 is NULL or anio = $7)
			'
		using _area,_objetivo,_proceso, _subproceso,_actividad, _estado, _anio ;
	
END;
$$;

alter function mostrar_matriz_poa_etapas(text, integer, integer, integer, text, integer, integer) owner to postgres;

