create procedure sp_insertar_exportacion_importacion_mascotas(json_data json, INOUT json_parametro json)
    language plpgsql
as
$$
/*
-------------------------------------------------------------------------
--  [g_mercancias_valor_comercial.sp_insertar_exportacion_importacion_mascotas]
--               
--  procedimiento que se encarga de realizar el proceso de ingreso de exportación
--  importación de mascotas mercancia sin valor comercial
--
--  VERSION		AUTOR					FECHA			HU			                           
--	1			Kleber Armijos		25-01-2024	 Control de cambios funcional Exportación e Importación de 
--												 de mascotas edición N°5
-------------------------------------------------------------------------
*/
DECLARE
  json_array_object json;
  key_json_array_object text;
  json_mascota_expo_impo JSON;
  vid_solicitud INTEGER;
  vid_producto_mascota INTEGER;
  vruta_comprobante_veterinatio text;
  json_productos_registrados JSON;
  json_vacunas JSON;
  json_desparasitacion Json;
  fecha timestamp without time zone;
  direccion_destinatario text;
  v_resultado_saldo json;-- variable de tipo json para soportar la consulta de disponiblidad de saldo en la funcion
  json_vacunas_desparasitacion_eliminados JSON;  --estas variables las uso en el update
  json_vacunas_desparasitacion_actualizada json;
  json_vacunas_desparasitaciones_agregadas json;
  json_productos_registrados_actualizados json;
  json_mascota_expo_impo_actualizado json;
  json_vacuna_actualizada json;
  json_desparasitacion_actualizada json;
  json_vacuna_agregada json;
  json_desparasitacion_agregada json;
  json_revision_formulario json;
  json_revision_firma_digital json;
  json_resultado_solicitudes_pago json;
  vid_grupo integer;
  vnumero_serial integer;
  vmensaje_clienta_facturacion_saldo text;
  no_error BOOLEAN ;
  vSQLERRM text;
 
BEGIN

 BEGIN   -- inicio transanccion
	  -- se mantiene el principio de los json claves valor
	  no_error:=TRUE;
			--RAISE NOTICE 'El valor de clave_a_mostrar es: %',json_data;			
				IF json_parametro->>'tipoAccion' = 'I' THEN -- PREGUNTO SI ES INSERCION O ACTULIZACION
					SELECT g_financiero.fs_validacion_cliente_facturacion_saldo_disponible(
						json_data->>'usuario',
						json_parametro->>'idArea',
						json_parametro->>'codigoTarifario'
					) INTO v_resultado_saldo;
				 IF v_resultado_saldo->>'saldo' = 'Suficiente' THEN --si el saldo es suficiente  pasa a insertar
				  IF json_data->>'tipoSolicitud' = 'Exportacion' THEN
					FOR json_mascota_expo_impo IN SELECT  json_data
					  LOOP
                      
					  INSERT INTO g_mercancias_valor_comercial.solicitudes(fecha_solicitud, identificador_operador, tipo_solicitud, nombre_propietario, 
									identificador_propietario, direccion_propietario,nombre_destinatario, direccion_destinatario, id_localizacion_origen_destino, 
									pais_origen_destino, id_uso, nombre_uso,fecha_embarque, id_lugar_control, puesto_control,id_pronvincia_control,nombre_provincia_control,
									 estado,tipo_identificacion_propietario, telefono_propietario, correo_propietario, id_oficina_atencion,
									 temperatura_mascota ,frecuencia_cardiaca , frecuencia_respiratoria ,gusano_barrenador ,parasito_externo,
    								verificacion_edad ,  fecha_valoracion_clinica ,fecha_toma_muestras_anticuerpos ,fecha_resultados_anticuerpo ,
									resultado_anticuerpos,cze_envio_muestra, id_localizacion_transito , nombre_pais_transito,observacion_informacion_solicitud,
									forma_pago									  )
						  VALUES (
							  to_timestamp(to_char(NOW(), 'YYYY-MM-DD HH24:MI:SS'), 'YYYY-MM-DD HH24:MI:SS'),
							  (json_mascota_expo_impo->>'usuario'),
							  json_mascota_expo_impo->>'tipoSolicitud',
							 json_mascota_expo_impo->>'nombrePropietario',
							 json_mascota_expo_impo->>'identificacionPropietario',
							 json_mascota_expo_impo->>'direccionPropietario',
							 json_mascota_expo_impo->>'nombreDestinatario',
							json_mascota_expo_impo->>'direccionDestinatario',
							 (json_mascota_expo_impo->>'pais')::integer,
							 json_mascota_expo_impo->>'nombrePais',
							 (json_mascota_expo_impo->>'uso')::integer,
							  json_mascota_expo_impo->>'nombreUso',
							 (json_mascota_expo_impo->>'fechaEmbarque')::timestamp without time zone,
							 (json_mascota_expo_impo->>'puestoControl')::integer,
							 json_mascota_expo_impo->>'nombrePuestoControl',
							 (json_mascota_expo_impo->>'idProvincia')::integer,
							 json_mascota_expo_impo->>'nombreProvincia',
							 'enviado',
							 json_mascota_expo_impo->>'tipoIdentificacion',
							 json_mascota_expo_impo->>'telefonoPropietario',
							 json_mascota_expo_impo->>'correoPropietario',
							(json_mascota_expo_impo->>'oficinaAtencion')::integer,
							  (json_mascota_expo_impo->>'temperatura')::numeric,
							  (json_mascota_expo_impo->>'frecuenciaCardiaca')::numeric,
							  (json_mascota_expo_impo->>'frecuenciaRespiratoria')::numeric,
							  json_mascota_expo_impo->>'gusanoBarrenador',
							  json_mascota_expo_impo->>'parasitoExterno',
							  (json_mascota_expo_impo->>'verificacionEdad')::integer,
							  (json_mascota_expo_impo->>'fechaInspeccionClinica')::timestamp without time zone,
                              CASE 
                                WHEN (json_mascota_expo_impo->>'fechaTomaMuestra') = '' THEN NULL
                                ELSE (json_mascota_expo_impo->>'fechaTomaMuestra')::timestamp without time zone
                              END,
                              CASE
                                 WHEN (json_mascota_expo_impo->>'fechaResultadoMuestra') = '' THEN NULL
                                 ELSE (json_mascota_expo_impo->>'fechaResultadoMuestra')::timestamp without time zone
                              END,
							   json_mascota_expo_impo->>'resultadoMuestraExamen',
							   json_mascota_expo_impo->>'czeEnvioMuestra',
                              CASE 
                                WHEN (json_mascota_expo_impo->>'paisTransito') = '' THEN NULL
                                ELSE (json_mascota_expo_impo->>'paisTransito')::integer
                              END,
							  json_mascota_expo_impo->>'nombrePaisTransito',
							  json_mascota_expo_impo->>'informacionZoo',
							  'saldo'
							 )RETURNING id_solicitud INTO vid_solicitud;

							 INSERT INTO g_mercancias_valor_comercial.documentos_adjuntos( ruta_vacuna, ruta_veterinario, ruta_anticuerpo, id_solicitud, ruta_autorizacion_min_ambiente, ruta_zoosanitario_exp,ruta_comprobante_veterinario)
							   VALUES ( CASE 
                                            WHEN json_mascota_expo_impo->>'rutaVacuna' IN ('0', 'No se cargó archivo. Extención incorrecta') THEN ''
                                            ELSE json_mascota_expo_impo->>'rutaVacuna'
                                        END,
                                        CASE 
                                            WHEN json_mascota_expo_impo->>'rutaVeterinario' IN ('0', 'No se cargó archivo. Extención incorrecta') THEN ''
                                            ELSE json_mascota_expo_impo->>'rutaVeterinario'
                                        END,
                                        CASE 
                                            WHEN json_mascota_expo_impo->>'rutaAnticuerpos' IN ('0', 'No se cargó archivo. Extención incorrecta') THEN ''
                                            ELSE json_mascota_expo_impo->>'rutaAnticuerpos'
                                        END,
									   vid_solicitud,
									   CASE 
                                            WHEN json_mascota_expo_impo->>'rutaAutMinAmb' IN ('0', 'No se cargó archivo. Extención incorrecta') THEN ''
                                            ELSE json_mascota_expo_impo->>'rutaAutMinAmb'
                                        END,
									   null,
									   json_parametro->>'rutaComprobante'||vid_solicitud||'.pdf'
									  )RETURNING ruta_comprobante_veterinario INTO vruta_comprobante_veterinatio ;	
							 FOR json_productos_registrados  IN   SELECT json_array_elements((json_data->'productosRegistros')::json)
								LOOP
									INSERT INTO
											g_mercancias_valor_comercial.producto_solicitudes(
											id_tipo_producto, nombre_tipo, id_subtipo_producto, nombre_subtipo,	id_producto,
											nombre_producto, sexo, raza, edad, color,id_solicitud,nombre_mascota,peso_mascota,
											numero_chip,fecha_aplicacion_chip,esterilizado,fecha_esterilizacion)
										VALUES ((json_productos_registrados->>'idTipoProducto')::INTEGER,
												json_productos_registrados->>'tipoProducto',
												(json_productos_registrados->>'idSubtipoProducto')::INTEGER,
												json_productos_registrados->>'nombreSubtipoProducto',
												(json_productos_registrados->>'idProducto')::INTEGER,
												json_productos_registrados->>'nombreProducto',
												json_productos_registrados->>'sexo',
												json_productos_registrados->>'raza',
												json_productos_registrados->>'edad',
												json_productos_registrados->>'color',
												vid_solicitud,
												json_productos_registrados->>'nombreAnimal',
												(json_productos_registrados->>'pesoAnimal')::numeric,
												json_productos_registrados->>'chipAnimal',
												json_productos_registrados->>'fechaAplicacionChip',
												(json_productos_registrados->>'esterilizado')::integer,
												json_productos_registrados->>'fechaEsterilizado'
												
												
											   ) RETURNING id_producto_solicitud INTO vid_producto_mascota;
								END LOOP;
							FOR json_array_object  IN  SELECT json_data->'lista'
							 LOOP 
							 	FOR json_vacunas IN SELECT * from json_array_elements((json_array_object->>'datosTablaVacunacion')::json)
									LOOP
										INSERT INTO
											g_mercancias_valor_comercial.vacunas_deparasitacion (
												enfermedad,nombre_vacuna,fecha_vacunacion ,
    											fecha_revacunacion ,fecha_expiracion_farmaco ,
   												lote ,numero_registro ,laboratorio ,tipo_registro,tipo_desparasitacion,fecha_aplicacion_desparasitacion,
												hora_aplicacion_desparasitante,nombre_comercial,fabricante_producto,principio_activo,
												dosis_aplicada,id_producto_solicitud
											)
											VALUES((json_vacunas->>'enfermedad'),
												  json_vacunas->>'nombreVacuna',
												  json_vacunas->>'fechaVacunacion',
												  json_vacunas->>'fechaRevacunacion',
												  json_vacunas->>'fechaExpiracion',
												   json_vacunas->>'lote',
												   json_vacunas->>'numeroRegistro',
												   json_vacunas->>'laboratorio',
												   0,--se envia cero por que es vacunacion y en la tabla recibe 0 vacunacion 1 desparasitacion
												   -1,-- no aplica en ese caso 
												   'N/A',
												   'N/A',
												   'N/A',
												   'N/A',
												   'N/A',
												   'N/A',
												   vid_producto_mascota
												  );

									END LOOP;
								FOR json_desparasitacion IN  SELECT * from   json_array_elements((json_array_object->>'datosTablaDesparacitacion')::json)
									LOOP
 										INSERT INTO g_mercancias_valor_comercial.vacunas_deparasitacion (
												enfermedad,nombre_vacuna,fecha_vacunacion ,
    											fecha_revacunacion ,fecha_expiracion_farmaco ,
   												lote ,numero_registro ,laboratorio ,tipo_registro,tipo_desparasitacion,fecha_aplicacion_desparasitacion,
												hora_aplicacion_desparasitante,nombre_comercial,fabricante_producto,principio_activo,
												dosis_aplicada,id_producto_solicitud
											)
 											VALUES(
												   'N/A',
												   'N/A',
												   'N/A',
												   'N/A',
												   'N/A',
												   'N/A',
												   'N/A',
												   'N/A',
												   1,-- si es desparasitacion va 1
												  (json_desparasitacion->>'tipoDesparasitacion')::INTEGER,
												  json_desparasitacion->>'fechaDesparasitacion',
												  json_desparasitacion->>'horaDesparacitacion',
												  json_desparasitacion->>'nombreDesparasitacion',
												  json_desparasitacion->>'fabricanteProducto',
												  json_desparasitacion->>'principioActivo',
												  json_desparasitacion->>'dosisDesparasitacion',
												vid_producto_mascota
											);
									END LOOP;
							END LOOP;
							
					  END LOOP;--ojo se manda en el commit al final por que  sirve para importaicon y exportacion
					    SELECT g_mercancias_valor_comercial.fs_validacion_solicitudes_creadas_vs_saldo_disponible(--valdio cuantas solicitude tienes en estado pago
						    json_data->>'usuario',
						    json_parametro->>'idArea',--'SA',
                            json_parametro->>'codigoTarifario', --'02.02.006'
                            'TODAS'
					    ) INTO json_resultado_solicitudes_pago;
                     
                          vruta_comprobante_veterinatio = substring(json_parametro->>'rutaComprobante'||vid_solicitud, 'aplicaciones/mvc/modulos/(.*)');
					      json_parametro =( 
 						 	SELECT concat('{"Error":"0",
                                          "Mensaje":"Datos Registrados!!",
                                          "idRegistro":"',vid_solicitud,'",
										  "rutaComprobante":"',vruta_comprobante_veterinatio,'" ,
                                          "Valor": "', v_resultado_saldo->>'detalle', '",
                                          "alerta":"',json_resultado_solicitudes_pago->>'alerta','",
                                          "mensajeSolicitudes":"',json_resultado_solicitudes_pago->>'mensaje','",
                                          "detalleSolicitudes":"',json_resultado_solicitudes_pago->>'detalle','"
                                          }')::json  );
						
				 ELSE  --aqui va la logica de importacion
					no_error:=FALSE;
					--RAISE NOTICE 'aqui va la logica de importacion';
						  json_parametro =( 
 						   SELECT concat('{"Error":"0","Mensaje":"Datos Registrados!!", "Valor": "Datos Registrados Importacion!! ', v_resultado_saldo->>'detalle', '"}')::json  );
			    END IF;
			 ELSIF v_resultado_saldo->>'saldo' = 'Insuficiente' THEN
			 --ojo si es insuno se deja crear se retorna el json con el mensaje  de saldo insuficiente y se termina el proceso 
			 --no se crea clientes ni vergas
							json_parametro =( 
 						  	 SELECT concat('{"Error":"1", "Mensaje":"Saldo Insuficiente!!","Valor": " ', v_resultado_saldo->>'saldo', '"}')::json  );
                             vmensaje_clienta_facturacion_saldo:='Saldo insuficiente, favor recargar saldo!!';
			 ELSIF v_resultado_saldo->>'saldo' = 'No' then -- cuando es cliente pero no tiene saldo registrado
							json_parametro =( 
 						  	 SELECT concat('{"Error":"1", "Mensaje": "Favor recargar saldo!! ', v_resultado_saldo->>'detalle', '"}')::json  );
								 no_error:=FALSE;
                                 vmensaje_clienta_facturacion_saldo:='Saldo insuficiente, favor recargar saldo!!';
			ELSE --este caso es cuando no esta registrado el cliente 
							json_parametro =( 
 						  	 SELECT concat('{"Error":"1", "Valor":"Sin Facturacion!!", "Mensaje": "Favor Registrese en Facturación y Recargue Saldo"}')::json  );
									 no_error:=FALSE;
                                     vmensaje_clienta_facturacion_saldo:='Favor registre su correo de facturación';
			-- esto es cuando el usuario no esta registrado.... de igual manera no se deja crear y se 
			END IF;
			ELSIF json_parametro->>'tipoAccion' = 'U' THEN ---- AQUI HACE EL UPDATE
                   
					IF json_data->>'tipoSolicitud' = 'Exportacion' THEN					
					IF (SELECT COUNT(*) FROM json_array_elements(json_data->'listaEliminados'->'desparasitacionesEliminadas')) > 0 then
  						DELETE FROM g_mercancias_valor_comercial.vacunas_deparasitacion
  						WHERE id_vacuna_desparasitacion IN (
						SELECT valor::integer
							FROM json_array_elements_text(json_data->'listaEliminados'->'desparasitacionesEliminadas') AS valor
  						);					
					END IF;				
					IF (SELECT COUNT(*) FROM json_array_elements(json_data->'listaEliminados'->'vacunasEliminadas')) >0  then 
  					DELETE FROM g_mercancias_valor_comercial.vacunas_deparasitacion
  					WHERE id_vacuna_desparasitacion IN (
   					 SELECT  valor_vacuna::integer 
						FROM json_array_elements_text(json_data->'listaEliminados'->'vacunasEliminadas') AS valor_vacuna
  					);
					END IF;-- termino el proceso de borrar si es que hay 
                    
                   
					FOR json_mascota_expo_impo_actualizado IN SELECT  json_data
						LOOP 
                         
						RAISE NOTICE 'vamos en el for: %',json_mascota_expo_impo_actualizado->>'identificacionPropietario';
						 UPDATE  g_mercancias_valor_comercial.solicitudes
						 SET
						 nombre_propietario=json_mascota_expo_impo_actualizado->>'nombrePropietario',
						 identificador_propietario=json_mascota_expo_impo_actualizado->>'identificacionPropietario',
						 direccion_propietario=json_mascota_expo_impo_actualizado->>'direccionPropietario',
						 nombre_destinatario=json_mascota_expo_impo_actualizado->>'nombreDestinatario',
						 direccion_destinatario=json_mascota_expo_impo_actualizado->>'direccionDestinatario',
						 id_localizacion_origen_destino=(json_mascota_expo_impo_actualizado->>'pais')::integer,
						 pais_origen_destino=json_mascota_expo_impo_actualizado->>'nombrePais',
						 id_uso=(json_mascota_expo_impo_actualizado->>'uso')::integer,
						 nombre_uso=json_mascota_expo_impo_actualizado->>'nombreUso',
						 fecha_embarque=(json_mascota_expo_impo_actualizado->>'fechaEmbarque')::timestamp without time zone,
						 id_lugar_control=(json_mascota_expo_impo_actualizado->>'puestoControl')::integer,
						 puesto_control=json_mascota_expo_impo_actualizado->>'nombrePuestoControl',
						 id_pronvincia_control=(json_mascota_expo_impo_actualizado->>'idProvincia')::integer,
						 nombre_provincia_control=json_mascota_expo_impo_actualizado->>'nombreProvincia',						
						 estado='enviado',
						 tipo_identificacion_propietario=json_mascota_expo_impo_actualizado->>'tipoIdentificacion',
						 telefono_propietario=json_mascota_expo_impo_actualizado->>'telefonoPropietario',
						 correo_propietario=json_mascota_expo_impo_actualizado->>'correoPropietario',
						 id_oficina_atencion=(json_mascota_expo_impo_actualizado->>'oficinaAtencion')::integer,
						 temperatura_mascota=(json_mascota_expo_impo_actualizado->>'temperatura')::numeric,
						 frecuencia_cardiaca=(json_mascota_expo_impo_actualizado->>'frecuenciaCardiaca')::numeric,
						 frecuencia_respiratoria=(json_mascota_expo_impo_actualizado->>'frecuenciaRespiratoria')::numeric,
						 gusano_barrenador=json_mascota_expo_impo_actualizado->>'gusanoBarrenador',
						 parasito_externo=json_mascota_expo_impo_actualizado->>'parasitoExterno',
						 verificacion_edad=(json_mascota_expo_impo_actualizado->>'verificacionEdad')::integer,
						 fecha_valoracion_clinica=(json_mascota_expo_impo_actualizado->>'fechaInspeccionClinica')::timestamp without time zone,
                        fecha_toma_muestras_anticuerpos = CASE 
                                                            WHEN json_mascota_expo_impo_actualizado->>'fechaTomaMuestra' = '' THEN NULL 
                                                            ELSE (json_mascota_expo_impo_actualizado->>'fechaTomaMuestra')::timestamp without time zone 
                                                          END,
                        fecha_resultados_anticuerpo = CASE 
                                                        WHEN json_mascota_expo_impo_actualizado->>'fechaResultadoMuestra' = '' THEN NULL 
                                                        ELSE (json_mascota_expo_impo_actualizado->>'fechaResultadoMuestra')::timestamp without time zone 
                                                      END,
						-- fecha_toma_muestras_anticuerpos=(json_mascota_expo_impo_actualizado->>'fechaTomaMuestra')::timestamp without time zone,
						 --fecha_resultados_anticuerpo=(json_mascota_expo_impo_actualizado->>'fechaResultadoMuestra')::timestamp without time zone,
						 resultado_anticuerpos=json_mascota_expo_impo_actualizado->>'resultadoMuestraExamen',
						 cze_envio_muestra=json_mascota_expo_impo_actualizado->>'czeEnvioMuestra',
                        id_localizacion_transito = CASE 
                                                        WHEN json_mascota_expo_impo_actualizado->>'paisTransito' = '' THEN NULL 
                                                        ELSE (json_mascota_expo_impo_actualizado->>'paisTransito')::integer 
                                                   END,
						-- id_localizacion_transito=(json_mascota_expo_impo_actualizado->>'paisTransito')::integer,
						 nombre_pais_transito=json_mascota_expo_impo_actualizado->>'nombrePaisTransito',
						 observacion_informacion_solicitud=json_mascota_expo_impo_actualizado->>'informacionZoo' 
						 WHERE id_solicitud=(json_mascota_expo_impo_actualizado->>'id_solicitud')::integer;
						UPDATE g_mercancias_valor_comercial.documentos_adjuntos --actualizO TABLA DE DOCUMENTO
						SET 
						ruta_vacuna = CASE 
                                        WHEN json_mascota_expo_impo_actualizado->>'rutaVacuna' IN ('0', 'No se cargó archivo. Extención incorrecta', '') THEN NULL
                                        ELSE json_mascota_expo_impo_actualizado->>'rutaVacuna'
                                      END,
                        ruta_veterinario = CASE 
                                             WHEN json_mascota_expo_impo_actualizado->>'rutaVeterinario' IN ('0', 'No se cargó archivo. Extención incorrecta', '') THEN NULL
                                             ELSE json_mascota_expo_impo_actualizado->>'rutaVeterinario'
                                           END,
                        ruta_anticuerpo = CASE 
                                            WHEN json_mascota_expo_impo_actualizado->>'rutaAnticuerpos' IN ('0', 'No se cargó archivo. Extención incorrecta', '') THEN NULL
                                            ELSE json_mascota_expo_impo_actualizado->>'rutaAnticuerpos'
                                          END,
                         ruta_autorizacion_min_ambiente = CASE 
                                                            WHEN json_mascota_expo_impo_actualizado->>'rutaAutMinAmb' IN ('0', 'No se cargó archivo. Extención incorrecta', '') THEN NULL
                                                            ELSE json_mascota_expo_impo_actualizado->>'rutaAutMinAmb'
                                                          END
						WHERE id_solicitud=(json_mascota_expo_impo_actualizado->>'id_solicitud')::integer;
						FOR json_productos_registrados_actualizados  IN   SELECT json_array_elements((json_data->'productosRegistros')::json)--ACTUALIZACION MASCOTAS
							LOOP
								UPDATE g_mercancias_valor_comercial.producto_solicitudes
								SET 
								id_tipo_producto=(json_productos_registrados_actualizados->>'idTipoProducto')::integer,
								nombre_tipo=json_productos_registrados_actualizados->>'tipoProducto',
								id_subtipo_producto=(json_productos_registrados_actualizados->>'idSubtipoProducto')::integer,
								nombre_subtipo=json_productos_registrados_actualizados->>'nombreSubtipoProducto',
								id_producto=(json_productos_registrados_actualizados->>'idProducto')::integer,
								nombre_producto=json_productos_registrados_actualizados->>'nombreProducto',
								sexo=json_productos_registrados_actualizados->>'sexo',
								raza=json_productos_registrados_actualizados->>'raza',
								edad=json_productos_registrados_actualizados->>'edad',
								color=json_productos_registrados_actualizados->>'color',
								nombre_mascota=json_productos_registrados_actualizados->>'nombreAnimal',
								peso_mascota=(json_productos_registrados_actualizados->>'pesoAnimal')::numeric,
								numero_chip=json_productos_registrados_actualizados->>'chipAnimal',
								fecha_aplicacion_chip=json_productos_registrados_actualizados->>'fechaAplicacionChip',
								esterilizado=(json_productos_registrados_actualizados->>'esterilizado')::integer,
								fecha_esterilizacion=json_productos_registrados_actualizados->>'fechaEsterilizado'
								WHERE	id_producto_solicitud=	(json_productos_registrados_actualizados->>'id_producto_solicitud')::integer;
							END LOOP;
							json_vacunas_desparasitacion_actualizada:=(SELECT json_data->'listaActualizados');
							
							IF (json_vacunas_desparasitacion_actualizada->'vacunasEditadas') IS NOT NULL AND 
  							 json_array_length(json_vacunas_desparasitacion_actualizada->'vacunasEditadas') > 0 THEN
								FOR json_vacuna_actualizada IN SELECT  *from json_array_elements((json_vacunas_desparasitacion_actualizada->>'vacunasEditadas')::json)
									LOOP
                                     
										UPDATE g_mercancias_valor_comercial.vacunas_deparasitacion 
										SET
												enfermedad=json_vacuna_actualizada->>'enfermedad',
												nombre_vacuna=json_vacuna_actualizada->>'nombre_vacuna',
												fecha_vacunacion= json_vacuna_actualizada->>'fecha_vacunacion' ,
    											fecha_revacunacion=json_vacuna_actualizada->>'fecha_revacunacion' ,
												fecha_expiracion_farmaco= json_vacuna_actualizada->>'fecha_expiracion_farmaco',
   												lote= json_vacuna_actualizada->>'lote',
												numero_registro= json_vacuna_actualizada->>'numero_registro',
												laboratorio=json_vacuna_actualizada->>'laboratorio'
												WHERE id_vacuna_desparasitacion=(json_vacuna_actualizada->>'id_vacuna_desparasitacion')::integer;
									END LOOP;
							END IF;
							IF (json_vacunas_desparasitacion_actualizada->'desparasitacionesEditadas') IS NOT NULL AND 
  							 json_array_length(json_vacunas_desparasitacion_actualizada->'desparasitacionesEditadas') > 0 THEN
								FOR json_desparasitacion_actualizada IN SELECT * from json_array_elements((json_vacunas_desparasitacion_actualizada->>'desparasitacionesEditadas')::json)
									LOOP
                                         
 										UPDATE  g_mercancias_valor_comercial.vacunas_deparasitacion 
										SET
												tipo_desparasitacion=(json_desparasitacion_actualizada->>'tipo_desparasitacion')::integer,
												fecha_aplicacion_desparasitacion=json_desparasitacion_actualizada->>'fecha_aplicacion_desparasitacion',
												hora_aplicacion_desparasitante=json_desparasitacion_actualizada->>'hora_aplicacion_desparasitante',
												nombre_comercial=json_desparasitacion_actualizada->>'nombre_comercial',
												fabricante_producto=json_desparasitacion_actualizada->>'fabricante_producto',
												principio_activo=json_desparasitacion_actualizada->>'principio_activo',
												dosis_aplicada=json_desparasitacion_actualizada->>'dosis_aplicada'
												WHERE id_vacuna_desparasitacion=(json_desparasitacion_actualizada->>'id_vacuna_desparasitacion')::integer;
									END LOOP;
							END IF;
							--END LOOP; --1
							
						END LOOP;
						-- aqui agrego las vacuans y desparasiteciones si es que hubieran
						json_vacunas_desparasitaciones_agregadas:= (SELECT json_data->'listaVacunasDesparasitacionAdd');
						IF (json_vacunas_desparasitaciones_agregadas->'vacunaAgregadas') IS NOT NULL AND 
  							 json_array_length(json_vacunas_desparasitaciones_agregadas->'vacunaAgregadas') > 0 THEN
						-- AQUI INSERTO
						FOR json_vacuna_agregada IN SELECT json_array_elements((json_vacunas_desparasitaciones_agregadas->'vacunaAgregadas')::json)
							LOOP
								INSERT INTO
											g_mercancias_valor_comercial.vacunas_deparasitacion (
												enfermedad,nombre_vacuna,fecha_vacunacion ,
    											fecha_revacunacion ,fecha_expiracion_farmaco ,
   												lote ,numero_registro ,laboratorio ,tipo_registro,tipo_desparasitacion,fecha_aplicacion_desparasitacion,
												hora_aplicacion_desparasitante,nombre_comercial,fabricante_producto,principio_activo,
												dosis_aplicada,id_producto_solicitud
											)
											VALUES((json_vacuna_agregada->>'enfermedad'),
												  json_vacuna_agregada->>'nombre_vacuna',
												  json_vacuna_agregada->>'fecha_vacunacion',
												  json_vacuna_agregada->>'fecha_revacunacion',
												  json_vacuna_agregada->>'fecha_expiracion_farmaco',
												   json_vacuna_agregada->>'lote',
												   json_vacuna_agregada->>'numero_registro',
												   json_vacuna_agregada->>'laboratorio',
												   0,--se envia cero por que es vacunacion y en la tabla recibe 0 vacunacion 1 desparasitacion
												   -1,-- no aplica en ese caso 
												   'N/A',
												   'N/A',
												   'N/A',
												   'N/A',
												   'N/A',
												   'N/A',
												  ( json_productos_registrados_actualizados->>'id_producto_solicitud')::integer
												  );

							END LOOP;
						END IF;
						IF (json_vacunas_desparasitaciones_agregadas->'desparasitacionAgregadas') IS NOT NULL AND 
  							 json_array_length(json_vacunas_desparasitaciones_agregadas->'desparasitacionAgregadas') > 0 THEN 
							 --AQUI INSERTO 
						FOR json_desparasitacion_agregada IN SELECT json_array_elements((json_vacunas_desparasitaciones_agregadas->'desparasitacionAgregadas')::json)
							LOOP
							INSERT INTO g_mercancias_valor_comercial.vacunas_deparasitacion (
												enfermedad,nombre_vacuna,fecha_vacunacion ,
    											fecha_revacunacion ,fecha_expiracion_farmaco ,
   												lote ,numero_registro ,laboratorio ,tipo_registro,tipo_desparasitacion,fecha_aplicacion_desparasitacion,
												hora_aplicacion_desparasitante,nombre_comercial,fabricante_producto,principio_activo,
												dosis_aplicada,id_producto_solicitud
											)
 											VALUES(
												   'N/A',
												   'N/A',
												   'N/A',
												   'N/A',
												   'N/A',
												   'N/A',
												   'N/A',
												   'N/A',
												   1,-- si es desparasitacion va 1
												  (json_desparasitacion_agregada->>'tipo_desparasitacion')::INTEGER,
												  json_desparasitacion_agregada->>'fecha_aplicacion_desparasitacion',
												  json_desparasitacion_agregada->>'hora_aplicacion_desparasitante',
												  json_desparasitacion_agregada->>'nombre_comercial',
												  json_desparasitacion_agregada->>'fabricante_producto',
												  json_desparasitacion_agregada->>'principio_activo',
												  json_desparasitacion_agregada->>'dosis_aplicada',
												  (json_productos_registrados_actualizados->>'id_producto_solicitud')::integer
											);
							END LOOP;
						END IF ;
				ELSE --UPDATE IMPORTACION

				END IF; --fin del proceso de actualizacion POR EL ELSE IMPORTACION
				 json_parametro =( 
 						 	SELECT concat('{"Error":"0",
										  "Mensaje":"Datos Actualizados!!",
										  "Valor": "Exito"}')::json  );
			ELSE -- actualizo estados
			-- actulizo el estado desde revicion de formularios e inserto en las tablas de revisionsolicirudes
			json_revision_formulario :=(select json_data);
			IF json_revision_formulario->>'estado' ='pago'THEN 
                SELECT * FROM g_firma_documentos.fs_validacion_firma_digital(json_revision_formulario->>'inspector') INTO json_revision_firma_digital;
                    IF json_revision_firma_digital->>'error'='1'THEN
                    json_parametro =( 
 						 	SELECT concat('{"Error":"1",
										  "Mensaje":"',json_revision_firma_digital->>'detalle','",
										  "Valor": "Exito"}')::json  );
                    ELSE
                    UPDATE  g_mercancias_valor_comercial.solicitudes
						 SET
						 estado =json_revision_formulario->>'estado',
						 observacion= COALESCE(NULLIF(json_revision_formulario->>'observacion', ''), observacion),
						 fecha_emision=now(),
						 detalle_pago='Pago Automatico Con Saldo'
						 where id_solicitud = (json_revision_formulario->>'id_solicitud')::integer;
                INSERT INTO g_revision_solicitudes.asignacion_inspector--inserto en tabla 1
				(identificador_inspector,
				fecha_asignacion, 
				identificador_asignante, 
				tipo_solicitud, 
				tipo_inspector, 
				id_operador_tipo_operacion, 
				id_historial_operacion)
				VALUES (
				json_revision_formulario->>'inspector',
				now(),
				json_revision_formulario->>'inspector',
				json_revision_formulario->>'tipoSolicitud',--aqui va mercanciasSinValorComercialExportacion, 
				json_revision_formulario->>'tipoInspector' ,--Documental, cuando esta en revision; validar que se pone cuando se afirma
				0, --0, 
				0)RETURNING id_grupo into vid_grupo;
				
				INSERT INTO g_revision_solicitudes.grupos_solicitudes --inserto en otra tabla
					VALUES(
					vid_grupo,
					(json_revision_formulario->>'id_solicitud')::integer,
					json_revision_formulario->>'tipoInspector' 
				);
				--saco el serial  del orden 
				SELECT
				 COALESCE(
				  MAX(
					CAST(orden as  numeric(5))),0)+1 as orden
					FROM
					g_revision_solicitudes.revision_documental
					WHERE
					id_grupo = vid_grupo into vnumero_serial;
				INSERT INTO g_revision_solicitudes.revision_documental(
				id_grupo, 
				identificador_inspector, 
				fecha_inspeccion, 
				observacion, 
				estado, 
				orden, 
				ruta_archivo_documental)
				VALUES (
					vid_grupo, 
					json_revision_formulario->>'inspector', 
					now(), 
					json_revision_formulario->>'observacion', 
					json_revision_formulario->>'estado',
					vnumero_serial, 
					'');
					json_parametro =( 
 						 	SELECT concat('{"Error":"0",
										  "Mensaje":"Revisión realizada con exito",
										  "Valor": "Exito"}')::json  );
                END IF;
				
			ELSE
				UPDATE  g_mercancias_valor_comercial.solicitudes
						 SET
						 estado =json_revision_formulario->>'estado',
						 observacion= json_revision_formulario->>'observacion'
						 where id_solicitud = (json_revision_formulario->>'id_solicitud')::integer;
                INSERT INTO g_revision_solicitudes.asignacion_inspector--inserto en tabla 1
				(identificador_inspector,
				fecha_asignacion, 
				identificador_asignante, 
				tipo_solicitud, 
				tipo_inspector, 
				id_operador_tipo_operacion, 
				id_historial_operacion)
				VALUES (
				json_revision_formulario->>'inspector',
				now(),
				json_revision_formulario->>'inspector',
				json_revision_formulario->>'tipoSolicitud',--aqui va mercanciasSinValorComercialExportacion, 
				json_revision_formulario->>'tipoInspector' ,--Documental, cuando esta en revision; validar que se pone cuando se afirma
				0, --0, 
				0)RETURNING id_grupo into vid_grupo;
				
				INSERT INTO g_revision_solicitudes.grupos_solicitudes --inserto en otra tabla
					VALUES(
					vid_grupo,
					(json_revision_formulario->>'id_solicitud')::integer,
					json_revision_formulario->>'tipoInspector' 
				);
				--saco el serial  del orden 
				SELECT
				 COALESCE(
				  MAX(
					CAST(orden as  numeric(5))),0)+1 as orden
					FROM
					g_revision_solicitudes.revision_documental
					WHERE
					id_grupo = vid_grupo into vnumero_serial;
				INSERT INTO g_revision_solicitudes.revision_documental(
				id_grupo, 
				identificador_inspector, 
				fecha_inspeccion, 
				observacion, 
				estado, 
				orden, 
				ruta_archivo_documental)
				VALUES (
					vid_grupo, 
					json_revision_formulario->>'inspector', 
					now(), 
					json_revision_formulario->>'observacion', 
					json_revision_formulario->>'estado',
					vnumero_serial, 
					'');
					json_parametro =( 
 						 	SELECT concat('{"Error":"0",
										  "Mensaje":"Revisión realizada con exito",
										  "Valor": "Exito"}')::json  );
			END IF;
		END IF;-- PROCESO DEL SP
		  EXCEPTION	 
    WHEN others THEN
      -- Rollback the transaction and raise the exception
	  no_error:=FALSE;
      ROLLBACK;
  vSQLERRM :=SQLERRM;
    IF vSQLERRM IS NOT NULL or vSQLERRM <> '' THEN
         INSERT INTO g_errores_procedimientos.errores (objeto, error_capturado,esquema,tablas)
         VALUES (json_data, vSQLERRM,'g_mercancias_valor_comercial','solicitudes,producto_solicitudes,documentos_adjuntos,vacunas_deparasitacion');
        COMMIT;
       END IF;
  END ;
            IF no_error THEN
                COMMIT;
            ELSE
                  json_parametro := (
                      SELECT 
                        CASE 
                          WHEN vSQLERRM IS NULL OR vSQLERRM = '' THEN
                            concat('{"Error":"1", "Mensaje":"',vmensaje_clienta_facturacion_saldo,'","Valor": "', v_resultado_saldo->>'detalle','"}')::json
                          ELSE
                            concat('{"Error":"2", "Mensaje":"Error Datos No Registrados!!","Valor": "', vSQLERRM,'"}')::json
                        END
                 );
 	 	ROLLBACK   ;
	END IF;
END;
$$;

alter procedure sp_insertar_exportacion_importacion_mascotas(json, inout json) owner to postgres;

