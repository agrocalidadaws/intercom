create function canalesingresados(idemisioncertificado integer, OUT oid_detalle_emision_certificado integer, OUT ofecha_produccion date, OUT otipo_especie character varying, OUT otipo_producto_movilizar_canal character varying, OUT otipo_movilizacion_canal character varying, OUT ocodigo_canal character varying, OUT ocodigo text) returns SETOF record
    language plpgsql
as
$$

DECLARE
	
BEGIN	

 RETURN QUERY SELECT 
					id_detalle_emision_certificado, fecha_produccion,tipo_especie, tipo_producto_movilizar_canal, 
					tipo_movilizacion_canal, codigo_canal, 
					CONCAT(id_detalle_emision_certificado, '/', codigo_canal, '/', id_emision_certificado, '/', fecha_produccion, '/', tipo_especie) AS codigo
					FROM g_emision_certificacion_origen.detalle_emision_certificado 
					WHERE id_emision_certificado = $1 order by 1 desc ;

	
END;
$$;

alter function canalesingresados(integer, out integer, out date, out varchar, out varchar, out varchar, out varchar, out text) owner to postgres;

