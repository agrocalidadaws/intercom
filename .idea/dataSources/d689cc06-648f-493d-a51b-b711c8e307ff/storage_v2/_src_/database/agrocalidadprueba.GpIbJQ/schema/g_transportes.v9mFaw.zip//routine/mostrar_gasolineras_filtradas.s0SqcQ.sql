create function mostrar_gasolineras_filtradas(_localizacion text, _gasolinera integer, _direccion text, _estado integer) returns SETOF g_transportes.gasolineras
    language plpgsql
as
$$
DECLARE
	query text;
BEGIN	
	return query EXECUTE '	
		SELECT
			*
		FROM 
			g_transportes.gasolineras g
		WHERE 
			($1 is NULL or id_gasolinera = $1) and 
			($2 is NULL or direccion like $2) and
			($3 is NULL or estado = $3) and 
			($4 is NULL or $4 = localizacion) 
			
		ORDER BY
			g.nombre'
		using _gasolinera,_direccion,_estado,_localizacion;
	
END;
$$;

alter function mostrar_gasolineras_filtradas(text, integer, text, integer) owner to postgres;

