create function completar_total_evaluacion() returns trigger
    language plpgsql
as
$$ 
DECLARE
	_suma double precision;
	--_total_superior double precision;
BEGIN

	--IF(NEW.resultado_inferior != 0) THEN
	--	_total_superior := (NEW.resultado_superior+NEW.resultado_inferior)/2;
	--ELSE
	--	_total_superior := NEW.resultado_superior;
	--END IF;
	
	--_suma := _total_superior + NEW.resultado_par + NEW.resultado_autoevaluacion + NEW.resultado_cumplimiento;
	_suma := NEW.resultado_superior + NEW.resultado_inferior + NEW.resultado_par + NEW.resultado_autoevaluacion + NEW.resultado_cumplimiento + NEW.resultado_individual;
		
	NEW.total = _suma;
				
	RETURN NEW;
	
END;
$$;

alter function completar_total_evaluacion() owner to postgres;

