create function procedimiento_secuencia_catastro() returns trigger
    language plpgsql
as
$$ 
	DECLARE _minimo INTEGER;
	DECLARE _maximo INTEGER;
BEGIN
	--_minimo:= (SELECT min(secuencia_inicial) FROM g_catastro.secuencia_catastro WHERE id_area = NEW.id_area and anio = NEW.anio);
	_maximo:= (SELECT max(secuencia_final) FROM g_catastro.secuencia_catastro WHERE id_area = NEW.id_area and anio = NEW.anio);
	
	IF (_maximo IS NOT NULL) THEN
	
		IF (NEW.secuencia_inicial > _maximo AND NEW.secuencia_final > _maximo) THEN
			RETURN NEW;
		ELSE
			RETURN NULL;
		END IF;

	ELSE

	RETURN NEW;

	END IF;
	
END; 
	
$$;

alter function procedimiento_secuencia_catastro() owner to postgres;

