create function enviar_correo_creacion_exportacion() returns trigger
    language plpgsql
as
$$
/*
-------------------------------------------------------------------------
--  [g_mercancias_valor_comercial.enviar_correo_cambio_estado_exportacion()]
--               
--  Esta funcion Permite ingresar en el esquema g_correos.correos para enviar el comprobante a la persona que va exportar
--
--  VERSION		AUTOR					FECHA			HU			                           CAMBIO
--	1			Kleber Armijos		17-03-2024			Actulizacion Exportacion Mascotas      
-------------------------------------------------------------------------
*/
DECLARE
vcorreo_exportador character varying;
vnombre_exportador character varying;
vestado character varying;
vtipo_solicitud character varying;
vforma_pago character varying;
vid_correo integer;
vasunto character varying ;
vcuerpo character varying ;
vpath_servidor character varying default '/var/www/html/agrodbPrueba/';--/var/www/html/agrodbPrueba/,/var/www/html/agrodb/;
vruta_comprobante character varying;
BEGIN

	SELECT correo_propietario ,nombre_propietario,estado,tipo_solicitud,forma_pago INTO vcorreo_exportador ,vnombre_exportador,vestado,vtipo_solicitud,vforma_pago
    FROM g_mercancias_valor_comercial.solicitudes 
    WHERE id_solicitud=NEW.id_solicitud;
    vruta_comprobante:=vpath_servidor||NEW.ruta_comprobante_veterinario;
	vasunto:='Confirmación de envío de solicitud de Certificado zoosanitario de exportación de mascotas – Solicitud Nro. '||new.id_solicitud;
	vcuerpo:='<tr>
				<td style="font-family:"Text Me One", 
	             "Segoe UI", "Tahoma", "Helvetica", "freesans", "sans-serif2; padding-top:25px; font-size:14px;color:#2a2a2a; width: 80%; text-align:justify;">'
				 ||'Estimado Sr. <font color="green">' || vnombre_exportador || '</font>,<br/><br/>'
				 ||'Por medio de la presente se comunica que hemos recibido una solicitud de certificado de exportación de mascotas, Nro. <font color="green">' ||new.id_solicitud ||'</font>'||
				 ' la cual será atendida por nuestro personal técnico.<br/><br/>' 
				 ||'El resultado de la revisión técnica será remitido al médico veterinario registrado para su atención.<br/><br/>'
				 ||'Saludos Cordiales.
				</td>
			 </tr>';
    IF vestado IN ('enviado') AND vtipo_solicitud = 'Exportacion' AND vforma_pago = 'saldo' THEN
        INSERT INTO g_correos.correos (
									   asunto,
									   cuerpo,
									   estado,
									   codigo_modulo,
									   tabla_modulo,
									   id_solicitud_tabla	   
									  )
        VALUES (vasunto, 
				vcuerpo,
			   	'Por enviar',
				'PRG_EXPO_IMPO_V2',
				'g_mercancias_valor_comercial.solicitudes',
				NEW.id_solicitud
			   )
		RETURNING id_correo INTO vid_correo; -- Aquí coloca la dirección de correo electrónico a la que quieres enviar la notificación
		
		INSERT INTO g_correos.destinatarios(id_correo,destinatario_correo)
		VALUES(vid_correo,vcorreo_exportador);
        
		INSERT INTO g_correos.documentos_adjuntos (id_correo,ruta_documento_adjunto)
        VALUES(vid_correo,vruta_comprobante);
		END if;
RETURN NEW;
END;
$$;

alter function enviar_correo_creacion_exportacion() owner to postgres;

