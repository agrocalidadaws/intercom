create function funcion_estados() returns trigger
    language plpgsql
as
$$
BEGIN
	
	PERFORM g_inspeccion_musaceas.funcion_estado_inspeccion(NEW.estado,NEW.id_solicitud_inspeccion,NEW.identificador_registro);	
	
RETURN NEW;
END;
$$;

alter function funcion_estados() owner to postgres;

