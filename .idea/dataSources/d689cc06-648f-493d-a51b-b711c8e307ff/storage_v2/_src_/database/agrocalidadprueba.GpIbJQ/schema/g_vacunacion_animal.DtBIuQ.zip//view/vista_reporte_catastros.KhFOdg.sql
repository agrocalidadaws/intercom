create view vista_reporte_catastros
            (id_catastro, nombre_concepto, coeficiente, nombre_especie, nombre_comun, cantidad, total,
             cantidad_vacunado, total_vacunado, identificador, nombres, provincia, canton, parroquia, sitio, area,
             provincia_destino, canton_destino, parroquia_destino, sitio_destino, area_destino, id_sitio, id_area,
             id_sitio_destino, id_area_destino, numero_documento, fecha_catastro, fecha_movilizacion_desde,
             numero_documento_referencia)
as
SELECT ca.id_catastro,
       cc.nombre_concepto,
       cc.coeficiente,
       ca.nombre_especie,
       pr.nombre_comun,
       ca.cantidad,
       ca.total,
       ca.cantidad_vacunado,
       ca.total_vacunado,
       o.identificador,
       (o.nombre_representante::text || ' '::text) || o.apellido_representante::text AS nombres,
       s.provincia,
       s.canton,
       s.parroquia,
       s.nombre_lugar                                                                AS sitio,
       a.nombre_area                                                                 AS area,
       ss.provincia                                                                  AS provincia_destino,
       ss.canton                                                                     AS canton_destino,
       ss.parroquia                                                                  AS parroquia_destino,
       ss.nombre_lugar                                                               AS sitio_destino,
       aa.nombre_area                                                                AS area_destino,
       ca.id_sitio,
       ca.id_area,
       ma.id_sitio_destino,
       ma.id_area_destino,
       ca.numero_documento,
       ca.fecha_catastro,
       ma.fecha_movilizacion_desde,
       ca.numero_documento_referencia
FROM g_catalogos.productos pr,
     g_movilizacion_animal.movilizacion_animales ma,
     g_vacunacion_animal.catastros ca,
     g_vacunacion_animal.concepto_catastros cc,
     g_operadores.sitios s,
     g_operadores.areas a,
     g_operadores.sitios ss,
     g_operadores.areas aa,
     g_operadores.operadores o
WHERE ca.id_producto = pr.id_producto
  AND ca.id_concepto_catastro = cc.id_concepto_catastro
  AND o.identificador::text = s.identificador_operador::text
  AND ma.id_sitio_origen = s.id_sitio
  AND ma.id_area_origen = a.id_area
  AND ma.id_sitio_destino = ss.id_sitio
  AND ma.id_area_destino = aa.id_area
  AND ca.numero_documento_referencia::text = ma.numero_certificado::text
UNION
SELECT ca.id_catastro,
       cc.nombre_concepto,
       cc.coeficiente,
       ca.nombre_especie,
       pr.nombre_comun,
       ca.cantidad,
       ca.total,
       ca.cantidad_vacunado,
       ca.total_vacunado,
       o.identificador,
       (o.nombre_representante::text || ' '::text) || o.apellido_representante::text AS nombres,
       s.provincia,
       s.canton,
       s.parroquia,
       s.nombre_lugar                                                                AS sitio,
       a.nombre_area                                                                 AS area,
       ''::character varying                                                         AS provincia_destino,
       ''::character varying                                                         AS canton_destino,
       ''::character varying                                                         AS parroquia_destino,
       ''::character varying                                                         AS sitio_destino,
       ''::character varying                                                         AS area_destino,
       ca.id_sitio,
       ca.id_area,
       0                                                                             AS id_sitio_destino,
       0                                                                             AS id_area_destino,
       ca.numero_documento,
       ca.fecha_catastro,
       NULL::timestamp without time zone                                             AS fecha_movilizacion_desde,
       ca.numero_documento_referencia
FROM g_catalogos.productos pr,
     g_vacunacion_animal.catastros ca,
     g_vacunacion_animal.concepto_catastros cc,
     g_operadores.sitios s,
     g_operadores.areas a,
     g_operadores.sitios ss,
     g_operadores.areas aa,
     g_operadores.operadores o
WHERE ca.id_producto = pr.id_producto
  AND ca.id_concepto_catastro = cc.id_concepto_catastro
  AND o.identificador::text = s.identificador_operador::text
  AND o.identificador::text = ss.identificador_operador::text
  AND ca.id_sitio = s.id_sitio
  AND ca.id_area = a.id_area
  AND ca.id_sitio = ss.id_sitio
  AND ca.id_area = aa.id_area
  AND ca.numero_documento_referencia::text = ''::text
ORDER BY 1;

alter table vista_reporte_catastros
    owner to postgres;

