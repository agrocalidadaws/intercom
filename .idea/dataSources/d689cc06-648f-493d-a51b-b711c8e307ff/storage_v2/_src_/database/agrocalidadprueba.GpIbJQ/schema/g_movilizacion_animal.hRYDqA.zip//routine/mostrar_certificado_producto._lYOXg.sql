create function mostrar_certificado_producto(id_sitio integer, id_area integer, id_especie integer) returns SETOF g_movilizacion_animal.mostrar_certificado_producto
    language plpgsql
as
$$
DECLARE
	query text;
BEGIN	
	return query EXECUTE '
			      select c.id_producto
				, p.nombre_comun producto
				, c.numero_documento
				, c.total_vacunado total
				, c.edad_producto
				, c.fecha_nacimiento
				, c.fecha_vacunacion fecha_vacunacion_desde
				, c.fecha_vacunacion fecha_vacunacion_hasta
				, c.id_concepto_catastro
				from g_vacunacion_animal.catastros c,
				g_catalogos.productos p
				where c.id_producto = p.id_producto
				and c.id_concepto_catastro not in (5, 6, 8)
				and c.numero_documento not in (''Ninguno'')
				and c.total_vacunado > 0
				and c.id_catastro in (select max(id_catastro) id
				from g_vacunacion_animal.catastros c
				where id_sitio = $1
				and id_area = $2
				and id_especie = $3
				and cantidad_vacunado is not null group by c.id_producto, c.numero_documento)													
				
				union
				
				select c.id_producto
				, p.nombre_comun producto
				, c.numero_documento
				, c.total
				, c.edad_producto
				, c.fecha_nacimiento fecha_nacimiento
				, c.fecha_vacunacion fecha_vacunacion_desde
				, c.fecha_vacunacion fecha_vacunacion_hasta
				, c.id_concepto_catastro
				from g_vacunacion_animal.catastros c, g_catalogos.productos p
				where c.id_producto = p.id_producto
				and c.numero_documento in (''Ninguno'')
				and c.total > 0
				and c.id_catastro in (select max(id_catastro) id
				from g_vacunacion_animal.catastros c
				where id_sitio = $1
				and id_area = $2
				and id_especie = $3
				and cantidad is not null
				and id_producto in (select id_producto from g_catalogos.productos_animales
				where id_especie = $3 and tipo_documento = ''ninguno''))
				'			
		using id_sitio,id_area,id_especie;
	
END;
$$;

alter function mostrar_certificado_producto(integer, integer, integer) owner to postgres;

