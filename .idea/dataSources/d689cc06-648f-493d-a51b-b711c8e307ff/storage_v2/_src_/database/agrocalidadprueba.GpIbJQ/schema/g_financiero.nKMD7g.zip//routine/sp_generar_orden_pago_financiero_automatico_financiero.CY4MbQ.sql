create procedure sp_generar_orden_pago_financiero_automatico_financiero(INOUT json_parametro json)
    language plpgsql
as
$$
/*
-------------------------------------------------------------------------
--  [g_financiero.sp_generar_orden_pago_financiero_automatico_financiero]
--               
--  procedimiento que se encarga de realizar el proceso de ingreso de las tablas de financiero_automatico a financiero
--  y genera l pago
--
--  VERSION		AUTOR					FECHA			HU			                           
--	1			Kleber Armijos		25-01-2024	 Control de cambios funcional Exportación e Importación de 
--												 de mascotas edición N°5
-------------------------------------------------------------------------
*/
DECLARE
	
	rcrd_financiero_cabecera record;
	rcrd_solicitudes_exportacion_mascotas record;
	rcrd_financiero_detalle record;
	ids_solicitudes_con_saldo INT[];
	ids_solicitudes_sin_saldo INT[];
  	cursor_financiero_cabecera  CURSOR  For
       SELECT 
   		fin_ca.id_financiero_cabecera,
   		fin_ca.id_vue,
		fin_ca.total_pagar,
  		fin_ca.metodo_pago,
		fin_ca.estado,
		fin_ca.tipo_solicitud
-- 		fin_det.id_servicio, 
-- 		fin_det.concepto_orden, 
-- 		sum(fin_det.cantidad) as cantidad, 
-- 		sum(fin_det.precio_unitario) as precio_unitario, 
-- 		sum(fin_det.descuento)as descuento, 
-- 		sum(fin_det.iva) as iva, 
-- 		sum(fin_det.total) as total
   	FROM g_financiero_automatico.financiero_cabecera fin_ca
	INNER JOIN g_mercancias_valor_comercial.solicitudes sol_mas
	ON fin_ca.id_vue::integer=sol_mas.id_solicitud::integer
   	WHERE 
   		fin_ca.tipo_solicitud= json_parametro->>'tipo_solicitud'--'certificadoZooExportacion'
   		AND fin_ca.estado  in(json_parametro->>'estado_con_saldo'::varchar,json_parametro->>'estado_sin_saldo'::varchar)
        AND sol_mas.estado NOT IN('aprobado');--json_parametro->>'estado';
-- 	GROUP BY
-- 		fin_ca.id_financiero_cabecera,
--    		fin_ca.id_vue,
--   		fin_ca.metodo_pago,
-- 		fin_ca.estado,
-- 		fin_det.id_servicio, 
-- 		fin_det.concepto_orden;
	
	vvalor_servicio NUMERIC;
	vconcepto_servicio VARCHAR;
	vid_servicio INTEGER;
	vid_financiero_cabecera INTEGER;
	vtipo_solicitud_nuevo_nombre VARCHAR;
  no_error BOOLEAN ;
  vSQLERRM TEXT;
  ---
   v_oficina_recaudacion RECORD;
   vtipo_solicitud VARCHAR DEFAULT 'certificadoZooExportacion';
   vtipo_inspector VARCHAR DEFAULT 'Financiero';
   vcliente_correo VARCHAR;
   vsaldo_disponible_operador DECIMAL;
   vbandera_generar_orden_pago BOOLEAN DEFAULT TRUE;
   vestado_solicitudes_verificacion VARCHAR DEFAULT 'verificacion';
   vid_grupo_inspector INTEGER;
   vestado_grupo_solicitudes VARCHAR DEFAULT 'Financiero';
   vfinanciero_orden INTEGER;
   vrev_solicitudes_id_financiero INTEGER;
   vanio_actual INTEGER;
   vnumero_documento VARCHAR;
   vnumero_solicitud VARCHAR;
   vpartes_documento TEXT [];
   vincremento_pago INTEGER;
   vnumero_solicitud_pago VARCHAR;
   vfinanciero_id_pago INTEGER;
   vobservacion_orden_pago_financiero VARCHAR DEFAULT 'Imposición automática por sistema GUIA.';
   vestado_financiero_orden_pago INTEGER DEFAULT 3;
   
    vfecha_actual_doc TIMESTAMP; 
    vfecha_partir1_doc INT;
    vfecha_partir2_doc INT;
    vfecha_partir3_doc INT;
    vfecha_partir4_doc INT;
	vruta_fecha VARCHAR;
	vnombre_reporte VARCHAR default 'ReporteOrden';
	vnombre_archivo VARCHAR ;
	vnombre_archivo_sin_extension VARCHAR;
	vruta_archivo_orden_pago VARCHAR;
	vpath_base_ruta_archivo VARCHAR DEFAULT 'aplicaciones/financiero/documentos/ordenPago/';
	vestado_final_financiero_automatico VARCHAR DEFAULT 'Atendida';
	json_rutas_orden_pago JSONB DEFAULT '[]';
	vnombre_secuencia TEXT;
	--BANCO
	vid_banco INTEGER DEFAULT 0;
	vnombre_banco VARCHAR 	DEFAULT 'Pago con saldo';
	vpapeleta_banco VARCHAR DEFAULT 'Saldo disponible';
	vtipo_saldo VARCHAR DEFAULT 'saldoAgr';
    vestado_financiero_cabecera_automatico VARCHAR DEFAULT 'W';
    
	
BEGIN
	
 BEGIN   -- inicio transanccion
	  no_error:=TRUE;
	 
			--RAISE NOTICE 'El valor de clave_a_mostrar es: %',json_data;
			--1.- Seleciono todo los registros que esten en estado ('Por atender','Por atender Saldo'),
			-- ademas que sean de tipo_solicitud certificadoZooExportacion por que exite un cron obtiene registros en estado 
			-- ('Por atender','Por atender Saldo'),
			--2.- selecciono datos de la tabla g_financiero.oficina_recaudacion deacuerdo al recaudador
			--3 comienzo a iterar de acuerdo a lo requerido 
			SELECT identificador_firmante,oficina,provincia,id_provincia,iva
												INTO v_oficina_recaudacion
											FROM
												g_financiero.oficina_recaudacion
											WHERE
												identificador_firmante = json_parametro->>'identificador_firmante' and --'1313841262' and --esto envio en mi parametro
												estado_recaudador='activo';-- DATOS DEL RECAUDADOR
				 vnombre_secuencia := 'unique_seq_' || REPLACE(TO_CHAR(CURRENT_TIMESTAMP, 'YYYYMMDDHHMMSSMS'), ' ', '');
					 EXECUTE 'CREATE SEQUENCE ' || vnombre_secuencia;
	
					OPEN cursor_financiero_cabecera; --abro el cursor
 					LOOP
					 
					 FETCH   FROM cursor_financiero_cabecera INTO rcrd_financiero_cabecera;
						EXIT WHEN NOT FOUND;
						IF rcrd_financiero_cabecera.tipo_solicitud = 'certificadoZooExportacion' THEN
						 RAISE NOTICE 'solicitud que se actualiza el estado a W en mi modulo: %',rcrd_financiero_cabecera.id_vue;
						  UPDATE 
							 g_financiero_automatico.financiero_cabecera 
						  SET
							 estado = vestado_financiero_cabecera_automatico
						  WHERE
							 id_financiero_cabecera = (rcrd_financiero_cabecera.id_vue)::Integer
							 AND  tipo_solicitud=vtipo_solicitud;
							SELECT sol.id_solicitud, 
								   sol.identificador_operador,
								  sol.identificador_propietario,
								  loc.nombre as nombre_provincia
								 INTO rcrd_solicitudes_exportacion_mascotas 
							FROM g_mercancias_valor_comercial.solicitudes sol
							INNER JOIN g_catalogos.oficina_atencion ofi_aten ON sol.id_oficina_atencion =ofi_aten.id_oficina_atencion
							INNER JOIN g_catalogos.localizacion loc ON ofi_aten.id_localizacion=loc.id_localizacion
							WHERE id_solicitud=(rcrd_financiero_cabecera.id_vue)::INTEGER;
																	
							 SELECT
								  correo
								  INTO vcliente_correo
							 FROM
								   g_financiero.clientes 
							 WHERE
							identificador=(rcrd_solicitudes_exportacion_mascotas.identificador_operador)::varchar;
							--AQUI DEBO HACER LA LOGICA DEL SALSO DISPONIBLE VERSUS EL TOTAL en las SOLICITUDES
							SELECT saldo_disponible
							INTO vsaldo_disponible_operador
								FROM (
								SELECT saldo_disponible, ROW_NUMBER() OVER (ORDER BY id_saldo DESC) as row_num
								FROM g_financiero.saldos
								WHERE identificador_operador = rcrd_solicitudes_exportacion_mascotas.identificador_operador
								) AS subquery
								WHERE row_num = 1;
								IF vsaldo_disponible_operador >= rcrd_financiero_cabecera.total_pagar THEN --pregunto si el saldo es suficiente debo armar
									vbandera_generar_orden_pago:=TRUE;	
									---aqui debo descontar el saldo de de finacniero saldo
									ids_solicitudes_con_saldo := array_append(ids_solicitudes_con_saldo, rcrd_financiero_cabecera.id_financiero_cabecera);--capturo las sol
									UPDATE g_mercancias_valor_comercial.solicitudes 
  								    SET estado = vestado_solicitudes_verificacion
  								    WHERE id_solicitud = (rcrd_financiero_cabecera.id_vue)::INTEGER;																											--que tuvieron comos er descontadas
									
								ELSE
									vbandera_generar_orden_pago:=FALSE;
									UPDATE 
										g_financiero_automatico.financiero_cabecera 
									SET
										estado = json_parametro->>'estado_sin_saldo',
										estado_factura=json_parametro->>'estado_sin_saldo'
								    WHERE
										id_financiero_cabecera = (rcrd_financiero_cabecera.id_vue)::INTEGER
                                        AND  tipo_solicitud=vtipo_solicitud;
                                    UPDATE g_mercancias_valor_comercial.solicitudes 
  								    SET estado = vestado_solicitudes_verificacion||' sin saldo'
  								    WHERE id_solicitud = (rcrd_financiero_cabecera.id_vue)::INTEGER;
									--capturo las solicitudes que no tuvieron como ser descontadas
									ids_solicitudes_sin_saldo:=array_append(ids_solicitudes_sin_saldo, rcrd_financiero_cabecera.id_financiero_cabecera);
									
								END IF;
								--FIN LOGICA CONSULTA DE SALDO
								--UPDATE g_mercancias_valor_comercial.solicitudes 
  								--SET estado = vestado_solicitudes_verificacion
  								--WHERE id_solicitud = (rcrd_financiero_cabecera.id_vue)::INTEGER;
							
							END IF;--fin del proceso de tipo solicitud certificadoZooExportacion
							--ESTE ES EL PROCESO DE GENERAR DOCUMENTO
							IF vbandera_generar_orden_pago THEN--paso para generar el reporte
							-- GUARDO EL GRUPO 
							INSERT INTO 
								g_revision_solicitudes.asignacion_inspector(
									identificador_inspector, 
									fecha_asignacion, 
									identificador_asignante, 
									tipo_solicitud, 
									tipo_inspector, 
									id_operador_tipo_operacion, 
									id_historial_operacion)
							VALUES (COALESCE(NULLIF((v_oficina_recaudacion.identificador_firmante)::varchar, ''), (v_oficina_recaudacion.identificador_firmante)::varchar),
									now(), 
									COALESCE(NULLIF((v_oficina_recaudacion.identificador_firmante)::varchar, ''), (v_oficina_recaudacion.identificador_firmante)::varchar),
									vtipo_solicitud, 
									vtipo_inspector, 
									0,
									0)
							RETURNING id_grupo INTO vid_grupo_inspector;
							
							INSERT INTO g_revision_solicitudes.grupos_solicitudes
							VALUES(vid_grupo_inspector,(rcrd_financiero_cabecera.id_vue)::integer,vestado_grupo_solicitudes);
								   --el serial de la orden 
							SELECT
								COALESCE(MAX(CAST(orden as  numeric(5))),0)+1 as orden
							FROM
							g_revision_solicitudes.financiero
							WHERE
							id_grupo = vid_grupo_inspector INTO vfinanciero_orden;
							--
							--INGRERO EN SOLICITUDES FINANCIERO
							INSERT INTO
							g_revision_solicitudes.financiero 
							(id_grupo, 
							 identificador_inspector, 
							 monto, 
							 fecha_asignacion_monto, 
							 orden)
							VALUES(vid_grupo_inspector, 
								   v_oficina_recaudacion.identificador_firmante, 
								   rcrd_financiero_cabecera.total_pagar, 
								   now(), 
								   vfinanciero_orden)
							RETURNING id_financiero INTO vrev_solicitudes_id_financiero;
							
							vanio_actual:=EXTRACT(YEAR FROM CURRENT_DATE);
							SELECT
								MAX(numero_solicitud) as numero
								FROM 
								 g_financiero.orden_pago
									WHERE 
									numero_solicitud LIKE '%AGR-'||vanio_actual||'%' INTO vnumero_documento;--busco el maximo numero sol en orden_pago 
																		
									vpartes_documento := string_to_array(vnumero_documento, '-');
									vincremento_pago := CAST(vpartes_documento[array_length(vpartes_documento, 1)] AS INT) + 1;--le sumo 1
									
									vnumero_solicitud_pago := CONCAT('AGR-', vanio_actual, '-', LPAD(vincremento_pago::TEXT, 9, '0'));
								
							 
							--creao la ruta del archivo 
									vfecha_actual_doc := CURRENT_TIMESTAMP;
									
    								vfecha_partir1_doc := EXTRACT(HOUR FROM vfecha_actual_doc);
    								vfecha_partir2_doc := EXTRACT(MINUTE FROM vfecha_actual_doc);
--     								vfecha_partir4_doc := EXTRACT(SECOND   FROM vfecha_actual_doc)* 1000000 + FLOOR(RANDOM() * 1000000)::BIGINT;
									vfecha_partir4_doc := EXTRACT(SECOND   FROM vfecha_actual_doc)+ NEXTVAL(vnombre_secuencia);
    								vfecha_partir3_doc := vfecha_partir1_doc - 1;
																	
									vruta_fecha := TO_CHAR(CURRENT_DATE, 'YYYY/MM/DD');
									
									vnombre_archivo :=vnombre_reporte||'_'||rcrd_solicitudes_exportacion_mascotas.identificador_operador
													||'_'||TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD')
													||'_'|| vfecha_partir3_doc --(EXTRACT(HOUR FROM CURRENT_TIMESTAMP)-1)
													||'_'|| vfecha_partir2_doc-- EXTRACT(MINUTE FROM CURRENT_TIMESTAMP)
													||'_'|| vfecha_partir4_doc-- EXTRACT(SECOND FROM CURRENT_TIMESTAMP) 
													||'.pdf';
									
									vnombre_archivo_sin_extension := SPLIT_PART(vnombre_archivo, '.', 1);
									
									vruta_archivo_orden_pago:=
									vpath_base_ruta_archivo||vruta_fecha||'/'||vnombre_archivo;
									
							---creacion numero orden pago
							INSERT INTO g_financiero.orden_pago(
										identificador_operador, 
										numero_solicitud, 
            							fecha_orden_pago,
										total_pagar,
										observacion,
										estado,
										localizacion, 
										nombre_provincia, 
										id_provincia, 
										identificador_usuario, 
										tipo_solicitud, 
										id_grupo_solicitud, 
										id_solicitud, 
										porcentaje_iva,
										orden_pago,
										metodo_pago)
							VALUES ((rcrd_solicitudes_exportacion_mascotas.identificador_operador)::varchar,
									vnumero_solicitud_pago,
									now(),
									(rcrd_financiero_cabecera.total_pagar)::numeric(8,2),
									vobservacion_orden_pago_financiero,
									vestado_financiero_orden_pago,
									v_oficina_recaudacion.oficina,
									v_oficina_recaudacion.provincia, 
									(v_oficina_recaudacion.id_provincia)::integer,
									(v_oficina_recaudacion.identificador_firmante)::varchar, 
									vtipo_solicitud, 
									vid_grupo_inspector, 
									(rcrd_solicitudes_exportacion_mascotas.id_solicitud)::integer, 
									v_oficina_recaudacion.iva,
									vruta_archivo_orden_pago,
									rcrd_financiero_cabecera.metodo_pago) RETURNING id_pago INTO vfinanciero_id_pago;
									
								
									--ingreso detalle 
								  FOR   rcrd_financiero_detalle IN
										--DETALLE POR CADA CABECERA
								        SELECT
								        fin_det.id_servicio, 
								        fin_det.concepto_orden, 
								        sum(fin_det.cantidad) as cantidad, 
								        sum(fin_det.precio_unitario) as precio_unitario, 
								        sum(fin_det.descuento)as descuento, 
								        sum(fin_det.iva) as iva, 
								        sum(fin_det.total) as total 
								        --INTO rcrd_financiero_detalle
								        FROM g_financiero_automatico.financiero_detalle fin_det 
								        WHERE fin_det.id_financiero_cabecera=(rcrd_financiero_cabecera.id_financiero_cabecera)::integer
								        GROUP BY
                        		        fin_det.id_servicio, 
                        		        fin_det.concepto_orden
									LOOP
									
											INSERT INTO g_financiero.detalle_pago(
            										id_pago, 
													id_servicio, 
													concepto_orden, 
													cantidad, 
													precio_unitario,
													descuento,
													iva,
													total, 
													subsidio)
											VALUES (vfinanciero_id_pago,
												(rcrd_financiero_detalle.id_servicio)::integer,
												rcrd_financiero_detalle.concepto_orden,
												(rcrd_financiero_detalle.cantidad)::double precision,
												(rcrd_financiero_detalle.precio_unitario)::numeric(12,6),
												(rcrd_financiero_detalle.descuento)::numeric(8,2),
												(rcrd_financiero_detalle.iva)::numeric(8,2),
												(rcrd_financiero_detalle.total)::numeric(8,2),
												0);
										END LOOP;
															
									--actulizo financiero automatico una vez terminado el proceso 
									UPDATE
												g_financiero_automatico.financiero_cabecera
											SET
												id_orden_pago = vfinanciero_id_pago,
												estado=vestado_final_financiero_automatico,
												estado_factura=json_parametro->>'estado_con_saldo',
												fecha_ingreso_factura=now()
											WHERE
												id_financiero_cabecera = (rcrd_financiero_cabecera.id_financiero_cabecera)::integer
									        AND  tipo_solicitud=vtipo_solicitud;
									 INSERT INTO g_financiero.detalle_forma_pago
									 (id_pago,
									  id_banco, 
									  institucion_bancaria, 
									  transaccion, 
									  valor_deposito, 
									  fecha_orden_pago, 
									  id_nota_credito, 
									  id_cuenta_bancaria, 
									  numero_cuenta)
									 VALUES 
									 (vfinanciero_id_pago,
									  vid_banco,
									  vnombre_banco,
									  vpapeleta_banco,
									 ( rcrd_financiero_cabecera.total_pagar)::numeric(8,2),
									  now(), 
									 0, 
									  0, 
									  '0');
									 
									  --descuento el saldo del valor de la solicitud segun el tarifario 
									  INSERT INTO g_financiero.saldos
									  		(id_pago,
										 	 fecha_deposito, 
											 valor_egreso, 
											 saldo_disponible, 
											 identificador_operador, 
											 tipo_saldo)
									  VALUES 
									  		(vfinanciero_id_pago,
									   		 now(),
											 (rcrd_financiero_cabecera.total_pagar)::double precision,
											 (vsaldo_disponible_operador-rcrd_financiero_cabecera.total_pagar)::double precision, 
											(rcrd_solicitudes_exportacion_mascotas.identificador_operador)::varchar, 
											 vtipo_saldo
											) ;
											
					--armo el json son a retornar que me contiene el id del orden pago , la ruta del salida del archivo, cmo la salida reporte
									json_rutas_orden_pago := json_rutas_orden_pago || jsonb_build_object(
               						 'idOrdenPago', vfinanciero_id_pago,
                					 'rutaArchivo', vruta_archivo_orden_pago,
                					 'archivoSalida', vruta_archivo_orden_pago,
									 'correoCliente',vcliente_correo,
									 'rutaFecha',vruta_fecha,
									'nombreProvincia',rcrd_solicitudes_exportacion_mascotas.nombre_provincia
           							 );  									
								
							END IF;--proceso de generada documento

 					END LOOP;--FIN DE MI PROCESO GENERAR ORDEN PAGO
 				CLOSE cursor_financiero_cabecera;--cierro el cursos u cursos abierto siempre se debe de cerrar FIN SP
					
				
			--IF json_parametro->>'tipoAccion' = 'generarOrdenMascotas' THEN
				
 				
				
                 IF (ids_solicitudes_con_saldo IS NOT NULL AND array_length(ids_solicitudes_con_saldo, 1) IS NOT NULL ) 
				 OR  (ids_solicitudes_sin_saldo IS NOT NULL AND array_length(ids_solicitudes_sin_saldo, 1) IS NOT NULL )THEN
                 json_parametro =( 
 						   SELECT concat('{"Error":"0",
										   "Mensaje":"Datos Procesados correctamente!!",
										   "DatoProcesadosSaldo":"Estas solicitudes fueron Procesadas', array_to_json(ids_solicitudes_con_saldo),'",
										   "DatoProcesadosSinSaldo":"Estas solicitudes fueron Procesadas Sin Saldo', array_to_json(ids_solicitudes_sin_saldo),'",
										   "OrdenesGenerada":',json_rutas_orden_pago,'
										 	
										 }
										')::json);
                 ELSE
                 json_parametro =( 
 						   SELECT concat('{"Error":"0",
										   "Mensaje":"Datos Procesados correctamente!!",
										   "DatoProcesados":"Ninguno"
										 }
										')::json);
                 END IF;
			--ELSE						--queda abierto para otro proceso
			--END IF;-- fin SP
			
			
		  EXCEPTION
		 
    WHEN others THEN
	  no_error:=FALSE;
      ROLLBACK;
  vSQLERRM :=SQLERRM;
  END ;
  	--RAISE NOTICE 'Datos insertados correctamente: %',existe_error;
	IF no_error THEN
		COMMIT;
 		ELSE
		  json_parametro := (
			  SELECT 
				CASE 
				  WHEN vSQLERRM IS NULL OR vSQLERRM = '' THEN
					concat('{"Error":"1", "Mensaje":"Error Datos No Registrados!!","Valor": "', vSQLERRM,'"}')::json
				END
   		 );
		json_parametro := (
			  SELECT 
				CASE 
				  WHEN vSQLERRM IS NULL OR vSQLERRM = '' THEN
					concat('{"Error":"1", "Mensaje":"Error Datos No Registrados!!","Valor": "', vSQLERRM,'"}')::json
			else
			--concat('{"Error":"1", "Mensaje":"Error Datos No Registradoselse !!","Valor": "', vSQLERRM,'"}')::json
			concat('{"Error":"1", "Mensaje":"Error Datos No Registradoselse !!","Valor": "', vSQLERRM,'"}')::json
				END
   		 );
 	 	ROLLBACK   ;
	END IF;
  	
END;
$$;

alter procedure sp_generar_orden_pago_financiero_automatico_financiero(inout json) owner to postgres;

