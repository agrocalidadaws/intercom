create function mostrar_catastro_vacunados(id_sitio integer, id_area integer, id_especie integer) returns SETOF g_vacunacion_animal.mostrar_catastro_vacunados
    language plpgsql
as
$$
DECLARE
	query text;
BEGIN	
	return query EXECUTE '
			      select d.orden, p.id_producto
				, p.nombre_comun producto
				, c.id_especie
				, c.nombre_especie
				, sum(c.total_vacunado) total_vacunado
				from g_vacunacion_animal.catastros c
				, g_catalogos.productos p
				, g_catalogos.productos_animales d
				where p.id_producto = c.id_producto
				and c.id_producto = d.id_producto
				and p.id_producto = d.id_producto
				and c.total_vacunado > 0
				and numero_documento <> ''Ninguno''
				and c.id_catastro in (select max(id_catastro)
				from g_vacunacion_animal.catastros c, g_catalogos.productos_animales a
				where c.id_producto = a.id_producto
				and c.id_especie = a.id_especie
				and total_vacunado is not null
				and c.id_sitio = $1 
				and c.id_area = $2
				and c.id_especie = $3
				group by c.id_producto, c.numero_documento)
				group by d.orden, p.id_producto, p.nombre_comun, c.id_especie, c.nombre_especie
			   union
			   select distinct d.orden, p.id_producto
				, p.nombre_comun producto
				, d.id_especie
				, d.nombre_especie
				, 0 total_vacunado
				from g_catalogos.productos p
				, g_catalogos.productos_animales d
				where p.id_producto = d.id_producto
				and p.id_producto not in (select distinct p.id_producto
				from g_vacunacion_animal.catastros c
				, g_catalogos.productos p
				, g_catalogos.productos_animales d
				where p.id_producto = c.id_producto
				and c.id_producto = d.id_producto
				and p.id_producto = d.id_producto
				and c.total_vacunado > 0
				and numero_documento <> ''Ninguno''
				and c.id_catastro in (select max(id_catastro)
				from g_vacunacion_animal.catastros c, g_catalogos.productos_animales a
				where c.id_producto = a.id_producto
				and c.id_especie = a.id_especie
				and total_vacunado is not null
				and c.id_sitio = $1 
				and c.id_area = $2
				and c.id_especie = $3
				group by c.id_producto, c.numero_documento)
				)
				order by orden desc
			'			
		using id_sitio,id_area,id_especie;
	
END;
$$;

alter function mostrar_catastro_vacunados(integer, integer, integer) owner to postgres;

