create procedure sp_generar_orden_pago_procesos_automaticos(INOUT json_parametro json)
    language plpgsql
as
$$
/*
-------------------------------------------------------------------------
--  [g_financiero.sp_generar_orden_pago_procesos_automaticos]
--               
--  procedimiento que se encarga de realizar el proceso de ingreso de las tablas de g_financiero.orden_pago,
--  g_financiero_detalle_pago, actualiza el estado de las tablas de los diferentes procesos y registra en las
--  tablas del esquema g_revision_solicitudes en el caso de que el proceso lo requiera en procesos de 
--  generacion automatica de ordenes de pago
--
--  VERSION		AUTOR					FECHA			HU			                           
--	1			Kleber Armijos		23-08-2024	 Control de cambios funcional interconexion 
--				Milton Nivelo				     refactoracion financiero pry-banred
-------------------------------------------------------------------------
*/
DECLARE
	
	--Variables JSON
	v_da JSON;
	v_datos_orden_pago JSON;
    
	--Variables JSON pago--
	v_identificador_cliente TEXT;	
	v_tipo_solicitud TEXT;
	v_identificador_recaudador TEXT;
	v_nombre_provincia_recaudador TEXT;
	v_id_provincia_recaudador INTEGER;
	v_porcentaje_iva INTEGER;
	v_id_solicitud TEXT;
	v_metodo_pago TEXT;
	v_asignar_monto_solicitud BOOLEAN;
	v_codigo_servicio TEXT;
	v_id_area_financiero TEXT;
	v_nombre_provincia_solicitud TEXT;
	v_razon_social TEXT;
	v_correo TEXT;
	
	--Variables orden pago--
	v_numero_solicitud TEXT;
	v_fecha_orden_pago TIMESTAMP WITHOUT TIME ZONE := now();
	v_total_pagar DOUBLE PRECISION;
	v_observacion TEXT := 'Imposición automática por sistema GUIA.';
	v_localizacion_recaudador TEXT;
    v_nombre_secuencia INTEGER;
	v_ruta_raiz_guia TEXT;
	v_ruta_dominio_guia TEXT;
	v_tipo_proceso TEXT := 'factura';	
	v_estado_orden_pago INTEGER;
	v_n_id_pago INTEGER;
	v_total_subsidio DOUBLE PRECISION := 0;
	v_estado_solicitud TEXT := 'verificacion';
	
	--Variables asignar monto solicitud--
	v_id_grupo INTEGER;
	v_orden INTEGER;
	v_tipo_inspector TEXT := 'Financiero';
	v_id_operador_tipo_operacion INTEGER := 0;
	v_id_historial_operacion INTEGER := 0;
	
	--Variables detalle pago--
	v_id_servicio_detalle INTEGER;
	v_concepto_detalle TEXT;
	v_cantidad_detalle INTEGER;
	v_precio_unitario_detalle DOUBLE PRECISION;
	v_posee_iva BOOLEAN;
	v_subsidio_detalle DOUBLE PRECISION;
	v_descuento_detalle DOUBLE PRECISION := 0;
	v_iva_detalle DOUBLE PRECISION := 0;
	v_total_detalle DOUBLE PRECISION;
	v_saldo_disponible_cliente DOUBLE PRECISION;
	v_generar_orden_pago BOOLEAN := TRUE;
	
	--Variables orden pago PDF--	
	v_fecha_partir1_doc INTEGER;
	v_fecha_partir2_doc INTEGER;
	v_fecha_partir4_doc INTEGER;
	v_fecha_partir3_doc INTEGER;
	v_ruta_archivo_orden_pago TEXT;
	v_path_base_ruta_archivo TEXT := 'aplicaciones/financiero/documentos/ordenPago/';
	v_ruta_fecha TEXT;
	v_nombre_archivo TEXT;
	v_nombre_reporte TEXT := 'ReporteOrden';
	
	--Variables Lims--
	r_detalle_orden_trabajo RECORD;	
	
BEGIN
 
	v_da := json_parametro; 
	
	v_identificador_cliente := v_da->'datosOrdenPago'->>'identificadorCliente';		
	v_tipo_solicitud := v_da->'datosOrdenPago'->>'tipoSolicitud';
	v_estado_orden_pago := v_da->'datosOrdenPago'->>'estadoOrdenPago';
	v_identificador_recaudador := v_da->'datosOrdenPago'->>'identificadorRecaudador';
	v_localizacion_recaudador := v_da->'datosOrdenPago'->>'localizacionRecaudador';
	v_nombre_provincia_recaudador := v_da->'datosOrdenPago'->>'nombreProvinciaRecaudador';
	v_id_provincia_recaudador := v_da->'datosOrdenPago'->>'idProvinciaRecaudador';
	v_porcentaje_iva := v_da->'datosOrdenPago'->>'porcentajeIva';
	v_id_solicitud := v_da->'datosOrdenPago'->>'idSolicitud';
	v_metodo_pago := v_da->'datosOrdenPago'->>'metodoPago';
	v_asignar_monto_solicitud := v_da->'datosOrdenPago'->>'asignarMontoSolicitud';
	v_codigo_servicio := v_da->'datosOrdenPago'->>'codigoServicio';
	v_id_area_financiero := v_da->'datosOrdenPago'->>'idAreaFinanciero';
	v_nombre_provincia_solicitud := v_da->'datosOrdenPago'->>'nombreProvinciaSolicitud';
	v_ruta_raiz_guia := v_da->'datosOrdenPago'->>'rutaRaizGuia';
	v_ruta_dominio_guia := v_da->'datosOrdenPago'->>'rutaDominioGuia';
	
	
	/*IF v_metodo_pago = 'saldo'THEN
	
		SELECT 
	
	END IF;*/
	
	IF v_id_area_financiero <> 'N/A' THEN
	
		--Inicio obtener el item del tarifario--				
		SELECT
			id_servicio
			, concepto
			, unidad
			, valor
			, iva
			, subsidio
		FROM
			g_financiero.servicios
		WHERE
			codigo = v_codigo_servicio
			AND id_area = v_id_area_financiero INTO v_id_servicio_detalle, v_concepto_detalle, v_cantidad_detalle, v_precio_unitario_detalle, v_posee_iva, v_subsidio_detalle;
		--Fin obtener el item del tarifario--						
		
		v_total_pagar := v_precio_unitario_detalle;
		v_total_detalle := v_precio_unitario_detalle;
		
		--Inicio calculo iva--
		IF v_posee_iva THEN
		
			SELECT				
				v_total_pagar * (v_porcentaje_iva/100)
			INTO v_iva_detalle;

			v_total_pagar := v_total_pagar + v_iva_detalle;								
			v_total_detalle := v_total_pagar;
		
		END IF;
		--Fin calculo iva--
		
		--Inicio calcular disponibilidad de saldo--
		IF v_metodo_pago = 'saldo' THEN
		
			SELECT
				vsaldo_cliente
				, vresultado_saldo
			FROM
				g_financiero.fs_validar_saldo_servicio_operador(v_identificador_cliente, v_total_pagar) 
			INTO 
				v_saldo_disponible_cliente, v_generar_orden_pago;
				
		END IF;
		--Fin calcular disponibilidad de saldo--
	
	END IF;
	
	
	IF v_generar_orden_pago THEN
	
		---------------------------------------------------------------------------	
		--Inicio registro de grupos solicitudes y registro en revision financiero--
		--valida si se debe registrar en las tablas de g_revision_solicitudes    --
		---------------------------------------------------------------------------
		IF v_asignar_monto_solicitud THEN				
			
			INSERT INTO 
				g_revision_solicitudes.asignacion_inspector
				(identificador_inspector,
				 fecha_asignacion,
				 identificador_asignante,
				 tipo_solicitud,
				 tipo_inspector,
				 id_operador_tipo_operacion,
				 id_historial_operacion)
			VALUES 
				(v_identificador_recaudador,
				 now(),
				 v_identificador_recaudador,
				 v_tipo_solicitud,
				 v_tipo_inspector,
				 v_id_operador_tipo_operacion,
				 v_id_historial_operacion) RETURNING id_grupo INTO v_id_grupo;

			INSERT INTO 
				g_revision_solicitudes.grupos_solicitudes
			VALUES
				(v_id_grupo, v_id_solicitud::INTEGER, 'Financiero');        

			SELECT
				COALESCE(MAX(CAST(orden as  numeric(5))), 0 ) + 1 as orden
			FROM
				g_revision_solicitudes.financiero
			WHERE
				id_grupo = v_id_grupo INTO v_orden;

			INSERT INTO
				g_revision_solicitudes.financiero 
				(id_grupo, 
				 identificador_inspector, 
				 monto, 
				 fecha_asignacion_monto, 
				 orden)
			VALUES
				(v_id_grupo, v_identificador_recaudador, v_total_pagar, v_fecha_orden_pago, v_orden);	
		
		END IF;
		--Fin registro de grupos solicitudes y registro en revision financiero--
		
		--Inicio generar numero de documento--
		SELECT g_financiero.fs_generacion_numero_orden_pago() INTO v_numero_solicitud;
		--Fin generar numero de documento--		
				
		--Inicio ruta orden pago pdf--		
		v_nombre_secuencia:= g_financiero.obtener_secuencia_orden_pago_diaria();
		v_fecha_partir1_doc := EXTRACT(HOUR FROM v_fecha_orden_pago);
		v_fecha_partir2_doc := EXTRACT(MINUTE FROM v_fecha_orden_pago);
		v_fecha_partir4_doc := EXTRACT(SECOND FROM v_fecha_orden_pago) + v_nombre_secuencia;
		v_fecha_partir3_doc := v_fecha_partir1_doc - 1;
										
		v_ruta_fecha := TO_CHAR(v_fecha_orden_pago, 'YYYY/MM/DD');

		v_nombre_archivo := v_nombre_reporte || '_' || v_identificador_cliente
						|| '_' ||TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD')
						|| '_' || v_fecha_partir3_doc
						|| '_' || v_fecha_partir2_doc
						|| '_' || v_fecha_partir4_doc 
						|| '.pdf';

		v_ruta_archivo_orden_pago := v_path_base_ruta_archivo || v_ruta_fecha || '/' || v_nombre_archivo;
		--Fin ruta orden pago pdf--
		
		---------------------------------------------------------------------------
		--Valida si la orden de pago se genera a partir de un codigo de tarifario--
		--si v_id_area_financiero <> N/A se recibe un item de tarifario y un area--
		---------------------------------------------------------------------------
		IF v_tipo_solicitud <> 'lims' THEN
			
			
							
			--Inicio insercion en cabecera orden pago--
			INSERT INTO g_financiero.orden_pago(identificador_operador, numero_solicitud, fecha_orden_pago, total_pagar, observacion, estado
												, localizacion, nombre_provincia, id_provincia, identificador_usuario, tipo_solicitud
												, id_grupo_solicitud, id_solicitud, orden_pago, tipo_proceso, porcentaje_iva, metodo_pago)
										VALUES (v_identificador_cliente, v_numero_solicitud, v_fecha_orden_pago, v_total_pagar, v_observacion, v_estado_orden_pago
												, v_localizacion_recaudador, v_nombre_provincia_recaudador, v_id_provincia_recaudador, v_identificador_recaudador, v_tipo_solicitud
												, v_id_grupo, v_id_solicitud, v_ruta_archivo_orden_pago, v_tipo_proceso, v_porcentaje_iva, v_metodo_pago) RETURNING id_pago INTO v_n_id_pago;
			--Fin insercion en cabecera orden pago--
			
			--Inicio registrar datos detalle pago--
			INSERT INTO g_financiero.detalle_pago(id_pago, id_servicio, concepto_orden, 
												cantidad, precio_unitario, descuento, iva, total, subsidio)
										VALUES (v_n_id_pago, v_id_servicio_detalle, v_concepto_detalle,
												v_cantidad_detalle, v_precio_unitario_detalle, v_descuento_detalle, v_iva_detalle, v_total_detalle, v_subsidio_detalle);
			--Fin registrar datos detalle pago--
			
		ELSIF v_tipo_solicitud = 'lims' THEN				
			
				SELECT
					total_pagar
				FROM
					g_lims.orden_trabajo
				WHERE
					id_orden_trabajo::TEXT = v_id_solicitud INTO v_total_pagar;
					
				--Inicio insercion en cabecera orden pago--
				INSERT INTO g_financiero.orden_pago(identificador_operador, numero_solicitud, fecha_orden_pago, total_pagar, observacion, estado
													, localizacion, nombre_provincia, id_provincia, identificador_usuario, tipo_solicitud
													, id_grupo_solicitud, id_solicitud, orden_pago, tipo_proceso, porcentaje_iva, metodo_pago)
											VALUES (v_identificador_cliente, v_numero_solicitud, v_fecha_orden_pago, v_total_pagar, v_observacion, v_estado_orden_pago
													, v_localizacion_recaudador, v_nombre_provincia_recaudador, v_id_provincia_recaudador, v_identificador_recaudador, v_tipo_solicitud
													, v_id_grupo, v_id_solicitud, v_ruta_archivo_orden_pago, v_tipo_proceso, v_porcentaje_iva, v_metodo_pago) RETURNING id_pago INTO v_n_id_pago;
				--Fin insercion en cabecera orden pago--
				
				--Inicio registrar datos detalle pago--
				FOR r_detalle_orden_trabajo IN (SELECT 
													id_servicio, concepto_orden, cantidad, precio_unitario, descuento, iva, total 
												FROM 
													g_lims.orden_trabajo_detalle 
												WHERE 
													id_orden_trabajo::TEXT = v_id_solicitud) LOOP
				
					v_id_servicio_detalle := r_detalle_orden_trabajo.id_servicio;
					v_concepto_detalle := r_detalle_orden_trabajo.concepto_orden;
					v_cantidad_detalle := r_detalle_orden_trabajo.cantidad;
					v_precio_unitario_detalle := r_detalle_orden_trabajo.precio_unitario;
					v_descuento_detalle := r_detalle_orden_trabajo.descuento;
					v_iva_detalle := r_detalle_orden_trabajo.iva;
					v_total_detalle := r_detalle_orden_trabajo.total;
					v_subsidio_detalle := 0;
				
					INSERT INTO g_financiero.detalle_pago(id_pago, id_servicio, concepto_orden, 
														cantidad, precio_unitario, descuento, iva, total, subsidio)
												VALUES (v_n_id_pago, v_id_servicio_detalle, v_concepto_detalle,
														v_cantidad_detalle, v_precio_unitario_detalle, v_descuento_detalle, v_iva_detalle, v_total_detalle, v_subsidio_detalle);
				
				END LOOP;			
				--Fin registrar datos detalle pago--
			
			END IF;	
		
		
		--Inicio cambio de estado de solicitudes--
		IF v_tipo_solicitud = 'modificacionProductoRia' THEN
		
			UPDATE
				g_modificacion_productos.solicitudes_productos
			 SET
				estado_solicitud_producto = v_estado_solicitud
			 WHERE
				id_solicitud_producto::TEXT = v_id_solicitud;

		ELSIF v_tipo_solicitud = 'registroProductoRia' THEN
			
			UPDATE
				g_registro_productos.solicitudes_registro_productos
			SET
				estado = v_estado_solicitud
			WHERE
				id_solicitud_registro_producto::TEXT = v_id_solicitud;
				
		ELSIF v_tipo_solicitud = 'certificadoFito' THEN
					
			UPDATE 
				g_certificado_fitosanitario.certificado_fitosanitario
			SET 
				estado_certificado = v_estado_solicitud
			WHERE
				id_certificado_fitosanitario::TEXT = v_id_solicitud;
				
			IF v_metodo_pago = 'saldo' THEN
			
				INSERT INTO 
					g_financiero.saldos(id_pago, fecha_deposito, valor_egreso, saldo_disponible, identificador_operador, tipo_saldo)
				VALUES 
					(v_n_id_pago, now(), ROUND (v_total_pagar::NUMERIC, 2), ROUND ((v_saldo_disponible_cliente - v_total_pagar)::NUMERIC, 2), v_identificador_cliente, 'saldoAgr');
			
			END IF;
				
		ELSIF v_tipo_solicitud = 'lims' THEN
					
			UPDATE
				g_lims.orden_trabajo
			SET
				ruta_orden_pago = v_ruta_dominio_guia || v_ruta_archivo_orden_pago
				, estado = v_estado_solicitud
			WHERE
				id_orden_trabajo::TEXT = v_id_solicitud;
		
		END IF;
		--Fin cambio de estado de solicitudes--
		
		--Inio envio de correo con orden de pago--
		IF v_total_pagar > 0 THEN
		
			SELECT
				razon_social
				, correo
			FROM
				g_financiero.clientes
			WHERE
				identificador = v_identificador_cliente INTO v_razon_social, v_correo;					
		
			v_datos_orden_pago := json_build_object(
									'idPago', v_n_id_pago,
									'tipoSolicitud', v_tipo_solicitud,
									'numeroSolicitud', v_numero_solicitud,
									'razonSocial', v_razon_social,
									'correoCliente', v_correo,
									'rutaOrdenPago', v_ruta_raiz_guia || v_ruta_archivo_orden_pago
								);
							
			CALL g_financiero.sp_envio_correo_orden_pago(v_datos_orden_pago);
			
		END IF;
		--Fin envio de correo con orden de pago--
		
		json_parametro := json_build_object('error', 0,
											'mensaje', 'Éxito',
											'idPago', v_n_id_pago,
											'totalSubsidio', v_total_subsidio,
											'provinciaSolicitud', v_nombre_provincia_solicitud,
											'rutaOrdenPago', v_ruta_archivo_orden_pago,
											'rutaFecha', v_ruta_fecha,
											'archivoSalida', v_ruta_archivo_orden_pago,
											'estado', v_estado_orden_pago);			
	ELSE
	
		json_parametro := json_build_object('error', 1);	
		
	END IF;
	

END;
$$;

alter procedure sp_generar_orden_pago_procesos_automaticos(inout json) owner to postgres;

