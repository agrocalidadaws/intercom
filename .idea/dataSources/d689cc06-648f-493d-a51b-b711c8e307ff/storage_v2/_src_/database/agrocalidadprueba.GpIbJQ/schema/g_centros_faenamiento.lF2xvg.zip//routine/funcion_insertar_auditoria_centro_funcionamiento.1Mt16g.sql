create function funcion_insertar_auditoria_centro_funcionamiento(_criterio_funcionamiento character varying, _observacion character varying, _identificador_registro character varying, _id_centro_faenamiento integer) returns void
    language plpgsql
as
$$
BEGIN
	INSERT INTO g_centros_faenamiento.auditoria_centro_faenamiento(criterio_funcionamiento, observacion,identificador_registro, id_centro_faenamiento)
		VALUES (_criterio_funcionamiento, _observacion, _identificador_registro,_id_centro_faenamiento);
		
END;
$$;

alter function funcion_insertar_auditoria_centro_funcionamiento(varchar, varchar, varchar, integer) owner to postgres;

