create function mostrar_presupuestos(_area text, _objetivo integer, _proceso integer, _subproceso integer, _actividad text, _fecha_inicio timestamp without time zone, _fecha_fin timestamp without time zone, _item_presupuestario text, _gasto text, _estado integer, _anio integer) returns SETOF g_poa.vista_matriz_presupuesto
    language plpgsql
as
$$
DECLARE
	query text;
BEGIN	
	_area=replace(_area, '-', ''',''');
	
	return query EXECUTE '	
		SELECT
			*
		FROM 
			g_poa.vista_matriz_presupuesto
		WHERE 
		        
			($1 is NULL or id_area in ('''|| $1 ||''')) and 
			($2 is NULL or id_objetivo = $2) and 
			($3 is NULL or id_proceso = $3) and 
			($4 is NULL or id_subproceso = $4) and  
			($5 is NULL or codigo_actividad = $5) and 
			($6 is NULL or fecha_creacion >= $6) and 
			($7 is NULL or fecha_creacion <= $7) and
			($8 is NULL or codigo_item = $8) and
			($9 is NULL or detalle_gasto like $9) and
			($10 is NULL or estado = $10) and
			($11 is NULL or anio = $11)
			
		ORDER BY
			proceso,subproceso,nombre'
		using _area,_objetivo,_proceso, _subproceso,_actividad, _fecha_inicio,_fecha_fin,_item_presupuestario,_gasto, _estado, _anio ;
	
END;
$$;

alter function mostrar_presupuestos(text, integer, integer, integer, text, timestamp, timestamp, text, text, integer, integer) owner to postgres;

