create function pac(_n2 text, _programa text, _proyecto text, _actividad text, _provincia integer, _anio integer, _estado text) returns SETOF g_programacion_presupuestaria.vista_pac
    language plpgsql
as
$$
DECLARE
	query text;
BEGIN	
	return query EXECUTE '	
		SELECT
			*
		FROM 
			g_programacion_presupuestaria.vista_pac
		WHERE 		        
			($1 is NULL or id_area_n2 = $1) and 
			($2 is NULL or programa = $2) and 
			($3 is NULL or codigo_proyecto = $3) and
			($4 is NULL or codigo_actividad = $4) and
			($5 is NULL or id_provincia = $5) and
			($6 is NULL or anio = $6) and
			($7 is NULL or estado_presupuesto = $7)
			
		ORDER BY
			area_n2, programa, codigo_proyecto, codigo_actividad'
			
		using _n2, _programa, _proyecto, _actividad, _provincia, _anio, _estado;
	
END;
$$;

alter function pac(text, text, text, text, integer, integer, text) owner to postgres;

