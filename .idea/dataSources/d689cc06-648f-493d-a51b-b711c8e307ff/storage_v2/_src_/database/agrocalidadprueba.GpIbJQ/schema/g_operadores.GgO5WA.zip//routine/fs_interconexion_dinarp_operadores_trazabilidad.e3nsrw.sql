create function fs_interconexion_dinarp_operadores_trazabilidad(pidentificador character varying, OUT cedula_ruc character varying, OUT razon_social character varying, OUT nombre_representante_legal text, OUT id_tipo_operacion integer, OUT tipo_operacion character varying, OUT id_tipo_producto integer, OUT tipo_producto character varying, OUT id_subtipo_producto integer, OUT subtipo_producto character varying, OUT id_producto integer, OUT nombre_producto text, OUT superficie_area double precision, OUT unidad_medida character varying, OUT codigo_area text, OUT id_provincia integer, OUT provincia character varying, OUT id_canton integer, OUT canton character varying, OUT id_parroquia integer, OUT parroquia character varying, OUT longitud_x character varying, OUT latitud_y character varying, OUT zona character varying, OUT codigo_tipo_operacion character varying, OUT area_tematica character varying, OUT id_area_operacion integer, OUT nombre_area_operacion character varying, OUT codigo_area_operacion character varying, OUT estado_registro character varying, OUT fecha_aprobacion timestamp without time zone, OUT fecha_siembra timestamp without time zone, OUT existencias integer, OUT codigo_postal character varying, OUT coordenadas_area character varying) returns SETOF record
    language plpgsql
as
$$

/*
-------------------------------------------------------------------------
--  [g_operadores.fs_interconexion_dinarp_operadores_trazabilidad]
--               
--  Esta funcion retorna un json con los campos seleccionados de los operadores de para hacer una trazabilidad de las operaciones en estado registrado
--  Cabe recalcar que esta funcion es fundamental para la compartision de datos mediante ws a la dinarp
--
--  VERSION		AUTOR					FECHA			HU	
--	1			Kleber Armijos		12-08-2024	  Funcion retorna json de un operador dandole trazabilidad de las operaciones registradas. 
--												  
-------------------------------------------------------------------------
*/
declare 
--operadores_trazabilidad_operaciones json;
operadores_trazabilidad_operaciones record;
--vid_producto integer :=33827; --para el producto leche
BEGIN	
        --SELECT  json_agg(row_to_json(t))
       -- INTO operadores_trazabilidad_operaciones
       -- FROM (
        return query    SELECT 
                    distinct o.identificador AS cedula_ruc,
                    o.razon_social AS razon_social,
                    upper(o.nombre_representante ||' '||o.apellido_representante) AS nombre_representante_legal,	
                    op.id_tipo_operacion,
                    top.nombre AS tipo_operacion,
                    tp_pro.id_tipo_producto,
                    tp_pro.nombre as tipo_producto,
                    sub_pro.id_subtipo_producto,
                    sub_pro.nombre as subtipo_producto,
                    pr.id_producto,
                    REPLACE(REPLACE(REPLACE(pr.nombre_comun,chr(9),''),chr(10),''),chr(13),'') as nombre_producto,
                    a.superficie_utilizada AS superficie_area,
                    ap.unidad_medida,
                    o.identificador||'.'||s.codigo_provincia||s.codigo||a.codigo||a.secuencial AS codigo_area,
                    loc_prov.id_localizacion AS id_provincia,
                    loc_prov.nombre as provincia,
                    loc_cant.id_localizacion AS id_canton,
                    loc_cant.nombre as canton,
                    loc_parr.id_localizacion AS id_parroquia,
                    loc_parr.nombre as parroquia,	
                    s.longitud AS x,
					s.latitud AS y,                    
                    s.zona,
                   -- top.id_tipo_operacion,
                    --top.nombre AS tipo_operacion,
                    top.codigo AS codigo_tipo_operacion,
                    top.id_area AS area_tematica,
                    ap.id_area_operacion,
                    ap.nombre AS nombre_area_operacion,
                    ap.codigo AS codigo_area_operacion,
                    op.estado AS estado_registro,
                    op.fecha_aprobacion,
                    null::timestamp without time zone as fecha_siembra ,
                    null::integer as existencias,
                    null::character varying as codigo_postal,
                    null::character varying as coordenadas_area
                FROM
                    g_operadores.operadores o 
                    INNER JOIN g_operadores.sitios s ON s.identificador_operador = o.identificador
                    INNER JOIN g_catalogos.localizacion loc_prov ON UPPER(UNACCENT(loc_prov.nombre)) = UPPER(UNACCENT(s.provincia))  AND loc_prov.id_localizacion_padre = 66 
                    INNER JOIN g_catalogos.localizacion loc_cant ON UPPER(UNACCENT(loc_cant.nombre)) = UPPER(UNACCENT(s.canton))  AND loc_cant.id_localizacion_padre = loc_prov.id_localizacion 
                    INNER JOIN g_catalogos.localizacion loc_parr ON UPPER(UNACCENT(loc_parr.nombre)) = UPPER(UNACCENT(s.parroquia)) AND loc_parr.id_localizacion_padre = loc_cant.id_localizacion   
                    INNER JOIN g_operadores.areas a ON a.id_sitio = s.id_sitio
                    INNER JOIN g_operadores.productos_areas_operacion pao ON pao.id_area = a.id_area
                    INNER JOIN g_operadores.operaciones op ON op.id_operacion = pao.id_operacion
                    INNER JOIN g_catalogos.tipos_operacion top ON top.id_tipo_operacion = op.id_tipo_operacion  
                    INNER JOIN g_catalogos.areas_operacion ap ON ap.id_tipo_operacion = top.id_tipo_operacion
                    LEFT JOIN g_catalogos.productos pr ON pr.id_producto = op.id_producto
                    LEFT JOIN g_catalogos.subtipo_productos sub_pro ON sub_pro.id_subtipo_producto = pr.id_subtipo_producto
                    LEFT JOIN g_catalogos.tipo_productos tp_pro ON tp_pro.id_tipo_producto = sub_pro.id_tipo_producto

                WHERE
                    top.id_area || top.codigo IN ('AIACO', 'AICOM', 'AIFAE', 'AIINL', 'AIMDC', 'AIMDT', 'AIPRC', 'AIPRO', 'AIREC', 'CGRIAALM', 'CGRIAICP',
                                            'CGRIAODI', 'IAFDIS', 'IAFENV', 'IAFFIE', 'IAFIDE', 'IAPAER', 'IAPDIS', 'IAPENV', 'IAPFOR', 'IAPFRA',
                                            'IAPMAN', 'IAVDIS', 'IAVENV', 'IAVFOR', 'IAVFRA', 'SACOD', 'SACOM', 'SACPE', 'SADMR', 'SAEPE', 'SAINC',
                                            'SAIND', 'SAOPI', 'SAOPM', 'SAOPT', 'SAPMR', 'SAPRA', 'SAPRO', 'SASEA', 'SATAV', 'SVACO', 'SVAGE', 'SVALM',
                                            'SVCOM', 'SVCON', 'SVFRA', 'SVIND', 'SVMIM', 'SVPRO', 'SVPRP', 'SVVVE')
                    AND	op.estado = 'registrado'
                    AND op.identificador_operador = $1
                ORDER BY  loc_prov.nombre,loc_cant.nombre,  loc_parr.nombre, top.nombre ASC ;
        --) t;
--return operadores_trazabilidad_operaciones;
END;
$$;

alter function fs_interconexion_dinarp_operadores_trazabilidad(varchar, out varchar, out varchar, out text, out integer, out varchar, out integer, out varchar, out integer, out varchar, out integer, out text, out double precision, out varchar, out text, out integer, out varchar, out integer, out varchar, out integer, out varchar, out varchar, out varchar, out varchar, out varchar, out varchar, out integer, out varchar, out varchar, out varchar, out timestamp, out timestamp, out integer, out varchar, out varchar) owner to postgres;

