create function fs_reporte_importacion_sanidad_animal_2_rechazados(pfecha_inicio date, pfecha_inicio2 date, OUT identificador character varying, OUT razon_social character varying, OUT direccion character varying, OUT correo character varying, OUT tipo_producto character varying, OUT subtipo_prodcuto character varying, OUT nombre_producto character varying, OUT partida_arancelaria character varying, OUT cantidad_producto double precision, OUT unidad_producto character varying, OUT peso double precision, OUT unidad_peso character varying, OUT licencia_magap character varying, OUT pais_origen character varying, OUT razon_exportador character varying, OUT direccion_exportador character varying, OUT tipo_transporte character varying, OUT puerto_embarque character varying, OUT puerto_destino character varying, OUT id_vue character varying, OUT valor_fob double precision, OUT nombre_provincia character varying, OUT nombre_ciudad character varying, OUT fecha_creacion date, OUT id_importacion integer, OUT fecha_aprobacion date, OUT fecha_vigencia date, OUT estado character varying, OUT id_revision_documental integer, OUT nombre_tecnico text, OUT fecha_inspeccion date, OUT observacion character varying, OUT fecha_imposicion_tasa date) returns SETOF record
    language plpgsql
as
$$
BEGIN
create    table tbl_revision_doc as(SELECT 			
						distinct
						o.identificador,	
						o.razon_social,
						o.direccion,
						o.correo, 
					    tp.nombre as tipo_producto,
						sp.nombre as subtipo_prodcuto,
						p.nombre_comun as nombre_producto,
						p.partida_arancelaria,
						ip.unidad as cantidad_producto,
						ip.unidad_medida as unidad_cantidad,
						ip.peso,
						ip.unidad_peso,
						ip.licencia_magap,
						ip.valor_fob,
						i.identificador_operador, 						
						i.id_importacion,
						i.id_area,
						i.estado,
					    i.fecha_inicio as fecha_aprobacion,
						i.fecha_vigencia,
					    i.pais_exportacion as pais_origen,
						i.nombre_exportador as razon_exportador,
						i.direccion_exportador as direccion_exportador,
						i.tipo_transporte,
						i.puerto_embarque,
						i.puerto_destino,
						i.id_vue,
						i.nombre_provincia,
						i.nombre_ciudad,
						i.fecha_creacion,						
			 			rd.estado as estado_revision_documental,
						rd.id_revision_documental,
						ai2.id_grupo
						
 						FROM  
							g_importaciones.importaciones_productos ip,
							g_catalogos.productos p,
							g_catalogos.subtipo_productos sp,
							g_catalogos.tipo_productos tp,
							g_importaciones.importaciones i,
 							g_revision_solicitudes.grupos_solicitudes gs2, 
 							g_revision_solicitudes.asignacion_inspector ai2, 
 							g_revision_solicitudes.revision_documental rd, 
							g_operadores.operadores o,							
 							g_uath.ficha_empleado fe 
 						WHERE 							
 							gs2.id_grupo = ai2.id_grupo and 
 							ai2.id_grupo = rd.id_grupo and  
 							ai2.tipo_solicitud = 'Importación' and 
 							ai2.tipo_inspector = 'Documental' and 
 							gs2.id_solicitud =i.id_importacion and 
 							fe.identificador = ai2.identificador_inspector
							and o.identificador = i.identificador_operador
							and i.id_importacion = ip.id_importacion 
	       					and ip.id_producto = p.id_producto 
							and p.id_subtipo_producto = sp.id_subtipo_producto 
							and sp.id_tipo_producto = tp.id_tipo_producto 
							and rd.fecha_inspeccion>=$1
							and rd.fecha_inspeccion<=$2 
							and i.id_area='SA'
							and i.estado in ('rechazado','subsanacion')							

  group by 				o.identificador,	
						o.razon_social,
						o.direccion,
						o.correo, 
						tp.nombre ,
						sp.nombre,
						p.nombre_comun ,
						p.partida_arancelaria,
						ip.unidad ,
						ip.unidad_medida ,
						ip.peso,
						ip.unidad_peso,
						ip.licencia_magap,
						ip.valor_fob,
						i.identificador_operador, 						
						i.id_importacion,
						i.id_area,
						i.estado,
					    i.fecha_inicio ,
						i.fecha_vigencia,
					    i.pais_exportacion ,
						i.nombre_exportador ,
						i.direccion_exportador ,
						i.tipo_transporte,
						i.puerto_embarque,
						i.puerto_destino,
						i.id_vue,
						i.nombre_provincia,
						i.nombre_ciudad,
						i.fecha_creacion,						
			 			rd.estado ,
						rd.id_revision_documental,
						ai2.id_grupo				   

);

create   table tmp_revision_documental as(
SELECT 
	
						tbl_rev_doc.identificador,	
						tbl_rev_doc.razon_social,
						tbl_rev_doc.direccion,
						tbl_rev_doc.correo, 
					    tbl_rev_doc.tipo_producto,
						tbl_rev_doc.subtipo_prodcuto,
						tbl_rev_doc.nombre_producto,
						tbl_rev_doc.partida_arancelaria,
						tbl_rev_doc.cantidad_producto,
						tbl_rev_doc.unidad_cantidad,
						tbl_rev_doc.peso,
						tbl_rev_doc.unidad_peso,
						tbl_rev_doc.licencia_magap,	
						tbl_rev_doc.valor_fob,
					    tbl_rev_doc.fecha_aprobacion,
						tbl_rev_doc.fecha_vigencia,
					    tbl_rev_doc.pais_origen,
						tbl_rev_doc.razon_exportador,
						tbl_rev_doc.direccion_exportador,
						tbl_rev_doc.tipo_transporte,
						tbl_rev_doc.puerto_embarque,
						tbl_rev_doc.puerto_destino,
						tbl_rev_doc.id_vue,
						tbl_rev_doc.nombre_provincia,
						tbl_rev_doc.nombre_ciudad,
						tbl_rev_doc.fecha_creacion,				
						tbl_rev_doc.id_revision_documental,
						tbl_rev_doc.id_importacion,
						tbl_rev_doc.id_area,
						tbl_rev_doc.estado,
						tbl_rev_doc.estado_revision_documental,
						tbl_rev_doc.id_grupo,
						tbl_rev_doc.identificador_operador,
						 (fe.apellido ||' '|| fe.nombre ) as nombre_tecnico,
						 rd.fecha_inspeccion::date , 
						 rd.observacion
 		FROM
			tbl_revision_doc tbl_rev_doc,
			g_revision_solicitudes.revision_documental rd, 
 			g_uath.ficha_empleado fe 
 		WHERE 
 			fe.identificador = rd.identificador_inspector and 
 		 	rd.id_revision_documental =tbl_rev_doc.id_revision_documental
	and rd.estado in('rechazado','subsanacion')
			
);	

create  table tmp_fecha_revision as(SELECT 
		temp_rev.identificador,
		temp_rev.razon_social,
		temp_rev.direccion,
		temp_rev.correo,
		temp_rev.tipo_producto,
		temp_rev.subtipo_prodcuto,
		temp_rev.nombre_producto,
		temp_rev.partida_arancelaria,	
		temp_rev.cantidad_producto,
		temp_rev.unidad_cantidad,
		temp_rev.peso,
		temp_rev.unidad_peso,
		temp_rev.licencia_magap,		
		temp_rev.pais_origen,
		temp_rev.razon_exportador,
		temp_rev.direccion_exportador,	
		temp_rev.tipo_transporte,
		temp_rev.puerto_embarque,
		temp_rev.puerto_destino,
		temp_rev.id_vue,
		temp_rev.valor_fob,	
		temp_rev.nombre_provincia,
		temp_rev.nombre_ciudad,
		temp_rev.fecha_creacion,		
		temp_rev.id_importacion,									
		temp_rev.fecha_aprobacion,
		temp_rev.fecha_vigencia,
		temp_rev.estado,
		temp_rev.id_revision_documental,
		temp_rev.nombre_tecnico,
		temp_rev.fecha_inspeccion,	
		temp_rev.observacion,			
		MAX(f1.fecha_asignacion_monto)::date AS  fecha_imposicion_tasa
		FROM  
		tmp_revision_documental temp_rev,
		g_revision_solicitudes.grupos_solicitudes gs1, 
		g_revision_solicitudes.asignacion_inspector ai1, 
		g_revision_solicitudes.financiero f1 
		WHERE
		gs1.id_grupo = ai1.id_grupo 
		and ai1.id_grupo = f1.id_grupo 
		--and ai1.tipo_solicitud = 'Importación' 
		and ai1.tipo_inspector = 'Financiero' 
		and gs1.id_solicitud = temp_rev.id_importacion 
		and f1.estado = 'aprobado'
		--and temp_rev.estado_revision_documental not in('pago','subsanacion')
		group by 
		temp_rev.identificador,
		temp_rev.razon_social,
		temp_rev.direccion,
		temp_rev.correo,
		temp_rev.tipo_producto,
		temp_rev.subtipo_prodcuto,
		temp_rev.nombre_producto,
		temp_rev.partida_arancelaria,	
		temp_rev.cantidad_producto,
		temp_rev.unidad_cantidad,
		temp_rev.peso,
		temp_rev.unidad_peso,
		temp_rev.licencia_magap,
		temp_rev.valor_fob,
		temp_rev.fecha_aprobacion,
		temp_rev.fecha_vigencia,
		temp_rev.pais_origen,
		temp_rev.razon_exportador,
		temp_rev.direccion_exportador,
		temp_rev.tipo_transporte,
		temp_rev.puerto_embarque,
		temp_rev.puerto_destino,
		temp_rev.id_vue,
		temp_rev.nombre_provincia,
		temp_rev.nombre_ciudad,
		temp_rev.fecha_creacion,
		temp_rev.id_revision_documental,
		temp_rev.id_importacion,
		temp_rev.id_area,
		temp_rev.estado,
		temp_rev.estado_revision_documental,
		temp_rev.id_grupo,
		temp_rev.nombre_tecnico,
		temp_rev.fecha_inspeccion,
		temp_rev.identificador_operador,
		--							f1.estado,
		temp_rev.observacion
		ORDER BY 
		temp_rev.id_vue
	);
 RETURN QUERY	select *from tmp_fecha_revision;
			drop table tbl_revision_doc;
			drop table tmp_revision_documental;
			drop table tmp_fecha_revision;
END;
$$;

alter function fs_reporte_importacion_sanidad_animal_2_rechazados(date, date, out varchar, out varchar, out varchar, out varchar, out varchar, out varchar, out varchar, out varchar, out double precision, out varchar, out double precision, out varchar, out varchar, out varchar, out varchar, out varchar, out varchar, out varchar, out varchar, out varchar, out double precision, out varchar, out varchar, out date, out integer, out date, out date, out varchar, out integer, out text, out date, out varchar, out date) owner to postgres;

