create function insertar_orden_estructura() returns trigger
    language plpgsql
as
$$ 

BEGIN
	IF (NEW.id_estructura_padre is null) THEN
		NEW.orden = public.calcular_orden_siguiente('g_biblioteca.estructuras', 'id_resolucion', NEW.id_resolucion);
	ELSE
		NEW.orden = public.calcular_orden_siguiente('g_biblioteca.estructuras', 'id_estructura_padre', NEW.id_estructura_padre);
	END IF;
	RETURN NEW;
	END; 
	
$$;

alter function insertar_orden_estructura() owner to postgres;

