create function reporte_manejo_integrado_actividad(pfecha_desde date, pfecha_hasta date, OUT identificador_tecnico character varying, OUT provincia character varying, OUT canton character varying, OUT parroquia character varying, OUT coordenada_x character varying, OUT coordenada_y character varying, OUT coordenada_z character varying, OUT fecha timestamp without time zone, OUT semana integer, OUT acciones_mip character varying, OUT mdt_inicial numeric, OUT plaga_objetivo character varying, OUT escenario character varying, OUT especie_hortofruticola character varying, OUT especie_hospedante character varying, OUT superficie numeric, OUT medidas_control character varying, OUT cantidad numeric, OUT insumos character varying, OUT fuente character varying, OUT mdt_final numeric) returns SETOF record
    language plpgsql
as
$$
/*
-------------------------------------------------------------------------
--  [f_inspeccion.reporte_manejo_integrado_actividad]
--               
--  Esta funcion retorna records de los manejos integrados de las actividades 
--
--  VERSION		AUTOR					FECHA			HU			                           CAMBIO
--	1			Kleber Armijos		03-07-2023			frm manejo integrado actividad           Creacion generacion reporte 
-------------------------------------------------------------------------
*/
DECLARE
	
BEGIN	
CREATE TABLE  temp_reporte_manejo_integrado AS(
	SELECT 
	act_man_int.usuario_id,
 	act_man_int.provincia , 
    act_man_int.canton ,
    act_man_int.parroquia ,
    act_man_int.coordenada_x ,
    act_man_int.coordenada_y ,
    act_man_int.coordenada_z ,
    act_man_int.fecha_registro_actividad AS fecha,
    act_man_int.semana_actual  AS semana,
    ca_acc_mip.nombre AS acciones_mip ,
    ROUND(act_man_int.mtd_inicial, 3) mdt_inicial,
    ca_pla_ob.nombre AS plaga_objetivo ,
    ca_esc.nombre AS escenario,
    ca_esp_hort.nombre AS especie_hortofruticola ,
	ca_esp_hosp.nombre as especie_Hospedante,
	--string_agg(ca_esp_hosp.nombre,',') AS especie_Hospedante,
    ROUND(act_man_int.superficie ,2) superficie,
	ca_med_con.nombre as medidas_control,
	 man_in_fu_can.cantidad_medidas_control as cantidad,
	 ca_in.nombre as insumos,
	 ca_fue_ac.nombre AS fuente,
	  ROUND(act_man_int.mtd_final, 3) mdt_final
	 --string_agg(ca_in.nombre,'-') AS insumos
-- 		(SELECT ARRAY_TO_JSON(ARRAY_AGG(ROW_TO_JSON(subquery))) as medidascontrol
-- 		FROM (
-- 		 SELECT ca_med_con.nombre AS "Medidas Control ",ca_fue_ac.nombre AS "Fuente " , man_in_fu_can.cantidad_medidas_control AS "Cantidad "
-- 		 ,string_agg(ca_in.nombre,'-') AS "Insumos " 
-- 		FROM 
-- 		f_inspeccion.actividadmedidascontrol_catalogofuente_cantidad man_in_fu_can 
-- 		INNER JOIN f_inspeccion.actividadmanejo_mcfc_catalogoinsumoactividad mcfc_insumo on man_in_fu_can. id=mcfc_insumo.idactividadintegrado_medidascontrol
-- 		INNER JOIN g_catalogos.insumo_actividad ca_in ON mcfc_insumo.id_catalogo_insumos=ca_in.id
-- 		INNER JOIN g_catalogos.medidas_control ca_med_con ON man_in_fu_can.id_manejomedidascontrol_catalogo_medidas_control=ca_med_con.id
-- 		INNER JOIN g_catalogos.fuente_actividad ca_fue_ac ON man_in_fu_can.id_manejomedidascontrol_catalogofuente=ca_fue_ac.id
-- 		WHERE man_in_fu_can.id_manejo_integrado=act_man_int.id
-- 		GROUP BY 
-- 		act_man_int.id,
-- 		ca_med_con.nombre,
-- 		ca_fue_ac.nombre,
-- 		man_in_fu_can.cantidad_medidas_control

-- 		) subquery)
	FROM 
	f_inspeccion.actividades_manejo_integrado act_man_int 
	INNER JOIN g_catalogos.actividad_manejo_integrado ca_acc_mip ON act_man_int.id_accion_mip=ca_acc_mip.id 
	INNER JOIN g_catalogos.actividad_manejo_integrado ca_esc ON act_man_int.id_escenario=ca_esc.id 	
	INNER JOIN g_catalogos.actividad_manejo_integrado  ca_esp_hort ON act_man_int.id_especie_hortofruticola=ca_esp_hort.id 
	INNER JOIN f_inspeccion.actividadmanejointegrado_catalogoespeciehospedante act_man_ca_hospe ON act_man_int.id=act_man_ca_hospe.id_actividad_integrado 
	INNER JOIN g_catalogos.actividad_manejo_integrado ca_esp_hosp ON act_man_ca_hospe.id_catalogo_especie_hospedante= ca_esp_hosp.id 
	inner join f_inspeccion.actividadmedidascontrol_catalogofuente_cantidad man_in_fu_can  on man_in_fu_can.id_manejo_integrado=act_man_int.id
	INNER JOIN f_inspeccion.actividadmanejo_mcfc_catalogoinsumoactividad mcfc_insumo on man_in_fu_can. id=mcfc_insumo.idactividadintegrado_medidascontrol
	INNER JOIN g_catalogos.actividad_manejo_integrado ca_in ON mcfc_insumo.id_catalogo_insumos=ca_in.id
	INNER JOIN g_catalogos.actividad_manejo_integrado ca_med_con ON man_in_fu_can.id_manejomedidascontrol_catalogo_medidas_control=ca_med_con.id
	INNER JOIN g_catalogos.actividad_manejo_integrado ca_fue_ac ON man_in_fu_can.id_manejomedidascontrol_catalogofuente=ca_fue_ac.id
	
	LEFT JOIN g_catalogos.actividad_manejo_integrado ca_pla_ob ON act_man_int.id_plaga_objetivo=ca_pla_ob.id
	WHERE  --act_man_int.fecha_registro_actividad::DATE BETWEEN $1 AND $2
	act_man_int.fecha_registro_actividad::DATE>=$1
	AND act_man_int.fecha_registro_actividad::DATE<=$2
	GROUP BY 
	act_man_int.id,
	act_man_int.provincia,
	act_man_int.canton,
	act_man_int.parroquia ,
	act_man_int.coordenada_x ,
	act_man_int.coordenada_y ,
	act_man_int.coordenada_z ,
	act_man_int.fecha_registro_actividad,
	act_man_int.semana_actual  ,
	ca_acc_mip.nombre ,
	act_man_int.mtd_inicial,
	ca_esc.nombre,
	ca_esp_hort.nombre ,
	ca_pla_ob.nombre,
	act_man_int.superficie,
	ca_med_con.nombre ,
	ca_fue_ac.nombre,
	 man_in_fu_can.cantidad_medidas_control,
	  ca_esp_hosp.nombre,
	  ca_in.nombre
	-- string_agg(ca_in.nombre,'-') 	
);
 RETURN QUERY select *from temp_reporte_manejo_integrado;
  drop table temp_reporte_manejo_integrado;
	
END;
$$;

alter function reporte_manejo_integrado_actividad(date, date, out varchar, out varchar, out varchar, out varchar, out varchar, out varchar, out varchar, out timestamp, out integer, out varchar, out numeric, out varchar, out varchar, out varchar, out varchar, out numeric, out varchar, out numeric, out varchar, out varchar, out numeric) owner to postgres;

