create function actualizar_placa() returns trigger
    language plpgsql
as
$$ 

BEGIN
	--IF (NEW.placa != OLD.placa)
	--THEN
		UPDATE g_transportes.combustible SET placa = NEW.placa WHERE id_vehiculo = OLD.id_vehiculo;
		UPDATE g_transportes.mantenimientos SET placa = NEW.placa WHERE id_vehiculo = OLD.id_vehiculo;
		UPDATE g_transportes.movilizaciones SET placa = NEW.placa WHERE id_vehiculo = OLD.id_vehiculo;
		UPDATE g_transportes.siniestros SET placa = NEW.placa WHERE id_vehiculo = OLD.id_vehiculo;
	--END IF;
	RETURN NEW;
	END; 
	
$$;

alter function actualizar_placa() owner to postgres;

