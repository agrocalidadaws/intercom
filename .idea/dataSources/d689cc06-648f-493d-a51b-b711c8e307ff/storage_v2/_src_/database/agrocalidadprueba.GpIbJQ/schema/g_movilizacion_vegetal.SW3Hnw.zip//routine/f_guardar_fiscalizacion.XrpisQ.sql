create function f_guardar_fiscalizacion(p_datos_fiscalizacion jsonb) returns jsonb
    language plpgsql
as
$$


DECLARE
--p_datos_fiscalizacion JSONB:= '{ "id_movilizacion": "33281", "id_sitio_origen": "544309", "id_sitio_destino": "780630", "estado_movilizacion": "Vigente", "identificador_fiscalizador": "1722551049", --"nombre_fiscalizador": "EDISON JAVIER AYALA ROSERO", "resultado_fiscalizacion": "Negativo", "accion_correctiva": "Anulado", "observacion_fiscalizacion": "dsas", "provincia_fiscalizacion": "Pichincha", "causa_anulacion": "Cambio de fecha", "fecha_fiscalizacion": "2024-01-17", "anio_actual": "2024" }';


--VARIABLES--
detalle_elemento RECORD;
detalle_elemento_transaccion RECORD;
r_validar_cupo RECORD;

v_id_fiscalizacion g_movilizacion_vegetal.fiscalizacion.id_fiscalizacion%TYPE;
v_id_movilizacion g_movilizacion_vegetal.fiscalizacion.id_movilizacion%TYPE;
v_id_sitio_origen g_movilizacion_vegetal.movilizacion.id_sitio_origen%TYPE;
v_id_sitio_destino g_movilizacion_vegetal.movilizacion.id_sitio_destino%TYPE;
v_estado_movilizacion g_movilizacion_vegetal.movilizacion.estado_movilizacion%TYPE;
v_estado_fiscalizacion g_movilizacion_vegetal.movilizacion.estado_fiscalizacion%TYPE;
v_identificador_fiscalizador g_movilizacion_vegetal.fiscalizacion.identificador_fiscalizador%TYPE;
v_nombre_fiscalizador g_movilizacion_vegetal.fiscalizacion.nombre_fiscalizador%TYPE;
v_resultado_fiscalizacion g_movilizacion_vegetal.fiscalizacion.resultado_fiscalizacion%TYPE;
v_accion_correctiva g_movilizacion_vegetal.fiscalizacion.accion_correctiva%TYPE;
v_observacion_fiscalizacion g_movilizacion_vegetal.fiscalizacion.observacion_fiscalizacion%TYPE;
v_provincia_fiscalizacion g_movilizacion_vegetal.fiscalizacion.provincia_fiscalizacion%TYPE;
v_causa_anulacion g_movilizacion_vegetal.fiscalizacion.causa_anulacion%TYPE;
v_fecha_fiscalizacion g_movilizacion_vegetal.fiscalizacion.fecha_fiscalizacion%TYPE;
v_anio_actual INTEGER;

 
--VALIDACIONES--
v_bandera_validar_registro BOOLEAN := true;


-- RETORNAR --
a_resultado JSONB;
resultado TEXT := 'Exito';
mensaje TEXT := 'Los datos fueron registrados con éxito';

BEGIN
    v_id_movilizacion := p_datos_fiscalizacion->>'id_movilizacion';
    v_estado_movilizacion := p_datos_fiscalizacion->>'estado_movilizacion';
    v_id_sitio_origen := p_datos_fiscalizacion->>'id_sitio_origen';
	v_id_sitio_destino := p_datos_fiscalizacion->>'v_id_sitio_destino';
	v_identificador_fiscalizador := p_datos_fiscalizacion->>'identificador_fiscalizador';
	v_nombre_fiscalizador := p_datos_fiscalizacion->>'nombre_fiscalizador';
	v_resultado_fiscalizacion := p_datos_fiscalizacion->>'resultado_fiscalizacion';
	v_accion_correctiva := p_datos_fiscalizacion->>'accion_correctiva';
	v_observacion_fiscalizacion := p_datos_fiscalizacion->>'observacion_fiscalizacion';
	v_provincia_fiscalizacion := p_datos_fiscalizacion->>'provincia_fiscalizacion';
	v_causa_anulacion := p_datos_fiscalizacion->>'causa_anulacion';
	v_fecha_fiscalizacion := (p_datos_fiscalizacion->>'fecha_fiscalizacion');
    v_anio_actual := (p_datos_fiscalizacion->>'anio_actual');
    v_estado_fiscalizacion := 'Fiscalizado';
    
    IF v_estado_movilizacion = 'Vigente' THEN

        -- 1 Recorrer todos los elementos del array "detalle"
        IF v_accion_correctiva = 'Anulado' THEN

            FOR detalle_elemento IN SELECT cantidad, producto, id_producto, unidad, id_area_destino FROM g_movilizacion_vegetal.detalle_movilizacion WHERE id_movilizacion = v_id_movilizacion
            LOOP

				PERFORM
				id_configuracion_producto_cupo
					FROM 
						g_movilizacion_vegetal.configuracion_producto_cupo
					WHERE
					id_producto = detalle_elemento.id_producto
					AND estado_configuracion_producto_cupo = 'Activo';
					
				IF FOUND THEN
				
					PERFORM
						id_unidad_fitosanitaria
					FROM
						g_catalogos.unidades_fitosanitarias
					WHERE
						id_unidad_fitosanitaria = detalle_elemento.unidad
						AND codigo_unidad_fitosanitaria = 'KGM';
						
					IF FOUND THEN

						SELECT 
							cupo_disponible
						FROM 
							g_movilizacion_vegetal.asignacion_cupo
						WHERE
							id_area = detalle_elemento.id_area_destino
							AND id_producto = detalle_elemento.id_producto
							AND estado_asignacion_cupo = 'Activo'
							AND anio_asignacion_cupo = v_anio_actual INTO r_validar_cupo;

						IF FOUND THEN
						
							-- Validacion de cupos por id_area, id_producto --
							IF (detalle_elemento.cantidad > r_validar_cupo.cupo_disponible) THEN

								v_bandera_validar_registro := false;
								resultado := 'Fallo';
								mensaje := 'La cantidad del producto ' || detalle_elemento.producto || ' es mayor al del cupo disponible ' || detalle_elemento.cantidad || ' > ' ||                                                   r_validar_cupo.cupo_disponible;
								EXIT;

							END IF;
							
						END IF;
						
					ELSE
			
						v_bandera_validar_registro := false;
						resultado := 'Fallo';
						mensaje := 'El permiso de movilización posee el producto ' || detalle_elemento.producto || ' configurado con cupo, por lo que no puede ser fiscalizada.';
						EXIT;
						
					END IF;
					
				END IF;

            END LOOP;
			
        END IF;

        IF (v_bandera_validar_registro = true) THEN

            INSERT INTO 
                g_movilizacion_vegetal.fiscalizacion(id_movilizacion, identificador_fiscalizador, nombre_fiscalizador, resultado_fiscalizacion, accion_correctiva, 
                                                    observacion_fiscalizacion, fecha_fiscalizacion, provincia_fiscalizacion, causa_anulacion)
            VALUES (v_id_movilizacion, v_identificador_fiscalizador, v_nombre_fiscalizador, v_resultado_fiscalizacion, v_accion_correctiva, 
                    v_observacion_fiscalizacion, v_fecha_fiscalizacion, v_provincia_fiscalizacion, v_causa_anulacion)
            RETURNING 
                id_fiscalizacion 
            INTO 
                v_id_fiscalizacion;

            IF v_accion_correctiva = 'Anulado' THEN
                FOR detalle_elemento_transaccion IN SELECT cantidad, id_producto, id_area_origen, id_area_destino, unidad, lote FROM g_movilizacion_vegetal.detalle_movilizacion WHERE id_movilizacion = v_id_movilizacion
                LOOP

                    --Valida si el producto esta configurado para cupo
                    PERFORM
                        id_configuracion_producto_cupo
                    FROM 
                        g_movilizacion_vegetal.configuracion_producto_cupo
                    WHERE
                    id_producto = detalle_elemento_transaccion.id_producto
                    AND estado_configuracion_producto_cupo = 'Activo';
                                        
                    IF FOUND THEN

                        PERFORM 
                            id_asignacion_cupo
                        FROM 
                            g_movilizacion_vegetal.asignacion_cupo
                        WHERE
                            id_area = detalle_elemento_transaccion.id_area_destino
                            AND id_producto = detalle_elemento_transaccion.id_producto
                            AND estado_asignacion_cupo = 'Activo'
                            AND anio_asignacion_cupo = v_anio_actual;

                        IF FOUND THEN

                            ----5. Ingreso - Permiso anulado (Fiscalizacion movilizacion destino)
                            PERFORM 
                                * 
                            FROM 
                                g_movilizacion_vegetal.f_transaccion_cupo_movilizacion(v_id_sitio_destino
                                                                        , detalle_elemento_transaccion.id_area_destino
                                                                        , detalle_elemento_transaccion.id_producto
                                                                        , detalle_elemento_transaccion.unidad
                                                                        , detalle_elemento_transaccion.lote
                                                                        , detalle_elemento_transaccion.cantidad
                                                                        , 0
                                                                        , v_anio_actual
                                                                        , v_identificador_fiscalizador
                                                                        , 7
                                                                        , v_id_fiscalizacion);
	

                        END IF;

                        --6. Egreso - Permiso anulado (Fiscalizacion movilizacion origen)		
                        PERFORM 
                            * 
                        FROM 
                            g_movilizacion_vegetal.f_transaccion_cupo_movilizacion(v_id_sitio_origen
                                                                    , detalle_elemento_transaccion.id_area_origen
                                                                    , detalle_elemento_transaccion.id_producto
                                                                    , detalle_elemento_transaccion.unidad
                                                                    , detalle_elemento_transaccion.lote
                                                                    , detalle_elemento_transaccion.cantidad
                                                                    , 0
                                                                    , v_anio_actual
                                                                    , v_identificador_fiscalizador
                                                                    , 8
                                                                    , v_id_fiscalizacion);
                    END IF;		
	
                END LOOP;
                
                v_estado_movilizacion := v_accion_correctiva;
                
            END IF;
                      
            UPDATE 
                g_movilizacion_vegetal.movilizacion
            SET 
                estado_movilizacion = v_estado_movilizacion, estado_fiscalizacion = v_estado_fiscalizacion
            WHERE 
                id_movilizacion = v_id_movilizacion;
                
            IF NOT FOUND THEN
                resultado := 'Fallo';
                mensaje := 'Error al actualizar los datos de movilización por fiscalziacion';
                v_estado_fiscalizacion := 'No fiscalizado';
            END IF;
                
        END IF;
        
    ELSE 
        resultado := 'Fallo';
        mensaje := 'La movilización ya no se encuentra vigente para fiscalizar.';
    END IF;
    
	--RAISE NOTICE '%', jsonb_build_object('resultado', resultado, 'mensaje', mensaje);	
	RETURN jsonb_build_object('resultado', resultado, 'mensaje', mensaje, 'estadoFiscalizacion', v_estado_fiscalizacion);
	
END;

$$;

alter function f_guardar_fiscalizacion(jsonb) owner to postgres;

