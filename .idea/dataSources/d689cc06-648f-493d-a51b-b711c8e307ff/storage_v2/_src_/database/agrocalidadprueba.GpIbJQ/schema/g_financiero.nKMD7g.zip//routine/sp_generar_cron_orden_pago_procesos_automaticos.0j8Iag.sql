create procedure sp_generar_cron_orden_pago_procesos_automaticos(INOUT json_parametro json)
    language plpgsql
as
$$
/*
-------------------------------------------------------------------------
--  [g_financiero.sp_generar_cron_orden_pago_procesos_automaticos]
--               
--  procedimiento que se encarga de recorrer los procesos por generar orden de pago,
--  generacion automatica de ordenes de pago
--
--  VERSION		AUTOR					FECHA			HU			                           
--	1			Kleber Armijos		23-08-2024	 Control de cambios funcional interconexion 
--				Milton Nivelo				     refactoracion financiero pry-banred
-------------------------------------------------------------------------
*/
DECLARE
	
		--Inicio declarar el cursor para obtener los datos de modificacion de productos--
		c_modificacion_producto CURSOR FOR
		SELECT
			id_solicitud_producto::TEXT
			, numero_solicitud
			, identificador_operador			
			, id_area
		FROM
			g_modificacion_productos.solicitudes_productos
		WHERE
			estado_solicitud_producto = 'pago'
			AND descuento IS NULL;
		--Fin declarar el cursor para obtener los datos de modificacion de productos--
		
		--Inicio declarar el cursor para obtener los datos de registro de productos--
		c_registro_producto_ria CURSOR FOR
		SELECT
			id_solicitud_registro_producto::TEXT
			, numero_solicitud
			, identificador_operador			
			, tipo_solicitud
			, provincia_operador
		FROM
			g_registro_productos.solicitudes_registro_productos
		WHERE
			estado = 'pago'
			AND requiere_descuento = false
			AND tipo_solicitud not in ('clonesplaguicidas','bioplaguicidas');
		--Inicio declarar el cursor para obtener los datos de registro de productos--

		--Inicio declarar el cursor para obtener los datos de certificado fitosanitario--
		c_certificado_fitosanitario CURSOR FOR
		SELECT
			id_certificado_fitosanitario
			, tipo_solicitud
			, identificador_solicitante
			, forma_pago
		FROM
			g_certificado_fitosanitario.certificado_fitosanitario
		WHERE
			estado_certificado = 'pago'
			and tipo_solicitud in ('ornamentales', 'musaceas')
			and descuento = 'No';
		--Inicio declarar el cursor para obtener los datos de certificado fitosanitario--

		--Inicio declarar el cursor para obtener los datos de solicitudes LIMS--
		c_lims CURSOR FOR
		SELECT
			id_orden_trabajo
			, identificador
			, provincia
		FROM
			g_lims.orden_trabajo
		WHERE
			estado = 'Por atender';
		--Inicio declarar el cursor para obtener los datos de solicitudes LIMS--	
		
		--Variables de validacion de errores
		vSQLERRM TEXT;
		no_error BOOLEAN;
		
		v_da JSON;
		v_datos_orden_pago JSON;
		v_respuesta_sp_generar_orden_pago_procesos_automaticos JSON;
		a_datos_orden_pago JSON := '[]'::JSON;
		
		-- Variables de modificacion de productos--
		r_datos_modificacion_producto RECORD;

		-- Variables de registro de productos ria--
		r_datos_registro_producto_ria RECORD;

		-- Variables de certificado fitosanitario--
		r_datos_certificado_fitosanitario RECORD;
		
		--Variables de lims--
		r_datos_lims RECORD;
						
		--Variables datos generales--
		v_id_area TEXT;
		v_tipo_solicitud TEXT;
		v_identificador_recaudador TEXT;
		v_asignar_monto_solicitud BOOLEAN;
		v_id_area_financiero TEXT;
		v_ruta_raiz_guia TEXT;
		v_ruta_dominio_guia TEXT;
		v_codigo_servicio TEXT;		
		v_localizacion_recaudador TEXT;
		v_nombre_provincia_recaudador TEXT;	
		v_id_provincia_recaudador INTEGER;
		v_porcentaje_iva INTEGER;
		v_id_solicitud TEXT;
		v_identificador_cliente TEXT;
		v_metodo_pago TEXT := 'efectivo';
		v_nombre_provincia_solicitud TEXT := 'N/A';
		v_estado_orden_pago INTEGER := 3;

		--Variables mensaje--
        d_mensaje JSON := '[]'::JSON;
		a_mensaje JSON := '[]'::JSON;
		
BEGIN 
	
	BEGIN   -- inicio transanccion
		
		no_error := TRUE;
	
		v_da := json_parametro; 
		
		v_tipo_solicitud := v_da->'datosGenerales'->>'tipoSolicitud';
		v_identificador_recaudador := v_da->'datosGenerales'->>'identificadorRecaudador';
		v_asignar_monto_solicitud := v_da->'datosGenerales'->>'asignarMontoSolicitud';
		v_id_area_financiero := v_da->'datosGenerales'->>'idAreaFinanciero';
		v_ruta_raiz_guia := v_da->'datosGenerales'->>'rutaRaizGuia';
		v_ruta_dominio_guia := v_da->'datosGenerales'->>'rutaDominioGuia';
		
		--Inicio obtener datos de recaudador---
		SELECT
			oficina
			, provincia
			, id_provincia
			, iva
		FROM
			g_financiero.oficina_recaudacion
		WHERE
			identificador_firmante = v_identificador_recaudador 
			AND estado_recaudador='activo' INTO v_localizacion_recaudador, v_nombre_provincia_recaudador, v_id_provincia_recaudador, v_porcentaje_iva;
		--Fin obtener datos de recaudador---
		
		IF v_tipo_solicitud = 'modificacionProductoRia' THEN
		--RAISE NOTICE '%', 'modificacionProductoRia';
			OPEN c_modificacion_producto;

				LOOP

					FETCH c_modificacion_producto INTO r_datos_modificacion_producto;

					EXIT WHEN NOT FOUND;

					v_id_area := r_datos_modificacion_producto.id_area;				
					v_id_solicitud := r_datos_modificacion_producto.id_solicitud_producto;
					v_identificador_cliente := r_datos_modificacion_producto.identificador_operador;
					
					--Validar si existe la orde de pago--
					PERFORM
						id_pago
					FROM
						g_financiero.orden_pago											
					WHERE
						id_solicitud = v_id_solicitud::TEXT
						AND tipo_solicitud = v_tipo_solicitud;
					
					IF FOUND THEN
                        d_mensaje := json_build_object('error', 3,
                                                            'mensaje', 'Orden Generda',
                                                            'ordenGenerada', 'La orden id_solicitud -> ' || v_id_solicitud || ', de tipo solicitud ' || v_tipo_solicitud || ' ya fue generada'
                                                            );
						 a_mensaje := (
                                        a_mensaje::jsonb || 
                                        d_mensaje::jsonb
                                    )::json;

					ELSE
                    
						--Inicio obtener provincia de la solicitud--
						SELECT
							o.provincia
						FROM
							g_modificacion_productos.solicitudes_productos sp
						INNER JOIN g_operadores.operadores o ON o.identificador = sp.identificador_operador
						WHERE
							sp.id_solicitud_producto::TEXT = v_id_solicitud INTO v_nombre_provincia_solicitud;
						--Fin obtener provincia de la solicitud--				
										
						-- Verificar si la clave existe en el objeto 'itemTarifario' y extraer su valor
						v_codigo_servicio := v_da->'itemTarifario'->>v_id_area;		
			
						--Inicio formar JSON envio de datos para generar orden de pago--
						v_datos_orden_pago := json_build_object(
												'datosOrdenPago', json_build_object(
												'identificadorCliente', v_identificador_cliente,
												'tipoSolicitud', v_tipo_solicitud,
												'estadoOrdenPago', v_estado_orden_pago,
												'identificadorRecaudador', v_identificador_recaudador,
												'localizacionRecaudador', v_localizacion_recaudador,
												'nombreProvinciaRecaudador', v_nombre_provincia_recaudador,
												'idProvinciaRecaudador', v_id_provincia_recaudador,
												'porcentajeIva', v_porcentaje_iva,
												'idSolicitud', v_id_solicitud,
												'metodoPago', v_metodo_pago,
												'asignarMontoSolicitud', v_asignar_monto_solicitud,
												'codigoServicio', v_codigo_servicio,
												'idAreaFinanciero', v_id_area_financiero,
												'nombreProvinciaSolicitud', v_nombre_provincia_solicitud,
												'rutaRaizGuia', v_ruta_raiz_guia,
												'rutaDominioGuia', v_ruta_dominio_guia
											)
										);
										
						CALL g_financiero.sp_generar_orden_pago_procesos_automaticos(v_datos_orden_pago);

						v_respuesta_sp_generar_orden_pago_procesos_automaticos := v_datos_orden_pago;						
                                    a_datos_orden_pago := (
                                        a_datos_orden_pago::jsonb || 
                                        v_respuesta_sp_generar_orden_pago_procesos_automaticos::jsonb
                                    )::json;

					END IF;			

				END LOOP;

			CLOSE c_modificacion_producto;

		ELSIF v_tipo_solicitud = 'registroProductoRia' THEN
		--RAISE NOTICE '%', 'registroProductoRia';
			OPEN c_registro_producto_ria;

				LOOP

					FETCH c_registro_producto_ria INTO r_datos_registro_producto_ria;

					EXIT WHEN NOT FOUND;
					
					v_id_area := r_datos_registro_producto_ria.tipo_solicitud;				
					v_id_solicitud := r_datos_registro_producto_ria.id_solicitud_registro_producto;
					v_identificador_cliente := r_datos_registro_producto_ria.identificador_operador;
					v_nombre_provincia_solicitud := r_datos_registro_producto_ria.provincia_operador;
										
					--Validar si existe la orde de pago--
					PERFORM
						id_pago
					FROM
						g_financiero.orden_pago											
					WHERE
						id_solicitud = v_id_solicitud::TEXT
						AND tipo_solicitud = v_tipo_solicitud;
					
					IF FOUND THEN
                        d_mensaje := json_build_object('error', 3,
                                                            'mensaje', 'Orden Generda',
                                                            'ordenGenerada', 'La orden id_solicitud -> ' || v_id_solicitud || ', de tipo solicitud ' || v_tipo_solicitud || ' ya fue generada'
                                                            );
						 a_mensaje := (
                                        a_mensaje::jsonb || 
                                        d_mensaje::jsonb
                                    )::json;

					ELSE							
										
						-- Verificar si la clave existe en el objeto 'itemTarifario' y extraer su valor
						v_codigo_servicio := v_da->'itemTarifario'->>v_id_area;		
			
						--Inicio formar JSON envio de datos para generar orden de pago--
						v_datos_orden_pago := json_build_object(
												'datosOrdenPago', json_build_object(
												'identificadorCliente', v_identificador_cliente,
												'tipoSolicitud', v_tipo_solicitud,
												'estadoOrdenPago', v_estado_orden_pago,
												'identificadorRecaudador', v_identificador_recaudador,
												'localizacionRecaudador', v_localizacion_recaudador,
												'nombreProvinciaRecaudador', v_nombre_provincia_recaudador,
												'idProvinciaRecaudador', v_id_provincia_recaudador,
												'porcentajeIva', v_porcentaje_iva,
												'idSolicitud', v_id_solicitud,
												'metodoPago', v_metodo_pago,
												'asignarMontoSolicitud', v_asignar_monto_solicitud,
												'codigoServicio', v_codigo_servicio,
												'idAreaFinanciero', v_id_area_financiero,
												'nombreProvinciaSolicitud', v_nombre_provincia_solicitud,
												'rutaRaizGuia', v_ruta_raiz_guia,
												'rutaDominioGuia', v_ruta_dominio_guia
											)
										);
										
						CALL g_financiero.sp_generar_orden_pago_procesos_automaticos(v_datos_orden_pago);

						v_respuesta_sp_generar_orden_pago_procesos_automaticos := v_datos_orden_pago;						
                                    a_datos_orden_pago := (
                                        a_datos_orden_pago::jsonb || 
                                        v_respuesta_sp_generar_orden_pago_procesos_automaticos::jsonb
                                    )::json;

					END IF;					
					
				END LOOP;

			CLOSE c_registro_producto_ria;		

		ELSIF v_tipo_solicitud = 'certificadoFito' THEN
		--RAISE NOTICE '%', 'certificadoFito';
			OPEN c_certificado_fitosanitario;

				LOOP

					FETCH c_certificado_fitosanitario INTO r_datos_certificado_fitosanitario;

					EXIT WHEN NOT FOUND;
					
					v_id_area := r_datos_certificado_fitosanitario.tipo_solicitud;				
					v_id_solicitud := r_datos_certificado_fitosanitario.id_certificado_fitosanitario;
					v_identificador_cliente := r_datos_certificado_fitosanitario.identificador_solicitante;
					v_metodo_pago := r_datos_certificado_fitosanitario.forma_pago;
					
					IF v_metodo_pago = 'saldo' THEN
						v_estado_orden_pago := 5;
					ELSE
						v_estado_orden_pago := 3;
					END IF;
											
					--Validar si existe la orden de pago--
					PERFORM
						id_pago
					FROM
						g_financiero.orden_pago											
					WHERE
						id_solicitud = v_id_solicitud::TEXT
						AND tipo_solicitud = v_tipo_solicitud;
					
					IF FOUND THEN
						d_mensaje := json_build_object('error', 3,
															'mensaje', 'Orden Generda',
															'ordenGenerada', 'La orden id_solicitud -> ' || v_id_solicitud || ', de tipo solicitud ' || v_tipo_solicitud || ' ya fue generada'
															);
						 a_mensaje := (
										a_mensaje::jsonb || 
										d_mensaje::jsonb
									)::json;

					ELSE
					
						--Inicio obtener provincia de la solicitud--
						SELECT
							cf.id_certificado_fitosanitario
							, l.nombre as nombre_provincia
						FROM
							g_certificado_fitosanitario.certificado_fitosanitario cf
							INNER JOIN g_catalogos.localizacion l ON l.id_localizacion = cf.id_provincia_puerto_embarque
						WHERE
							cf.id_certificado_fitosanitario::TEXT = v_id_solicitud INTO v_nombre_provincia_solicitud;
						--Fin obtener provincia de la solicitud--
						
						
						v_codigo_servicio := v_da->'itemTarifario'->>v_id_area;		
			
						--Inicio formar JSON envio de datos para generar orden de pago--
						v_datos_orden_pago := json_build_object(
												'datosOrdenPago', json_build_object(
												'identificadorCliente', v_identificador_cliente,
												'tipoSolicitud', v_tipo_solicitud,
												'estadoOrdenPago', v_estado_orden_pago,
												'identificadorRecaudador', v_identificador_recaudador,
												'localizacionRecaudador', v_localizacion_recaudador,
												'nombreProvinciaRecaudador', v_nombre_provincia_recaudador,
												'idProvinciaRecaudador', v_id_provincia_recaudador,
												'porcentajeIva', v_porcentaje_iva,
												'idSolicitud', v_id_solicitud,
												'metodoPago', v_metodo_pago,
												'asignarMontoSolicitud', v_asignar_monto_solicitud,
												'codigoServicio', v_codigo_servicio,
												'idAreaFinanciero', v_id_area_financiero,
												'nombreProvinciaSolicitud', v_nombre_provincia_solicitud,
												'rutaRaizGuia', v_ruta_raiz_guia,
												'rutaDominioGuia', v_ruta_dominio_guia
											)
										);
										
						CALL g_financiero.sp_generar_orden_pago_procesos_automaticos(v_datos_orden_pago);

						v_respuesta_sp_generar_orden_pago_procesos_automaticos := v_datos_orden_pago;
						
						IF v_respuesta_sp_generar_orden_pago_procesos_automaticos->>'error' = '0' THEN
						
							a_datos_orden_pago := (
								a_datos_orden_pago::jsonb || 
								v_respuesta_sp_generar_orden_pago_procesos_automaticos::jsonb
							)::json;
						
						END IF;
					
					END IF;				
				
				END LOOP;

			CLOSE c_certificado_fitosanitario;

		ELSIF v_tipo_solicitud = 'lims' THEN
		--RAISE NOTICE '%', 'lims';
			OPEN c_lims;

				LOOP

					FETCH c_lims INTO r_datos_lims;

					EXIT WHEN NOT FOUND;
					
					v_id_solicitud := r_datos_lims.id_orden_trabajo;
					v_identificador_cliente := r_datos_lims.identificador;
					v_nombre_provincia_solicitud := r_datos_lims.provincia;
					
					--Validar si existe la orde de pago--
					PERFORM
						id_pago
					FROM
						g_financiero.orden_pago											
					WHERE
						id_solicitud = v_id_solicitud::TEXT
						AND tipo_solicitud = v_tipo_solicitud;
					
					IF FOUND THEN
                        d_mensaje := json_build_object('error', 3,
                                                            'mensaje', 'Orden Generda',
                                                            'ordenGenerada', 'La orden id_solicitud -> ' || v_id_solicitud || ', de tipo solicitud ' || v_tipo_solicitud || ' ya fue generada'
                                                            );
						 a_mensaje := (
                                        a_mensaje::jsonb || 
                                        d_mensaje::jsonb
                                    )::json;

					ELSE
													
						--Inicio formar JSON envio de datos para generar orden de pago--
						v_datos_orden_pago := json_build_object(
												'datosOrdenPago', json_build_object(
												'identificadorCliente', v_identificador_cliente,
												'tipoSolicitud', v_tipo_solicitud,
												'estadoOrdenPago', v_estado_orden_pago,
												'identificadorRecaudador', v_identificador_recaudador,
												'localizacionRecaudador', v_localizacion_recaudador,
												'nombreProvinciaRecaudador', v_nombre_provincia_recaudador,
												'idProvinciaRecaudador', v_id_provincia_recaudador,
												'porcentajeIva', v_porcentaje_iva,
												'idSolicitud', v_id_solicitud,
												'metodoPago', v_metodo_pago,
												'asignarMontoSolicitud', v_asignar_monto_solicitud,
												'codigoServicio', 'N/A',
												'idAreaFinanciero', v_id_area_financiero,
												'nombreProvinciaSolicitud', v_nombre_provincia_solicitud,
												'rutaRaizGuia', v_ruta_raiz_guia,
												'rutaDominioGuia', v_ruta_dominio_guia
											)
										);
										
						CALL g_financiero.sp_generar_orden_pago_procesos_automaticos(v_datos_orden_pago);

						v_respuesta_sp_generar_orden_pago_procesos_automaticos := v_datos_orden_pago;						
									a_datos_orden_pago := (
										a_datos_orden_pago::jsonb || 
										v_respuesta_sp_generar_orden_pago_procesos_automaticos::jsonb
									)::json;
						
					END IF;
					
				END LOOP;

			CLOSE c_lims;

		ELSE

			RAISE NOTICE 'EL RESTO DE CASOS';
		
		END IF;
		
		
  
		EXCEPTION
		
			WHEN others THEN
			-- Rollback the transaction and raise the exception
			no_error := FALSE;
            ROLLBACK;
			vSQLERRM := SQLERRM;
			IF vSQLERRM IS NOT NULL or vSQLERRM <> '' THEN
				INSERT INTO g_errores_procedimientos.errores (objeto, error_capturado, esquema, tablas)
				VALUES (v_da, vSQLERRM, 'g_finciero', 'orden_pago -> procedimiento sp_generar_cron_orden_pago_procesos_automaticos');
				COMMIT;
			END IF;
	END ;
	
	IF no_error THEN
	
		COMMIT;
         json_parametro := (
							a_mensaje::jsonb || 
							a_datos_orden_pago::jsonb
							)::json;		
	ELSE
	
		json_parametro := (
		SELECT 
			CASE 
				WHEN vSQLERRM IS NOT NULL THEN			
				CONCAT('{"error":"1", "mensaje":"', vSQLERRM, '"}')::json
			END
		);
		
		ROLLBACK;
		
	END IF;
  	
END;
$$;

alter procedure sp_generar_cron_orden_pago_procesos_automaticos(inout json) owner to postgres;

