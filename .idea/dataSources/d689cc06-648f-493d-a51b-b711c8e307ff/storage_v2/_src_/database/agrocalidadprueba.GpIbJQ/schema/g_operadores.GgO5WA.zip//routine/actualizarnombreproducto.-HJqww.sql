create function actualizarnombreproducto() returns text
    language plpgsql
as
$$
DECLARE
  op record;
BEGIN
FOR op in (SELECT DISTINCT id_producto FROM g_operadores.operaciones) 
	LOOP
		UPDATE g_operadores.operaciones set nombre_producto = (SELECT nombre_comun from g_catalogos.productos WHERE id_producto = op.id_producto) WHERE id_producto = op.id_producto AND id_pais = 0;
	END LOOP;
	RETURN op;
END
$$;

alter function actualizarnombreproducto() owner to postgres;

