create function mostrar_combustibles_individual(_placa text, _fecha_inicio date, _fecha_fin date, _localizacion text) returns SETOF g_transportes.combustible_individual
    language plpgsql
as
$$
DECLARE
	query text;
BEGIN	
	return query EXECUTE '
			SELECT 
				COUNT(c.id_combustible) numero,
				(SELECT SUM(valor_liquidacion) FROM g_transportes.combustible WHERE placa like $1 and ($2 is NULL or  fecha_despacho >= $2) and ($3 is NULL or  fecha_despacho <= $3) and estado = 3) suma,
				(SELECT MAX(kilometraje) FROM g_transportes.combustible WHERE placa like $1 and ($2 is NULL or  fecha_despacho >= $2) and ($3 is NULL or  fecha_despacho <= $3) and estado = 3) maximo,
				(SELECT MIN(kilometraje) FROM g_transportes.combustible WHERE placa like $1 and ($2 is NULL or  fecha_despacho >= $2) and ($3 is NULL or  fecha_despacho <= $3) and estado = 3) minimo,
				(SELECT SUM(cantidad_galones) FROM g_transportes.combustible WHERE placa like $1 and ($2 is NULL or  fecha_despacho >= $2) and ($3 is NULL or  fecha_despacho <= $3) and estado = 3) galones,
				v.placa,
				v.modelo,
				v.marca,
				v.localizacion
			FROM
				g_transportes.combustible c,
				g_transportes.vehiculos v
			WHERE
				c.placa = v.placa and
				c.placa like $1 and
				($2 is NULL or  c.fecha_despacho >= $2) and 
				($3 is NULL or  c.fecha_despacho <= $3) and
				($4 is NULL or $4 = v.localizacion) and 
				c.estado = 3
			GROUP BY 
				v.placa,
				v.modelo,
				v.marca,
				v.localizacion'
			
		using _placa,_fecha_inicio,_fecha_fin,_localizacion;
	
END;
$$;

alter function mostrar_combustibles_individual(text, date, date, text) owner to postgres;

