create function funcion_usuario_auditoria() returns trigger
    language plpgsql
as
$$ 
DECLARE 
	_idlog integer;
	_observacion varchar;
	_condicion varchar;

BEGIN

_idlog := (SELECT distinct l.id_log FROM  g_auditoria.log l INNER JOIN g_auditoria.ingreso i ON l.id_log = i.id_log WHERE i.identificador = NEW.identificador and l.id_aplicacion = 0);

	IF (_idlog is null) THEN
		INSERT INTO g_auditoria.log(id_aplicacion) VALUES ('0') returning id_log INTO _idlog ;
	END IF;

	IF (TG_OP = 'INSERT') THEN
		INSERT INTO g_auditoria.ingreso(id_log,identificador,fecha_inicio,accion, tipo, ip_acceso) VALUES (_idlog, NEW.identificador, now(), 'Creación de usuario', 'LOG', NEW.ip_modificacion_clave);
	ELSIF (TG_OP = 'UPDATE') THEN

		IF (NEW.observacion_usuario is null) THEN
			NEW.observacion_usuario = 'Sin observación';
		END IF;	
		
		IF(OLD.codigo_temporal != NEW.codigo_temporal) THEN
			_observacion = 'Actualización de codigo temporal de usuario'||', '||NEW.observacion_usuario;
			INSERT INTO g_auditoria.ingreso(id_log,identificador,fecha_inicio,accion, tipo, ip_acceso) VALUES (_idlog, OLD.identificador, now(), _observacion, 'LOG', NEW.ip_modificacion_clave);
		END IF;	

		IF(OLD.intento != NEW.intento) THEN
			_observacion = 'Actualización de intento de usuario'||', '||NEW.observacion_usuario;
			INSERT INTO g_auditoria.ingreso(id_log,identificador,fecha_inicio,accion, tipo, ip_acceso) VALUES (_idlog, OLD.identificador, now(), _observacion, 'LOG', NEW.ip_modificacion_clave);
		END IF;	

		IF(OLD.identificador != NEW.identificador) THEN
			_observacion = 'Actualización de identificador usuario'||', '||NEW.observacion_usuario;
			INSERT INTO g_auditoria.ingreso(id_log,identificador,fecha_inicio,accion, tipo, ip_acceso) VALUES (_idlog, OLD.identificador, now(), _observacion, 'LOG', NEW.ip_modificacion_clave);
		END IF;

		IF(OLD.nombre_usuario != NEW.nombre_usuario) THEN
			_observacion = 'Actualización del nombre de usuario'||', '||NEW.observacion_usuario;
			INSERT INTO g_auditoria.ingreso(id_log,identificador,fecha_inicio,accion, tipo, ip_acceso) VALUES (_idlog, OLD.identificador, now(), _observacion, 'LOG', NEW.ip_modificacion_clave);
		END IF;	

		IF(OLD.estado != NEW.estado) THEN
			IF(new.ESTADO = 1) THEN
				_condicion = 'EXITO';
			ELSE
				_condicion = 'LOG';
			END IF;
			 _observacion = 'Actualización de estado de usuario'||', '||NEW.observacion_usuario;
			INSERT INTO g_auditoria.ingreso(id_log,identificador,fecha_inicio,accion, tipo, ip_acceso) VALUES (_idlog, OLD.identificador, now(), _observacion, _condicion, NEW.ip_modificacion_clave);
		END IF;	

		IF(OLD.clave != NEW.clave) THEN
			_observacion = 'Actualización de clave de usuario'||', '||NEW.observacion_usuario;
			INSERT INTO g_auditoria.ingreso(id_log,identificador,fecha_inicio,accion, tipo, ip_acceso) VALUES (_idlog, OLD.identificador, now(), _observacion, 'LOG', NEW.ip_modificacion_clave);
		END IF;	
	
	ELSE
		INSERT INTO g_auditoria.ingreso(id_log,identificador,fecha_inicio,accion, tipo, ip_acceso) VALUES (_idlog, OLD.identificador, now(), 'Eliminación de usuario.', 'LOG', OLD.ip_modificacion_clave);
	END IF;	
	
	RETURN NEW;
END; 
	
$$;

alter function funcion_usuario_auditoria() owner to postgres;

