create function mostrar_mantenimientos_filtrados(_localizacion text, _motivo text, _taller integer, _placa text, _fecha_inicio timestamp without time zone, _fecha_fin timestamp without time zone, _estado integer) returns SETOF g_transportes.mantenimientos
    language plpgsql
as
$$
DECLARE
	query text;
BEGIN	
	return query EXECUTE '	
		SELECT
			*
		FROM 
			g_transportes.mantenimientos m
		WHERE 
			($1 is NULL or motivo like $1) and 
			($2 is NULL or placa like $2) and
			($3 is NULL or estado = $3) and 
			($4 is NULL or taller = $4) and  
			($5 is NULL or fecha_solicitud >= $5) and 
			($6 is NULL or fecha_solicitud <= $6) and
			($7 is NULL or $7 = localizacion) 
			
		ORDER BY
			m.fecha_solicitud'
		using _motivo,_placa,_estado,_taller,_fecha_inicio,_fecha_fin,_localizacion;
	
END;
$$;

alter function mostrar_mantenimientos_filtrados(text, text, integer, text, timestamp, timestamp, integer) owner to postgres;

