create function reporte_manejo_integrado_actividad_with(pfecha_desde date, pfecha_hasta date, OUT identificador_tecnico character varying, OUT provincia character varying, OUT canton character varying, OUT parroquia character varying, OUT coordenada_x character varying, OUT coordenada_y character varying, OUT coordenada_z character varying, OUT fecha timestamp without time zone, OUT semana integer, OUT acciones_mip character varying, OUT mdt_inicial numeric, OUT plaga_objetivo character varying, OUT escenario character varying, OUT especie_hortofruticola character varying, OUT especie_hospedante character varying, OUT superficie numeric, OUT medidas_control character varying, OUT cantidad numeric, OUT insumos character varying, OUT fuente character varying, OUT mdt_final numeric) returns SETOF record
    language plpgsql
as
$$
DECLARE
BEGIN
    RETURN QUERY
    WITH temp_reporte_manejo_integrado AS (
        SELECT 
            act_man_int.usuario_id,
            act_man_int.provincia , 
            act_man_int.canton ,
            act_man_int.parroquia ,
            act_man_int.coordenada_x ,
            act_man_int.coordenada_y ,
            act_man_int.coordenada_z ,
            act_man_int.fecha_registro_actividad AS fecha,
            act_man_int.semana_actual  AS semana,
            ca_acc_mip.nombre AS acciones_mip ,
            ROUND(act_man_int.mtd_inicial, 3) mdt_inicial,
            ca_pla_ob.nombre AS plaga_objetivo ,
            ca_esc.nombre AS escenario,
            ca_esp_hort.nombre AS especie_hortofruticola ,
            ca_esp_hosp.nombre as especie_Hospedante,
            ROUND(act_man_int.superficie ,2) superficie,
            ca_med_con.nombre as medidas_control,
            man_in_fu_can.cantidad_medidas_control as cantidad,
            ca_in.nombre as insumos,
            ca_fue_ac.nombre AS fuente,
            ROUND(act_man_int.mtd_final, 3) mdt_final
        FROM 
            f_inspeccion.actividades_manejo_integrado act_man_int 
        INNER JOIN 
            g_catalogos.actividad_manejo_integrado ca_acc_mip ON act_man_int.id_accion_mip=ca_acc_mip.id 
        INNER JOIN 
            g_catalogos.actividad_manejo_integrado ca_esc ON act_man_int.id_escenario=ca_esc.id 	
        INNER JOIN 
            g_catalogos.actividad_manejo_integrado  ca_esp_hort ON act_man_int.id_especie_hortofruticola=ca_esp_hort.id 
        INNER JOIN 
            f_inspeccion.actividadmanejointegrado_catalogoespeciehospedante act_man_ca_hospe ON act_man_int.id=act_man_ca_hospe.id_actividad_integrado 
        INNER JOIN 
            g_catalogos.actividad_manejo_integrado ca_esp_hosp ON act_man_ca_hospe.id_catalogo_especie_hospedante= ca_esp_hosp.id 
        INNER JOIN 
            f_inspeccion.actividadmedidascontrol_catalogofuente_cantidad man_in_fu_can  on man_in_fu_can.id_manejo_integrado=act_man_int.id
        INNER JOIN 
            f_inspeccion.actividadmanejo_mcfc_catalogoinsumoactividad mcfc_insumo on man_in_fu_can. id=mcfc_insumo.idactividadintegrado_medidascontrol
        INNER JOIN 
            g_catalogos.actividad_manejo_integrado ca_in ON mcfc_insumo.id_catalogo_insumos=ca_in.id
        INNER JOIN 
            g_catalogos.actividad_manejo_integrado ca_med_con ON man_in_fu_can.id_manejomedidascontrol_catalogo_medidas_control=ca_med_con.id
        INNER JOIN 
            g_catalogos.actividad_manejo_integrado ca_fue_ac ON man_in_fu_can.id_manejomedidascontrol_catalogofuente=ca_fue_ac.id
        LEFT JOIN 
            g_catalogos.actividad_manejo_integrado ca_pla_ob ON act_man_int.id_plaga_objetivo=ca_pla_ob.id
        WHERE  
            act_man_int.fecha_registro_actividad::DATE >= pfecha_desde
            AND act_man_int.fecha_registro_actividad::DATE <= pfecha_hasta
    )
    SELECT * FROM temp_reporte_manejo_integrado;
END;
$$;

alter function reporte_manejo_integrado_actividad_with(date, date, out varchar, out varchar, out varchar, out varchar, out varchar, out varchar, out varchar, out timestamp, out integer, out varchar, out numeric, out varchar, out varchar, out varchar, out varchar, out numeric, out varchar, out numeric, out varchar, out varchar, out numeric) owner to postgres;

