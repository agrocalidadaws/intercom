create function f_caducar_cupo_anual_movilizacion(p_anio_caducidad integer) returns void
    language plpgsql
as
$$

							DECLARE

							BEGIN

								CREATE TEMPORARY TABLE tmp_datos_cupo (id_asignacion_cupo integer
									, cupo_disponible double precision default 0
									, estado_asignacion_cupo character varying (8) default 'Caducado'
									, fecha_actualizacion timestamp without time zone default now()
									, cantidad_ingreso_cupo double precision default 0
									, cantidad_egreso_cupo double precision
									, cantidad_total_cupo double precision default 0
									, tipo_transaccion_cupo integer default 6
									, id_tabla_origen integer
									, tabla_origen character varying (128) default 'g_movilizacion_vegetal.asignacion_cupo'
									, identificador_responsable character varying (13) default 'G.U.I.A'
									, nombre_responsable character varying (13) default 'G.U.I.A'
									, fecha_creacion timestamp without time zone default now()
									) ON COMMIT DROP;

								INSERT INTO tmp_datos_cupo (id_asignacion_cupo, cantidad_egreso_cupo, id_tabla_origen) 
								(SELECT 
									id_asignacion_cupo,
									cupo_disponible AS cantidad_egreso_cupo,
									id_asignacion_cupo AS id_tabla_origen
								FROM 
									g_movilizacion_vegetal.asignacion_cupo
								WHERE
									estado_asignacion_cupo = 'Activo'
									and anio_asignacion_cupo = p_anio_caducidad
								ORDER BY 
									id_asignacion_cupo);
									
								INSERT INTO 
									g_movilizacion_vegetal.transaccion_cupo_movilizacion(
									id_asignacion_cupo, id_tabla_origen, tabla_origen, cantidad_ingreso_cupo, cantidad_egreso_cupo, cantidad_total_cupo, tipo_transaccion_cupo
									, identificador_responsable, nombre_responsable)
								(SELECT id_asignacion_cupo, id_tabla_origen, tabla_origen, cantidad_ingreso_cupo, cantidad_egreso_cupo, cantidad_total_cupo, tipo_transaccion_cupo
									, identificador_responsable, nombre_responsable FROM tmp_datos_cupo);

								UPDATE 
									g_movilizacion_vegetal.asignacion_cupo
								SET
									cupo_disponible = tmp_datos_cupo.cupo_disponible,
									estado_asignacion_cupo = tmp_datos_cupo.estado_asignacion_cupo,
									fecha_actualizacion = tmp_datos_cupo.fecha_actualizacion
								FROM 
									tmp_datos_cupo
								WHERE 
									g_movilizacion_vegetal.asignacion_cupo.id_asignacion_cupo = tmp_datos_cupo.id_asignacion_cupo;
									
							END

						
				
		$$;

alter function f_caducar_cupo_anual_movilizacion(integer) owner to postgres;

