create function insertar_serie_cuvs(text[], observacion text) returns integer
    language plpgsql
as
$$
DECLARE cuvreg ALIAS FOR $1;
_observacion ALIAS FOR $2;

BEGIN

	CREATE TEMP TABLE temp_cuvs(tid_especie integer, testado text, tnumero_documento text, tfecha_registro date, tobservacion text) ON COMMIT DROP;  
  
	FOR I IN 1..(ARRAY_LENGTH(cuvreg,1)) LOOP
		INSERT INTO temp_cuvs(tid_especie, testado, tnumero_documento, tfecha_registro, tobservacion)values(6, 'creado', cuvreg[I], now(), _observacion);
	END LOOP;

	INSERT INTO g_catalogos.certificados_vacunacion (id_especie, estado, numero_documento, fecha_registro, observacion) SELECT tid_especie, testado, tnumero_documento, tfecha_registro, tobservacion
		FROM temp_cuvs WHERE not exists(SELECT
												numero_documento 
											FROM 
												g_catalogos.certificados_vacunacion
											WHERE 
												temp_cuvs.tnumero_documento = certificados_vacunacion.numero_documento);
												
return 1;

END;
$$;

alter function insertar_serie_cuvs(text[], text) owner to postgres;

