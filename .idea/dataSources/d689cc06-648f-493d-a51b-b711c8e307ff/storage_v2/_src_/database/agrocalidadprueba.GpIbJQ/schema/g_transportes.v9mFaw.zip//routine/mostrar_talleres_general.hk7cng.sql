create function mostrar_talleres_general(_fecha_inicio timestamp without time zone, _fecha_fin date, _localizacion text, _cantidad integer) returns SETOF g_transportes.talleres_general
    language plpgsql
as
$$
DECLARE
	query text;
BEGIN	
	return query EXECUTE '
			SELECT 
				SUM(m.valor_liquidacion) valor,
				t.id_taller,
				t.nombre,
				t.direccion,
				t.telefono,
				t.localizacion
			FROM 
				g_transportes.mantenimientos m,
				g_transportes.talleres t
			WHERE
				($1 is NULL or  m.fecha_solicitud >= $1) and 
				($2 is NULL or  m.fecha_solicitud <= $2) and
				($3 is NULL or $3 = t.localizacion) and 
				m.estado = 3 and
				m.taller = t.id_taller
			GROUP BY 
				t.id_taller,
				t.nombre,
				t.direccion,
				t.telefono,
				t.localizacion
			ORDER BY valor desc
			LIMIT $4'
			
		using _fecha_inicio,_fecha_fin,_localizacion,_cantidad;
	
END;
$$;

alter function mostrar_talleres_general(timestamp, date, text, integer) owner to postgres;

