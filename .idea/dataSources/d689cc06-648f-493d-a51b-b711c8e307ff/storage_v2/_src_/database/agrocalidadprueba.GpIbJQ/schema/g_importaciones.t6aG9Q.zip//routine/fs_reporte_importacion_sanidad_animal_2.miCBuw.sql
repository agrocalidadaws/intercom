create function fs_reporte_importacion_sanidad_animal_2(pfecha_inicio date, pfecha_inicio2 date, ptipo_reporte character varying, OUT identificador character varying, OUT razon_social character varying, OUT direccion character varying, OUT correo character varying, OUT tipo_producto character varying, OUT subtipo_prodcuto character varying, OUT nombre_producto character varying, OUT partida_arancelaria character varying, OUT cantidad_producto double precision, OUT unidad_producto character varying, OUT peso double precision, OUT unidad_peso character varying, OUT licencia_magap character varying, OUT pais_origen character varying, OUT razon_exportador character varying, OUT direccion_exportador character varying, OUT tipo_transporte character varying, OUT puerto_embarque character varying, OUT puerto_destino character varying, OUT id_vue character varying, OUT valor_fob double precision, OUT nombre_provincia character varying, OUT nombre_ciudad character varying, OUT fecha_creacion date, OUT id_importacion integer, OUT fecha_aprobacion date, OUT fecha_vigencia date, OUT estado character varying, OUT id_revision_documental integer, OUT nombre_tecnico text, OUT fecha_inspeccion date, OUT observacion character varying, OUT fecha_imposicion_tasa date) returns SETOF record
    language plpgsql
as
$$
BEGIN

if('aprobado'=$3) then
			 	with temp_import as(

			SELECT
				distinct
				o.identificador,	
				o.razon_social,
				o.direccion,
				o.correo,
				tp.nombre as tipo_producto,
				sp.nombre as subtipo_prodcuto,
				p.nombre_comun as nombre_producto,
				p.partida_arancelaria,
				ip.unidad as cantidad_producto,
				ip.unidad_medida as unidad_cantidad,
				ip.peso,
				ip.unidad_peso,
				ip.licencia_magap,
				i.pais_exportacion as pais_origen,
				i.nombre_exportador as razon_exportador,
				i.direccion_exportador as direccion_exportador,
				i.tipo_transporte,
				i.puerto_embarque,
				i.puerto_destino,
				i.id_vue,
				ip.valor_fob,
				i.nombre_provincia,
				i.nombre_ciudad,
				i.fecha_creacion,
				i.id_importacion,

				i.fecha_inicio as fecha_aprobacion,
				i.fecha_vigencia,
				i.estado
			FROM 
				g_importaciones.importaciones i,
				g_importaciones.importaciones_productos ip,
				g_catalogos.productos p,
				g_catalogos.subtipo_productos sp,
				g_catalogos.tipo_productos tp,
				g_operadores.operadores o	
			WHERE	
				i.id_importacion = ip.id_importacion and
				ip.id_producto = p.id_producto and
				p.id_subtipo_producto = sp.id_subtipo_producto and
				sp.id_tipo_producto = tp.id_tipo_producto and
				o.identificador = i.identificador_operador and
				i.id_area = 'SA' and 
				--i.fecha_creacion >= '2023-01-01' and
				--i.fecha_creacion <='2023-01-31' and
				i.fecha_inicio >= $1 AND 
				i.fecha_inicio <=$2 and
				i.estado in ('aprobado', 'ampliado', 'rechazado')
			ORDER BY 
				i.id_vue
			),

	  
 	temp_identificador as	
 	 	(SELECT   tp_imp.identificador,
 				  tp_imp.razon_social,
 				  tp_imp.direccion,
 				  tp_imp.correo,
 				  tp_imp.tipo_producto,
 				  tp_imp.subtipo_prodcuto,
 				  tp_imp.nombre_producto,
 				  tp_imp.partida_arancelaria,
 		 		  tp_imp.cantidad_producto,
 				  tp_imp.unidad_cantidad,
 				  tp_imp.peso,
 				  tp_imp.licencia_magap,
 				  tp_imp.pais_origen,
 				  tp_imp.razon_exportador,
 				  tp_imp.direccion_exportador,
 				  tp_imp.tipo_transporte,
 				  tp_imp.puerto_embarque,
 				  tp_imp.puerto_destino,
 				  tp_imp.id_vue,
 				  tp_imp.valor_fob,
 				  tp_imp.nombre_provincia,
 				  tp_imp.nombre_ciudad,
 				  tp_imp.fecha_creacion,
 				  tp_imp.id_importacion,
 				  tp_imp.fecha_aprobacion,
 				  tp_imp.fecha_vigencia,
 				  tp_imp.estado,	
 				  MAX(f1.fecha_asignacion_monto)::date AS  fecha_imposicion_tasa
 		 FROM 
 			 temp_import tp_imp,
 	         g_revision_solicitudes.grupos_solicitudes gs1,
  	         g_revision_solicitudes.asignacion_inspector ai1, 
  	         g_revision_solicitudes.financiero f1
 		 WHERE   gs1.id_grupo = ai1.id_grupo 
 				 and ai1.id_grupo = f1.id_grupo 
 			
 				 and gs1.id_solicitud = tp_imp.id_importacion 
				 and  ai1.tipo_solicitud = 'Importación' 
 				 and ai1.tipo_inspector = 'Financiero' 
				--and((ai1.tipo_solicitud = 'Importación') or(ai1.tipo_solicitud = 'Operadores' ) )	
 				-- and ((ai1.tipo_inspector = 'Financiero' )or(ai1.tipo_inspector='Documental')) 				 
 				 and f1.estado = 'aprobado'
				 
 		GROUP BY tp_imp.identificador,
 				 tp_imp.razon_social,
 				 tp_imp.direccion,
 				 tp_imp.correo,
 				 tp_imp.tipo_producto,
 				 tp_imp.subtipo_prodcuto,
 				 tp_imp.nombre_producto,
 				 tp_imp.partida_arancelaria,
 		 		 tp_imp.cantidad_producto,
 				 tp_imp.unidad_cantidad,
 				 tp_imp.peso,
 				 tp_imp.licencia_magap,
 				 tp_imp.pais_origen,
 				 tp_imp.razon_exportador,
 				 tp_imp.direccion_exportador,
 				 tp_imp.tipo_transporte,
 				 tp_imp.puerto_embarque,
 				 tp_imp.puerto_destino,
 				 tp_imp.id_vue,
 				 tp_imp.valor_fob,
 				 tp_imp.nombre_provincia,
 				 tp_imp.nombre_ciudad,
 				 tp_imp.fecha_creacion,
 				 tp_imp.id_importacion,
 				 tp_imp.fecha_aprobacion,
 				 tp_imp.fecha_vigencia,
 				 tp_imp.estado
		  		order by tp_imp.identificador
 		),
		 temp_solicitudes as(
				 SELECT 
							 tp_imp.identificador,			 
							 tp_imp.razon_social,
							 tp_imp.direccion,
							 tp_imp.correo,
							 tp_imp.tipo_producto,
							 tp_imp.subtipo_prodcuto,
							 tp_imp.nombre_producto,
							 tp_imp.partida_arancelaria,
							 tp_imp.cantidad_producto,
							 tp_imp.unidad_cantidad,
							 tp_imp.peso,
							 tp_imp.unidad_peso,
							 tp_imp.licencia_magap,
							 tp_imp.pais_origen,
							 tp_imp.razon_exportador,
							 tp_imp.direccion_exportador,
							 tp_imp.tipo_transporte,
							 tp_imp.puerto_embarque,
							 tp_imp.puerto_destino,
							 tp_imp.id_vue,
							 tp_imp.valor_fob,
							 tp_imp.nombre_provincia,
							 tp_imp.nombre_ciudad,
							 tp_imp.fecha_creacion,
							 tp_imp.id_importacion,
							 tp_imp.fecha_aprobacion,
							 tp_imp.fecha_vigencia,
							 tp_imp.estado,		
 							max(rd.id_revision_documental) as id_revision_documental
 						FROM 
			 				temp_identificador tem_iden,
							temp_import tp_imp,
 							g_revision_solicitudes.grupos_solicitudes gs2, 
 							g_revision_solicitudes.asignacion_inspector ai2, 
 							g_revision_solicitudes.revision_documental rd, 
 							g_uath.ficha_empleado fe 
 						WHERE 
			 				tp_imp.identificador=tem_iden.identificador and
 							gs2.id_grupo = ai2.id_grupo and 
 							ai2.id_grupo = rd.id_grupo and  
 							ai2.tipo_solicitud = 'Importación' and 
 							ai2.tipo_inspector = 'Documental' and 
 							gs2.id_solicitud = tp_imp.id_importacion and 
 							fe.identificador = ai2.identificador_inspector
			 
			 group by  tp_imp.identificador,			 
							 tp_imp.razon_social,
							 tp_imp.direccion,
							 tp_imp.correo,
							 tp_imp.tipo_producto,
							 tp_imp.subtipo_prodcuto,
							 tp_imp.nombre_producto,
							 tp_imp.partida_arancelaria,
							 tp_imp.cantidad_producto,
							 tp_imp.unidad_cantidad,
							 tp_imp.peso,
							 tp_imp.unidad_peso,
							 tp_imp.licencia_magap,
							 tp_imp.pais_origen,
							 tp_imp.razon_exportador,
							 tp_imp.direccion_exportador,
							 tp_imp.tipo_transporte,
							 tp_imp.puerto_embarque,
							 tp_imp.puerto_destino,
							 tp_imp.id_vue,
							 tp_imp.valor_fob,
							 tp_imp.nombre_provincia,
							 tp_imp.nombre_ciudad,
							 tp_imp.fecha_creacion,
							 tp_imp.id_importacion,
							 tp_imp.fecha_aprobacion,
							 tp_imp.fecha_vigencia,
							 tp_imp.estado	
			 order by  tp_imp.identificador
		 ), temp_total as 
						(SELECT 						 
						 tp_identificador.*,
						-- (fe.apellido ||' '|| fe.nombre ||' adwert '|| fecha_inspeccion::date ||' adwert '|| observacion) as nombre_tecnico		
						 (fe.apellido ||' '|| fe.nombre ) as nombre_tecnico,
						rd.fecha_inspeccion,
						 rd.observacion
						FROM						
								temp_solicitudes tp_identificador , 
								g_revision_solicitudes.revision_documental rd,		 	
								g_uath.ficha_empleado fe 			
						WHERE 						 	
							fe.identificador = rd.identificador_inspector and 
							rd.id_revision_documental =tp_identificador.id_revision_documental						 
						),temp_total_fecha as(					
						select 
						tem_t.identificador,
						tem_t.razon_social,
						tem_t.direccion,
						tem_t.correo,
						tem_t.tipo_producto,
						tem_t.subtipo_prodcuto,
						tem_t.nombre_producto,
						tem_t.partida_arancelaria,
						tem_t.cantidad_producto,
						tem_t.unidad_cantidad,
						tem_t.peso,
						tem_t.unidad_peso,
						tem_t.licencia_magap,
						tem_t.pais_origen,
						tem_t.razon_exportador,
						tem_t.direccion_exportador,
						tem_t.tipo_transporte,
						tem_t.puerto_embarque,
						tem_t.puerto_destino,
						tem_t.id_vue,
						tem_t.valor_fob,
						tem_t.nombre_provincia,
						tem_t.nombre_ciudad,
						tem_t.fecha_creacion,
						tem_t.id_importacion,
						tem_t.fecha_aprobacion,
						tem_t.fecha_vigencia,
						tem_t.estado,
						tem_t.id_revision_documental,
						tem_t.nombre_tecnico,	
						tem_t.fecha_inspeccion::date,
						tem_t.observacion,
						tem_iden.fecha_imposicion_tasa
						from 
						temp_total tem_t
						inner join temp_identificador tem_iden
						on tem_t.identificador =tem_iden.identificador
						and tem_t.id_vue=tem_iden.id_vue
						group by 
						tem_t.identificador,
						tem_t.razon_social,
						tem_t.direccion,
						tem_t.correo,
						tem_t.tipo_producto,
						tem_t.subtipo_prodcuto,
						tem_t.nombre_producto,
						tem_t.partida_arancelaria,
						tem_t.cantidad_producto,
						tem_t.unidad_cantidad,
						tem_t.peso,
						tem_t.unidad_peso,
						tem_t.licencia_magap,
						tem_t.pais_origen,
						tem_t.razon_exportador,
						tem_t.direccion_exportador,
						tem_t.tipo_transporte,
						tem_t.puerto_embarque,
						tem_t.puerto_destino,
						tem_t.id_vue,
						tem_t.valor_fob,
						tem_t.nombre_provincia,
						tem_t.nombre_ciudad,
						tem_t.fecha_creacion,
						tem_t.id_importacion,
						tem_t.fecha_aprobacion,
						tem_t.fecha_vigencia,
						tem_t.estado,
						tem_t.id_revision_documental,
						tem_t.nombre_tecnico,	
						tem_t.fecha_inspeccion,
						tem_t.observacion,
						tem_iden.fecha_imposicion_tasa)  select *from temp_total_fecha ;

			--drop table temp_import;
			--drop table temp_identificador;
			--drop table temp_solicitudes;
			--drop table temp_total;
			--drop table temp_total_fecha;
	end if;
	if('rechazado'=$3) then
		RETURN QUERY  SELECT *FROM g_importaciones.fs_reporte_importacion_sanidad_animal_2_rechazados($1,$2);
	end if;
						
		 

		

END;
$$;

alter function fs_reporte_importacion_sanidad_animal_2(date, date, varchar, out varchar, out varchar, out varchar, out varchar, out varchar, out varchar, out varchar, out varchar, out double precision, out varchar, out double precision, out varchar, out varchar, out varchar, out varchar, out varchar, out varchar, out varchar, out varchar, out varchar, out double precision, out varchar, out varchar, out date, out integer, out date, out date, out varchar, out integer, out text, out date, out varchar, out date) owner to postgres;

