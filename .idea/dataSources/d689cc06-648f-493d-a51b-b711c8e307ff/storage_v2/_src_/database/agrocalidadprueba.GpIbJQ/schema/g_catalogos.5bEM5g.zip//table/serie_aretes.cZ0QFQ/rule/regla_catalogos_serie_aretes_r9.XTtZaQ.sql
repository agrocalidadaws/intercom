CREATE RULE regla_catalogos_serie_aretes_r9 AS
    ON INSERT TO g_catalogos.serie_aretes
   WHERE new.numero_arete::text >= 'EC020000000'::text AND new.numero_arete::text <= 'EC039999999'::text DO INSTEAD  INSERT INTO g_catalogos.serie_aretes_r9 (id_serie_aretes, estado, id_especie, numero_arete, fecha_registro, observacion)
  VALUES (new.id_serie_aretes, new.estado, new.id_especie, new.numero_arete, new.fecha_registro, new.observacion);

