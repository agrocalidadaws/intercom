create function mostrar_mantenimientos_individual(_placa text, _fecha_inicio date, _fecha_fin date, _localizacion text) returns SETOF g_transportes.mantenimiento_individual
    language plpgsql
as
$$
DECLARE
	query text;
BEGIN	
	return query EXECUTE '
			SELECT 
				COUNT(m.id_mantenimiento) numero,
				(SELECT SUM(valor_liquidacion) FROM g_transportes.mantenimientos WHERE placa like $1 and ($2 is NULL or  fecha_solicitud >= $2) and 
				($3 is NULL or  fecha_solicitud <= $3) and tipo like ''%Preventivo%'' and estado = 3) suma_preventivo,
				(SELECT COUNT(id_mantenimiento) FROM g_transportes.mantenimientos WHERE placa like $1 and ($2 is NULL or  fecha_solicitud >= $2) and 
				($3 is NULL or  fecha_solicitud <= $3) and tipo like ''%Preventivo%'' and estado = 3) numero_preventivo,
				(SELECT SUM(valor_liquidacion) FROM g_transportes.mantenimientos WHERE placa like $1 and ($2 is NULL or  fecha_solicitud >= $2) and 
				($3 is NULL or  fecha_solicitud <= $3) and tipo like ''%Correctivo%'' and estado = 3) suma_correctivo,
				(SELECT COUNT(id_mantenimiento) FROM g_transportes.mantenimientos WHERE placa like $1 and ($2 is NULL or  fecha_solicitud >= $2) and 
				($3 is NULL or  fecha_solicitud <= $3) and tipo like ''%Correctivo%'' and estado = 3) numero_correctivo,
				(SELECT SUM(valor_liquidacion) FROM g_transportes.mantenimientos WHERE placa like $1 and ($2 is NULL or  fecha_solicitud >= $2) and 
				($3 is NULL or  fecha_solicitud <= $3) and tipo like ''%Lavada%'' and estado = 3) suma_lavada,
				(SELECT COUNT(id_mantenimiento) FROM g_transportes.mantenimientos WHERE placa like $1 and ($2 is NULL or  fecha_solicitud >= $2) and 
				($3 is NULL or  fecha_solicitud <= $3) and tipo like ''%Lavada%'' and estado = 3) numero_lavada,
				(SELECT COUNT(id_mantenimiento) FROM g_transportes.mantenimientos WHERE placa like $1 and ($2 is NULL or  fecha_solicitud >= $2) and 
				($3 is NULL or  fecha_solicitud <= $3) and estado in (1, 2)) numero_pendientes,
				(SELECT COUNT(id_mantenimiento) FROM g_transportes.mantenimientos WHERE placa like $1 and ($2 is NULL or  fecha_solicitud >= $2) and 
				($3 is NULL or  fecha_solicitud <= $3) and estado = 9) numero_eliminados,
				v.placa,
				v.modelo,
				v.marca,
				v.localizacion
			FROM
				g_transportes.mantenimientos m,
				g_transportes.vehiculos v 
			WHERE
				m.placa = v.placa and
				m.placa like $1 and
				($2 is NULL or  m.fecha_solicitud >= $2) and 
				($3 is NULL or  m.fecha_solicitud <= $3) and
				($4 is NULL or $4 = v.localizacion)
			GROUP BY 
				v.placa,
				v.modelo,
				v.marca,
				v.localizacion'
			
		using _placa,_fecha_inicio,_fecha_fin,_localizacion;
	
END;
$$;

alter function mostrar_mantenimientos_individual(text, date, date, text) owner to postgres;

