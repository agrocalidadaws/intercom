create function incrementodiapasadocincoanios(in_anio integer, in_minutos integer)
    returns TABLE(mensaje character varying)
    language plpgsql
as
$$
DECLARE
cursorFecha record;
cursorFe record;
mayorAnios record;
consultafiltrada record;
finalContrato record;
historial_incremento record;
vIdDatosContrato INT;
vFechaInicio  TIMESTAMP;
vFechaFin TIMESTAMP;
vIdentificador varchar;
vEstado INT;

vIdDatosContrato1 INT;
vFechaInicio1  TIMESTAMP;
vFechaFin1 TIMESTAMP;
vIdentificador1 varchar;
vEstado1 INT;
vCantidadDiasAnios INT;
--VARIABLES CONSTANTES;
vAnioActual INT;
vTiempo INT;
filasAfectadas INT;

BEGIN
--INICIALIZAR VARIABLES
vCantidadDiasAnios:=0;
vAnioActual:=in_anio;--date_part('year',NOW());
vTiempo:=in_minutos;
filasAfectadas:=0;
--CREAR TABLAS TEMPORALES

CREATE TEMPORARY TABLE contratosConsecutivos(id_datos_contrato int,fecha_inicio timestamp,fecha_fin timestamp,estado int ,identificador VARCHAR)ON COMMIT DROP;
CREATE TEMPORARY TABLE datos_contratoTemporal(id_datos_contrato int,fecha_inicio timestamp,fecha_fin timestamp,estado int ,identificador VARCHAR)ON COMMIT DROP;
CREATE TEMPORARY TABLE datos_contrato_final(
id_contratos VARCHAR,
identificador VARCHAR,
estado_contratos VARCHAR,
fecha_ingreso_institucion TIMESTAMP,
fecha_fin TIMESTAMP,
anios_trabajo int,
dias_incrementar int
) ON COMMIT DROP;
CREATE TEMPORARY TABLE datos_funcionario_incremento_dia(
mensaje VARCHAR
) ON COMMIT DROP;
--CONSULTA EMPLEADOS QUE HAN TRABAJO MAS DE 5 AÑOS SIN SABER SI SON CONSECUTIVOS
--==========================INICIO CONSULTA MAS DE 4 DE AÑOS TRABAJADOS===========
	FOR mayorAnios IN(SELECT
			dc.id_datos_contrato, dc.identificador,dc.fecha_inicio,dc.fecha_fin,dc.estado
	FROM g_uath.datos_contrato dc
	where dc.regimen_laboral in('Código de Trabajo','Sujetos Código de Trabajo')
			and(
				SELECT sum((date_part('year', dc1.fecha_fin) - date_part('year', dc1.fecha_inicio))) as totalYear
				FROM g_uath.datos_contrato dc1
				where  dc1.regimen_laboral in( 'Código de Trabajo','Sujetos Código de Trabajo')
						and dc1.identificador=dc.identificador)>= 5
	GROUP BY dc.id_datos_contrato, dc.identificador,dc.fecha_inicio,dc.fecha_fin,dc.estado
	ORDER BY dc.identificador,dc.fecha_fin desc)
	LOOP
		INSERT 	 into datos_contratoTemporal VALUES(mayorAnios.id_datos_contrato, mayorAnios.fecha_inicio,mayorAnios.fecha_fin,mayorAnios.estado,mayorAnios.identificador);
	END LOOP;
--==========================FIN CONSULTA MAS DE 4 DE AÑOS TRABAJADOS===========

--==========================INICIO CONSULTA E INSERTA DATOS CONTRATOS CON AÑOS CONSECUTIVOS ===========
FOR cursorFe IN(select distinct identificador FROM datos_contratoTemporal)
			LOOP
			SELECT id_datos_contrato,fecha_inicio,fecha_fin,estado,identificador
			 into
		    vIdDatosContrato,vFechaInicio,vFechaFin,vEstado,vIdentificador
		    from datos_contratoTemporal where estado=1 and identificador=cursorFe.identificador ;
			IF vIdDatosContrato IS NOT NULL THEN
			INSERT INTO contratosConsecutivos VALUES( vIdDatosContrato,vFechaInicio,vFechaFin,vEstado,vIdentificador);
			END IF;
		 FOR cursorFecha IN(select id_datos_contrato,fecha_inicio,fecha_fin,estado,identificador
							FROM datos_contratoTemporal WHERE --identificador='0101966810' AND
							identificador=cursorFe.identificador and estado!=1)
			LOOP
			SELECT  id_datos_contrato,fecha_inicio,fecha_fin,estado,identificador  into  vIdDatosContrato1,vFechaInicio1,vFechaFin1,vEstado1,vIdentificador1  from
			datos_contratoTemporal where identificador=cursorFecha.identificador
			and  fecha_fin=vFechaInicio - INTERVAL'1 day';
			vFechaInicio = vFechaInicio1;
			IF vFechaInicio1 IS NOT NULL THEN
			INSERT INTO contratosConsecutivos VALUES( vIdDatosContrato1,vFechaInicio1,vFechaFin1,vEstado1,vIdentificador1);
			END IF;
  END LOOP;
  END LOOP;

  --==========================FIN CONSULTA E INSERTA DATOS CONTRATOS CON AÑOS CONSECUTIVOS ===========
  --==========================INICIO INSERTAR DATOS FILTRADOS ===========
 FOR finalContrato IN ( SELECT  STRING_AGG(ct.id_datos_contrato::VARCHAR,',') as id_contratos ,ct.identificador,STRING_AGG(ct.estado::VARCHAR,',') as estado_contratos,
	(SELECT  min(dta.fecha_inicio) from contratosConsecutivos dta where dta.identificador=ct.identificador) as fecha_ingreso_institucion,
	(SELECT dta.fecha_fin from g_uath.datos_contrato dta where dta.identificador=ct.identificador and estado=1)
	,sum((date_part('year', ct.fecha_fin) - date_part('year', ct.fecha_inicio))) as anios_trabajo
	,(CASE WHEN   sum((date_part('year', ct.fecha_fin) - date_part('year', ct.fecha_inicio))) > 19 THEN
				15
				ELSE
				sum((date_part('year', ct.fecha_fin) - date_part('year', ct.fecha_inicio))) - 4
			   END
			   ) AS dias_incrementar

	FROM  contratosConsecutivos ct
	GROUP BY ct.identificador
	having sum((date_part('year', ct.fecha_fin) - date_part('year', ct.fecha_inicio)))>= 5
	ORDER BY ct.identificador asc)
	LOOP
	 INSERT INTO datos_contrato_final VALUES(finalContrato.id_contratos,finalContrato.identificador,
					finalContrato.estado_contratos,finalContrato.fecha_ingreso_institucion,finalContrato.fecha_fin,
				finalContrato.anios_trabajo,finalContrato.dias_incrementar);
	END LOOP;
	 --==========================FIN INSERTAR DATOS FILTRADOS ===========
	--==========================INICIO CONSULTA PARA LA TABLA HISTORIAL_INCREMENTO_DIAS_ANIO  ===========
	--DELETE  FROM g_uath.historial_incremento_dias_anio;
		FOR historial_incremento IN	(SELECT cf.identificador,
				cf.anios_trabajo AS anios_trabajo_consecutivo, cf.dias_incrementar AS dias_incrementados,
				cf.fecha_ingreso_institucion AS fecha_inicio_contrato_consecutivo,
				cf.fecha_fin AS fecha_fin_contrato_consecutivo,
				SUM((vAnioActual- date_part('year',cf.fecha_ingreso_institucion))) AS anios_contrato_consecutivo
				FROM datos_contrato_final cf
				GROUP BY
				cf.identificador, cf.anios_trabajo,
				cf.dias_incrementar,cf.fecha_ingreso_institucion,cf.fecha_fin
		ORDER BY cf.identificador)
	LOOP
	/*INSERT INTO g_vacaciones.minutos_disponibles_funcionarios
					 VALUES (historial_incremento.identificador,2022, 0, TRUE,1);*/
		  SELECT COUNT(md.identificador) INTO vCantidadDiasAnios FROM g_vacaciones.minutos_disponibles_funcionarios md
		  WHERE md.anio=vAnioActual AND md.dia_incremento=true AND md.identificador=historial_incremento.identificador;

						IF vCantidadDiasAnios = 0 THEN

						WITH resultadoUpdate AS (
                             UPDATE
								g_vacaciones.minutos_disponibles_funcionarios
							 SET
								 minutos_disponibles=minutos_disponibles+vTiempo,
								 dia_incremento=true,
								 observacion='Acreditación de ' || vTiempo || ' minutos al usuario con cédula número '|| historial_incremento.identificador||' para el año '|| vAnioActual ||' con fecha de registro '|| NOW()
							 WHERE
								activo=true and
								anio = vAnioActual and
								identificador=historial_incremento.identificador
  RETURNING anio
) SELECT COUNT(*) into filasAfectadas FROM resultadoUpdate ;

IF filasAfectadas > 0 THEN
						--INSERTAR HISTORIAL DE INCREMENTO DEL DIA
						INSERT INTO datos_funcionario_incremento_dia VALUES(
						'Acreditación de ' || vTiempo || ' minutos al usuario con cédula número '|| historial_incremento.identificador||' para el año '|| vAnioActual ||' con fecha de registro '|| NOW()
						);
						          INSERT INTO g_uath.historial_incremento_dias_anio (
									  				identificador,anios_trabajo_consecutivo,
													dias_incrementados,fecha_inicio_contrato_consecutivo,
													fecha_fin_contrato_consecutivo,anios_contrato_consecutivo)
											  VALUES(historial_incremento.identificador,historial_incremento.anios_trabajo_consecutivo,
													 historial_incremento.dias_incrementados,
													 historial_incremento.fecha_inicio_contrato_consecutivo,
													 historial_incremento.fecha_fin_contrato_consecutivo,
													 historial_incremento.anios_contrato_consecutivo);
													 ELSE
													 INSERT INTO datos_funcionario_incremento_dia VALUES(
						'No se Acredito de ' || vTiempo || ' minutos al usuario con cédula número '|| historial_incremento.identificador||' para el año '|| vAnioActual ||' con fecha de registro '|| NOW() ||' porque en la tabla 	g_vacaciones.minutos_disponibles_funcionarios no tiene el anio actual actualizado y estado activo'
						);
													 END IF;

						 END IF;

	END LOOP;
	RETURN QUERY
 SELECT * FROM datos_funcionario_incremento_dia;


END;
$$;

alter function incrementodiapasadocincoanios(integer, integer) owner to postgres;

