create function mostrar_capacitacion_empleado(_identificador text, _nombre text, _apellido text, _titulo_capacitacion text, _fecha_inicio timestamp without time zone, _fecha_fin timestamp without time zone) returns SETOF g_uath.vista_ficha_empleado
    language plpgsql
as
$$
DECLARE
	query text;
BEGIN	
	return query EXECUTE 'SELECT
			*
		FROM 
			g_uath.vista_ficha_empleado
		WHERE 
		        
			($1 is NULL or identificador like $1) and 
			($2 is NULL or upper(nombre) like $2) and 
			($3 is NULL or upper(apellido) like $3) and
			($4 is NULL or upper(titulo_capacitacion) like $4) and
			($5 is NULL or fecha_inicio_capacitacion = $5) and 
			($6 is NULL or fecha_fin_capacitacion = $6)' 
		using _identificador,_nombre,_apellido,_titulo_capacitacion,_fecha_inicio,_fecha_fin;
	
END;
$$;

alter function mostrar_capacitacion_empleado(text, text, text, text, timestamp, timestamp) owner to postgres;

