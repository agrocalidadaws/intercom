create function f_monitoreo_solicitud() returns trigger
    language plpgsql
as
$$
			DECLARE _id_solicitud_destino INTEGER;
			BEGIN

				IF (NEW.estado_inspeccion_fitosanitaria = 'Creado') THEN
					_id_solicitud_destino:= NEW.id_inspeccion_fitosanitaria;

					INSERT INTO 
						g_monitoreo_solicitudes.solicitudes
							(nombre_tabla_origen, nombre_campo_identificar_tabla_origen, id_tabla_origen, nombre_campo_estado_tabla_origen, 
							 estado_tabla_origen, nombre_campo_observacion_tabla_origen, observacion_tabla_origen, fecha_finalizacion) 
					VALUES 
					('g_inspeccion_fitosanitaria.inspeccion_fitosanitaria', 'id_inspeccion_fitosanitaria', NEW.id_inspeccion_fitosanitaria, 'estado_inspeccion_fitosanitaria',
					'Rechazado', 'observacion_revisor', 'Registro en estado rechazado debido a que la solicitud no fue enviada en 1 día', CURRENT_TIMESTAMP + CAST('1 days' AS INTERVAL));
				ELSEIF(NEW.estado_inspeccion_fitosanitaria = 'Enviado') THEN
					UPDATE g_monitoreo_solicitudes.solicitudes 
					SET estado = 'Atendida'
					WHERE
						estado = 'Por atender' and 
						nombre_tabla_origen = 'g_inspeccion_fitosanitaria.inspeccion_fitosanitaria' and
						nombre_campo_identificar_tabla_origen = 'id_inspeccion_fitosanitaria' and 
						id_tabla_origen = NEW.id_inspeccion_fitosanitaria;
				ELSEIF(NEW.estado_inspeccion_fitosanitaria = 'Aprobado') THEN
					INSERT INTO 
						g_monitoreo_solicitudes.solicitudes
							(nombre_tabla_origen, nombre_campo_identificar_tabla_origen, id_tabla_origen, nombre_campo_estado_tabla_origen, 
							 estado_tabla_origen, nombre_campo_observacion_tabla_origen, observacion_tabla_origen, fecha_finalizacion) 
					VALUES 
					('g_inspeccion_fitosanitaria.inspeccion_fitosanitaria', 'id_inspeccion_fitosanitaria', NEW.id_inspeccion_fitosanitaria, 'estado_inspeccion_fitosanitaria',
					'Caducado', 'observacion_revisor', 'Solicitud caducada el ' || NEW.fecha_vigencia, NEW.fecha_vigencia);
				END IF;	
				
				RETURN NEW;
			END;
		
	
$$;

alter function f_monitoreo_solicitud() owner to postgres;

