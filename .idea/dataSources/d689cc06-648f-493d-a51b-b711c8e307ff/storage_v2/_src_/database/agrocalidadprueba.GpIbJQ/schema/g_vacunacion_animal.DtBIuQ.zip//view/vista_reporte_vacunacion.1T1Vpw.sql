create view vista_reporte_vacunacion
            (id_vacuna_animal, tipo_digitador, id_sitio, id_area, id_especie, nombre_sitio, nombre_area, provincia,
             canton, parroquia, nombre_especie, identificador_administrador, identificador_distribuidor,
             identificador_vacunador, identificador_propietario, usuario_responsable, nombre_administrador,
             nombre_distribuidor, nombre_vacunador, nombre_responsable, nombre_propietario, id_lote, id_laboratorio,
             id_tipo_vacuna, nombre_vacuna, nombre_laboratorio, numero_lote, num_certificado, control_areteo,
             total_existente, total_vacunado, costo_vacuna, total_vacuna, fecha_registro, fecha_vacunacion,
             fecha_vencimiento, estado, observacion)
as
SELECT DISTINCT v.id_vacuna_animal,
                'Usuario interno'::text                                                                AS tipo_digitador,
                v.id_sitio,
                v.id_area,
                v.id_especie,
                upper(s.nombre_lugar::text)                                                            AS nombre_sitio,
                upper(a.nombre_area::text)                                                             AS nombre_area,
                s.provincia,
                s.canton,
                s.parroquia,
                v.nombre_especie,
                v.identificador_administrador,
                v.identificador_distribuidor,
                v.identificador_vacunador,
                pp.identificador                                                                       AS identificador_propietario,
                v.usuario_responsable,
                CASE
                    WHEN oa.razon_social::text = ''::text THEN upper((oa.nombre_representante::text || ' '::text) ||
                                                                     oa.apellido_representante::text)::character varying::text
                    ELSE upper(oa.razon_social::text)
                    END                                                                                AS nombre_administrador,
                CASE
                    WHEN od.razon_social::text = ''::text THEN upper((od.nombre_representante::text || ' '::text) ||
                                                                     od.apellido_representante::text)::character varying::text
                    ELSE upper(od.razon_social::text)
                    END                                                                                AS nombre_distribuidor,
                upper((ov.nombre_representante::text || ' '::text) ||
                      ov.apellido_representante::text)                                                 AS nombre_vacunador,
                upper((rs.nombre::text || ' '::text) || rs.apellido::text)                             AS nombre_responsable,
                upper((pp.nombre_representante::text || ' '::text) ||
                      pp.apellido_representante::text)                                                 AS nombre_propietario,
                v.id_lote,
                t.id_laboratorio,
                v.id_tipo_vacuna,
                tv.nombre_vacuna,
                t.nombre_laboratorio,
                l.numero_lote,
                v.num_certificado,
                v.control_areteo,
                v.total_existente,
                v.total_vacunado,
                v.costo_vacuna,
                v.total_vacuna,
                v.fecha_registro,
                v.fecha_vacunacion,
                v.fecha_vencimiento,
                v.estado_vacunacion                                                                    AS estado,
                v.observacion
FROM g_vacunacion_animal.vacuna_animales v,
     g_operadores.operadores oa,
     g_operadores.operadores od,
     g_operadores.operadores ov,
     g_uath.ficha_empleado rs,
     g_operadores.sitios s,
     g_operadores.operadores pp,
     g_operadores.areas a,
     g_catalogos.lotes l,
     g_catalogos.laboratorios t,
     g_catalogos.tipo_vacunas tv,
     g_usuario.usuarios_perfiles up,
     g_usuario.perfiles p
WHERE v.identificador_administrador::text = oa.identificador::text
  AND v.identificador_distribuidor::text = od.identificador::text
  AND v.identificador_vacunador::text = ov.identificador::text
  AND v.usuario_responsable::text = rs.identificador::text
  AND s.id_sitio = v.id_sitio
  AND s.identificador_operador::text = pp.identificador::text
  AND a.id_area = v.id_area
  AND v.id_lote = l.id_lote
  AND l.id_laboratorio = t.id_laboratorio
  AND v.id_tipo_vacuna = tv.id_tipo_vacuna
  AND v.usuario_responsable::text = up.identificador::text
  AND up.id_perfil = p.id_perfil
  AND p.id_perfil = 2
UNION
SELECT v.id_vacuna_animal,
       'Usuario externo'::text                                                                AS tipo_digitador,
       v.id_sitio,
       v.id_area,
       v.id_especie,
       upper(s.nombre_lugar::text)                                                            AS nombre_sitio,
       upper(a.nombre_area::text)                                                             AS nombre_area,
       s.provincia,
       s.canton,
       s.parroquia,
       v.nombre_especie,
       v.identificador_administrador,
       v.identificador_distribuidor,
       v.identificador_vacunador,
       pp.identificador                                                                       AS identificador_propietario,
       v.usuario_responsable,
       CASE
           WHEN oa.razon_social::text = ''::text THEN upper((oa.nombre_representante::text || ' '::text) ||
                                                            oa.apellido_representante::text)::character varying::text
           ELSE upper(oa.razon_social::text)
           END                                                                                AS nombre_administrador,
       CASE
           WHEN od.razon_social::text = ''::text THEN upper((od.nombre_representante::text || ' '::text) ||
                                                            od.apellido_representante::text)::character varying::text
           ELSE upper(od.razon_social::text)
           END                                                                                AS nombre_distribuidor,
       upper((ov.nombre_representante::text || ' '::text) || ov.apellido_representante::text) AS nombre_vacunador,
       upper((rs.nombre_representante::text || ' '::text) || rs.apellido_representante::text) AS nombre_responsable,
       upper((pp.nombre_representante::text || ' '::text) || pp.apellido_representante::text) AS nombre_propietario,
       v.id_lote,
       t.id_laboratorio,
       v.id_tipo_vacuna,
       tv.nombre_vacuna,
       t.nombre_laboratorio,
       l.numero_lote,
       v.num_certificado,
       v.control_areteo,
       v.total_existente,
       v.total_vacunado,
       v.costo_vacuna,
       v.total_vacuna,
       v.fecha_registro,
       v.fecha_vacunacion,
       v.fecha_vencimiento,
       v.estado_vacunacion                                                                    AS estado,
       v.observacion
FROM g_vacunacion_animal.vacuna_animales v,
     g_operadores.operadores oa,
     g_operadores.operadores od,
     g_operadores.operadores ov,
     g_operadores.operadores rs,
     g_operadores.sitios s,
     g_operadores.operadores pp,
     g_operadores.areas a,
     g_catalogos.lotes l,
     g_catalogos.laboratorios t,
     g_catalogos.tipo_vacunas tv,
     g_usuario.usuarios_perfiles up,
     g_usuario.perfiles p
WHERE v.identificador_administrador::text = oa.identificador::text
  AND v.identificador_distribuidor::text = od.identificador::text
  AND v.identificador_vacunador::text = ov.identificador::text
  AND v.usuario_responsable::text = rs.identificador::text
  AND s.id_sitio = v.id_sitio
  AND a.id_area = v.id_area
  AND s.identificador_operador::text = pp.identificador::text
  AND v.id_lote = l.id_lote
  AND l.id_laboratorio = t.id_laboratorio
  AND v.id_tipo_vacuna = tv.id_tipo_vacuna
  AND v.usuario_responsable::text = up.identificador::text
  AND up.id_perfil = p.id_perfil
  AND p.id_perfil = 6
  AND NOT (v.usuario_responsable::text IN (SELECT DISTINCT v_1.usuario_responsable
                                           FROM g_vacunacion_animal.vacuna_animales v_1,
                                                g_usuario.usuarios_perfiles up_1,
                                                g_uath.ficha_empleado rs_1
                                           WHERE v_1.usuario_responsable::text = up_1.identificador::text
                                             AND v_1.usuario_responsable::text = rs_1.identificador::text
                                             AND up_1.id_perfil = 6));

alter table vista_reporte_vacunacion
    owner to postgres;

