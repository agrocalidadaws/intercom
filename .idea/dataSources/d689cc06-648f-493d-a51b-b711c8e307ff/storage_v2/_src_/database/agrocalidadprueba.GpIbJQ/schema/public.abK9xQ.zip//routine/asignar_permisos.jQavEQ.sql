create function asignar_permisos() returns event_trigger
    language plpgsql
as
$$
DECLARE
    obj record;
    grant_command text;
BEGIN
    FOR obj IN SELECT * FROM pg_event_trigger_ddl_commands() where object_type = 'table'
    loop
        grant_command = format('grant select on table %s to read_only', obj.objid::regclass::text);
        execute grant_command;
    end loop;
END;
$$;

alter function asignar_permisos() owner to postgres;

