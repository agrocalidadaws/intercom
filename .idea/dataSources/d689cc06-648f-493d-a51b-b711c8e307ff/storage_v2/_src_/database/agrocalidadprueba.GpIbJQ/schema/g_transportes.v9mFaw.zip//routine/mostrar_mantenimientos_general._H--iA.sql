create function mostrar_mantenimientos_general(_placa text, _fecha_inicio timestamp without time zone, _fecha_fin date, _localizacion text, _cantidad integer) returns SETOF g_transportes.mantenimientos_general
    language plpgsql
as
$$
DECLARE
	query text;
BEGIN	
	return query EXECUTE '
			SELECT 
				SUM(m.valor_liquidacion) valor,
				v.placa,
				v.modelo,
				v.marca,
				v.localizacion
			FROM 
				g_transportes.mantenimientos m,
				g_transportes.vehiculos v
			WHERE
				($1 is NULL or m.placa like $1) and 
				($2 is NULL or  m.fecha_solicitud >= $2) and 
				($3 is NULL or  m.fecha_solicitud <= $3) and
				($4 is NULL or $4 = v.localizacion) and 
				m.estado = 3 and
				m.placa = v.placa
			GROUP BY 
				v.placa,
				v.localizacion,
				v.marca,
				v.modelo
			ORDER BY valor desc
			LIMIT $5'
			
		using _placa,_fecha_inicio,_fecha_fin,_localizacion,_cantidad;
	
END;
$$;

alter function mostrar_mantenimientos_general(text, timestamp, date, text, integer) owner to postgres;

