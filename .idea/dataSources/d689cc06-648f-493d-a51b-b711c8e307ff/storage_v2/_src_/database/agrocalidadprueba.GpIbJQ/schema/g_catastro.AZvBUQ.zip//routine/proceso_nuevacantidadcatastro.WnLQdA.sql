create function proceso_nuevacantidadcatastro(cantidadcatastro integer, identificadorinicial text) returns integer
    language plpgsql
as
$$

	DECLARE cantidadcatastronueva integer = 0;

BEGIN

	cantidadcatastronueva = (SELECT 
					count(estado) cantidad
				FROM 
					g_catalogos.serie_aretes
				WHERE
					numero_arete >= identificadorInicial
					and numero_arete < (SELECT 
								'EC'||lpad((split_part(numero_arete, 'EC', 2)::integer+cantidadCatastro)::text,9,'0')
							FROM 
								g_catalogos.serie_aretes
							WHERE
								numero_arete = identificadorInicial)
								and estado = 'utilizado');

RETURN cantidadcatastronueva;
  END;
$$;

alter function proceso_nuevacantidadcatastro(integer, text) owner to postgres;

