create function f_generar_bpa_plus(p_id_solicitud_origen integer, p_id_tipo_bpa_plus integer, p_ruta_certificado_adicional text) returns integer
    language plpgsql
as
$$

	DECLARE
	--p_id_solicitud_origen integer := 5133;
	--p_id_tipo_bpa_plus INTEGER := 33;
	v_id_solicitud INTEGER := 0;

	BEGIN

		INSERT INTO 
			g_certificacion_bpa.solicitudes(identificador, fecha_creacion, es_asociacion, tipo_solicitud, tipo_explotacion, num_animales, identificador_operador, razon_social, identificador_representante_legal, nombre_representante_legal, correo, telefono, direccion, identificador_representante_tecnico, nombre_representante_tecnico, correo_representante_tecnico, telefono_representante_tecnico, id_sitio_unidad_produccion, sitio_unidad_produccion, provincia_unidad_produccion, canton_unidad_produccion, parroquia_unidad_produccion, direccion_unidad_produccion, utm_x, utm_y, altitud, tipo_certificado, num_trabajadores, codigo_equivalente, fecha_inicio_equivalente, fecha_fin_equivalente, observacion_alcance, ruta_certificado_equivalente, num_hectareas, estado, provincia_revision, anexo_nacional, es_tipo_bpa_plus, id_bpa_origen, id_tipo_bpa_plus, ruta_certificado_adicional)
			SELECT 
				identificador, now(), es_asociacion, tipo_solicitud, tipo_explotacion, num_animales, identificador_operador, razon_social, identificador_representante_legal, nombre_representante_legal, correo, telefono, direccion, identificador_representante_tecnico, nombre_representante_tecnico, correo_representante_tecnico, telefono_representante_tecnico, id_sitio_unidad_produccion, sitio_unidad_produccion, provincia_unidad_produccion, canton_unidad_produccion, parroquia_unidad_produccion, direccion_unidad_produccion, utm_x, utm_y, altitud, tipo_certificado, num_trabajadores, codigo_equivalente, fecha_inicio_equivalente, fecha_fin_equivalente, observacion_alcance, ruta_certificado_equivalente, num_hectareas, 'enviado', provincia_revision, anexo_nacional, 'Si', p_id_solicitud_origen, p_id_tipo_bpa_plus, p_ruta_certificado_adicional
			FROM 
				g_certificacion_bpa.solicitudes
			WHERE 
				id_solicitud = p_id_solicitud_origen RETURNING id_solicitud INTO v_id_solicitud;
			
		INSERT INTO 
			g_certificacion_bpa.auditorias_solicitadas(id_solicitud, fecha_creacion, id_tipo_auditoria, tipo_auditoria, estado)
			SELECT 
				v_id_solicitud, now(), id_tipo_auditoria, tipo_auditoria, 'Activo'
			FROM 
				g_certificacion_bpa.auditorias_solicitadas
			WHERE
				id_solicitud = p_id_solicitud_origen;
				
		INSERT INTO 
			g_certificacion_bpa.sitios_areas_productos(id_solicitud, fecha_creacion, identificador_operador, identificador_sitio, id_sitio, nombre_sitio, id_area, nombre_area, id_producto, nombre_producto, id_operacion, nombre_operacion, superficie, num_animales, estado, id_subtipo_producto, nombre_subtipo_producto)
			SELECT 
				v_id_solicitud, now(), identificador_operador, identificador_sitio, id_sitio, nombre_sitio, id_area, nombre_area, id_producto, nombre_producto, id_operacion, nombre_operacion, superficie, num_animales, 'Nuevo', id_subtipo_producto, nombre_subtipo_producto
			FROM 
				g_certificacion_bpa.sitios_areas_productos
			WHERE
				id_solicitud = p_id_solicitud_origen;

	RETURN v_id_solicitud;

END;
$$;

alter function f_generar_bpa_plus(integer, integer, text) owner to postgres;

