create function fs_interconexion_dinarp_certificacion_bpa(pidentificador character varying) returns json
    language plpgsql
as
$$

/*
-------------------------------------------------------------------------
--  [g_certificacion_bpa.fs_interconexion_dinarp_certificacion_bpa]
--               
--  Esta funcion retorna un json con los campos seleccionados de los operadores que tienen certificacion Bpa en estado Aprobado 
--  Cabe recalcar que esta funcion es fundamental para la compartisión de datos mediante ws a la dinarp
--
--  VERSION		AUTOR					FECHA			HU	
--	1			Kleber Armijos		07-08-2024	  Funcion retorna json de un operador de transporte de leche en especifico 
--												  
-------------------------------------------------------------------------
*/
declare 
operadores_certificacion_bpa json;
vnombre_subtipo_producto character varying :='Bovinos'; --para el producto leche
BEGIN	

        SELECT  json_agg(row_to_json(t))
        INTO operadores_certificacion_bpa
        FROM (SELECT 
                si_ar_pro.identificador_operador,
                RTRIM(REPLACE(REPLACE(REPLACE(op.razon_social,chr(9),''),chr(10),''),chr(13),'')) as razon_social,
                op.identificador as identificador_representante_legal,
                op.nombre_representante ||' '||op.apellido_representante as nombre_representante_legal,
                op.correo,
                op.telefono_uno as telefono,
                sol_bpa.sitio_unidad_produccion,
                loc_prov.id_localizacion as id_provincia_unidad_produccion,
                sol_bpa.provincia_unidad_produccion,
                loc_cant.id_localizacion  as id_canton_unidad_produccion,
                sol_bpa.canton_unidad_produccion,
                loc_parr.id_localizacion as id_parroquia_unidad_produccion,
                sol_bpa.parroquia_unidad_produccion,
                sol_bpa.direccion_unidad_produccion,
                sol_bpa.estado,
                sol_bpa.fecha_inicio_vigencia,
                sol_bpa.fecha_fin_vigencia,
                sol_bpa.numero_certificado,
                si_ar_pro.nombre_area,
                tp_pro.id_tipo_producto,
                tp_pro.nombre as tipo_producto,
                si_ar_pro.id_subtipo_producto,
                si_ar_pro.nombre_subtipo_producto as subtipo_producto,
                si_ar_pro.id_producto,
                si_ar_pro.nombre_producto,
                si_ar_pro.superficie,
                'Ha' as unidad_superficie
          FROM g_certificacion_bpa.solicitudes sol_bpa
          INNER JOIN g_certificacion_bpa.sitios_areas_productos si_ar_pro ON si_ar_pro.id_solicitud = sol_bpa.id_solicitud
          INNER JOIN g_operadores.operadores op on si_ar_pro.identificador_operador=op.identificador
          LEFT JOIN g_catalogos.localizacion loc_prov ON loc_prov.nombre = sol_bpa.provincia_unidad_produccion AND loc_prov.id_localizacion_padre = 66
          LEFT JOIN g_catalogos.localizacion loc_cant ON loc_cant.nombre = sol_bpa.canton_unidad_produccion AND loc_cant.id_localizacion_padre = loc_prov.id_localizacion
          LEFT JOIN g_catalogos.localizacion loc_parr ON loc_parr.nombre = sol_bpa.parroquia_unidad_produccion AND loc_parr.id_localizacion_padre = loc_cant.id_localizacion
          LEFT JOIN g_catalogos.subtipo_productos sub_pro ON sub_pro.id_subtipo_producto = si_ar_pro.id_subtipo_producto
          LEFT JOIN g_catalogos.tipo_productos tp_pro ON tp_pro.id_tipo_producto = sub_pro.id_tipo_producto
          WHERE
          si_ar_pro.identificador_sitio= $1 and
          sol_bpa.estado='Aprobado' and
          si_ar_pro.nombre_subtipo_producto =vnombre_subtipo_producto
        ) t;
return operadores_certificacion_bpa;
END;
$$;

alter function fs_interconexion_dinarp_certificacion_bpa(varchar) owner to postgres;

