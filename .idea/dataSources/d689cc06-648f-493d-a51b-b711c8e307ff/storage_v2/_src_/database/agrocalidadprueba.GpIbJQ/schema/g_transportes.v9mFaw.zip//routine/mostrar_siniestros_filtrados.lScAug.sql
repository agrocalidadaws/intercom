create function mostrar_siniestros_filtrados(_tipo_siniestro text, _placa text, _estado integer, _fecha_inicio timestamp without time zone, _fecha_fin timestamp without time zone, _localizacion text) returns SETOF g_transportes.siniestros
    language plpgsql
as
$$
DECLARE
 query text;
BEGIN 
 return query EXECUTE ' 
  SELECT
   *
  FROM 
   g_transportes.siniestros s
  WHERE 
   ($1 is NULL or tipo_siniestro like $1) and 
   ($2 is NULL or placa like $2) and
   ($3 is NULL or estado = $3) and 
   ($4 is NULL or fecha_siniestro >= $4) and 
   ($5 is NULL or fecha_siniestro <= $5) 
   
  ORDER BY
   s.fecha_siniestro'
  using _tipo_siniestro,_placa,_estado,_fecha_inicio,_fecha_fin,_localizacion;
 
END;$$;

alter function mostrar_siniestros_filtrados(text, text, integer, timestamp, timestamp, text) owner to postgres;

