create function mostrar_talleres_filtrados(_localizacion text, _taller integer, _direccion text, _estado integer) returns SETOF g_transportes.talleres
    language plpgsql
as
$$
DECLARE
	query text;
BEGIN	
	return query EXECUTE '	
		SELECT
			*
		FROM 
			g_transportes.talleres t
		WHERE 
			($1 is NULL or id_taller = $1) and 
			($2 is NULL or direccion like $2) and
			($3 is NULL or estado = $3) and 
			($4 is NULL or $4 = localizacion) 
			
		ORDER BY
			t.nombre'
		using _taller,_direccion,_estado,_localizacion;
	
END;
$$;

alter function mostrar_talleres_filtrados(text, integer, text, integer) owner to postgres;

