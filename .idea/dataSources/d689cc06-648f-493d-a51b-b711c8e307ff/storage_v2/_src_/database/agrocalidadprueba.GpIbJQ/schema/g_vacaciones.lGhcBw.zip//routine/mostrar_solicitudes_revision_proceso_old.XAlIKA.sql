create function mostrar_solicitudes_revision_proceso_old(_tipo_permiso integer, _fecha_desde timestamp without time zone, _fecha_hasta timestamp without time zone, _estado text, _area text) returns SETOF g_vacaciones.vista_permisos_vacaciones
    language plpgsql
as
$$
DECLARE
	query text;	
BEGIN

       _area=replace(_area, '-', ''',''');	
	return query EXECUTE '
		SELECT
			*
		FROM 
			g_vacaciones.vista_permisos_vacaciones
		WHERE 		        
			($1 is NULL or sub_tipo = $1) and 
			($2 is NULL or fecha_inicio between $2 and $3) and 
			($3 is NULL or fecha_fin between $2 and $3) and
			($5 is NULL or id_area_jefe in ('''|| $5 ||''')) and
			($4 is NULL or estado = $4 ) ' 
		using _tipo_permiso,_fecha_desde,_fecha_hasta,_estado,_area;
END;
$$;

alter function mostrar_solicitudes_revision_proceso_old(integer, timestamp, timestamp, text, text) owner to postgres;

