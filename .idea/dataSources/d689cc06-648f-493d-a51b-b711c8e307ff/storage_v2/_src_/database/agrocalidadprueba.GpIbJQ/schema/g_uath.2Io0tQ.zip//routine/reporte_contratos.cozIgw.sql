create function reporte_contratos(_regimen_laboral text, _provincia text, _canton text, _oficina text, _coordinacion text, _direccion text, _gestion text, _estado integer, _fecha_inicio date, _fecha_fin date, _nombre_puesto text) returns SETOF g_uath.vista_contrato_empleado
    language plpgsql
as
$$
DECLARE
	query text;
BEGIN	
	return query EXECUTE 'SELECT
			*
		FROM 
			g_uath.vista_contrato_empleado
		WHERE 
		        
			($1 is NULL or regimen_laboral = $1) and 
			($2 is NULL or provincia = $2) and
			($3 is NULL or canton = $3) and 
			($4 is NULL or oficina = $4) and 
			($5 is NULL or coordinacion = $5) and 
			($6 is NULL or direccion = $6) and 
			($7 is NULL or gestion = $7) and 
			($8 is NULL or estado = $8) and
			($9 is NULL or fecha_inicio >= $9) and 
			($10 is NULL or fecha_fin <= $10) and
			($11 is NULL or nombre_puesto <= $11)' 

		using _regimen_laboral,_provincia,_canton,_oficina,_coordinacion,_direccion,_gestion,_estado, _fecha_inicio, _fecha_fin, _nombre_puesto;
	
END;
$$;

alter function reporte_contratos(text, text, text, text, text, text, text, integer, date, date, text) owner to postgres;

