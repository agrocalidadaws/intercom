create function proceso_cambioduenio(identificador text, aredestino integer, identificadoroperadororigen text, identificadoroperadordestino text, idsitioorigen integer, idsitiodestino integer, identificadorresponsable text, tipoactivacion text, motivoactivacion text, observacionactivacion text) returns text
    language plpgsql
as
$$

-- TRABAJO
DECLARE contador INTEGER := 0;
DECLARE identificadorreg record;
DECLARE idproductomadre integer := 0;
DECLARE idproductolechon integer := 0;
DECLARE idproductolechona integer := 0;
DECLARE banderamadre boolean := false;
DECLARE cantidadreproduccion integer :=0;
DECLARE nuevocatastro integer := 0;

BEGIN

--//Obtenemos el id del producto cerda madre
			
SELECT id_producto 
INTO idproductomadre
FROM g_catalogos.productos_animales pa 
WHERE pa.codigo = 'PORDRE' and pa.estado_producto = 'activo';

--//Obtenemos el id del producto lechon

SELECT id_producto 
INTO idproductolechon
FROM g_catalogos.productos_animales pa 
WHERE pa.codigo = 'PORHON' and pa.estado_producto = 'activo';
	
--//Obtenemos el id del producto lechona

SELECT id_producto 
INTO idproductolechona
FROM g_catalogos.productos_animales pa 
WHERE pa.codigo = 'PORONA' and pa.estado_producto = 'activo';

-- GUARDO EN TABLA TEMPORAL LOS IDENTIFICADORES
CREATE TEMP TABLE tmp_identificadores (tidentificador text, tarea_origen integer, tarea_destino integer, tproducto integer, tcantidad integer, tnumero_lote text, 
                                       tunidad_comercial integer, ttipo_operacion_origen integer,ttipo_operacion_destino integer, tidcatastro integer,
                                       tidentificador_producto text, tidentificadorunicoproducto text, testado text) ON COMMIT DROP;
   INSERT INTO tmp_identificadores SELECT identificador,0, aredestino,0,0,'0',34,0,0,0;

   --CREA TABLA TEMPORAL PARA CATASTROS
   
	CREATE TEMP TABLE tmp_catastros (tid_catastro integer, tid_sitio integer, tid_area integer, tid_producto integer, tcantidad double precision, tfecha_registro timestamp without time zone, 
					tidentificador_responsable text, tunidad_medida_peso text, tfecha_modificacion_etapa timestamp without time zone, 
					tnombre_producto text, peso double precision, tid_especie integer, tfecha_nacimiento timestamp without time zone, 
					tnumero_lote text, testado_etapa text, tid_tipo_operacion integer, 
					tunidad_comercial integer, tnumero_actualizacion_cupo integer) ON COMMIT DROP;
	-- DROP TABLE tmp_catastros

	---CREAMOS UN TABLA TEMPORAL PARA CONTROL DE REPRODUCCION 
	CREATE TEMP TABLE tmp_controlreproduccion (tidentificador_operador_origen text, tidentificador_operador_destino text, 
						tcupocriadestino integer, tcantidadcriadestino integer, tmadresdestino integer, tlechonesdestino integer, tnuevocupocriadestino integer, tnuevocantidadcriadestino integer,
						tcupocriaorigen integer, tcantidadcriaorigen integer, tmadresorigen integer, tlechonesorigen integer, tnuevocupocriaorigen integer,
						tnuevocantidadcriaorigen integer) ON COMMIT DROP;
					--

   INSERT INTO tmp_controlreproduccion (tidentificador_operador_origen, tidentificador_operador_destino) values (identificadoroperadororigen, identificadoroperadordestino);



-- NECESITO DATOS DE ORIGEN: AREA, PRODUCTO, ID_CATASTRO ACTUAL DEL IDENTIFICADOR


   update tmp_identificadores ti set
     tarea_origen = c.id_area, 
     tproducto = c.id_producto,
     tidcatastro = c.id_catastro 
   from g_catastro.detalle_catastros dc inner join g_catastro.catastros c
        on c.id_catastro = dc.id_catastro
   where
   (ti.tidentificador = dc.identificador_producto
   or ti.tidentificador = dc.identificador_unico_producto);

-- LLENA TABLA CATASTRO

   INSERT INTO tmp_catastros SELECT id_catastro, id_sitio, id_area, id_producto, cantidad, fecha_registro, 
       identificador_responsable, unidad_medida_peso, fecha_modificacion_etapa, 
       nombre_producto, peso, id_especie, fecha_nacimiento, numero_lote, 
       estado_etapa, id_tipo_operacion, unidad_comercial, numero_actualizacion_cupo
	FROM g_catastro.catastros WHERE id_catastro in (SELECT tidcatastro FROM tmp_identificadores);

-- TOMANDO EN CUANTA QUE EN SA NO SE COMPARTAN AREAS se completan los tipos_operaciones
   FOR identificadorreg in (SELECT tarea_origen, tarea_destino from tmp_identificadores)
   LOOP
     update tmp_identificadores ti set
     ttipo_operacion_origen = o.id_tipo_operacion
     from g_operadores.productos_areas_operacion pao inner join g_operadores.operaciones o 
     on o.id_operacion = pao.id_operacion
     where pao.id_area = identificadorreg.tarea_origen;
   
     update tmp_identificadores ti set
     ttipo_operacion_destino = o.id_tipo_operacion
     from g_operadores.productos_areas_operacion pao inner join g_operadores.operaciones o 
     on o.id_operacion = pao.id_operacion
     where pao.id_area = identificadorreg.tarea_destino;
      
   END LOOP;

-- COMPELTAMOS NUMEROS DE IDENTIFICACION

update tmp_identificadores ti set  
tidentificador_producto = dc.identificador_producto,
tidentificadorunicoproducto = dc.identificador_unico_producto,
testado = 'activo'
FROM g_catastro.detalle_catastros dc
WHERE dc.id_catastro = ti.tidcatastro 
and 
  case when dc.identificador_producto is null 
       then  dc.identificador_unico_producto 
       else dc.identificador_producto 
  end = ti.tidentificador;

	    

--VERICAMOS SI SE MOVILIZA UN ACERDA MADRE
IF EXISTS (select tproducto FROM tmp_identificadores WHERE tproducto = idproductomadre) THEN

banderamadre = true;

END IF;



	--------------------//////////////////////////////INICIO CATASTRO/////////////////////////////////------------------------------------------------------

-- INSERTA CABECERA CATASTRO


		FOR identificadorreg in (select count(tproducto) as tcuenta,  tarea_origen, tidcatastro, tproducto, ttipo_operacion_origen,
					tarea_destino, ttipo_operacion_destino from  tmp_identificadores 
					group by tproducto, tarea_origen, tidcatastro, ttipo_operacion_origen, tarea_destino, ttipo_operacion_destino)                         
		   LOOP     

		   RAISE NOTICE '% % % % %', identificadorreg.tcuenta, identificadorreg.tarea_origen , identificadorreg.tproducto , identificadorreg.ttipo_operacion_origen , identificadorreg.tarea_destino;

			--INSERTO CABECERA
			INSERT INTO g_catastro.catastros(id_sitio, id_area, id_producto, cantidad, identificador_responsable, unidad_medida_peso, fecha_modificacion_etapa, nombre_producto, 
								peso, id_especie, fecha_nacimiento, numero_lote, estado_etapa, id_tipo_operacion, unidad_comercial )
						select   idsitiodestino, identificadorreg.tarea_destino, identificadorreg.tproducto, identificadorreg.tcuenta,
							  identificadorresponsable, tc.tunidad_medida_peso, tc.tfecha_modificacion_etapa, tc.tnombre_producto, tc.peso, tc.tid_especie, tc.tfecha_nacimiento, tc.tnumero_lote,
							  tc.testado_etapa, identificadorreg.ttipo_operacion_destino, tc.tunidad_comercial 
						from 
							tmp_catastros tc 
						where 
							tid_catastro = identificadorreg.tidcatastro --and tc.tid_producto = identificadorreg.tproducto
						RETURNING id_catastro INTO nuevocatastro;
			-- RECUPERO NUEVO ID_CATASTR


			-- INSERTO CATASTRO TRANSACCION RESTA

			--OBTENGO TOTAL DE PRODUCTOS CATASTRADOS POR AREY Y PRODUCTO
			SELECT cantidad_total into contador  FROM g_catastro.transaccion_catastro WHERE id_area = identificadorreg.tarea_origen 
			and id_producto = identificadorreg.tproducto and id_tipo_operacion = identificadorreg.ttipo_operacion_origen 
			ORDER BY id_transaccion_catastro DESC LIMIT 1;

			
			INSERT INTO g_catastro.transaccion_catastro
					  (id_catastro, id_area, id_concepto_catastro, id_producto, cantidad_egreso,
					  cantidad_total, unidad_comercial,identificador_responsable, id_tipo_operacion)
				    select  identificadorreg.tidcatastro, identificadorreg.tarea_origen, 
					   (SELECT id_concepto_catastro FROM g_catastro.concepto_catastros WHERE codigo = 'MOOR'),            
					    identificadorreg.tproducto, identificadorreg.tcuenta,
					    case when contador is not null 
						then contador - identificadorreg.tcuenta
						else 0
					    end,
					tc.tunidad_comercial, identificadorresponsable, identificadorreg.ttipo_operacion_origen
					FROM
					tmp_catastros tc
					where 
					tc.tid_producto = identificadorreg.tproducto
					and tc.tid_catastro = identificadorreg.tidcatastro;

			contador := 0;
			
			
			-- INSERTO CATASTRO TRASNSACCION SUMA

			SELECT cantidad_total into contador  FROM g_catastro.transaccion_catastro WHERE id_area = identificadorreg.tarea_destino 
			and id_producto = identificadorreg.tproducto and id_tipo_operacion = identificadorreg.ttipo_operacion_destino 
			ORDER BY id_transaccion_catastro DESC LIMIT 1;

			
			INSERT INTO g_catastro.transaccion_catastro
					  (id_catastro, id_area, id_concepto_catastro, id_producto, cantidad_ingreso,
					  cantidad_total, unidad_comercial, identificador_responsable, id_tipo_operacion)
				    select  nuevocatastro, identificadorreg.tarea_destino, 
					   (SELECT id_concepto_catastro FROM g_catastro.concepto_catastros WHERE codigo='MODE'),            
					    identificadorreg.tproducto, identificadorreg.tcuenta,
					    case when contador is not null 
						then contador + identificadorreg.tcuenta
						else 0
					    end,
					tc.tunidad_comercial, identificadorresponsable, identificadorreg.ttipo_operacion_destino
					FROM
					tmp_catastros tc
					where 
					tc.tid_producto = identificadorreg.tproducto
					and tc.tid_catastro = identificadorreg.tidcatastro;


			---- GUARDO DETALLE CATASTRO	
		
			INSERT INTO g_catastro.detalle_catastros(id_catastro, identificador_producto, identificador_unico_producto ,estado_registro)
			    SELECT nuevocatastro, ti.tidentificador_producto, ti.tidentificadorunicoproducto, ti.testado
			    FROM 
				tmp_identificadores ti
			    WHERE 
				tarea_destino = identificadorreg.tarea_destino
				and tproducto = identificadorreg.tproducto
				and tidcatastro = identificadorreg.tidcatastro;

			UPDATE g_catastro.detalle_catastros SET estado_registro = 'eliminado'
			WHERE id_catastro = identificadorreg.tidcatastro and 
			(identificador_unico_producto in (SELECT ti.tidentificadorunicoproducto FROM tmp_identificadores ti)
			or identificador_producto in (SELECT ti.tidentificadorunicoproducto FROM tmp_identificadores ti)
			);

			INSERT INTO g_catastro.log_activacion_producto(id_sitio_origen, id_area_origen, id_sitio_destino, id_area_destino, identificador_producto, 
									identificador_responsable, fecha_registro, tipo_activacion, motivo_activacion, observacion_activacion)
			SELECT idsitioorigen, identificadorreg.tarea_origen, idsitiodestino, identificadorreg.tarea_destino, COALESCE(tidentificador_producto, tidentificadorunicoproducto),
				identificadorresponsable, 'now()', tipoactivacion, motivoactivacion, observacionactivacion
			FROM
				tmp_identificadores ti
			WHERE 
				tarea_destino = identificadorreg.tarea_destino
				and tproducto = identificadorreg.tproducto
				and tidcatastro = identificadorreg.tidcatastro;
			
			
		END LOOP;



		--------------------//////////////////////////////INICIO CONTROL REPORDUCCION/////////////////////////////////------------------------------------------------------
		IF banderamadre THEN

			UPDATE tmp_controlreproduccion set 
			  tcupocriadestino = cp.cupo_cria,
			  tcantidadcriadestino = cp.cantidad_cria
			  from g_catastro.control_reproduccion cp
			  where id_control_reproduccion = (select max(id_control_reproduccion) from g_catastro.control_reproduccion where id_producto = idproductomadre
			  and identificador_operador = identificadoroperadordestino);

			 UPDATE tmp_controlreproduccion set 
			  tmadresdestino = (SELECT count(id_detalle_catastro) cantidad
						FROM g_catastro.catastros c, g_catastro.detalle_catastros dc, g_operadores.sitios s
						WHERE c.id_catastro = dc.id_catastro and s.id_sitio = c.id_sitio and s.identificador_operador = identificadoroperadordestino
						and c.id_producto = idproductomadre and dc.estado_registro = 'activo'),
			  tlechonesdestino = (SELECT count(id_detalle_catastro) cantidad
						FROM g_catastro.catastros c, g_catastro.detalle_catastros dc, g_operadores.sitios s
						WHERE c.id_catastro = dc.id_catastro and s.id_sitio = c.id_sitio and s.identificador_operador = identificadoroperadordestino
						and c.id_producto in (idproductolechon,idproductolechona) and dc.estado_registro = 'activo');

			  UPDATE tmp_controlreproduccion set 
			  tcupocriaorigen = cp.cupo_cria,
			  tcantidadcriaorigen = cp.cantidad_cria 
			  from g_catastro.control_reproduccion cp
			  where id_control_reproduccion = (select max(id_control_reproduccion) from g_catastro.control_reproduccion where id_producto = idproductomadre
			  and identificador_operador = identificadoroperadordestino);

			 UPDATE tmp_controlreproduccion set 
			  tmadresorigen = (SELECT count(id_detalle_catastro) cantidad
						FROM g_catastro.catastros c, g_catastro.detalle_catastros dc, g_operadores.sitios s
						WHERE c.id_catastro = dc.id_catastro and s.id_sitio = c.id_sitio and s.identificador_operador = identificadoroperadordestino
						and c.id_producto = idproductomadre and dc.estado_registro = 'activo'),
			  tlechonesorigen = (SELECT count(id_detalle_catastro) cantidad
						FROM g_catastro.catastros c, g_catastro.detalle_catastros dc, g_operadores.sitios s
						WHERE c.id_catastro = dc.id_catastro and s.id_sitio = c.id_sitio and s.identificador_operador = identificadoroperadordestino
						and c.id_producto in (idproductolechon,idproductolechona) and dc.estado_registro = 'activo');
			  
			-- actualizar cupodestino
			update tmp_controlreproduccion set 
			tnuevocupocriadestino =  case when tcupocriadestino is not null then (tcupocriadestino + (cantidadreproduccion * 28)) 
							     else cantidadreproduccion * 28
							end,
			tnuevocantidadcriadestino = case when tcupocriadestino is not null then tcantidadcriadestino 
							     else tlechonesdestino
							end,
			tnuevocupocriaorigen = case when tcupocriaorigen is not null then (tcupocriaorigen - (cantidadreproduccion * 28))  
							     else cantidadreproduccion * 28
							end,
			
			tnuevocantidadcriaorigen = case when tcupocriaorigen is not null then tcantidadcriaorigen  
							     else tlechonesorigen
							end;
			  
			INSERT INTO g_catastro.control_reproduccion
				   (identificador_operador, id_producto, cupo_cria, fecha_registro, cantidad_cria) 
				SELECT 
					tidentificador_operador_destino, idproductomadre, tnuevocupocriadestino,now(), tnuevocantidadcriadestino  
				FROM  
					tmp_controlreproduccion 
				WHERE
					tidentificador_operador_destino = identificadoroperadordestino;

			INSERT INTO g_catastro.control_reproduccion
				   (identificador_operador, id_producto, cupo_cria, fecha_registro, cantidad_cria) 
				SELECT 
					tidentificador_operador_origen, idproductomadre, tnuevocupocriaorigen,now(), tnuevocantidadcriaorigen 
				FROM  
					tmp_controlreproduccion 
				WHERE
					tidentificador_operador_origen = identificadoroperadordestino;


		END IF;



RETURN nuevocatastro;
  END;
$$;

alter function proceso_cambioduenio(text, integer, text, text, integer, integer, text, text, text, text) owner to postgres;

