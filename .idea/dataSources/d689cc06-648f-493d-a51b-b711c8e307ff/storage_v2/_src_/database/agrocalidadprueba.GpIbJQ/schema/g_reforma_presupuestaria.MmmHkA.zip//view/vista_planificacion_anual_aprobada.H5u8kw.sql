create view vista_planificacion_anual_aprobada
            (id_planificacion_anual, identificador, id_area_funcionario, fecha_creacion, anio, id_objetivo_estrategico,
             objetivo_estrategico, id_area_n2, area_n2, id_objetivo_especifico, objetivo_especifico, id_area_n4,
             area_n4, id_objetivo_operativo, objetivo_operativo, id_area_unidad, gestion, id_proceso_proyecto,
             proceso_proyecto, tipo, id_componente, componente, id_actividad, actividad, producto_final, id_provincia,
             provincia, cantidad_usuarios, poblacion_objetivo, medio_verificacion, identificador_responsable,
             nombre_responsable, total_presupuesto_solicitado, estado, identificador_aprobador_ga, id_area_aprobador_ga,
             fecha_aprobacion_ga, observaciones_aprobacion_ga, identificador_aprobador_gf, id_area_aprobador_gf,
             fecha_aprobacion_gf, observaciones_aprobacion_gf)
as
SELECT DISTINCT pa.id_planificacion_anual,
                pa.identificador,
                pa.id_area_funcionario,
                pa.fecha_creacion,
                pa.anio,
                pa.id_objetivo_estrategico,
                oe.nombre                    AS objetivo_estrategico,
                pa.id_area_n2,
                n2.nombre                    AS area_n2,
                pa.id_objetivo_especifico,
                oe.nombre                    AS objetivo_especifico,
                pa.id_area_n4,
                n4.nombre                    AS area_n4,
                pa.id_objetivo_operativo,
                oo.nombre                    AS objetivo_operativo,
                pa.id_area_unidad,
                g.nombre                     AS gestion,
                pa.id_proceso_proyecto,
                pp.nombre                    AS proceso_proyecto,
                pa.tipo,
                pa.id_componente,
                c.nombre                     AS componente,
                pa.id_actividad,
                ac.nombre                    AS actividad,
                pa.producto_final,
                pa.id_provincia,
                pa.provincia,
                pa.cantidad_usuarios,
                pa.poblacion_objetivo,
                pa.medio_verificacion,
                pa.identificador_responsable,
                pa.nombre_responsable,
                pa.total_presupuesto_solicitado,
                pa.estado,
                pa.identificador_revisor_ga  AS identificador_aprobador_ga,
                pa.id_area_revisor_ga        AS id_area_aprobador_ga,
                pa.fecha_revision_ga         AS fecha_aprobacion_ga,
                pa.observaciones_revision_ga AS observaciones_aprobacion_ga,
                pa.identificador_revisor_gf  AS identificador_aprobador_gf,
                pa.id_area_revisor_gf        AS id_area_aprobador_gf,
                pa.fecha_revision_gf         AS fecha_aprobacion_gf,
                pa.observaciones_revision_gf AS observaciones_aprobacion_gf
FROM g_reforma_presupuestaria.planificacion_anual pa,
     g_programacion_presupuestaria.objetivo_estrategico oe,
     g_programacion_presupuestaria.objetivo_especifico oes,
     g_programacion_presupuestaria.objetivo_operativo oo,
     g_programacion_presupuestaria.proceso_proyecto pp,
     g_programacion_presupuestaria.programas p,
     g_programacion_presupuestaria.componente c,
     g_programacion_presupuestaria.actividad ac,
     g_programacion_presupuestaria.codigo_proyecto cp,
     g_estructura.area n2,
     g_estructura.area n4,
     g_estructura.area g,
     g_estructura.area a,
     g_estructura.funcionarios f,
     g_uath.ficha_empleado fe
WHERE pa.identificador::text = fe.identificador::text
  AND fe.identificador::text = f.identificador::text
  AND pa.id_objetivo_estrategico = oe.id_objetivo_estrategico
  AND pa.id_objetivo_especifico = oes.id_objetivo_especifico
  AND pa.id_objetivo_operativo = oo.id_objetivo_operativo
  AND pa.id_proceso_proyecto = pp.id_proceso_proyecto
  AND pa.id_componente = c.id_componente
  AND pa.id_area_funcionario::text = a.id_area::text
  AND pa.id_area_n2::text = n2.id_area::text
  AND pa.id_area_n4::text = n4.id_area::text
  AND pa.id_area_unidad::text = g.id_area::text
  AND pa.id_actividad = ac.id_actividad;

alter table vista_planificacion_anual_aprobada
    owner to postgres;

