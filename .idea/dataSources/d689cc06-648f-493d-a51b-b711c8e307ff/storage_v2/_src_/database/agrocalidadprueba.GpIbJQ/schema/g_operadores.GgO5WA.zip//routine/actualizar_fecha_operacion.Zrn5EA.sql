create function actualizar_fecha_operacion() returns trigger
    language plpgsql
as
$$ 
BEGIN
	IF (NEW.estado != OLD.estado)
	THEN
		UPDATE g_operadores.operaciones SET fecha_modificacion = now() WHERE id_operacion = NEW.id_operacion;
	END IF;
	RETURN NEW;
	END; 
	
$$;

alter function actualizar_fecha_operacion() owner to postgres;

