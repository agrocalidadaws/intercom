create function fs_vigilancia_rt4_fusariun(pfecha_inspeccion_inicial date, pfecha_inspeccion_final date, ptipo_enfermedad character varying) returns SETOF json
    language plpgsql
as
$$

/*
-------------------------------------------------------------------------
--  [f_inspeccion.fs_vigilancia_rt4_fusariun]
--               
--  Esta funcion se encarga de devolver un json en un formato especifico GeoJson
--
--  VERSION		AUTOR					FECHA			HU			                           CAMBIO
--	1.1			Kleber Armijos		30-05-2023			Servicio Web PestDisplace              se castea de cordenadas wgs 84 utm 17S a grados decimales
-------------------------------------------------------------------------
*/
BEGIN
return QUERY SELECT json_agg(json_build_object(
  'features',json_build_object(
	'geometry', json_build_object(
		  'coordinates', json_build_array(
			  CASE
                    WHEN f.coordenada_x similar to '%.%' AND f.coordenada_y similar to '%.%' THEN f.coordenada_x::double precision
                    ELSE  CASE 
			  					WHEN ABS(f.coordenada_x::double precision)>400000 THEN  ST_X(ST_Transform(ST_SetSRID(ST_MakePoint(coordenada_x::double precision, coordenada_y::double precision), 32717), 4326))
			  					ELSE ST_X(ST_Transform(ST_SetSRID(ST_MakePoint(coordenada_x::double precision +667800, coordenada_y::double precision), 32717), 4326))
			  					END
			 
			  	
                END,
              CASE
                    WHEN f.coordenada_x similar to '%.%' AND f.coordenada_y similar to '%.%' THEN f.coordenada_y::double precision
                    ELSE CASE
			  				WHEN ABS(f.coordenada_y::double precision)<900000  THEN ST_Y(ST_Transform(ST_SetSRID(ST_MakePoint(coordenada_x::double precision, coordenada_y::double precision+10000000), 32717), 4326))
			  				ELSE ST_Y(ST_Transform(ST_SetSRID(ST_MakePoint(coordenada_x::double precision, coordenada_y::double precision), 32717), 4326))
			  				END
			  			
                END
			    --ST_X(ST_Transform(ST_SetSRID(ST_MakePoint(coordenada_x::double precision, coordenada_y::double precision), 32717), 4326)),
			   --ST_Y(ST_Transform(ST_SetSRID(ST_MakePoint(coordenada_x::double precision, coordenada_y::double precision), 32717), 4326))
						-- f.coordenada_x,
						-- f.coordenada_y
		  ),
		  'type', 'Point'
	  ),
	  'properties', json_build_object(
		'dateCollection', f.fecha_inspeccion,
		 --'dateSync',f.fecha_ingreso_guia,
		'disease',f.plaga_diagnostico_visual_prediagnostico,
		'lab_code', f.envio_muestra,
		'location_level2',f.nombre_provincia,
		'location_level3',f.nombre_canton,
		'location_level4',f.nombre_parroquia,
		'cultivar_name',f.especie_vegetal,
		'incidence',f.porcentaje_incidencia
		 
	 
	  ),
	 'type', 'Feature'
  )
) )AS geoJson
 FROM
                      f_inspeccion.vigilanciaf02 f
                       LEFT JOIN f_inspeccion.vigilanciaf02_detalle_ordenes fdo 
					   ON fdo.id_padre = f.id
                    WHERE
						f.porcentaje_incidencia<=100 and f.porcentaje_incidencia is not null and
                      f.fecha_inspeccion BETWEEN $1 AND $2
					  AND f.plaga_diagnostico_visual_prediagnostico like($3)
					  and f.coordenada_x<>'-'
					  and f.coordenada_x<>'.'
					  and f.coordenada_y<>'-'
					  and f.coordenada_y<>'.'
					  and f.coordenada_x !~'\.\d{1,3}$' 
					  and f.coordenada_y !~'\.\d{1,3}$';
                  

END;
$$;

alter function fs_vigilancia_rt4_fusariun(date, date, varchar) owner to postgres;

