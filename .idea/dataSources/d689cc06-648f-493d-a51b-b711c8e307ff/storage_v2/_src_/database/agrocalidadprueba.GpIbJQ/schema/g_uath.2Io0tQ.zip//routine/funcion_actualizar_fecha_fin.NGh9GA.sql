create function funcion_actualizar_fecha_fin() returns trigger
    language plpgsql
as
$$ 
BEGIN
	IF NEW.estado != OLD.estado THEN
		NEW.fecha_fin = now();
	END IF;
	
	RETURN NEW;
END; 
$$;

alter function funcion_actualizar_fecha_fin() owner to postgres;

