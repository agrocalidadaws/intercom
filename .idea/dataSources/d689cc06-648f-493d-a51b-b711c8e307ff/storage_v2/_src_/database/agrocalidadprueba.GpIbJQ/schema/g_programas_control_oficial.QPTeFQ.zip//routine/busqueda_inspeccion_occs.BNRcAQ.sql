create function busqueda_inspeccion_occs(_num_solicitud text, _fecha timestamp without time zone, _nombre_predio text, _nombre_propietario text, _nombre_asociacion text, _id_provincia integer, _id_canton integer, _id_parroquia integer, _sector text, _estado text) returns SETOF g_programas_control_oficial.vista_busqueda_inspeccion_occs
    language plpgsql
as
$$
DECLARE
	query text;
BEGIN	
	return query EXECUTE '	
		SELECT
			*
		FROM 
			g_programas_control_oficial.vista_busqueda_inspeccion_occs
		WHERE 		        
			($1 is NULL or num_solicitud ilike $1) and 
			($2 is NULL or fecha >= $2) and 
			($3 is NULL or nombre_predio ilike $3) and 
			($4 is NULL or nombre_propietario ilike $4) and 
			($5 is NULL or nombre_asociacion ilike $5) and 
			($6 is NULL or id_provincia = $6) and 
			($7 is NULL or id_canton = $7) and 
			($8 is NULL or id_parroquia = $8) and 
			($9 is NULL or sector ilike $9) and
			($10 is NULL or estado = $10)
			
		ORDER BY
			num_solicitud, id_provincia, id_canton, id_parroquia, estado'
			
		using _num_solicitud, _fecha, _nombre_predio, _nombre_propietario, _nombre_asociacion, _id_provincia, _id_canton, _id_parroquia, _sector, _estado;
	
END;
$$;

alter function busqueda_inspeccion_occs(text, timestamp, text, text, text, integer, integer, integer, text, text) owner to postgres;

