create function reporte_funcionarios_fecha(_identificador text, _apellido text, _nombre text, _provincia text, _modalidad text) returns SETOF g_uath.vista_funcionario
    language plpgsql
as
$$
DECLARE
	query text;
BEGIN	
	return query EXECUTE 'SELECT
			*
		FROM 
			g_uath.vista_funcionario
		WHERE 
		        
			($1 is NULL or identificador = $1) and 
			($2 is NULL or apellido = $2) and
			($3 is NULL or nombre = $3) and
			($4 is NULL or provincia = $4) and
			($5 is NULL or tipo_contrato = $5)'  
		using _identificador, _apellido, _nombre, _provincia, _modalidad;
END;
$$;

alter function reporte_funcionarios_fecha(text, text, text, text, text) owner to postgres;

