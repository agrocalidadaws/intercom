create function actualiza_notificacion_solicitud() returns trigger
    language plpgsql
as
$$ 
DECLARE _incremento INTEGER;
DECLARE _situacion BOOLEAN;
	BEGIN 
	--TG_OP = 'INSERT' OR 
	IF ((TG_OP = 'INSERT' AND NEW.situacion is not null) OR (TG_OP = 'UPDATE' AND (OLD.situacion is null OR OLD.situacion!=NEW.situacion )))
	THEN
		IF NEW.situacion
		THEN --Significa que la situación de la solicitud esta "abierto" (ha sido revisado)
			_incremento:=-1;
		ELSE --Significa que la situación de la solicitud esta "cerrada" (no ha revisado)
			_incremento:=1;
			
			--IF (TG_OP = 'UPDATE') THEN 
				--NEW.estado = 'Pendiente';
			--END IF;
		END IF;
		PERFORM g_programas.actualizarnotificaciones(_incremento, NEW.identificador, (SELECT a.id_aplicacion FROM g_programas.aplicaciones a WHERE a.codificacion_aplicacion='PRG_SOLICITUDES'));
	END IF;
	RETURN NEW;
	END; 
$$;

alter function actualiza_notificacion_solicitud() owner to postgres;

