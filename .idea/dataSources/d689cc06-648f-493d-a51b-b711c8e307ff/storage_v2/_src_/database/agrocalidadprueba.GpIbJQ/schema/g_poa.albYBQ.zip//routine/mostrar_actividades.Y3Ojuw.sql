create function mostrar_actividades(_area text, _objetivo integer, _proceso integer, _subproceso integer, _actividad text, _anio integer) returns SETOF g_poa.vista_actividades
    language plpgsql
as
$$
DECLARE
	query text;
BEGIN	
	_area=replace(_area, '-', ''',''');
	return query EXECUTE '	
		SELECT
			*
		FROM 
			g_poa.vista_actividades
		WHERE 
		        
			($1 is NULL or id_area in ('''|| $1 ||''')) and
			($2 is NULL or id_objetivo = $2) and 
			($3 is NULL or id_proceso = $3) and 
			($4 is NULL or id_subproceso = $4) and  
			($5 is NULL or actividad like $5) and
			($6 is NULL or anio = $6)
			
		ORDER BY
			id_actividad'
		using _area,_objetivo,_proceso, _subproceso,_actividad, _anio;
	
END;
$$;

alter function mostrar_actividades(text, integer, integer, integer, text, integer) owner to postgres;

