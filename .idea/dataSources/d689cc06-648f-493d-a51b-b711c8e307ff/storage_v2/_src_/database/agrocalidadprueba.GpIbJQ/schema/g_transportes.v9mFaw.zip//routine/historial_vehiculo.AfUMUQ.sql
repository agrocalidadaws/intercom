create function historial_vehiculo(_placa text) returns SETOF g_transportes.historico
    language plpgsql
as
$$
DECLARE
cont record;
BEGIN
FOR cont in (SELECT
		v.placa as concepto, 
		v.fecha_compra as fecha, 
		v.kilometraje_actual as kilometraje_uno, 
		v.marca as descripcion, 
		v.carroceria as numero, 
		v.modelo as observacion,
		v.kilometraje_inicial as kilometraje_dos,
		v.numero_motor as detalle,
		v.numero_chasis as conductor,
		'Vehiculo'::varchar as tipo
     FROM
        g_transportes.vehiculos v
     WHERE v.placa = _placa
UNION
     SELECT
        g.nombre, 
        c.fecha_solicitud, 
        c.kilometraje, 
        c.tipo_combustible, 
        to_char(c.valor_liquidacion, 'FM999999.90'), 
        c.observacion , 
        c.cantidad_galones,
        c.fecha_liquidacion::varchar,
        g_uath.cambia_formato_nombre(fe.nombre,fe.apellido) AS nombres_completos  ,
        'Combustible'
     FROM
        g_transportes.combustible c,
        g_transportes.gasolineras g,
        g_uath.ficha_empleado fe
     WHERE c.placa = _placa 
	   and c.gasolinera = g.id_gasolinera
	   and c.conductor = fe.identificador
UNION
    SELECT
        mo.descripcion,
        mo.fecha_solicitud,
        mo.kilometraje_final,
        array_to_string(ARRAY(
            SELECT
                r.localizacion
            FROM
                g_transportes.rutas r
            WHERE
                mo.placa = _placa and r.id_movilizacion = mo.id_movilizacion ),', '),
	mo.id_movilizacion, 
		array_to_string(ARRAY(
	    SELECT
		g_uath.cambia_formato_nombre(fe.nombre,fe.apellido) AS nombres_completos
	    FROM
		g_transportes.ocupantes o, g_uath.ficha_empleado fe
	    WHERE mo.placa = _placa and o.id_movilizacion = mo.id_movilizacion and o.identificador = fe.identificador
		),', '),
	mo.kilometraje_inicial,
	mo.tipo_movilizacion,
	g_uath.cambia_formato_nombre(fe.nombre,fe.apellido) AS nombres_completos,
	'Movilización'
      FROM
        g_transportes.movilizaciones mo,
        g_uath.ficha_empleado fe
      WHERE mo.placa = _placa
      and mo.conductor = fe.identificador
UNION
     SELECT 
	ma.motivo, 
	ma.fecha_solicitud, 
	ma.kilometraje, 
	t.nombre, 
	to_char(ma.valor_liquidacion,'FM999999.90'), 
	ma.numero_factura,
	ma.estado,
	ma.numero_factura,
	g_uath.cambia_formato_nombre(fe.nombre,fe.apellido) AS nombres_completos,
	'Mantenimiento'
      FROM
        g_transportes.mantenimientos ma, 
        g_transportes.talleres t,
         g_uath.ficha_empleado fe
      WHERE ma.placa = _placa 
	and ma.taller = t.id_taller
	and ma.conductor = fe.identificador
UNION
     SELECT 
	s.tipo_siniestro, 
	s.fecha_siniestro, 
	s.estado, 
	s.magnitud_danio_siniestro, 
	to_char(s.estado,'FM999999'), 
	g_uath.cambia_formato_nombre(fe.nombre,fe.apellido) AS nombres_completos,
	s.estado,
	s.lugar_siniestro,
	s.observacion_siniestro,	
	'Siniestro'
      FROM
        g_transportes.siniestros s, 
        g_uath.ficha_empleado fe
      WHERE s.placa = _placa 
	and s.conductor = fe.identificador
order by
fecha desc)
LOOP
return next cont;
END LOOP;
RETURN;			
END;
$$;

alter function historial_vehiculo(text) owner to postgres;

