create function funcion_insertar_log_detalle_catastros(_id_detalle_catastro integer, _id_catastro integer, _identificador_producto character varying, _secuencial integer, _identificador_unico_producto character varying, _estado_registro character varying, _observacion character varying) returns void
    language plpgsql
as
$$
BEGIN
	INSERT INTO g_catastro.log_detalle_catastros(id_detalle_catastro, id_catastro, identificador_producto, secuencial, identificador_unico_producto, estado_registro, observacion)
		VALUES (_id_detalle_catastro, _id_catastro, _identificador_producto, _secuencial, _identificador_unico_producto, _estado_registro, _observacion);

	DELETE FROM g_catastro.detalle_catastros WHERE id_detalle_catastro = _id_detalle_catastro;
END;
$$;

alter function funcion_insertar_log_detalle_catastros(integer, integer, varchar, integer, varchar, varchar, varchar) owner to postgres;

