create function quitar_parentesis(character varying) returns text
    language sql
as
$$
SELECT TRANSLATE
($1,
'()',
'');
$$;

alter function quitar_parentesis(varchar) owner to postgres;

