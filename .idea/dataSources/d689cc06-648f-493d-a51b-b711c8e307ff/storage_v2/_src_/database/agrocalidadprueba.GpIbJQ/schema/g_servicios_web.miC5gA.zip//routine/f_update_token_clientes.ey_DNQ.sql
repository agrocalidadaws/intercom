create function f_update_token_clientes(OUT identificador character varying, OUT token character varying, OUT correo character varying) returns SETOF record
    language plpgsql
as
$$

/*
-------------------------------------------------------------------------
--  [g_servicios_web.f_update_token_clientes]
--               
--  Esta funcion se encarga actualizar los token en los clientes que consumiran servicios web
--
--  VERSION		AUTOR					FECHA			HU			                           CAMBIO
--	1			Kleber Armijos		01-06-2023			Servicio Web PestDisplace              
-------------------------------------------------------------------------
*/
DECLARE
r_temporal record;
BEGIN

 CREATE  TABLE temp_usuario_update_token as( 
		 SELECT * from g_servicios_web.usuarios 
		WHERE tiempo_renovacion_token= (now()::DATE -fecha_actualizacion_token::DATE)
	 );
	  FOR r_temporal IN SELECT * FROM temp_usuario_update_token
	  LOOP
		UPDATE g_servicios_web.usuarios ws_user
		SET token=(SELECT uuid_generate_v4()),
			fecha_actualizacion_token=now()
		where ws_user.id_usuario=r_temporal.id_usuario;
	  END LOOP;
	  
 	 
		

	

return QUERY SELECT 
 	 user_web.identificador,
 	 user_web.token, 
 	 user_web.correo 
 		FROM g_servicios_web.usuarios user_web
 		INNER JOIN temp_usuario_update_token temp_token
 		ON temp_token.id_usuario=user_web.id_usuario;

 DROP table temp_usuario_update_token;
END;
$$;

alter function f_update_token_clientes(out varchar, out varchar, out varchar) owner to postgres;

