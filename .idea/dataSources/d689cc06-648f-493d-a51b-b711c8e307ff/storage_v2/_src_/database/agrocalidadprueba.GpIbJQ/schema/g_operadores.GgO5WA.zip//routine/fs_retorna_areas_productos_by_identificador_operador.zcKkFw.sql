create function fs_retorna_areas_productos_by_identificador_operador(pid_tipo_operacion integer, pidentificador_operador character varying) returns SETOF json
    language plpgsql
as
$$
BEGIN
		CREATE TABLE consultas_tmp1 AS(  
		 SELECT
		 DISTINCT on (a3.id_area) 	
			 a3.id_area  
			,a3.nombre_area  
			,a3.tipo_area  
			,a3.superficie_utilizada 
			,a3.ruta_archivo 
			,a3.id_sitio id_sitio_en_area 
			,a3.observacion observacion_en_area
			,a3.estado    estado_en_area
			,a3.secuencial 
			,a3.codigo_transaccional
			,a3.codigo codigo_area
			,s3.*
		   ,s3.codigo codigo_sitio
		   ,aop.unidad_medida

		 FROM
		   g_operadores.operaciones opc3
		 , g_operadores.productos_areas_operacion pao3
		 , g_operadores.areas a3
		 , g_operadores.sitios s3
		 , g_catalogos.areas_operacion aop
		 WHERE
		 s3.id_sitio = a3.id_sitio
		 AND opc3.id_operacion = pao3.id_operacion
		 AND pao3.id_area = a3.id_area
		 AND a3.tipo_area = aop.nombre
		 AND opc3.id_tipo_operacion = $1	
		 AND opc3.identificador_operador = $2
		 ORDER BY 
		 a3.id_area
	  );
	  
	  CREATE TABLE consultas_tmp AS  (       
				SELECT
				  p.*
				 ,pao.estado estado_area
				 , opr.id_operacion
				 , opr.estado estado_operacion
				 , to_char(opr.fecha_creacion,'DD-MM-YYYY (HH24:MI)') AS fecha_creacion_opr
				 , sp.nombre AS subtipo
				 , tp.nombre AS tipo
				 , tp.id_area AS area
				 , COALESCE(opr.nombre_pais,'N/A')
	   			, pao.id_area
				FROM
				 g_operadores.productos_areas_operacion pao 
	            INNER JOIN g_operadores.operaciones opr 	   
	            ON pao.id_operacion = opr.id_operacion
	            INNER JOIN consultas_tmp1 c_temp
	            ON  pao.id_area =c_temp.id_area
				LEFT JOIN  g_catalogos.productos p 
	            ON  opr.id_producto = p.id_producto
				LEFT JOIN g_catalogos.subtipo_productos sp  
	            ON  p.id_subtipo_producto = sp.id_subtipo_producto
				LEFT JOIN g_catalogos.tipo_productos tp 
	            ON sp.id_tipo_producto = tp.id_tipo_producto
				WHERE
				opr.id_tipo_operacion = $1		
				AND pao.id_area = c_temp.id_area
		);


return QUERY SELECT array_to_json(ARRAY_AGG (row_to_json(areas))) AS areas
		FROM(
		  SELECT ar.* , 
		  (SELECT json_agg(productos_n4)
		  FROM (
			SELECT * FROM consultas_tmp WHERE id_area = ar.id_area
		  ) productos_n4
		) AS Productos
		FROM consultas_tmp1 AS ar) areas;

		DROP TABLE  consultas_tmp;
		DROP TABLE  consultas_tmp1;

END;$$;

alter function fs_retorna_areas_productos_by_identificador_operador(integer, varchar) owner to postgres;

