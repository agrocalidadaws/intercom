create function migracion_catastro_vigente() returns integer
    language plpgsql
as
$$
DECLARE contador INTEGER:=0;
DECLARE wid_catastro INTEGER:=0;
DECLARE identificadorreg record;
DECLARE devuelto record;
BEGIN
-- sacar todos los identificadores vigentes

				
-- sacar todos los identificadores en log_detalle_catastro 
-- 0. Sacar indentificadores del log_detalle_catastro que han sido eliminados por pasar 425 días posteriores a la fecha de nacimiento
CREATE TEMP TABLE tmp_vigentes (tidentificador character varying(32), tid_catastro integer, tvigente integer); -- ON COMMIT DROP;
INSERT INTO tmp_vigentes (SELECT case when ldc.identificador_producto is null then  ldc.identificador_unico_producto 
							else ldc.identificador_producto 
							end identificador_producto,
							c.id_catastro, 0
							FROM g_catastro.catastros c, g_catastro.log_detalle_catastros ldc 
							WHERE c.id_catastro = ldc.id_catastro
							and to_char(c.fecha_nacimiento,'YYYY-MM-DD')::date < (current_date - interval '245 days') ); 



-- 1. Hacer update con 1 a los que tienen vacunación vigente

UPDATE tmp_vigentes set tvigente = 1
where tidentificador in (select di.identificador 
						from tmp_vigentes tv, g_vacunacion.detalle_identificadores di, g_vacunacion.detalle_vacunacion dv, g_vacunacion.vacunacion v
						where tv.tidentificador = di.identificador
						and dv.id_detalle_vacunacion = di.id_detalle_vacunacion
						and v.id_vacunacion = dv.id_vacunacion
						and v.estado = 'vigente');

UPDATE tmp_vigentes set tvigente = 2
where tidentificador in (select di.identificador 
						from tmp_vigentes tv, g_vacunacion.detalle_identificadores di, g_vacunacion.detalle_vacunacion dv, g_vacunacion.vacunacion v
						where tv.tidentificador = di.identificador
						and dv.id_detalle_vacunacion = di.id_detalle_vacunacion
						and v.id_vacunacion = dv.id_vacunacion
						and v.estado = 'caducado');


-- 1 VIGENTE / 2 CADUCADO
						
-- 2. Elimino los que no estan vigentes
DELETE from  tmp_vigentes
where tvigente = 0;
								
-- 3. Paso al catastro mas actual

CREATE TEMP TABLE tmp_depurado (tdidentificador character varying(32), tbandera integer, tdid_catastro integer ); --ON COMMIT DROP;
INSERT INTO tmp_depurado (select tv.tidentificador, tv.tvigente, matv.tid_catastro
							from tmp_vigentes tv				
							GROUP BY  tv.tidentificador, tv.tvigente);

							
-- ELIMINAR LOS QUE SE HAN SUPERADO 425 posteriore s la fecha de vacunacion
/*delete from tmp_depurado td
where td.tdidentificador in (select distinct(tv1.tdidentificador) 
							from tmpd_depurado tv1 
							inner join g_vacunacion.detalle_identificadores di on di.identificador = tv1.tdidentificador
							inner join g_vacunacion.detalle_vacunacion dv on dv.id_detalle_vacunacion = di.id_detalle_vacunacion
							inner join g_vacunacion.vacunacion v on v.id_vacunacion = dv.id_vacunacion
							where to_char(v.fecha_vacunacion, 'YYYYMMDD')::date + interval '425 days' > current_date);*/

/*
update tmp_depurado 
set td_nombresitio = os.nombre_lugar,
td_nombreoperador = o.razon_social
from  g_operadores.sitios os inner join g_operadores.operadores o
on os.identificador_operador = o.identificador
where tdid_sitio = os.id_sitio;
*/



--3. Actualizo el catastro mas actual
--4. De acuerdo al depurado y al id_catastro inserto en detalle_catastro
/*
INSERT INTO g_catastro.detalle_catastros(
            id_detalle_catastro, id_catastro, identificador_producto, secuencial, 
            identificador_unico_producto, estado_registro, observacion, fecha_actualizacion)
	(select id_detalle_catastro, id_catastro, identificador_producto, secuencial, identificador_unico_producto, estado_registro, observacion, fecha_actualizacion
	from g_catastro.g_catastro.log_detalle_catastros ldc inner join tmp_depurado  td
	on ldc.id_catastro = td.tdid_catastro 
	where ldc.identificador_producto = td.tdidentificador);
*/


--3. De acuerdo al depurado elimino el id_catastro log_detalle_catastro

--4. De acuerdo al id_catastro elimino del log_detalle_Catastro	

/*
FOR devuelto IN (select  tdidentificador,matdid_catastro) as catastro, tdid_sitio, td_nombresitio, td_nombreoperador  from tmp_depurado group by tdidentificador,tdid_sitio, td_nombresitio, td_nombreoperador)
LOOP
	RAISE NOTICE '% % % % % %', devuelto.tdidentificador, devuelto.tdid_sitio, devuelto.catastro, devuelto.td_nombresitio,';', devuelto.td_nombreoperador;
END LOOP;*/
/*
FOR devuelto IN (select tv.tidentificador, tv.tvigente, matv.tid_catastro) as catastro
				from
				tmp_vigentes tv				
				GROUP BY  tv.tidentificador, tv.tvigente)
LOOP
	RAISE NOTICE '% % %', devuelto.tidentificador, devuelto.tvigente, devuelto.catastro;
END LOOP;*/

--select count into contador from tmp_vigentes;
RETURN contador;

    
  END;
$$;

alter function migracion_catastro_vigente() owner to postgres;

