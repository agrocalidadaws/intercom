create function mostrar_poa_filtrados(_subproceso integer, _asunto text, _fecha_inicio timestamp without time zone, _fecha_fin timestamp without time zone, _estado integer) returns SETOF g_poa.planta
    language plpgsql
as
$$
DECLARE
	query text;
BEGIN	
	return query EXECUTE '	
		SELECT
			*
		FROM 
			g_poa.planta
		WHERE 
		        ($1 is NULL or id_subproceso = $1) and 
			($2 is NULL or codigo_actividad like $2) and 
			($3 is NULL or estado = $3) and 
			($4 is NULL or fecha_creacion >= $4) and 
			($5 is NULL or fecha_creacion <= $5) 
			
		ORDER BY
			fecha_creacion'
		using _subproceso,_asunto,_estado,_fecha_inicio,_fecha_fin;
	
END;
$$;

alter function mostrar_poa_filtrados(integer, text, timestamp, timestamp, integer) owner to postgres;

