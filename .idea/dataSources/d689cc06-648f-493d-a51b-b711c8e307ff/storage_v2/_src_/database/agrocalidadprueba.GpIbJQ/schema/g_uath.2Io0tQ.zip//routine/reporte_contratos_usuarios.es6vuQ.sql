create function reporte_contratos_usuarios(_regimen_laboral text, _tipo_contrato text, _presupuesto text, _fuente integer, _nombre_puesto text, _grupo_ocupacional text, _remuneracion real, _provincia text, _canton text, _oficina text, _direccion text, _coordinacion text, _anio text, _mes text, _estado integer, _anio_salida text, _mes_salida text) returns SETOF g_uath.vista_contrato_empleado
    language plpgsql
as
$$
DECLARE
	query text;
BEGIN	
	return query EXECUTE 'SELECT
			*
		FROM 
			g_uath.vista_contrato_empleado
		WHERE 
		        
			($1 is NULL or regimen_laboral = $1) and 
			($2 is NULL or tipo_contrato = $2) and 
			($3 is NULL or presupuesto = $3) and
			($4 is NULL or fuente = $4) and
			($5 is NULL or nombre_puesto = $5) and
			($6 is NULL or grupo_ocupacional = $6) and
			($7 is NULL or remuneracion = $7) and
			($8 is NULL or provincia = $8) and
			($9 is NULL or canton = $9) and 
			($10 is NULL or oficina = $10) and 
			($11 is NULL or direccion = $11) and 
			($12 is NULL or coordinacion = $12) and 
			($13 is NULL or CAST(extract(year from fecha_fin) AS TEXT) like $13) and 
			($14 is NULL or CAST(extract(month from fecha_fin) AS TEXT) like $14) and  
			($15 is NULL or estado = $15) and
			($16 is NULL or CAST(extract(year from fecha_salida) AS TEXT) like $16) and
			($17 is NULL or CAST(extract(month from fecha_salida) AS TEXT) like $17)' 
		using _regimen_laboral,_tipo_contrato,_presupuesto,_fuente,_nombre_puesto,_grupo_ocupacional,_remuneracion,_provincia,_canton,_oficina,_direccion,_coordinacion,
		_anio,_mes,_estado,_anio_salida, _mes_salida;
	
END;
$$;

alter function reporte_contratos_usuarios(text, text, text, integer, text, text, real, text, text, text, text, text, text, text, integer, text, text) owner to postgres;

