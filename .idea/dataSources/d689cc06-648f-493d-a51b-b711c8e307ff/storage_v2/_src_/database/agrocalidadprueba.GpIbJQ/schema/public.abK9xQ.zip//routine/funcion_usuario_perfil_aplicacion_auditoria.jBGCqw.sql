create function funcion_usuario_perfil_aplicacion_auditoria() returns trigger
    language plpgsql
as
$$ 

BEGIN
	IF(TG_RELNAME = 'usuarios_perfiles') THEN

		IF (TG_OP = 'INSERT') THEN
			INSERT INTO g_auditoria.usuarios_perfiles_aplicaciones(identificador, id_tabla, accion, origen) VALUES (NEW.identificador, NEW.id_perfil, TG_OP, TG_RELNAME);
		ELSIF (TG_OP = 'UPDATE') THEN
			INSERT INTO g_auditoria.usuarios_perfiles_aplicaciones(identificador, id_tabla, accion, origen) VALUES (OLD.identificador, OLD.id_perfil, TG_OP||'-ANTERIOR'::text, TG_RELNAME);
			INSERT INTO g_auditoria.usuarios_perfiles_aplicaciones(identificador, id_tabla, accion, origen) VALUES (NEW.identificador, NEW.id_perfil, TG_OP||'-NUEVO'::text, TG_RELNAME);
		ELSE
			INSERT INTO g_auditoria.usuarios_perfiles_aplicaciones(identificador, id_tabla, accion, origen) VALUES (OLD.identificador, OLD.id_perfil, TG_OP, TG_RELNAME);
		END IF;	
		
	ELSE

		IF (TG_OP = 'INSERT') THEN
			INSERT INTO g_auditoria.usuarios_perfiles_aplicaciones(identificador, id_tabla, accion, origen) VALUES (NEW.identificador, NEW.id_aplicacion, TG_OP, TG_RELNAME);
		ELSIF (TG_OP = 'UPDATE') THEN
			INSERT INTO g_auditoria.usuarios_perfiles_aplicaciones(identificador, id_tabla, accion, origen) VALUES (OLD.identificador, OLD.id_aplicacion, TG_OP||'-ANTERIOR'::text, TG_RELNAME);
			INSERT INTO g_auditoria.usuarios_perfiles_aplicaciones(identificador, id_tabla, accion, origen) VALUES (NEW.identificador, NEW.id_aplicacion, TG_OP||'-NUEVO'::text, TG_RELNAME);
		ELSE
			INSERT INTO g_auditoria.usuarios_perfiles_aplicaciones(identificador, id_tabla, accion, origen) VALUES (OLD.identificador, OLD.id_aplicacion, TG_OP, TG_RELNAME);
		END IF;	
	
	END IF;
	
	RETURN NEW;
	END; 
	
$$;

alter function funcion_usuario_perfil_aplicacion_auditoria() owner to postgres;

