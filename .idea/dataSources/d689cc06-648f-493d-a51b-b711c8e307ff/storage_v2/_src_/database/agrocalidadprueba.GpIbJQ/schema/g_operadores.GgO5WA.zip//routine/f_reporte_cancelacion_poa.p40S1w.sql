create function f_reporte_cancelacion_poa()
    returns TABLE(id_cancelar integer, razon_social character varying, identificador character varying, nombre_representante text, provincia character varying, canton character varying, direccion character varying, codigo_poa character varying, subcodigo_poa character varying, motivo character varying, tipo_actividad character varying, agencia text, numero_productores bigint, estatus text, superficie numeric, fecha_creacion text)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
   SELECT
        capo.id_cancelar,
        o.razon_social,
        o.identificador,
        o.nombre_representante || ' ' ||  o.apellido_representante as nombre_representante,
        o.provincia,
        o.canton,
        o.direccion,
        copo.codigo_poa,
        supo.subcodigo_poa,
        capo.motivo,
        o.tipo_actividad,
        da.agencia,
        productores.numero_productores,
        da.estatus,
        super.superficie,
		TO_CHAR(capo.fecha_creacion, 'YYYY-MM-DD HH24:MI:SS') AS fecha_creacion
    FROM
    g_operadores.cancelar_poa AS capo
    INNER JOIN g_operadores.operadores AS o ON capo.identificador_operador = o.identificador
    INNER JOIN g_operadores.codigos_poa AS copo ON capo.id_codigo_poa = copo.id_codigo_poa
    INNER JOIN g_operadores.cancelar_poa_subcodigos AS caposu ON capo.id_cancelar = caposu.id_cancelar
    INNER JOIN g_operadores.subcodigos_poa AS supo ON caposu.id_subcodigo_poa = supo.id_subcodigo_poa
    LEFT JOIN (SELECT
                op.identificador_operador,
                op.id_tipo_operacion,        
                 COUNT(DISTINCT ma.identificador_miembro_asociacion) AS numero_productores
                  FROM
                    g_operadores.operaciones op
                    INNER JOIN g_operadores.miembros_asociacion ma ON ma.identificador_asociacion = op.identificador_operador
                    INNER JOIN g_operadores.detalle_miembros_asociacion dma ON ma.id_miembro_asociacion = dma.id_miembro_asociacion AND dma.id_operacion = op.id_operacion
                  WHERE
                    op.estado = 'noHabilitado'
                    GROUP BY op.identificador_operador, op.id_tipo_operacion) AS productores ON productores.identificador_operador = o.identificador AND productores.id_tipo_operacion = supo.id_tipo_operacion
    LEFT JOIN (SELECT
                op.identificador_operador,
                op.id_tipo_operacion,
                (SELECT rtrim(array_to_string(array_agg(DISTINCT ac.nombre_agencia_certificadora), ', '), ', ')) AS agencia,
                 string_agg(DISTINCT tt.nombre_tipo_transicion, ',') AS estatus
                  FROM
                    g_operadores.operaciones op
                    INNER JOIN g_operadores.operaciones_organico oo ON op.id_operacion = oo.id_operacion
                    INNER JOIN g_catalogos.tipo_transicion tt ON oo.id_tipo_transicion = tt.id_tipo_transicion
                    INNER JOIN g_catalogos.agencia_certificadora ac ON oo.id_agencia_certificadora = ac.id_agencia_certificadora
                  WHERE
                    op.estado = 'noHabilitado'
                    GROUP BY op.identificador_operador, op.id_tipo_operacion) AS da ON da.identificador_operador = o.identificador AND da.id_tipo_operacion = supo.id_tipo_operacion
    LEFT JOIN (SELECT
                op.identificador_operador,
                op.id_tipo_operacion,
                SUM(dma.superficie_miembro::DECIMAL) AS superficie
                  FROM
                    g_operadores.operaciones op
                    INNER JOIN g_operadores.miembros_asociacion ma ON ma.identificador_asociacion = op.identificador_operador
                    INNER JOIN g_operadores.detalle_miembros_asociacion dma ON ma.id_miembro_asociacion = dma.id_miembro_asociacion AND dma.id_operacion = op.id_operacion
                  WHERE
                    op.estado = 'noHabilitado'
                    GROUP BY op.identificador_operador, op.id_tipo_operacion) AS super ON super.identificador_operador = o.identificador AND super.id_tipo_operacion = supo.id_tipo_operacion
    GROUP BY capo.id_cancelar, o.identificador,copo.codigo_poa, supo.subcodigo_poa, da.agencia, productores.numero_productores, da.estatus, super.superficie
    ORDER BY o.razon_social, capo.id_cancelar ASC;
END;
$$;

alter function f_reporte_cancelacion_poa() owner to postgres;

