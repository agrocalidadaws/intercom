create function mostrar_movilizacion_individual(_placa text, _fecha_inicio date, _fecha_fin date, _localizacion text) returns SETOF g_transportes.movilizacion_individual
    language plpgsql
as
$$
DECLARE
	query text;
BEGIN	
	return query EXECUTE '
			SELECT 
				COUNT(id_movilizacion) numero,
				v.placa,
				v.modelo,
				v.marca,
				v.localizacion
			FROM
				g_transportes.movilizaciones m,
				g_transportes.vehiculos v 
			WHERE
				m.placa = v.placa and
				m.placa like $1 and
				($2 is NULL or  m.fecha_solicitud >= $2) and 
				($3 is NULL or  m.fecha_solicitud <= $3) and
				($4 is NULL or $4 = v.localizacion) and
				m.estado = 4
			GROUP BY 
				v.placa,
				v.modelo,
				v.marca,
				v.localizacion'
			
		using _placa,_fecha_inicio,_fecha_fin,_localizacion;
	
END;
$$;

alter function mostrar_movilizacion_individual(text, date, date, text) owner to postgres;

