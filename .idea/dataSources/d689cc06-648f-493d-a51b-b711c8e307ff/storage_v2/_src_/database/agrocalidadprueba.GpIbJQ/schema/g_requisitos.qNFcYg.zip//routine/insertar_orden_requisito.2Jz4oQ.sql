create function insertar_orden_requisito() returns trigger
    language plpgsql
as
$$ 

BEGIN
	NEW.orden = public.calcular_orden_siguiente('g_requisitos.requisitos_asignados', 'id_requisito_comercio', NEW.id_requisito_comercio);

	RETURN NEW;
	END; 
	
$$;

alter function insertar_orden_requisito() owner to postgres;

