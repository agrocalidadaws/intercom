create function funcion_insertar_auditoria_tipo_inspector(_id_tipo_inspector integer, _resultado character varying, _tipo_inspector character varying, _observacion character varying, _identificador_registro character varying) returns void
    language plpgsql
as
$$
BEGIN
	INSERT INTO g_centros_faenamiento.auditoria_tipo_inspector(id_tipo_inspector, resultado, tipo_inspector, observacion, identificador_registro)
		VALUES (_id_tipo_inspector, _resultado, _tipo_inspector, _observacion, _identificador_registro); 
		
END;
$$;

alter function funcion_insertar_auditoria_tipo_inspector(integer, varchar, varchar, varchar, varchar) owner to postgres;

