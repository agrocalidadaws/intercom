create function registarlogregistrooperadormasivo(text, text, integer, text, integer, text) returns void
    language plpgsql
as
$$

DECLARE _maximo integer;
DECLARE _accion text;

BEGIN

_maximo:= (SELECT max(id_log_registro_operador) FROM g_operadores.log_registro_operador WHERE identificador_operador = $2);

IF(_maximo is null) THEN
_accion = 'crear';
ELSE
_accion = 'modificar';
END IF;

INSERT INTO g_operadores.log_registro_operador(identificador_usuario, identificador_operador, id_sitio, id_area, id_tipo_operacion, id_producto, accion) VALUES ($1, $2, $3, $4, $5, $6, _accion);   

END       
$$;

alter function registarlogregistrooperadormasivo(text, text, integer, text, integer, text) owner to postgres;

