create function detalle_total_factura(_orden integer) returns SETOF g_financiero.detalle_factura
    language plpgsql
as
$$
DECLARE
	query text;
BEGIN	
	return query EXECUTE '
		SELECT
			distinct (id_pago),
			(select sum(total)::numeric(12,2)  from g_financiero.detalle_pago where id_pago  = $1 and iva = 0) as total_sin_iva, 
			(select sum(total)::numeric(12,2) - sum(iva)::numeric(12,2) from g_financiero.detalle_pago where id_pago  = $1 and iva != 0) as total_con_iva,
			(select sum(iva)::numeric(12,2)  from g_financiero.detalle_pago where id_pago  = $1) as suma_iva, 
			(select sum(descuento)::numeric(12,2)  from g_financiero.detalle_pago where id_pago  = $1 and iva = 0) as descuento_sin_iva,
			(select sum(descuento)::numeric(12,2)  from g_financiero.detalle_pago where id_pago  = $1 and iva != 0) as descuento_con_iva,
			(select sum(subsidio)::numeric(12,2)  from g_financiero.detalle_pago where id_pago  = $1) as subsidio
		FROM

			g_financiero.detalle_pago d	
			
		WHERE
			d.id_pago = $1'
			
		using _orden;
			
END;
$$;

alter function detalle_total_factura(integer) owner to postgres;

