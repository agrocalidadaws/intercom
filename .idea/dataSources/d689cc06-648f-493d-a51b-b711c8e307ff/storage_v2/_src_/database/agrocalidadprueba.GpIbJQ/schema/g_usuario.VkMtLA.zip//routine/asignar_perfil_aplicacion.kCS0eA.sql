create function asignar_perfil_aplicacion(_identificador text, _id_perfil integer) returns void
    language plpgsql
as
$$
DECLARE
cont record;
BEGIN
			
	INSERT INTO g_usuario.usuarios_perfiles(identificador, id_perfil)
		SELECT _identificador, _id_perfil 
		WHERE NOT EXISTS 
			(SELECT identificador, id_perfil FROM g_usuario.usuarios_perfiles WHERE identificador=_identificador and id_perfil = _id_perfil);
			
FOR cont IN (SELECT DISTINCT a.id_aplicacion,  pp.id_perfil
		FROM g_programas.aplicaciones a inner join g_programas.acciones ac on a.id_aplicacion=ac.id_aplicacion
		inner join g_programas.acciones_perfiles ap on ap.id_accion=ac.id_accion
		inner join g_usuario.perfiles pp on pp.id_perfil=ap.id_perfil
		where pp.id_perfil = _id_perfil)
	LOOP
	IF (cont.id_aplicacion <> 0 and cont.id_aplicacion <> 3) THEN
		INSERT INTO g_programas.aplicaciones_registradas (id_aplicacion,identificador,cantidad_notificacion,mensaje_notificacion) 
		SELECT cont.id_aplicacion,_identificador,0,'notificaciones'
		WHERE NOT EXISTS 
			(SELECT id_aplicacion,identificador FROM g_programas.aplicaciones_registradas WHERE identificador = _identificador and id_aplicacion=cont.id_aplicacion);
	END IF;
	END LOOP;
	RETURN;
	
END;
$$;

alter function asignar_perfil_aplicacion(text, integer) owner to postgres;

