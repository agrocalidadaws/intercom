create function proceso_guardarmovilizacion(cabecera text[], identificador text[], aredestino text[], dobleguia text, generaticket text) returns text
    language plpgsql
as
$$

-- TRABAJO
DECLARE contador INTEGER := 0;
DECLARE identificadorreg record;
DECLARE identificadorcat record;
DECLARE tproductoreg record;
DECLARE cabeceramovilizacion  INTEGER := 0;
DECLARE cabeceramovilizacion2  INTEGER := 0;
DECLARE cabeceramovilizaciondobleguia  INTEGER := 0;
DECLARE detallemovilizacion  INTEGER := 0;
DECLARE productoticket boolean := false;
DECLARE idproductomadre integer := 0;
DECLARE idproductolechon integer := 0;
DECLARE idproductolechona integer := 0;
DECLARE banderamadre boolean := false;
DECLARE cantidadreproduccion integer :=0;
DECLARE nuevocatastro integer := 0;

BEGIN

/*
if generaticket then
	if exists (SELECT es.codigo FROM 
		    g_catalogos.productos_animales pa, 
		    g_catalogos.especies_ticket_movilizacion es
		    WHERE es.id_especie = pa.id_especie and 
		    es.estado_ticket = TRUE and
		    es.codigo = 'PORCI') THEN
	   productoticket = true;
	END IF;
end if;
*/

IF cabecera[17] = '' THEN 
cabecera[17] = null;
END IF;

--//Obtenemos el id del producto cerda madre
			
SELECT id_producto 
INTO idproductomadre
FROM g_catalogos.productos_animales pa 
WHERE pa.codigo = 'PORDRE' and pa.estado_producto = 'activo';

--//Obtenemos el id del producto lechon

SELECT id_producto 
INTO idproductolechon
FROM g_catalogos.productos_animales pa 
WHERE pa.codigo = 'PORHON' and pa.estado_producto = 'activo';
	
--//Obtenemos el id del producto lechona

SELECT id_producto 
INTO idproductolechona
FROM g_catalogos.productos_animales pa 
WHERE pa.codigo = 'PORONA' and pa.estado_producto = 'activo';

-- GUARDO EN TABLA TEMPORAL LOS IDENTIFICADORES
CREATE TEMP TABLE tmp_identificadores (tidentificador text, tarea_origen integer, tarea_destino integer, tproducto integer, tcantidad integer, tnumero_lote text, 
                                       tunidad_comercial integer, ttipo_operacion_origen integer,ttipo_operacion_destino integer, tidcatastro integer,
                                       tidentificador_producto text, tidentificadorunicoproducto text, testado text) ON COMMIT DROP;
   INSERT INTO tmp_identificadores SELECT unnest(identificador::text[]),0, unnest(aredestino::integer[]),0,0,'0',34,0,0,0;
   --CREA TABLA TEMPORAL PARA CATASTROS
   
	CREATE TEMP TABLE tmp_catastros (tid_catastro integer, tid_sitio integer, tid_area integer, tid_producto integer, tcantidad double precision, tfecha_registro timestamp without time zone, 
					tidentificador_responsable text, tunidad_medida_peso text, tfecha_modificacion_etapa timestamp without time zone, 
					tnombre_producto text, peso double precision, tid_especie integer, tfecha_nacimiento timestamp without time zone, 
					tnumero_lote text, testado_etapa text, tid_tipo_operacion integer, 
					tunidad_comercial integer, tnumero_actualizacion_cupo integer) ON COMMIT DROP;
	-- DROP TABLE tmp_catastros

	---CREAMOS UN TABLA TEMPORAL PARA CONTROL DE REPRODUCCION 
	CREATE TEMP TABLE tmp_controlreproduccion (tidentificador_operador_origen text, tidentificador_operador_destino text, 
						tcupocriadestino integer, tcantidadcriadestino integer, tmadresdestino integer, tlechonesdestino integer, tnuevocupocriadestino integer, tnuevocantidadcriadestino integer,
						tcupocriaorigen integer, tcantidadcriaorigen integer, tmadresorigen integer, tlechonesorigen integer, tnuevocupocriaorigen integer,
						tnuevocantidadcriaorigen integer) ON COMMIT DROP;
					--

   INSERT INTO tmp_controlreproduccion (tidentificador_operador_origen, tidentificador_operador_destino) values (cabecera[22], cabecera[26]);



-- NECESITO DATOS DE ORIGEN: AREA, PRODUCTO, ID_CATASTRO ACTUAL DEL IDENTIFICADOR


   update tmp_identificadores ti set
     tarea_origen = c.id_area, 
     tproducto = c.id_producto,
     tidcatastro = c.id_catastro 
   from g_catastro.detalle_catastros dc inner join g_catastro.catastros c
        on c.id_catastro = dc.id_catastro
   where dc.estado_registro in ('activo', 'temporal')
   and (ti.tidentificador = dc.identificador_producto
   or ti.tidentificador = dc.identificador_unico_producto);

-- LLENA TABLA CATASTRO



   INSERT INTO tmp_catastros SELECT id_catastro, id_sitio, id_area, id_producto, cantidad, fecha_registro, 
       identificador_responsable, unidad_medida_peso, fecha_modificacion_etapa, 
       nombre_producto, peso, id_especie, fecha_nacimiento, numero_lote, 
       estado_etapa, id_tipo_operacion, unidad_comercial, numero_actualizacion_cupo
	FROM g_catastro.catastros WHERE id_catastro in (SELECT tidcatastro FROM tmp_identificadores);



-- TOMANDO EN CUANTA QUE EN SA NO SE COMPARTAN AREAS se completan los tipos_operaciones
   FOR identificadorreg in (SELECT tarea_origen, tarea_destino from tmp_identificadores)
   LOOP
     update tmp_identificadores ti set
     ttipo_operacion_origen = o.id_tipo_operacion
     from g_operadores.productos_areas_operacion pao inner join g_operadores.operaciones o 
     on o.id_operacion = pao.id_operacion
     where pao.id_area = identificadorreg.tarea_origen;
   
     update tmp_identificadores ti set
     ttipo_operacion_destino = o.id_tipo_operacion
     from g_operadores.productos_areas_operacion pao inner join g_operadores.operaciones o 
     on o.id_operacion = pao.id_operacion
     where pao.id_area = identificadorreg.tarea_destino;
      
   END LOOP;

-- COMPELTAMOS NUMEROS DE IDENTIFICACION
update tmp_identificadores ti set  
tidentificador_producto = dc.identificador_producto,
tidentificadorunicoproducto = dc.identificador_unico_producto,
testado = estado_registro
FROM g_catastro.detalle_catastros dc
WHERE dc.id_catastro = ti.tidcatastro 
and 
  case when dc.identificador_producto is null 
       then  dc.identificador_unico_producto 
       else dc.identificador_producto 
  end = ti.tidentificador;

	    

--VERICAMOS SI SE MOVILIZA UN ACERDA MADRE
IF EXISTS (select tproducto FROM tmp_identificadores WHERE tproducto = idproductomadre) THEN

banderamadre = true;

END IF;


-- VALIDAR SI LOS IDENTIFICADORES NO HAN SIDO ANTES MOVILIZADOS
IF  EXISTS (SELECT dc.identificador_producto, dc.identificador_unico_producto, dc.estado_registro
			FROM g_catastro.detalle_catastros dc WHERE dc.estado_registro in ('activo', 'temporal')
			and dc.id_catastro in (select distinct(tidcatastro) from tmp_identificadores)
			and dc.identificador_producto in (select distinct(tidentificador) from tmp_identificadores)
			or dc.identificador_unico_producto in (select distinct(tidentificador) from tmp_identificadores)) THEN


	-- GUARDA CABECERA //g_movilizacion_producto.movilizacion
	INSERT INTO g_movilizacion_producto.movilizacion 
	          (numero_certificado, provincia_emision, sitio_origen, sitio_destino, placa_transporte, identificador_conductor, 
	          usuario_responsable, estado, ruta_certificado, fecha_registro, fecha_inicio_vigencia, fecha_fin_vigencia, 
	          codigo_provincia_origen, codigo_provincia_destino, secuencial, nombre_conductor, medio_transporte, tipo_solicitud, 
	          observacion, ruta_ticket, oficina_emision, identificador_solicitante, cantidad_total, estado_fiscalizacion)
	  values (cabecera[1], cabecera[2], cabecera[3]::integer, cabecera[4]::integer, cabecera[5], cabecera[6], 
		  cabecera[7], cabecera[8], cabecera[9], cabecera[10]::timestamp, cabecera[11]::timestamp, cabecera[12]::timestamp, 
		  cabecera[13], cabecera[14], cabecera[15], cabecera[16], cabecera[17]::integer, cabecera[18], 
		  cabecera[19], cabecera[20], cabecera[21], cabecera[22], cabecera[23]::integer, cabecera[24]);

	-- RECUPERA ULTIMO REGISTRO GUARDADO
	 select id_movilizacion INTO cabeceramovilizacion from g_movilizacion_producto.movilizacion order by id_movilizacion desc limit 1;

	-- GUARDA DETALLE_MOVILIZACION
	-- SUMAR TODOS LOS PRODUCTOS QUE TENGAN EL MISMO AREA ORIGEN Y MISMA AREA DESTINO

	

	FOR identificadorreg in (select count(tproducto) as tcuenta, tarea_origen, tarea_destino, tproducto, ttipo_operacion_origen, ttipo_operacion_destino 
				 from  tmp_identificadores group by tproducto, tarea_origen, tarea_destino, tproducto, ttipo_operacion_origen, ttipo_operacion_destino )                         
	   LOOP
		if identificadorreg.tproducto = idproductomadre then
			cantidadreproduccion = identificadorreg.tcuenta;
		END IF;

		
	      INSERT INTO g_movilizacion_producto.detalle_movilizacion 
	      --INSERT INTO g_catastroprueba.detalle_movilizacion 
			      (id_movilizacion, area_origen, area_destino, producto, cantidad,
			      unidad_comercial, tipo_operacion_origen, tipo_operacion_destino)
		       VALUES (cabeceramovilizacion, identificadorreg.tarea_origen, identificadorreg.tarea_destino, identificadorreg.tproducto, identificadorreg.tcuenta,                               
			      34, identificadorreg.ttipo_operacion_origen, identificadorreg.ttipo_operacion_destino);

	       --   RAISE NOTICE 'Identificador  No.% % % %', identificadorreg.tcuenta, identificadorreg.tarea_origen, identificadorreg.tarea_destino, identificadorreg.tproducto;
	        -- RECUPERA  UTLIMO REGISTRO GUARDADO DETALLE MOVILIZACION
	        select id_detalle_movilizacion INTO detallemovilizacion from g_movilizacion_producto.detalle_movilizacion order by id_detalle_movilizacion desc limit 1;
	         -- select id_detalle_movilizacion INTO detallemovilizacion from g_catastroprueba.detalle_movilizacion order by id_detalle_movilizacion desc limit 1;
	         

	        -- GUARDA DETALLE IDENTIFICADORES MOVILIZACION
	        INSERT INTO g_movilizacion_producto.detalle_identificadores_movilizacion (id_detalle_movilizacion, identificador, control_identificador, id_catastro)
	        --INSERT INTO g_catastroprueba.detalle_identificadores_movilizacion (id_detalle_movilizacion, identificador, control_identificador, id_catastro)
			 SELECT detallemovilizacion, tidentificador, 'TRUE', tidcatastro from tmp_identificadores
			 WHERE tarea_origen = identificadorreg.tarea_origen
			 AND   tarea_destino = identificadorreg.tarea_destino
			 AND   tproducto = identificadorreg.tproducto
			 and   ttipo_operacion_origen = identificadorreg.ttipo_operacion_origen
			 AND   ttipo_operacion_destino = identificadorreg.ttipo_operacion_destino;

			IF generaticket = 'SI'  THEN
				perform g_movilizacion_producto.proceso_guardarticket(cabecera[1], detallemovilizacion);
			END IF;
		 
	  END LOOP;

	IF dobleguia != '' THEN
	
		-- GUARDA CABECERA //g_movilizacion_producto.movilizacion
		INSERT INTO g_movilizacion_producto.movilizacion 
	          (numero_certificado, provincia_emision, sitio_origen, sitio_destino, placa_transporte, identificador_conductor, 
	          usuario_responsable, estado, ruta_certificado, fecha_registro, fecha_inicio_vigencia, fecha_fin_vigencia, 
	          codigo_provincia_origen, codigo_provincia_destino, secuencial, nombre_conductor, medio_transporte, tipo_solicitud, 
	          observacion, ruta_ticket, oficina_emision, identificador_solicitante, cantidad_total, estado_fiscalizacion)
		  values (dobleguia, cabecera[2], cabecera[4]::integer, cabecera[3]::integer, cabecera[5], cabecera[6], 
			  cabecera[7], cabecera[8], cabecera[27], cabecera[10]::timestamp, cabecera[11]::timestamp, cabecera[12]::timestamp, 
			  cabecera[13], cabecera[14], cabecera[15], cabecera[16], cabecera[17]::integer, cabecera[18], 
			  cabecera[19], cabecera[20], cabecera[21], cabecera[22], cabecera[23]::integer, cabecera[24]);

		-- RECUPERA ULTIMO REGISTRO GUARDADO
		 select id_movilizacion INTO cabeceramovilizacion2 from g_movilizacion_producto.movilizacion order by id_movilizacion desc limit 1;
		 --select id_movilizacion INTO cabeceramovilizacion from g_catastroprueba.movilizacionprueba2 order by id_movilizacion desc limit 1;

		-- GUARDA DETALLE_MOVILIZACION
		-- SUMAR TODOS LOS PRODUCTOS QUE TENGAN EL MISMO AREA ORIGEN Y MISMA AREA DESTINO
		FOR identificadorreg in (select count(tproducto) as tcuenta, tarea_origen, tarea_destino, tproducto, ttipo_operacion_origen, ttipo_operacion_destino 
					 from  tmp_identificadores group by tproducto, tarea_origen, tarea_destino, tproducto, ttipo_operacion_origen, ttipo_operacion_destino )                         
		   LOOP

		      INSERT INTO g_movilizacion_producto.detalle_movilizacion 
		      --INSERT INTO g_catastroprueba.detalle_movilizacion 
				      (id_movilizacion, area_origen, area_destino, producto,cantidad,
				      unidad_comercial, tipo_operacion_origen, tipo_operacion_destino)
			       VALUES (cabeceramovilizacion2, identificadorreg.tarea_destino, identificadorreg.tarea_origen, identificadorreg.tproducto, identificadorreg.tcuenta,                               
				      34, identificadorreg.ttipo_operacion_destino, identificadorreg.ttipo_operacion_origen);
	
		       --   RAISE NOTICE 'Identificador  No.% % % %', identificadorreg.tcuenta, identificadorreg.tarea_origen, identificadorreg.tarea_destino, identificadorreg.tproducto;
			-- RECUPERA  UTLIMO REGISTRO GUARDADO DETALLE MOVILIZACION
			select id_detalle_movilizacion INTO detallemovilizacion from g_movilizacion_producto.detalle_movilizacion order by id_detalle_movilizacion desc limit 1;
			 -- select id_detalle_movilizacion INTO detallemovilizacion from g_catastroprueba.detalle_movilizacion order by id_detalle_movilizacion desc limit 1;
			 

			-- GUARDA DETALLE IDENTIFICADORES MOVILIZACION
			INSERT INTO g_movilizacion_producto.detalle_identificadores_movilizacion (id_detalle_movilizacion, identificador, control_identificador, id_catastro)
			--INSERT INTO g_catastroprueba.detalle_identificadores_movilizacion (id_detalle_movilizacion, identificador, control_identificador, id_catastro)
				 SELECT detallemovilizacion, tidentificador, 'TRUE', tidcatastro from tmp_identificadores
				 WHERE tarea_origen = identificadorreg.tarea_origen
				 and   tarea_destino = identificadorreg.tarea_destino
				 and   tproducto = identificadorreg.tproducto
				 and   ttipo_operacion_origen = identificadorreg.ttipo_operacion_origen
				 and   ttipo_operacion_destino = identificadorreg.ttipo_operacion_destino;	      
			 
		   END LOOP;

/*
		   UPDATE
				g_movilizacion_producto.movilizacion
			SET
				id_movilizacion_dos='$idMovilizacionDos',
				fecha_fin_vigencia='$fechaFinVigencia'
			WHERE
				id_movilizacion='$idMovilizacion'*/
	
	END IF;
	
	--------------------//////////////////////////////INICIO REGISTRO TRASNPORTE Y CONDUCTOR/////////////////////////////////------------------------------------------------------

	IF cabecera[5] != '' AND cabecera[6] != '' THEN

		INSERT INTO g_movilizacion_producto.transporte(placa_transporte, nombre_duenio_transporte) 
		    SELECT cabecera[5], cabecera[28]
			WHERE NOT EXISTS (
		    SELECT 1 FROM g_movilizacion_producto.transporte WHERE placa_transporte = cabecera[5]
		);

		INSERT INTO g_movilizacion_producto.conductor(identificador_conductor, nombre_conductor) 
		    SELECT cabecera[6], cabecera[16]
			WHERE NOT EXISTS (
		    SELECT 1 FROM g_movilizacion_producto.conductor WHERE identificador_conductor = cabecera[6]
		);

	END IF;	

	--------------------//////////////////////////////FIN REGISTRO TRASNPORTE Y CONDUCTOR/////////////////////////////////------------------------------------------------------


	--------------------//////////////////////////////INICIO CATASTRO/////////////////////////////////------------------------------------------------------

-- INSERTA CABECERA CATASTRO

	IF dobleguia = '' THEN

		FOR identificadorreg in (select count(tproducto) as tcuenta,  tarea_origen, tidcatastro, tproducto, ttipo_operacion_origen,
					tarea_destino, ttipo_operacion_destino from  tmp_identificadores 
					group by tproducto, tarea_origen, tidcatastro, ttipo_operacion_origen, tarea_destino, ttipo_operacion_destino)                         
		   LOOP     

		   RAISE NOTICE '% % % % %', identificadorreg.tcuenta, identificadorreg.tarea_origen , identificadorreg.tproducto , identificadorreg.ttipo_operacion_origen , identificadorreg.tarea_destino;

			--INSERTO CABECERA
			INSERT INTO g_catastro.catastros(id_sitio, id_area, id_producto, cantidad, identificador_responsable, unidad_medida_peso, fecha_modificacion_etapa, nombre_producto, 
								peso, id_especie, fecha_nacimiento, numero_lote, estado_etapa, id_tipo_operacion, unidad_comercial )
						select   cabecera[4]::integer, identificadorreg.tarea_destino, identificadorreg.tproducto, identificadorreg.tcuenta,
							  cabecera[7], tc.tunidad_medida_peso, tc.tfecha_modificacion_etapa, tc.tnombre_producto, tc.peso, tc.tid_especie, tc.tfecha_nacimiento, tc.tnumero_lote,
							  tc.testado_etapa, identificadorreg.ttipo_operacion_destino, tc.tunidad_comercial 
						from 
							tmp_catastros tc 
						where 
							tid_catastro = identificadorreg.tidcatastro --and tc.tid_producto = identificadorreg.tproducto
						RETURNING id_catastro INTO nuevocatastro;
			-- RECUPERO NUEVO ID_CATASTR


			-- INSERTO CATASTRO TRANSACCION RESTA

			--OBTENGO TOTAL DE PRODUCTOS CATASTRADOS POR AREY Y PRODUCTO
			SELECT cantidad_total into contador  FROM g_catastro.transaccion_catastro WHERE id_area = identificadorreg.tarea_origen 
			and id_producto = identificadorreg.tproducto and id_tipo_operacion = identificadorreg.ttipo_operacion_origen 
			ORDER BY id_transaccion_catastro DESC LIMIT 1;

			
			INSERT INTO g_catastro.transaccion_catastro
					  (id_catastro, id_area, id_concepto_catastro, id_producto, cantidad_egreso,
					  cantidad_total, unidad_comercial,identificador_responsable, id_tipo_operacion)
				    select  identificadorreg.tidcatastro, identificadorreg.tarea_origen, 
					   (SELECT id_concepto_catastro FROM g_catastro.concepto_catastros WHERE codigo = 'MOOR'),            
					    identificadorreg.tproducto, identificadorreg.tcuenta,
					    case when contador is not null 
						then contador - identificadorreg.tcuenta
						else 0
					    end,
					tc.tunidad_comercial, cabecera[7], identificadorreg.ttipo_operacion_origen
					FROM
					tmp_catastros tc
					where 
					tc.tid_producto = identificadorreg.tproducto
					and tc.tid_catastro = identificadorreg.tidcatastro;

			contador := 0;
			
			
			-- INSERTO CATASTRO TRASNSACCION SUMA

			SELECT cantidad_total into contador  FROM g_catastro.transaccion_catastro WHERE id_area = identificadorreg.tarea_destino 
			and id_producto = identificadorreg.tproducto and id_tipo_operacion = identificadorreg.ttipo_operacion_destino 
			ORDER BY id_transaccion_catastro DESC LIMIT 1;

			
			INSERT INTO g_catastro.transaccion_catastro
					  (id_catastro, id_area, id_concepto_catastro, id_producto, cantidad_ingreso,
					  cantidad_total, unidad_comercial, identificador_responsable, id_tipo_operacion)
				    select  nuevocatastro, identificadorreg.tarea_destino, 
					   (SELECT id_concepto_catastro FROM g_catastro.concepto_catastros WHERE codigo='MODE'),            
					    identificadorreg.tproducto, identificadorreg.tcuenta,
					    case when contador is not null 
						then contador + identificadorreg.tcuenta
						else 0
					    end,
					tc.tunidad_comercial, cabecera[7], identificadorreg.ttipo_operacion_destino
					FROM
					tmp_catastros tc
					where 
					tc.tid_producto = identificadorreg.tproducto
					and tc.tid_catastro = identificadorreg.tidcatastro;


			---- GUARDO DETALLE CATASTRO	
		
			INSERT INTO g_catastro.detalle_catastros(id_catastro, identificador_producto, identificador_unico_producto ,estado_registro)
			    SELECT nuevocatastro, ti.tidentificador_producto, ti.tidentificadorunicoproducto, ti.testado
			    FROM 
				tmp_identificadores ti
			    WHERE 
				tarea_destino = identificadorreg.tarea_destino
				and tproducto = identificadorreg.tproducto
				and tidcatastro = identificadorreg.tidcatastro;

			UPDATE g_catastro.detalle_catastros SET estado_registro = 'eliminado'
			WHERE id_catastro = identificadorreg.tidcatastro and 
			(identificador_unico_producto in (SELECT ti.tidentificadorunicoproducto FROM tmp_identificadores ti)
			or identificador_producto in (SELECT ti.tidentificadorunicoproducto FROM tmp_identificadores ti)
			);
			
		END LOOP;



		--------------------//////////////////////////////INICIO CONTROL REPORDUCCION/////////////////////////////////------------------------------------------------------
		IF banderamadre THEN

			UPDATE tmp_controlreproduccion set 
			  tcupocriadestino = cp.cupo_cria,
			  tcantidadcriadestino = cp.cantidad_cria
			  from g_catastro.control_reproduccion cp
			  where id_control_reproduccion = (select max(id_control_reproduccion) from g_catastro.control_reproduccion where id_producto = idproductomadre
			  and identificador_operador = cabecera[26]);

			 UPDATE tmp_controlreproduccion set 
			  tmadresdestino = (SELECT count(id_detalle_catastro) cantidad
						FROM g_catastro.catastros c, g_catastro.detalle_catastros dc, g_operadores.sitios s
						WHERE c.id_catastro = dc.id_catastro and s.id_sitio = c.id_sitio and s.identificador_operador = cabecera[26]
						and c.id_producto = idproductomadre and dc.estado_registro = 'activo'),
			  tlechonesdestino = (SELECT count(id_detalle_catastro) cantidad
						FROM g_catastro.catastros c, g_catastro.detalle_catastros dc, g_operadores.sitios s
						WHERE c.id_catastro = dc.id_catastro and s.id_sitio = c.id_sitio and s.identificador_operador = cabecera[26]
						and c.id_producto in (idproductolechon,idproductolechona) and dc.estado_registro = 'activo');

			  UPDATE tmp_controlreproduccion set 
			  tcupocriaorigen = cp.cupo_cria,
			  tcantidadcriaorigen = cp.cantidad_cria 
			  from g_catastro.control_reproduccion cp
			  where id_control_reproduccion = (select max(id_control_reproduccion) from g_catastro.control_reproduccion where id_producto = idproductomadre
			  and identificador_operador = cabecera[26]);

			 UPDATE tmp_controlreproduccion set 
			  tmadresorigen = (SELECT count(id_detalle_catastro) cantidad
						FROM g_catastro.catastros c, g_catastro.detalle_catastros dc, g_operadores.sitios s
						WHERE c.id_catastro = dc.id_catastro and s.id_sitio = c.id_sitio and s.identificador_operador = cabecera[26]
						and c.id_producto = idproductomadre and dc.estado_registro = 'activo'),
			  tlechonesorigen = (SELECT count(id_detalle_catastro) cantidad
						FROM g_catastro.catastros c, g_catastro.detalle_catastros dc, g_operadores.sitios s
						WHERE c.id_catastro = dc.id_catastro and s.id_sitio = c.id_sitio and s.identificador_operador = cabecera[26]
						and c.id_producto in (idproductolechon,idproductolechona) and dc.estado_registro = 'activo');
			  
			-- actualizar cupodestino
			update tmp_controlreproduccion set 
			tnuevocupocriadestino =  case when tcupocriadestino is not null then (tcupocriadestino + (cantidadreproduccion * 28)) 
							     else cantidadreproduccion * 28
							end,
			tnuevocantidadcriadestino = case when tcupocriadestino is not null then tcantidadcriadestino 
							     else tlechonesdestino
							end,
			tnuevocupocriaorigen = case when tcupocriaorigen is not null then (tcupocriaorigen - (cantidadreproduccion * 28))  
							     else cantidadreproduccion * 28
							end,
			
			tnuevocantidadcriaorigen = case when tcupocriaorigen is not null then tcantidadcriaorigen  
							     else tlechonesorigen
							end;
			  
			INSERT INTO g_catastro.control_reproduccion
				   (identificador_operador, id_producto, cupo_cria, fecha_registro, cantidad_cria) 
				SELECT 
					tidentificador_operador_destino, idproductomadre, tnuevocupocriadestino,now(), tnuevocantidadcriadestino  
				FROM  
					tmp_controlreproduccion 
				WHERE
					tidentificador_operador_destino = cabecera[26];

			INSERT INTO g_catastro.control_reproduccion
				   (identificador_operador, id_producto, cupo_cria, fecha_registro, cantidad_cria) 
				SELECT 
					tidentificador_operador_origen, idproductomadre, tnuevocupocriaorigen,now(), tnuevocantidadcriaorigen 
				FROM  
					tmp_controlreproduccion 
				WHERE
					tidentificador_operador_origen = cabecera[26];


		END IF;

	END IF;					   
--ELSE
----Se devuelve vacío los parámetros
END IF;


RETURN cabeceramovilizacion || '-' || cabeceramovilizacion2; -- Devolever los idMovilizacion y el Id_movilizaciondobleguia
  END;
$$;

alter function proceso_guardarmovilizacion(text[], text[], text[], text, text) owner to postgres;

