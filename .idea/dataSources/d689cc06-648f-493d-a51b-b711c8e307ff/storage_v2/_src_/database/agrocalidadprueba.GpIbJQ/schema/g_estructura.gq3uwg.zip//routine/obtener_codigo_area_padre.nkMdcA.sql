create function obtener_codigo_area_padre(text) returns text
    language plpgsql
as
$$
declare
	area alias for $1;
	area_padre text;
begin
	area_padre := (
		select 
			a.id_area_padre
		from
			g_estructura.area a
		where
			area=a.id_area);
	if (area_padre is null) then
		return area;
	else
		return lower(g_estructura.obtener_codigo_area_padre(area_padre) || '_' || area);
	end if;
end;
$$;

alter function obtener_codigo_area_padre(text) owner to postgres;

