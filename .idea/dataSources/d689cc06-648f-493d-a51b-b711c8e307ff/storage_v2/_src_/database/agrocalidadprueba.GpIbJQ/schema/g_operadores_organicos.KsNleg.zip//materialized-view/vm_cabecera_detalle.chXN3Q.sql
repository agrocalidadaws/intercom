create materialized view vm_cabecera_detalle as
SELECT a.id_detalle,
       a.id_cabecera,
       a.codigo_poa_actual,
       a.nombre_razon_social,
       a.representante_legal,
       a.cedula_ruc,
       a.tipo_operador,
       a.nombre_miembro,
       (SELECT count(DISTINCT ma.nombre_miembro_asociacion) AS count
        FROM g_operadores.miembros_asociacion ma
        WHERE ((ma.apellido_miembro_asociacion::text || ' '::text) || ma.nombre_miembro_asociacion::text) =
              a.nombre_miembro
          AND ma.nombre_miembro_asociacion::text <> 'No definido'::text) AS numero_productores,
       a.celular,
       a.telefono_fijo,
       a.correo_electronico,
       a.nombre_tipo_operacion                                           AS produccion_agricola,
       CASE
           WHEN a.exportador_importador_nacional IS NULL THEN 'No aplica'::character varying
           ELSE a.exportador_importador_nacional
           END                                                           AS exportador_importador_nacional,
       a.producto_primario_producto_elaborado,
       a.estatus_organico_t1_t2_t3_producido_organico,
       a.organismo_certificacion,
       a.produccion_anual_estimada,
       a.superficie_ha,
       a.nombre_unidad_produccion,
       a.codigo_magap,
       a.provincia,
       a.canton,
       a.parroquia_sector,
       a.direccion,
       a.localizacion_longitud,
       a.localizacion_latitud,
       CASE
           WHEN a.estado::text = 'registrado'::text THEN 'Habilitado'::text
           ELSE 'No habilitado'::text
           END                                                           AS habilitado,
       a.fecha_aprobacion,
       a.fecha_carga,
       a.estado_op
FROM g_operadores_organicos.detalle a
         JOIN g_operadores_organicos.cabecera b ON a.id_cabecera = b.id_cabecera
WHERE a.fecha_carga = CURRENT_DATE
  AND b.id_cabecera = ((SELECT max(cabecera.id_cabecera) AS max
                        FROM g_operadores_organicos.cabecera));

alter materialized view vm_cabecera_detalle owner to postgres;

