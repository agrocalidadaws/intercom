create function mostrar_orden_pago_filtrados_sri(_operador text, _numerofactura text, _fecha_inicio timestamp without time zone, _fecha_fin timestamp without time zone, _estado_sri text, _localizacion text) returns SETOF g_financiero.orden_pago
    language plpgsql
as
$$
DECLARE
	query text;
BEGIN	
	return query EXECUTE '	
		SELECT
			*
		FROM 
			g_financiero.orden_pago o
		WHERE 
			($1 is NULL or identificador_operador = $1) and
			($2 is NULL or numero_solicitud like $2) and
			($3 is NULL or fecha_orden_pago >= $3) and
			($4 is NULL or fecha_orden_pago <= $4) and
			($5 is NULL or $5 = estado_sri) and 
			($6 is NULL or $6 = localizacion) and
			tipo_solicitud = ''Otros''
			
		ORDER BY
			o.fecha_orden_pago'
		using _operador,_numeroFactura,_fecha_inicio,_fecha_fin,_estado_sri,_localizacion;
	
END;
$$;

alter function mostrar_orden_pago_filtrados_sri(text, text, timestamp, timestamp, text, text) owner to postgres;

