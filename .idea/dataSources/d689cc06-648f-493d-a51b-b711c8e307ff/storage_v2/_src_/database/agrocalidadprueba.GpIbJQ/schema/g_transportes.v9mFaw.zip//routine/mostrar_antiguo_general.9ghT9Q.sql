create function mostrar_antiguo_general(_placa text, _localizacion text, _cantidad integer) returns SETOF g_transportes.antiguo_general
    language plpgsql
as
$$
DECLARE
	query text;
BEGIN	
	return query EXECUTE '
			SELECT 
				anio_fabricacion,
				placa,
				localizacion
			FROM 
				g_transportes.vehiculos
			WHERE
				($1 is NULL or placa like $1) and 
				($2 is NULL or $2 = localizacion) and
				estado != 9
			ORDER BY anio_fabricacion asc
			LIMIT $3'
			
		using _placa,_localizacion,_cantidad;
	
END;
$$;

alter function mostrar_antiguo_general(text, text, integer) owner to postgres;

