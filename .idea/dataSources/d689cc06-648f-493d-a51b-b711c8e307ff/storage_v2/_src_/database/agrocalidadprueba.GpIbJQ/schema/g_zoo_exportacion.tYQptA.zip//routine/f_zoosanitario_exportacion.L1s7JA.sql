create function f_zoosanitario_exportacion(pfecha_desde date, pfecha_hasta date, OUT id_vue character varying, OUT fecha_creacion timestamp without time zone, OUT identificador_operador character varying, OUT nombre_importador character varying, OUT pais_destino character varying, OUT nombre_uso character varying, OUT transporte character varying, OUT puerto_embarque character varying, OUT numero_bultos integer, OUT descripcion_bultos character varying, OUT partida_arancelaria character varying, OUT nombre_producto character varying, OUT cantidad_fisica double precision, OUT unidad_fisica character varying, OUT pais_origen character varying, OUT sexo character varying, OUT edad integer, OUT raza character varying, OUT codigo_sitio character varying, OUT provincia_sitio character varying, OUT fecha_inicio date, OUT estado character varying, OUT nombre_operador character varying) returns SETOF record
    language plpgsql
as
$$
/*
-------------------------------------------------------------------------
--  [g_zoo_exportacion.f_zoosanitario_exportacion]
--               
--  Esta funcion retorna records de los certificados de exportacion zoosanitarios
--
--  VERSION		AUTOR					FECHA			HU			                           CAMBIO
--	1			Kleber Armijos		25-07-2023			compartir datos mag           seleccionar los certificados zoosanitarios de exportacion
-------------------------------------------------------------------------
*/
DECLARE
	
BEGIN	
CREATE TABLE  temp_certificado_export_zoosanitario AS(

	SELECT
	z.id_vue,
	z.fecha_creacion,
	z.identificador_operador,
	z.nombre_importador,
	z.pais_destino,
	u.nombre_uso,
	z.transporte,
	z.puerto_embarque,
	z.numero_bultos,
	z.descripcion_bultos,
	p.partida_arancelaria,
	zp.nombre_producto,
	zp.cantidad_fisica,
	zp.unidad_fisica,
	zp.pais_origen,
	zp.sexo,
	zp.edad,
	zp.raza,
	z.codigo_sitio,
	ops.provincia as provincia_sitio,
	z.fecha_inicio,
	z.estado,
	case when o.razon_social = '' then o.nombre_representante ||' '|| o.apellido_representante else o.razon_social end nombre_operador
FROM
	g_zoo_exportacion.zoo_exportaciones z
	inner join g_zoo_exportacion.zoo_exportaciones_productos zp on z.id_zoo_exportacion = zp.id_zoo_exportacion
	inner join  g_operadores.operadores o on z.identificador_operador = o.identificador
	inner join g_operadores.sitios ops on o.identificador=ops.identificador_operador
	inner join g_catalogos.productos p on zp.id_producto = p.id_producto 
	inner join g_catalogos.usos u on 	u.id_uso = z.uso_producto 
WHERE
   ops.identificador_operador||'.'||ops.codigo_provincia||codigo = z.codigo_sitio and 
	z.fecha_inicio BETWEEN $1 and $2
		
);
 RETURN QUERY select *from temp_certificado_export_zoosanitario;
  drop table temp_certificado_export_zoosanitario;
	
END;
$$;

alter function f_zoosanitario_exportacion(date, date, out varchar, out timestamp, out varchar, out varchar, out varchar, out varchar, out varchar, out varchar, out integer, out varchar, out varchar, out varchar, out double precision, out varchar, out varchar, out varchar, out integer, out varchar, out varchar, out varchar, out date, out varchar, out varchar) owner to postgres;

