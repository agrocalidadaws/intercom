create procedure sp_generar_orden_pago_procesos(INOUT json_parametro json)
    language plpgsql
as
$$
/*
-------------------------------------------------------------------------
--  [g_financiero.sp_generar_orden_pago_procesos]
--               
--  procedimiento que se encarga de realizar el proceso de ingreso de las tablas de g_financiero.orden_pago,
--  g_financiero_detalle_pago, actualiza el estado de las tablas de los diferentes procesos y registra en las
--  tablas del esquema g_revision_solicitudes en el caso de que el proceso lo requiera
--
--  VERSION		AUTOR					FECHA			HU			                           
--	1			Kleber Armijos		16-08-2024	 Control de cambios funcional interconexion 
--				Milton Nivelo				     refactoracion financiero pry-banred
-------------------------------------------------------------------------
*/
DECLARE
	
	--Variables de validacion de errores
	vSQLERRM TEXT;
	no_error BOOLEAN;
	
	--Variables JSON
    v_da JSON;
    v_detalle_item JSON;
	v_datos_orden_pago JSON;
    
    --variables datos generales---    
    v_envio_vue TEXT;
	v_identificador_inspector TEXT;
	v_tipo_inspector TEXT;
	v_id_operador_tipo_operacion INTEGER;
	v_id_historial_operacion INTEGER;
	v_monto DOUBLE PRECISION; 
	v_estado_proceso_solicitud TEXT;
	
    v_id_grupo INTEGER := 0;
    v_orden INTEGER := 0;
    v_id_financiero INTEGER := 0;
	
    --Variables cabecera orden pago--
    v_numero_solicitud TEXT;
    v_id_pago INTEGER;
	v_identificador_recaudador TEXT;
	v_localizacion_recaudador TEXT;
    v_id_provincia_recaudador INTEGER;
    v_nombre_provincia_recaudador TEXT;	
	v_nombre_recaudador TEXT;
	v_id_solicitud TEXT;
	v_tipo_solicitud TEXT;
	v_asignar_monto_solicitud BOOLEAN;
	v_id_vue TEXT;
	v_ruta_raiz_guia TEXT;
	v_metodo_pago TEXT;
	v_tipo_cliente TEXT;
	v_busqueda_cliente TEXT;
	v_observacion TEXT;
    v_identificador_cliente TEXT;	
    v_ruc_cliente TEXT;    
    r_datos_cliente RECORD;	
	v_razon_social TEXT;
	v_direccion TEXT;
	v_telefono TEXT;
	v_correo TEXT;	
    v_total_pagar DOUBLE PRECISION;    
    v_fecha_orden_pago TIMESTAMP WITHOUT TIME ZONE;
	v_porcentaje_iva INTEGER;	
	    
	--Variables orden de pago
    v_n_id_pago INTEGER;
	v_nombre_provincia_solicitud TEXT default 'N/A';
	v_estado_solicitud TEXT;
	v_tipo_proceso TEXT := 'factura';
	v_estado_orden_pago INTEGER := 3;
	
	--Variables orden pago PDF
    v_nombre_secuencia INTEGER;
    v_fecha_partir1_doc INTEGER;
	v_fecha_partir2_doc INTEGER;
	v_fecha_partir4_doc INTEGER;
	v_fecha_partir3_doc INTEGER;
	v_ruta_archivo_orden_pago TEXT;
	v_path_base_ruta_archivo TEXT DEFAULT 'aplicaciones/financiero/documentos/ordenPago/';
	v_ruta_fecha TEXT;
	v_nombre_archivo TEXT;
	v_nombre_reporte TEXT default 'ReporteOrden';
	
	--Variables detalle orden pago--	
	v_id_deposito INTEGER;
	v_concepto TEXT;
	v_cantidad DOUBLE PRECISION;
	v_descuento DOUBLE PRECISION;
	v_precio_unitario DOUBLE PRECISION;
	v_iva_individual DOUBLE PRECISION;
	v_total_individual DOUBLE PRECISION;
	v_subsidio DOUBLE PRECISION;
	
	--Variables bandera--
	b_validar_existencia_orden BOOLEAN := true;
	b_asignar_monto_solicitud BOOLEAN := false;
	
	--Variables mensaje--
	d_mensaje TEXT default 'Sin error';
	
	--Variables registro operador--
	v_id_flujo_operacion INTEGER;
    v_predecesor INTEGER;
	
	--Variables proceso comercio exterior--
	v_formulario TEXT;
	v_codigo_procesamiento TEXT;
	v_codigo_verificacion TEXT;
	
	--Variables importacion--
	v_cantidad_documento INTEGER;
	v_id_vue_importacion INTEGER;
	v_fecha_inicio_importacion TIMESTAMP WITHOUT TIME ZONE;
	v_fecha_vigencia_importacion TIMESTAMP WITHOUT TIME ZONE;
	v_id_area_importacion TEXT;
	v_estado_importacion TEXT;
	v_fecha_ampliacion_importacion TIMESTAMP WITHOUT TIME ZONE;
	
	--Variables fitosanitario--
	v_estado_fitosanitario TEXT;
	v_fecha_vigencia_fitosanitario TIMESTAMP WITHOUT TIME ZONE;
	
	--Variables Zoosanitario--
	v_informe_requisitos TEXT;
	v_nombre_informe_requisitos TEXT;
	
	--Variables fitosanitario exportacion--
	v_estado_anterior_fitosanitario_exportacion TEXT;
	
	--Variables importacion muestras--
	v_estado_importacion_muestra TEXT;
	v_codigo_tipo_solicitud_importacion_muestra TEXT;
	v_fecha_vigencia_importacion_muestra TIMESTAMP WITHOUT TIME ZONE;
	
	v_proceso_no_definido TEXT := 'Tipo de proceso no definido';
	
BEGIN
	
	BEGIN   -- inicio transanccion
		
		no_error := TRUE;
	 
		v_da := json_parametro;
		
		--Datos generales--
		v_envio_vue := v_da->'datosGenerales'->>'envioVue';
		v_identificador_inspector := v_da->'datosGenerales'->>'identificadorInspector';
		v_tipo_inspector := v_da->'datosGenerales'->>'tipoInspector';
		v_id_operador_tipo_operacion := v_da->'datosGenerales'->>'idOperadorTipoOperacion';
		v_id_historial_operacion := v_da->'datosGenerales'->>'idHistorialOperacion';
		v_monto := v_da->'factura'->'cabecera'->>'totalPagar';
		v_estado_proceso_solicitud := v_da->'datosGenerales'->>'estadoProcesoSolicitud';
		v_asignar_monto_solicitud := v_da->'datosGenerales'->>'asignarMontoSolicitud';
		v_id_vue := v_da->'datosGenerales'->>'idVue';
		v_ruta_raiz_guia := v_da->'datosGenerales'->>'rutaRaizGuia';

		--Datos orden pago--
		v_id_pago := v_da->'factura'->'cabecera'->>'idPago';
		v_identificador_recaudador := v_da->'factura'->'cabecera'->>'identificadorRecaudador';
		v_localizacion_recaudador := v_da->'factura'->'cabecera'->>'localizacionRecaudador';
		v_id_solicitud := v_da->'factura'->'cabecera'->>'idSolicitud';
		v_tipo_solicitud := v_da->'factura'->'cabecera'->>'tipoSolicitud';
		v_metodo_pago := v_da->'factura'->'cabecera'->>'metodoPago';
		v_tipo_cliente := v_da->'factura'->'cabecera'->>'tipoCliente';
		v_busqueda_cliente := v_da->'factura'->'cabecera'->>'busquedaCliente';
		v_observacion := v_da->'factura'->'cabecera'->>'observacion';
		v_identificador_cliente := v_da->'factura'->'cabecera'->>'identificadorCliente';
		v_ruc_cliente := v_da->'factura'->'cabecera'->>'rucCliente';
		v_total_pagar := v_da->'factura'->'cabecera'->>'totalPagar';
		v_fecha_orden_pago := now();    
		
		PERFORM 
			id_pago
		FROM
			g_financiero.orden_pago											
		WHERE
			id_solicitud = v_id_solicitud
			and tipo_solicitud = v_tipo_solicitud
			and tipo_solicitud NOT IN ('Otros');
											
		IF FOUND AND v_id_pago IS NULL THEN --Inicio proceso orden_pago--

			no_error := FALSE;
			b_validar_existencia_orden := false;
			d_mensaje := 'Ya existe una orden generada';	

		ELSE
		
			--TODO:Consultar en tablas banred--
			PERFORM
				id_pago_bandred
			FROM
				g_pago_banred.pago_banred
			WHERE
				id_orden_pago = v_id_pago
				AND estado_transaccion_bandred_agr = 6;
			
			--IF FOUND THEN --CAMBIAR ESTO Se habilitará cuando se integre con banred
			IF 1 THEN
			
				/*no_error := FALSE;
				b_validar_existencia_orden := false;
				RAISE NOTICE 'mostrar mensaje que ya existe una orden de pago generada % %', v_id_solicitud, v_tipo_solicitud;
				d_mensaje := 'La orden pago ya fue cancelada, no se puede editar';
		
			ELSE*/		
			
				--OBTENER PROVINCIA RECAUDADOR---
				SELECT
					l.id_localizacion
					, l.nombre
					, fe.nombre || ' ' || fe.apellido AS nombre_recaudador
				FROM
					g_estructura.funcionarios f 
				INNER JOIN g_catalogos.localizacion l ON l.id_localizacion = f.id_provincia
				INNER JOIN g_uath.ficha_empleado fe ON fe.identificador = f.identificador
				WHERE
					l.categoria = 1
					AND f.identificador = v_identificador_recaudador INTO v_id_provincia_recaudador, v_nombre_provincia_recaudador, v_nombre_recaudador;
			
				<<asignacion_monto_solicitud>>
				BEGIN
				----------------------------------
				--INICIO ASIGNAR MONTO SOLICITUD--
				----------------------------------			
				
				IF v_asignar_monto_solicitud THEN
				
					--Inicio registro de grupos solicitudes y registro en revision financiero--
					IF v_envio_vue <> 'tarifarioAntiguo' THEN --Inicio v_envio_vue--

						INSERT INTO 
							g_revision_solicitudes.asignacion_inspector
							(identificador_inspector, 
							 fecha_asignacion, 
							 identificador_asignante, 
							 tipo_solicitud, 
							 tipo_inspector, 
							 id_operador_tipo_operacion, 
							 id_historial_operacion)
						VALUES 
							(v_identificador_inspector,
							 now(), 
							 v_identificador_inspector,
							 v_tipo_solicitud,
							 v_tipo_inspector,
							 v_id_operador_tipo_operacion, 
							 v_id_historial_operacion) RETURNING id_grupo INTO v_id_grupo;

						INSERT INTO 
							g_revision_solicitudes.grupos_solicitudes
						VALUES
							(v_id_grupo, v_id_solicitud::INTEGER, 'Financiero');        

						SELECT
							COALESCE(MAX(CAST(orden as  numeric(5))), 0 ) + 1 as orden --pendiente siempre va 1
						FROM
							g_revision_solicitudes.financiero
						WHERE
						id_grupo = v_id_grupo INTO v_orden;

						INSERT INTO
							g_revision_solicitudes.financiero 
							(id_grupo, 
							 identificador_inspector, 
							 monto, 
							 fecha_asignacion_monto, 
							 orden)
						VALUES
							(v_id_grupo, v_identificador_inspector, v_monto, now(), v_orden) RETURNING id_financiero INTO v_id_financiero;

						IF v_monto = 0 THEN
							  
							UPDATE
								g_revision_solicitudes.financiero
							SET
								fecha_inspeccion = now(),
								estado = 'aprobado',
								observacion = 'Verificación de pago automatica por asignación de valor de pago con valor 0',
								codigo_banco = '0',
								monto_recaudado = v_monto,
								numero_factura = 'Recaudación ventanilla',
								nombre_banco = '000000000',
								identificador_verificador = v_identificador_inspector--,
								--numero_orden_vue = '$numeroOrdenVue'
							WHERE
								id_financiero = v_id_financiero;
						END IF;
					
					END IF; --Fin v_envio_vue--
					--Fin registro de grupos solicitudes y registro en revision financiero--
				
				END IF;
				
																
				IF v_tipo_solicitud = 'Operadores' THEN
			
					IF v_envio_vue <> 'tarifarioAntiguo' THEN --Inicio tarifario antiguo--
				
						--Inicio saltar fase de pago operacion--
						IF v_monto = 0 THEN --Inicio v_monto--
						
							--Inicio obtener flujo operacion-- 
							SELECT
								top.id_flujo_operacion
							FROM
								g_operadores.operaciones op
							INNER JOIN g_catalogos.tipos_operacion top ON top.id_tipo_operacion = op.id_tipo_operacion 
							WHERE					
								op.id_operacion::TEXT = v_id_solicitud INTO v_id_flujo_operacion;
							--Fin obtener flujo operacion--
							
							--Inicio obtener flujo actual de la operacion--
							SELECT
								predecesor
							FROM
								g_operadores.flujos_operaciones
							WHERE
								id_flujo = v_id_flujo_operacion
								AND estado = 'verificacion' INTO v_predecesor;
							--Fin obtener flujo actual de la operacion--
							
							--Inicio obtener siguiente estado operacion--
							SELECT
								estado
							FROM
								g_operadores.flujos_operaciones
							WHERE
								id_flujo = v_id_flujo_operacion
								AND id_fase = v_predecesor INTO v_estado_proceso_solicitud;
							--Fin obtener siguiente estado operacion--		
							
						END IF; --Fin v_monto--
						--Fin saltar fase de pago operacion--
						
						--Inicio obtener id_operador_tipo_operacion--
						SELECT
							id_operador_tipo_operacion
						FROM
							g_operadores.operaciones 
						WHERE
							id_operacion::TEXT = v_id_solicitud INTO v_id_operador_tipo_operacion;
						--Fin obtener id_operador_tipo_operacion--					
						
						--Inicio obtener id_histrial_operacion--
						SELECT 
							MAX (id_historial_operacion) AS id_historial_operacion
						FROM
							g_operadores.historial_operaciones
						WHERE
							 id_operador_tipo_operacion = v_id_operador_tipo_operacion INTO v_id_historial_operacion;
						--Fin obtener id_histrial_operacion--					
						
						--Inicio actualizar estado operador tipo operacion--
						UPDATE
							g_operadores.operadores_tipo_operaciones
						SET
							estado = v_estado_proceso_solicitud,
							fecha_modificacion = now()
						WHERE
							id_operador_tipo_operacion = v_id_operador_tipo_operacion;
						--Fin actualizar estado operador tipo operacion--
						
						--Inicio actualizar estado anterior de operacion--
						UPDATE
							g_operadores.operaciones o
						SET
							estado_anterior = op.estado
						FROM
							g_operadores.operaciones op
						WHERE
							o.id_operacion = op.id_operacion
							AND op.id_operador_tipo_operacion = v_id_operador_tipo_operacion
							AND op.id_historial_operacion = v_id_historial_operacion
							AND op.estado NOT IN ('noHabilitado');
						--Fin actualizar estado anterior de operacion--
						
						--Inicio actualizar estado de la operacion--				
						UPDATE
							g_operadores.operaciones
						SET
							estado = v_estado_proceso_solicitud,
							fecha_modificacion = now()
						where
							id_operador_tipo_operacion = v_id_operador_tipo_operacion
							AND id_historial_operacion = v_id_historial_operacion
							AND estado NOT IN ('noHabilitado');
						--Fin actualizar estado de la operacion--
					
					END IF; --Fin tarifario antiguo--

				ELSIF v_tipo_solicitud = 'Importación' THEN
				
					IF v_monto = 0 THEN
					
						--Inicio valida si existe un documento con pedido de apmpliacion--
						SELECT 
							COUNT (id_importacion)
						FROM
							g_importaciones.documentos_adjuntos
						WHERE
							id_importacion::TEXT = v_id_solicitud
							AND tipo_archivo = 'PEDIDO DE AMPLIACION' INTO v_cantidad_documento;
						--Fin valida si existe un documento con pedido de apmpliacion--
						
						--Inicio obtiene datos de importacion--
						SELECT
							id_vue
							, fecha_inicio
							, fecha_vigencia
							, id_area
						FROM
							g_importaciones.importaciones
						WHERE
							id_importacion::TEXT = v_id_solicitud INTO v_id_vue_importacion, v_fecha_inicio_importacion, v_fecha_vigencia_importacion, v_id_area_importacion;
						--Fin obtiene datos de importacion--
						
						IF v_cantidad_documento <> 0 AND v_fecha_inicio_importacion <> '' THEN

							v_estado_importacion := 'ampliado';
							v_formulario := '101-002-REQ';
							v_codigo_procesamiento := '340';
							v_codigo_verificacion := '21';
													
							v_fecha_ampliacion_importacion := TO_CHAR (v_fecha_vigencia_importacion + INTERVAL '30 days', 'YYYY-MM-DD');
							
							UPDATE
								g_importaciones.importaciones
							SET
								fecha_ampliacion = now(),
								fecha_vigencia = v_fecha_ampliacion_importacion
							WHERE
								id_importacion::TEXT = v_id_solicitud;							
						
						ELSE			
						
							v_estado_importacion := 'aprobado';
							v_formulario := '101-002-REQ';
							v_codigo_procesamiento := '320';
							v_codigo_verificacion := '21';
						
							IF v_id_area_importacion IN ('SA', 'SV') THEN					
								v_fecha_vigencia_importacion := TO_CHAR (now() + INTERVAL '3 month', 'YYYY-MM-DD');					
							ELSIF v_id_area_importacion IN ('IAP', 'IAF', 'IAV') THEN
								v_fecha_vigencia_importacion := TO_CHAR (now() + INTERVAL '6 month', 'YYYY-MM-DD');
							END IF;
							
							UPDATE
								g_importaciones.importaciones
							SET
								fecha_inicio = now()
								, fecha_vigencia = v_fecha_vigencia_importacion
							WHERE
								id_importacion::TEXT = v_id_solicitud;
						
						END IF;
					
						--Enviar importacion--
						UPDATE
							g_importaciones.importaciones
						SET
							estado = v_estado_importacion
						WHERE
							id_importacion::TEXT = v_id_solicitud;
							
						--Enviar productos importacion--
						UPDATE
							g_importaciones.importaciones_productos
						SET
							estado = v_estado_importacion
						WHERE
							id_importacion::TEXT = v_id_solicitud;
							
						IF v_id_vue <> '' THEN
							
							INSERT INTO 
								g_vue.solicitudes_atender
								(formulario
								, codigo_procesamiento
								, codigo_verificacion
								, solicitud
								, estado)
							VALUES 
								(v_formulario
								, v_codigo_procesamiento
								, v_codigo_verificacion
								, v_id_vue
								, 'Por atender');
							
						END IF;
					
					ELSE
					
						IF v_envio_vue <> 'tarifarioAntiguo' THEN
				
							v_formulario := '101-002-REQ';
							v_codigo_procesamiento := '120';
							v_codigo_verificacion := '21';
						
							UPDATE
								g_importaciones.importaciones
							SET
								estado = v_estado_proceso_solicitud
							WHERE
								id_importacion::TEXT = v_id_solicitud;
								
							INSERT INTO 
								g_vue.solicitudes_atender
								(formulario
								, codigo_procesamiento
								, codigo_verificacion
								, solicitud
								, estado)
							VALUES 
								(v_formulario
								, v_codigo_procesamiento
								, v_codigo_verificacion
								, v_id_vue
								, 'Por atender');				
							
						END IF;
					
					END IF;
					
				ELSIF v_tipo_solicitud = 'Fitosanitario' THEN
				
					IF v_monto = 0 THEN
			
						v_estado_fitosanitario := 'aprobado';
						v_fecha_vigencia_fitosanitario := TO_CHAR (now() + INTERVAL '3 month', 'YYYY-MM-DD');	
						v_formulario := '101-031-REQ';
						v_codigo_procesamiento := '320';
						v_codigo_verificacion := '21';

						UPDATE
							g_fito_exportacion.fito_exportaciones_operadores_productos
						SET
							estado = v_estado_fitosanitario
						WHERE
							id_fito_exportacion::TEXT = v_id_solicitud;
							
						UPDATE
							g_fito_exportacion.fito_exportaciones
						SET
							fecha_inicio = now(),
							fecha_vigencia = v_fecha_vigencia_fitosanitario
						WHERE
							id_fito_exportacion::TEXT = v_id_solicitud;			
					
					ELSE
					
						IF v_envio_vue <> 'tarifarioAntiguo' THEN
						
							v_estado_fitosanitario := v_estado_proceso_solicitud;			
							v_formulario := '101-031-REQ';
							v_codigo_procesamiento := '120';
							v_codigo_verificacion := '21';
						
						END IF;
					
					END IF;
					
					UPDATE
						g_fito_exportacion.fito_exportaciones
					SET
						estado = v_estado_fitosanitario
					WHERE
						id_fito_exportacion::TEXT = v_id_solicitud;
					
					IF v_envio_vue <> '' THEN
							
						INSERT INTO 
							g_vue.solicitudes_atender
							(formulario
							, codigo_procesamiento
							, codigo_verificacion
							, solicitud
							, estado)
						VALUES 
							(v_formulario
							, v_codigo_procesamiento
							, v_codigo_verificacion
							, v_id_vue
							, 'Por atender');
							
					END IF;

				ELSIF v_tipo_solicitud = 'Zoosanitario' THEN 
			
					v_informe_requisitos := 'aplicaciones/exportacionZoosanitario/archivosRequisitos/' || v_identificador_cliente || '-' || v_id_solicitud || '.pdf';
					v_nombre_informe_requisitos := v_identificador_cliente || '-' || v_id_solicitud || '.pdf';
				
					UPDATE
						g_zoo_exportacion.zoo_exportaciones
					SET
						informe_requisitos = v_informe_requisitos
					WHERE
						id_zoo_exportacion::TEXT = v_id_solicitud;
				
					IF v_id_vue <> '' AND v_envio_vue <> 'tarifarioAntiguo' THEN
					
						v_formulario := '101-031-REQ';
						v_codigo_procesamiento := '120';
						v_codigo_verificacion := '21';
						
						INSERT INTO 
								g_vue.solicitudes_atender
								(formulario
								, codigo_procesamiento
								, codigo_verificacion
								, solicitud
								, estado)
							VALUES 
								(v_formulario
								, v_codigo_procesamiento
								, v_codigo_verificacion
								, v_id_vue
								, 'Por atender');
					
					END IF;
				
					UPDATE
						g_zoo_exportacion.zoo_exportaciones
					SET
						estado = v_estado_proceso_solicitud
					WHERE
						id_zoo_exportacion = v_id_solicitud;
						
				ELSIF v_tipo_solicitud = 'CLV' THEN
		
					IF v_id_vue <> '' AND v_envio_vue <> 'tarifarioAntiguo' THEN
					
						v_formulario := '101-047-REQ';
						v_codigo_procesamiento := '120';
						v_codigo_verificacion := '21';
						
						INSERT INTO 
								g_vue.solicitudes_atender
								(formulario
								, codigo_procesamiento
								, codigo_verificacion
								, solicitud
								, estado)
							VALUES 
								(v_formulario
								, v_codigo_procesamiento
								, v_codigo_verificacion
								, v_id_vue
								, 'Por atender');
					
					END IF;
				
					UPDATE
						g_clv.certificado_clv
					SET
						estado = v_estado_proceso_solicitud
					WHERE
						id_clv::TEXT = v_id_solicitud;
						
				ELSIF v_tipo_solicitud = 'FitosanitarioExportacion' THEN
		
					IF v_envio_vue <> 'tarifarioAntiguo' THEN
					
						v_estado_anterior_fitosanitario_exportacion := 'pago';
					
						UPDATE
							g_fitosanitario_exportacion.fitosanitario_exportaciones
						SET
							estado = v_estado_proceso_solicitud
							, estado_anterior = v_estado_anterior_fitosanitario_exportacion
							, observacion = 'Imposición de pago'
						WHERE
							id_fitosanitario_exportacion::TEXT = v_id_solicitud;
							
						IF v_id_vue <> '' THEN
						
							v_formulario := '101-034-REQ';
							v_codigo_procesamiento := '120';
							v_codigo_verificacion := '21';
							
							INSERT INTO 
									g_vue.solicitudes_atender
									(formulario
									, codigo_procesamiento
									, codigo_verificacion
									, solicitud
									, estado)
								VALUES 
									(v_formulario
									, v_codigo_procesamiento
									, v_codigo_verificacion
									, v_id_vue
									, 'Por atender');
						
						END IF;
					
					END IF;
				
				ELSIF v_tipo_solicitud = 'dossierPecuario' THEN
					
					INSERT INTO 
							g_dossier_pecuario_mvc.secuencia_revision(
							id_solicitud
							, fecha_creacion
							, identificador_ejecutor
							, nombre_ejecutor
							, perfil
							, id_provincia
							, provincia
							, estado_revision
							, accion)
					VALUES (v_id_solicitud::INTEGER
							, now()
							, v_identificador_recaudador
							, v_nombre_recaudador
							, 'Financiero'
							, v_id_provincia_recaudador
							, v_nombre_provincia_recaudador
							, v_estado_proceso_solicitud
							, 'Técnico financiero realiza asignación de tasa');
				
				ELSIF v_tipo_solicitud = 'ImportacionMuestrasVUE' THEN
		
					IF v_monto = 0 THEN
				
						v_estado_importacion_muestra := 'aprobado';
						
						SELECT
							codigo_tipo_solicitud
						FROM
							g_importacion_muestras.importacion_muestras
						WHERE
							id_importacion_muestras::TEXT = v_id_solicitud INTO v_codigo_tipo_solicitud_importacion_muestra;
						
						IF v_codigo_tipo_solicitud_importacion_muestra IN ('SA', 'SV') THEN					
							v_fecha_vigencia_importacion_muestra := TO_CHAR (now() + INTERVAL '3 month', 'YYYY-MM-DD');					
						ELSIF v_codigo_tipo_solicitud_importacion_muestra IN ('IAV', 'IAPB', 'IAF') THEN
							v_fecha_vigencia_importacion_muestra := TO_CHAR (now() + INTERVAL '6 month', 'YYYY-MM-DD');
						ELSIF v_codigo_tipo_solicitud_importacion_muestra = 'IAPQ' THEN
							v_fecha_vigencia_importacion_muestra := TO_CHAR (now() + INTERVAL '12 month', 'YYYY-MM-DD');
						END IF;
						
						UPDATE
							g_importacion_muestras.importacion_muestras
						SET
							fecha_inicio_vigencia = now()
							, fecha_fin_vigencia = v_fecha_vigencia_importacion_muestra
						WHERE
							id_importacion_muestras::TEXT = v_id_solicitud;
						
						v_formulario := '101-062-REQ';
						v_codigo_procesamiento := '320';
						v_codigo_verificacion := '21';
						
					ELSE
					
						IF v_envio_vue != 'tarifarioAntiguo' THEN
						
							v_estado_importacion_muestra := v_estado_proceso_solicitud;
							v_formulario := '101-062-REQ';
							v_codigo_procesamiento := '120';
							v_codigo_verificacion := '21';
							
						END IF;
					
					END IF;
				
					UPDATE
						g_importacion_muestras.importacion_muestras
					SET
						estado = v_estado_importacion_muestra
					WHERE
						id_importacion_muestras::TEXT = v_id_solicitud;
						
					IF v_id_vue <> '' THEN
							
						INSERT INTO 
							g_vue.solicitudes_atender
							(formulario
							, codigo_procesamiento
							, codigo_verificacion
							, solicitud
							, estado)
						VALUES 
							(v_formulario
							, v_codigo_procesamiento
							, v_codigo_verificacion
							, v_id_vue
							, 'Por atender');
							
					END IF;
				
				ELSE 

					d_mensaje := 'Tipo de proceso no definido (Asignación de monto solicitud)';
				
				END IF;
				
				-------------------------------
				--FIN ASIGNAR MONTO SOLICITUD--
				-------------------------------
				END asignacion_monto_solicitud;	
			
				<<generar_orden_pago>>
				BEGIN				

				--GENERAR NUMERO DOCUMENTO--
 				SELECT g_financiero.fs_generacion_numero_orden_pago() INTO v_numero_solicitud;
				
				--VALIDAR CLIENTE--
				--Cuando el tipo es de Otros y se registra por razon social--
				
				--Validar si existe el cliente--
				SELECT
					tipo_identificacion
					, razon_social
					, direccion
					, telefono
					, correo
				FROM
					g_financiero.clientes c
				WHERE
					identificador = v_identificador_cliente INTO r_datos_cliente;
					
				IF FOUND THEN
								
					UPDATE
						g_financiero.clientes
					SET
						razon_social = r_datos_cliente.razon_social
						, direccion = r_datos_cliente.direccion
						, telefono = r_datos_cliente.telefono
						, correo = r_datos_cliente.correo
					WHERE
						identificador = v_identificador_cliente;
				
				ELSE
				
					v_razon_social := v_da->'factura'->'cabecera'->>'razonSocial';
					v_direccion := v_da->'factura'->'cabecera'->>'direccion';
					v_telefono := v_da->'factura'->'cabecera'->>'telefono';
					v_correo := v_da->'factura'->'cabecera'->>'correo';
				
					IF v_tipo_cliente = '01' THEN
					
						v_identificador_cliente := v_ruc_cliente;
					
						IF LENGTH(v_identificador_cliente) = 13 THEN 
							v_tipo_cliente := '04';
						ELSE 
							v_tipo_cliente := '05';
						END IF;
						
						--Validar si existe el cliente--
						PERFORM
							identificador
						FROM
							g_financiero.clientes c
						WHERE
							identificador = v_identificador_cliente;
							
						IF FOUND THEN
						
							UPDATE
								g_financiero.clientes
							SET
								tipo_identificacion = v_tipo_cliente
							WHERE
								identificador = v_identificador_cliente;
						
						ELSE
						
							INSERT INTO g_financiero.clientes(identificador
														, tipo_identificacion
														, razon_social
														, direccion
														, telefono
														,correo)
							VALUES (v_identificador_cliente
									, v_tipo_cliente
									, v_razon_social
									, v_direccion
									, v_telefono
									, v_correo) RETURNING identificador INTO v_identificador_cliente;
						
						END IF;	
					
					ELSE --Cuando el tipo es de otros y registra un cliente--
					
						v_identificador_cliente := v_busqueda_cliente;
					
						INSERT INTO g_financiero.clientes(identificador
														, tipo_identificacion
														, razon_social
														, direccion
														, telefono
														,correo)
									VALUES (v_identificador_cliente
											, v_tipo_cliente
											, v_razon_social
											, v_direccion
											, v_telefono
											, v_correo) RETURNING identificador INTO v_identificador_cliente;
					
					END IF;
				
				END IF;
																
				--------------------------------------
				--INICIO GENERACION DE ORDEN DE PAGO--
				--------------------------------------
				
				IF v_metodo_pago = 'saldo' AND v_total_pagar > 0 THEN
					v_estado_orden_pago := 5;
				END IF;
				
				--Inicio valida si ya esiste una orden de pago y la actualiza--
				IF v_id_pago IS NOT NULL THEN

					UPDATE
						g_financiero.orden_pago
					SET
						estado = 9,
						observacion_eliminacion = 'Orden de pago actualizada, se realiza el cambio de estado de la orden de pago por el usuario ' || v_identificador_recaudador || '.'
					WHERE
						id_pago = v_id_pago;
				
				END IF;
				--Fin valida si existe una orden de pago y la actualiza--		
				
				--Inicio generacion de cabecera de orden de pago--
							
				--Inicio ruta orden pago pdf--
			    v_nombre_secuencia:= g_financiero.obtener_secuencia_orden_pago_diaria();
				v_fecha_partir1_doc := EXTRACT(HOUR FROM v_fecha_orden_pago);
				v_fecha_partir2_doc := EXTRACT(MINUTE FROM v_fecha_orden_pago);
                v_fecha_partir4_doc := EXTRACT(SECOND FROM v_fecha_orden_pago)+ v_nombre_secuencia;
				v_fecha_partir3_doc := v_fecha_partir1_doc - 1;
												
				v_ruta_fecha := TO_CHAR(v_fecha_orden_pago, 'YYYY/MM/DD');

				v_nombre_archivo := v_nombre_reporte || '_' || v_identificador_cliente
								|| '_' ||TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD')
								|| '_' || v_fecha_partir3_doc --(EXTRACT(HOUR FROM CURRENT_TIMESTAMP)-1)
								|| '_' || v_fecha_partir2_doc-- EXTRACT(MINUTE FROM CURRENT_TIMESTAMP)
								|| '_' || v_fecha_partir4_doc-- EXTRACT(SECOND FROM CURRENT_TIMESTAMP) 
								|| '.pdf';

				v_ruta_archivo_orden_pago := v_path_base_ruta_archivo || v_ruta_fecha || '/' || v_nombre_archivo;
				--Fin ruta orden pago pdf--				
				
				INSERT INTO g_financiero.orden_pago(identificador_operador, numero_solicitud, fecha_orden_pago, total_pagar, observacion, estado
													, localizacion, nombre_provincia, id_provincia, identificador_usuario, tipo_solicitud 
													, id_grupo_solicitud, id_solicitud, orden_pago, tipo_proceso, metodo_pago)
											VALUES (v_identificador_cliente, v_numero_solicitud, v_fecha_orden_pago, v_total_pagar, v_observacion, v_estado_orden_pago
													, v_localizacion_recaudador, v_nombre_provincia_recaudador, v_id_provincia_recaudador, v_identificador_recaudador, v_tipo_solicitud
													, v_id_grupo, v_id_solicitud, v_ruta_archivo_orden_pago, v_tipo_proceso, v_metodo_pago) RETURNING id_pago INTO v_n_id_pago;
				
				--Inicio actualizar porcentaje iva--
				SELECT 
					o.iva
				FROM  
					g_financiero.oficina_recaudacion o
				INNER JOIN g_financiero.distritos d ON o.ruc = d.ruc
				WHERE
					o.identificador_firmante = v_identificador_recaudador
					and d.estado = 'activo' INTO v_porcentaje_iva;
					
				UPDATE
					g_financiero.orden_pago
				SET
					porcentaje_iva = v_porcentaje_iva
				WHERE
					id_pago = v_n_id_pago;
				--Fin actualizacion porcentaje iva--
														
				--Fin generacion de cabecera de orden de pago--		
				
				-- Extraer y recorrer el array 'detalle'
				FOR v_detalle_item IN SELECT * FROM json_array_elements(v_da->'factura'->'detalle') LOOP
				
					v_id_deposito := v_detalle_item->>'idDeposito';
					v_cantidad := v_detalle_item->>'cantidad';
					v_descuento := v_detalle_item->>'descuento';
					v_precio_unitario := v_detalle_item->>'precioUnitario';
					v_iva_individual:= v_detalle_item->>'ivaIndividual';
					v_total_individual := v_detalle_item->>'totalIndividual';
					v_subsidio := v_detalle_item->>'subsidio';
					
					--Inicio obtener detalle de servicio--
					SELECT 
						concepto
					FROM 
						g_financiero.servicios
					WHERE
						id_servicio = v_id_deposito INTO v_concepto;

					--Fin obtener detalle de servicio--
					
					--Inicio registrar datos detalle pago--
					INSERT INTO g_financiero.detalle_pago(id_pago, id_servicio, concepto_orden, 
														cantidad, precio_unitario, descuento, iva, total, subsidio)
												VALUES (v_n_id_pago, v_id_deposito, v_concepto,
														v_cantidad, v_precio_unitario, v_descuento, v_iva_individual, v_total_individual, v_subsidio);
					--Fin registrar datos detalle_pago--
					
						
				END LOOP;
				
				--Inicio valida si el valor de la orden es cero--
				IF v_total_pagar = 0 THEN
					
					--Inicio actualizar datos de factura por total pagar cero--
					UPDATE
						g_financiero.orden_pago
					SET
						estado = 4
						, ruta_xml = 'Ningún archivo disponible.'
						, tipo_emision = 'NORMAL'
						, estado_sri = 'FINALIZADO'
						, comprobante_factura = 'NINGUNA'
						, clave_acceso = 'Ninguna'
						, identificador_firmante = v_identificador_recaudador
					WHERE
						id_pago = v_n_id_pago;
					
				END IF;
				--Fin valida si el valor de la orden es cero--
				
				-----------------------------------
				--FIN GENERACION DE ORDEN DE PAGO--
				-----------------------------------
				END generar_orden_pago;
				
				<<cambio_estado_solicitud>>
				BEGIN
				-------------------------------------
				--INICIO CAMBIO DE ESTADO SOLICITUD--
				-------------------------------------
						
				IF v_tipo_solicitud = 'Emisión de Etiquetas' THEN
				
					IF v_total_pagar = 0 THEN
						v_estado_solicitud = 'Aprobado';
					ELSE
						v_estado_solicitud = 'Por Pagar';
					END IF;
					
					--Inicio actualizar estado emision etiqueta--
					UPDATE 
						g_etiquetas.etiquetas
					SET 
						estado = v_estado_solicitud
					WHERE
						id_etiqueta::TEXT = v_id_solicitud;
					--Fin actualizar estado emision etiqueta--
					
				ELSIF v_tipo_solicitud = 'dossierPecuario' THEN
				
					IF v_total_pagar = 0 THEN
						v_estado_solicitud = 'Pagado';
					ELSE
						v_estado_solicitud = 'verificacion';
					END IF;
					
					--Inicio actualizar estado dossier pecuario--
					UPDATE
						g_dossier_pecuario_mvc.solicitud
					SET
						estado_solicitud = v_estado_solicitud,
						fecha_revision = now(),
						fase_revision = 'Pago',																					 
						observacion_revision = 'Proceso de Asignación de Tasa'
					WHERE
						id_solicitud::TEXT = v_id_solicitud;
					--Inicio actualizar estado dossier pecuario--
					
				ELSIF v_tipo_solicitud = 'dossierFertilizantes' THEN
				
					IF v_total_pagar = 0 THEN
						v_estado_solicitud = 'asignarTecnico';
					ELSE
						v_estado_solicitud = 'verificacion';
					END IF;
					
					--Inicio actualizar estado dossier fertilizante--
					UPDATE
						g_dossier_fertilizante.solicitudes
					SET
						estado = v_estado_solicitud
					WHERE
						id_solicitud::TEXT = v_id_solicitud;
					--Inicio actualizar estado dossier fertilizante--
					
				ELSIF v_tipo_solicitud = 'dossierPlaguicida' THEN
				
					IF v_total_pagar = 0 THEN
						v_estado_solicitud = 'asignarTecnico';
					ELSE
						v_estado_solicitud = 'verificacion';
					END IF;
					
					--Inicio actualizar estado dossier plaguicida--			
					UPDATE
						g_dossier_plaguicida.solicitudes
					SET
						estado = v_estado_solicitud
					WHERE
						id_solicitud::TEXT = v_id_solicitud;
					--Fin actualizar estado dossier plaguicida--			
					
				ELSIF v_tipo_solicitud = 'ensayoEficacia' THEN
				
					IF v_total_pagar = 0 THEN
						v_estado_solicitud = 'inspeccion';
					ELSE
						v_estado_solicitud = 'verificacion';
					END IF;
					
					--Inicio actualizar estado ensayo eficacia--
					UPDATE
						g_ensayo_eficacia_mvc.solicitudes
					SET
						estado = v_estado_solicitud
					WHERE
						id_solicitud::TEXT = v_id_solicitud;
					--Fin actualizar estado ensayo eficacia--
					
				ELSIF v_tipo_solicitud = 'modificacionProductoRia' THEN
				
					IF v_total_pagar = 0 THEN
						v_estado_solicitud = 'inspeccion';
					ELSE
						v_estado_solicitud = 'verificacion';
					END IF;
					
					--Inicio actualizar estado modificacion producto ria--
					UPDATE
						g_modificacion_productos.solicitudes_productos
					SET
						estado_solicitud_producto = v_estado_solicitud
					WHERE
						id_solicitud_producto::TEXT = v_id_solicitud;
					--Inicio actualizar estado modificacion producto ria--
					
					--Inicio obtener provincia de la solicitud--
					SELECT
						o.provincia
					FROM
						g_modificacion_productos.solicitudes_productos sp
					INNER JOIN g_operadores.operadores o ON o.identificador = sp.identificador_operador
					WHERE
						sp.id_solicitud_producto::TEXT = v_id_solicitud INTO v_nombre_provincia_solicitud;
					--Fin obtener provincia de la solicitud--
					
				ELSIF v_tipo_solicitud = 'registroProductoRia' THEN
				
					IF v_total_pagar = 0 THEN
						v_estado_solicitud = 'inspeccion';
					ELSE
						v_estado_solicitud = 'verificacion';
					END IF;
					
					--Inicio actualizar estado registro producto ria--
					UPDATE 
						g_registro_productos.solicitudes_registro_productos
					SET
						estado = v_estado_solicitud,
						fecha_confirmacion_pago = CASE WHEN v_estado_solicitud = 'inspeccion' THEN 
														now()
													ELSE 
														fecha_confirmacion_pago
													END
					WHERE
						id_solicitud_registro_producto::TEXT = v_id_solicitud;
					--Inicio actualizar estado registro producto ria--
					
					--Inicio obtener provincia de la solicitud--
					SELECT
						provincia_operador
					FROM
						g_registro_productos.solicitudes_registro_productos
					WHERE
						id_solicitud_registro_producto::TEXT = v_id_solicitud INTO v_nombre_provincia_solicitud;
					--Fin obtener provincia de la solicitud--		
					
				ELSIF v_tipo_solicitud = 'certificadoFito' THEN
					
					IF v_total_pagar = 0 THEN
						v_estado_solicitud = 'Aprobado';
					ELSE
						v_estado_solicitud = 'verificacion';
					END IF;
					
					--Inicio actualizar estado certificado fitosanitario--
					UPDATE
						g_certificado_fitosanitario.certificado_fitosanitario
					SET
						estado_certificado = v_estado_solicitud
						, fecha_aprobacion_certificado = CASE WHEN v_estado_solicitud = 'Aprobado' THEN 
															now()
														ELSE 
															fecha_aprobacion_certificado
														END
					WHERE
						id_certificado_fitosanitario::TEXT = v_id_solicitud;
					--Fin actualizar estado certificado fitosanitario--
					
					--Inicio obtener provincia de la solicitud--
					SELECT
						l.nombre as nombre_provincia
					FROM
						g_certificado_fitosanitario.certificado_fitosanitario cf
					INNER JOIN g_catalogos.localizacion l ON l.id_localizacion = cf.id_provincia_puerto_embarque
					WHERE
						cf.id_certificado_fitosanitario::TEXT = v_id_solicitud INTO v_nombre_provincia_solicitud;
					--Fin obtener provincia de la solicitud--
				
				ELSIF v_tipo_solicitud = 'certificacionBPA' THEN
				
					IF v_total_pagar = 0 THEN
						v_estado_solicitud = 'inspeccion';
					ELSE
						v_estado_solicitud = 'verificacion';
					END IF;
					
					--Inicio actualizar estado BPA--
					UPDATE
						g_certificacion_bpa.solicitudes
					SET
						estado = v_estado_solicitud
					WHERE
						id_solicitud::TEXT = v_id_solicitud;
					--Fin actualizar estado BPA--
					
				ELSIF v_tipo_solicitud IN ('mercanciasSinValorComercialImportacion') THEN
				
					IF v_total_pagar = 0 THEN
						v_estado_solicitud = 'aprobado';
					ELSE
						v_estado_solicitud = 'verificacion';
					END IF;
					
					--Inicio actualizar estado mercacias--
					UPDATE
						g_mercancias_valor_comercial.solicitudes
					SET
						estado = v_estado_solicitud
					WHERE
						id_solicitud::TEXT = v_id_solicitud;
					--Inicio actualizar estado mercacias--
				
				ELSIF v_tipo_solicitud = 'Lims' THEN
				
					IF v_total_pagar = 0 THEN
						v_estado_solicitud = 'inspeccion';
					ELSE
						v_estado_solicitud = 'verificacion';
					END IF;
					
					--Inicio actualizar estado Lims--
					UPDATE
						g_lims.orden_trabajo
					SET
						estado = v_estado_solicitud
					WHERE
						id_orden_trabajo::TEXT = v_id_solicitud;
					--Fin actualizar estado Lims--

				ELSE
				
					d_mensaje := 'Tipo de proceso no definido (Generación de orden de pago)';
					
				END IF;			
						
				----------------------------------
				--FIN CAMBIO DE ESTADO SOLICITUD--
				-----------------------------------		
				END cambio_estado_solicitud;		
			
			END IF; --Fin validacion orden pago en banred--
			
			--Inio envio de correo con orden de pago--
			IF v_total_pagar > 0 THEN
			
				SELECT
					razon_social
					, correo
				FROM
					g_financiero.clientes
				WHERE
					identificador = v_identificador_cliente INTO v_razon_social, v_correo;					
			
				v_datos_orden_pago := json_build_object(
										'idPago', v_n_id_pago,
										'tipoSolicitud', v_tipo_solicitud,
										'numeroSolicitud', v_numero_solicitud,
										'razonSocial', v_razon_social,
										'correoCliente', v_correo,
										'rutaOrdenPago', v_ruta_raiz_guia || v_ruta_archivo_orden_pago
									);
								
				CALL g_financiero.sp_envio_correo_orden_pago(v_datos_orden_pago);
				
			END IF;
			--Fin envio de correo con orden de pago--		
			
		END IF;--Fin proceso orden_pago--
					
		EXCEPTION
		
			WHEN others THEN
			-- Rollback the transaction and raise the exception
			no_error := FALSE;
			ROLLBACK;
			vSQLERRM := SQLERRM;
			IF vSQLERRM IS NOT NULL or vSQLERRM <> '' THEN
				INSERT INTO g_errores_procedimientos.errores (objeto, error_capturado, esquema, tablas)
				VALUES (v_da, vSQLERRM, 'g_finciero', 'orden_pago -> procedimiento sp_generar_orden_pago_procesos');
				COMMIT;
			END IF;
	END ;
	
	IF no_error THEN
	
		COMMIT;
		
		json_parametro := json_build_object('error', 0,
                                            'mensaje', 'Éxito',
                                            'idPago', v_n_id_pago,
                                            'rutaOrdenPago', v_ruta_archivo_orden_pago,
                                            'rutaFecha', v_ruta_fecha,
                                            'archivoSalida', v_ruta_archivo_orden_pago,
                                            'estado', 3,
                                            'provinciaSolicitud', v_nombre_provincia_solicitud);
                                    
		IF v_informe_requisitos IS NOT NULL THEN
        
			json_parametro := json_build_object('error', 0,
                                                'mensaje', 'Éxito',
                                                'idPago', v_n_id_pago,
                                                'rutaOrdenPago', v_ruta_archivo_orden_pago,
                                                'rutaFecha', v_ruta_fecha,
                                                'archivoSalida', v_ruta_archivo_orden_pago,
                                                'estado', 3,
                                                'provinciaSolicitud', v_nombre_provincia_solicitud,
                                                'informeRequisitos', v_informe_requisitos
												'nombreInformeRequisitos', v_nombre_informe_requisitos
												);
        END IF;
		
	ELSE
	
		json_parametro := (
		SELECT 
			CASE 
				WHEN vSQLERRM IS NULL OR vSQLERRM = '' THEN
				CONCAT('{"error":"1", "mensaje":"', d_mensaje, '"}')::json
			ELSE
				CONCAT('{"error":"2", "mensaje":"', vSQLERRM, '"}')::json
			END
		);
		
		ROLLBACK;
		
	END IF;
  	
END;
$$;

alter procedure sp_generar_orden_pago_procesos(inout json) owner to postgres;

