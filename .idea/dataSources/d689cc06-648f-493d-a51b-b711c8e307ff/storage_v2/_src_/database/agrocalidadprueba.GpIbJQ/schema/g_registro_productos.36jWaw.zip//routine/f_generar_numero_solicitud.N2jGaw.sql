create function f_generar_numero_solicitud(_tipo_solicitud text) returns text
    language plpgsql
as
$$
					DECLARE
						secuencial int;
						codigo_solicitud text;
						letra text;
						numero int;
						
						BEGIN
						
						CASE 
							WHEN _tipo_solicitud = 'fertilizantes' THEN 
								letra = 'F';
								numero = 8;
							WHEN _tipo_solicitud = 'bioplaguicidas' THEN 
								letra = 'BP';
								numero = 9;
							WHEN _tipo_solicitud = 'clonesfertilizantes' THEN 
								letra = 'CLONF';
								numero = 12;
							WHEN _tipo_solicitud = 'clonesplaguicidas' THEN 
								letra = 'CLONP';
								numero = 12;
								
						END CASE;
						
							SELECT 
								MAX(SUBSTRING (numero_solicitud , numero , 4)::integer) INTO secuencial
							FROM 
								g_registro_productos.solicitudes_registro_productos
							WHERE
								numero_solicitud ilike '%'||letra||'-%'
								and tipo_solicitud = _tipo_solicitud;
								
							IF FOUND THEN
								IF (secuencial IS NULL) THEN
									secuencial = 1;
								ELSE
									secuencial = secuencial + 1;
								END IF;
							ELSE
								secuencial = 1;
							END IF;
							
							codigo_solicitud := letra|| '-' || (SELECT to_char(now(), 'YYYY')) || '-' || trim(to_char(secuencial, '0000'));
							
							RETURN codigo_solicitud;
						END
	$$;

alter function f_generar_numero_solicitud(text) owner to postgres;

