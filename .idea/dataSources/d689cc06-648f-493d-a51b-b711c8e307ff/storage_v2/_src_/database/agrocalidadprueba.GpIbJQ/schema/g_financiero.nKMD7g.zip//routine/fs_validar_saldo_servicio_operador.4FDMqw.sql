create function fs_validar_saldo_servicio_operador(pidentificador_cliente character varying, ptotal_pagar double precision, OUT vsaldo_cliente double precision, OUT vresultado_saldo boolean) returns SETOF record
    language plpgsql
as
$$

/*
-------------------------------------------------------------------------
--  [g_financiero.fs_validar_saldo_servicio_operador]
--               
--  Esta funcion retorna valida si el saldo del operador cubre el valor del servicio
--
--  VERSION		AUTOR					FECHA			HU	
--	1			Kleber Armijos		05-09-2024	  Funcion generica que verifica el saldo disponible 
--				Milton Nivelo				      del cliente, para procesos de pago por saldo
--											
-------------------------------------------------------------------------
*/
DECLARE
	vresultado_saldo BOOLEAN := FALSE;
BEGIN	

	RETURN QUERY SELECT
                        saldo_disponible
                        , CASE WHEN saldo_disponible >= ptotal_pagar THEN
                                TRUE
                            ELSE
                                FALSE
                            END AS resultado_saldo
                    FROM (
                        SELECT 
                            saldo_disponible
                            , ROW_NUMBER() OVER (ORDER BY id_saldo DESC) as row_num
                        FROM 
                            g_financiero.saldos
                        WHERE 
                            identificador_operador = pidentificador_cliente
                            AND tipo_saldo = 'saldoAgr'
                    ) AS subquery
                    WHERE 
                        row_num = 1;
		
END;
$$;

alter function fs_validar_saldo_servicio_operador(varchar, double precision, out double precision, out boolean) owner to postgres;

