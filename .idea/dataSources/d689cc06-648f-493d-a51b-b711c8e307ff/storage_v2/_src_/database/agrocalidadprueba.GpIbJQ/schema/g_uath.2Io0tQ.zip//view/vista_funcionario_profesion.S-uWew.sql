create view vista_funcionario_profesion
            (identificador, nombre, apellido, regimen_laboral, tipo_contrato, coordinacion, direccion, gestion,
             nombre_puesto, provincia, canton, oficina, nivel_instruccion, num_certificado, titulo, carrera,
             institucion, estado, observaciones_rrhh)
as
SELECT DISTINCT fe.identificador,
                fe.nombre,
                fe.apellido,
                dc.regimen_laboral,
                dc.tipo_contrato,
                dc.coordinacion,
                dc.direccion,
                dc.gestion,
                dc.nombre_puesto,
                dc.provincia,
                dc.canton,
                dc.oficina,
                da.nivel_instruccion,
                da.num_certificado,
                da.titulo,
                da.carrera,
                da.institucion,
                da.estado,
                da.observaciones_rrhh
FROM g_uath.ficha_empleado fe,
     g_uath.datos_contrato dc,
     g_uath.datos_academicos da,
     g_estructura.funcionarios f
WHERE fe.identificador::text = dc.identificador::text
  AND dc.estado = 1
  AND fe.identificador::text = da.identificador::text
  AND fe.identificador::text = f.identificador::text;

alter table vista_funcionario_profesion
    owner to postgres;

