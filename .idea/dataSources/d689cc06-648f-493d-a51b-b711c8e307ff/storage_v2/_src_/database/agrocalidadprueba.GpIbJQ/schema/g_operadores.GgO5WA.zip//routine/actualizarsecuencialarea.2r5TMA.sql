create function actualizarsecuencialarea() returns text
    language plpgsql
as
$$
DECLARE
  area record;
  _provincia character varying;
  _secuencial character varying;
  _identificador character varying;
  
BEGIN
FOR area in (SELECT * FROM g_operadores.areas) 
	LOOP
		_provincia = (SELECT provincia FROM g_operadores.sitios WHERE id_sitio = area.id_sitio);
		_identificador = (SELECT identificador_operador FROM g_operadores.sitios WHERE id_sitio = area.id_sitio);
		_secuencial = (SELECT COALESCE(MAX(CAST(secuencial as  numeric(5))),0)+1 as valor FROM g_operadores.sitios s, g_operadores.areas a WHERE a.id_sitio = s.id_sitio and s.identificador_operador = _identificador and upper(s.provincia) = upper(_provincia) and a.codigo = area.codigo);

		_secuencial = lpad(_secuencial,2,'0');
		  UPDATE g_operadores.areas SET secuencial = _secuencial WHERE id_area = area.id_area;
		
		
	END LOOP;
	RETURN true;
END
$$;

alter function actualizarsecuencialarea() owner to postgres;

