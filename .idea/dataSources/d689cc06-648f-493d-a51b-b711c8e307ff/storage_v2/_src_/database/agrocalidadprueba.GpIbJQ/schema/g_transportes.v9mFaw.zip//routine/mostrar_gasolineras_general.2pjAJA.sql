create function mostrar_gasolineras_general(_fecha_inicio timestamp without time zone, _fecha_fin date, _localizacion text, _cantidad integer) returns SETOF g_transportes.gasolineras_general
    language plpgsql
as
$$
DECLARE
	query text;
BEGIN	
	return query EXECUTE '
			SELECT 
				SUM(c.valor_liquidacion) valor,
				g.id_gasolinera,
				g.nombre,
				g.direccion,
				g.telefono,
				g.localizacion
			FROM 
				g_transportes.combustible c,
				g_transportes.gasolineras g
			WHERE
				($1 is NULL or  c.fecha_liquidacion >= $1) and 
				($2 is NULL or  c.fecha_liquidacion <= $2) and
				($3 is NULL or $3 = g.localizacion) and 
				c.estado = 3 and
				c.gasolinera = g.id_gasolinera
			GROUP BY 
				g.id_gasolinera,
				g.nombre,
				g.direccion,
				g.telefono,
				g.localizacion
			ORDER BY valor desc
			LIMIT $4'
			
		using _fecha_inicio,_fecha_fin,_localizacion,_cantidad;
	
END;
$$;

alter function mostrar_gasolineras_general(timestamp, date, text, integer) owner to postgres;

