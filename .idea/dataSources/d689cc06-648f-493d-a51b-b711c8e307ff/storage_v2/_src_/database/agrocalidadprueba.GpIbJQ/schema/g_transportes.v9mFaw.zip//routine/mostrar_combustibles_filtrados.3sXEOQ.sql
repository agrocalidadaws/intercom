create function mostrar_combustibles_filtrados(_localizacion text, _placa text, _tipo_combustible text, _gasolinera integer, _fecha_inicio timestamp without time zone, _fecha_fin timestamp without time zone, _estado integer) returns SETOF g_transportes.combustible
    language plpgsql
as
$$
DECLARE
	query text;
BEGIN	
	return query EXECUTE '	
		SELECT
			*
		FROM 
			g_transportes.combustible c
		WHERE 
			($1 is NULL or placa like $1) and 
			($2 is NULL or tipo_combustible like $2) and
			($3 is NULL or gasolinera = $3) and 
			($4 is NULL or estado = $4) and 
			($5 is NULL or fecha_solicitud >= $5) and 
			($6 is NULL or fecha_solicitud <= $6) and
			($7 is NULL or $7 = localizacion) 
			
		ORDER BY
			c.fecha_solicitud'
		using _placa,_tipo_combustible,_gasolinera,_estado,_fecha_inicio,_fecha_fin,_localizacion;
	
END;
$$;

alter function mostrar_combustibles_filtrados(text, text, text, integer, timestamp, timestamp, integer) owner to postgres;

