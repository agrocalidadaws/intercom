create view vista_matriz_poa
            (objetivo, id_objetivo, proceso, id_proceso, subproceso, id_subproceso, actividad, codigo_actividad,
             id_area, nombre, estado, programacion1, programacion2, programacion3, programacion4, cobertura,
             numero_beneficiados, poblacion, responsable, medios_verificacion, fecha_creacion, id_item_planta, anio)
as
SELECT ob.descripcion                      AS objetivo,
       pl.id_objetivo,
       pr.descripcion                      AS proceso,
       pl.id_proceso,
       su.descripcion                      AS subproceso,
       pl.id_subproceso,
       ac.descripcion                      AS actividad,
       pl.codigo_actividad,
       fu.id_area,
       ar.nombre,
       mp.estado,
       mpoa.programacion1,
       mpoa.programacion2,
       mpoa.programacion3,
       mpoa.programacion4,
       mpoa.cobertura,
       mpoa.numero_beneficiados,
       mpoa.descripcion_poblacion_objetivo AS poblacion,
       mpoa.responsable_subproceso         AS responsable,
       mpoa.medios_verificacion,
       mpoa.fecha_creacion,
       pl.id_item                          AS id_item_planta,
       pl.anio
FROM g_poa.planta pl,
     g_poa.objetivos_estrategicos ob,
     g_poa.procesos pr,
     g_poa.subprocesos su,
     g_poa.actividades ac,
     g_estructura.funcionarios fu,
     g_estructura.area ar,
     g_poa.matriz_presupuesto mp,
     g_poa.matriz_poa mpoa
WHERE pl.id_objetivo = ob.id_objetivo
  AND pl.id_proceso = pr.id_proceso
  AND pl.id_subproceso = su.id_subproceso
  AND pl.id_actividad = ac.id_actividad
  AND pl.identificar_usuario::text = fu.identificador::text
  AND fu.id_area::text = ar.id_area::text
  AND mp.id_item_planta = pl.id_item
  AND mp.estado = 4
  AND pl.estado = 4
  AND mpoa.id_item_poa = pl.id_item
GROUP BY pl.id_item, mp.id_item_planta, ob.descripcion, pl.id_objetivo, pr.descripcion, pl.id_proceso, su.descripcion,
         pl.id_subproceso, ac.descripcion, pl.codigo_actividad, fu.id_area, ar.nombre, mp.estado, mpoa.programacion1,
         mpoa.programacion2, mpoa.programacion3, mpoa.programacion4, mpoa.cobertura, mpoa.numero_beneficiados,
         mpoa.descripcion_poblacion_objetivo, mpoa.responsable_subproceso, mpoa.medios_verificacion,
         mpoa.fecha_creacion;

alter table vista_matriz_poa
    owner to postgres;

