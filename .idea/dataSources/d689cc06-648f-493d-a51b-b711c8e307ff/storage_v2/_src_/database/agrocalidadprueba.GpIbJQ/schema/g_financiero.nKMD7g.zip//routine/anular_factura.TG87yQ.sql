create function anular_factura(p_ruc text, p_numero_establecimiento text, p_numero_factura text, p_numero_glpi integer, p_motivo_anulacion text, p_identificador_usuario text) returns jsonb
    language plpgsql
as
$$
DECLARE
    -- Declaración de variables
    datos_factura record;
    datos_deposito record;
    v_valor_acreditar double precision;
    v_saldo_actual double precision;
    v_valor_total double precision;
    resultado text;
    mensaje text;
BEGIN
    -- Lógica de la función

    resultado := 'Error';

    SELECT 
        op.total_pagar,
        op.identificador_operador,
        op.id_pago,
        op.estado,
        op.estado_sri,
        op.tipo_solicitud,
		op.utilizado,
		now()::date - op.fecha_autorizacion::date AS tiempo_vigencia,
        array_agg(DISTINCT dfp.institucion_bancaria) AS institucion_bancaria,
        CASE WHEN ('Pago en nota de credito') = ANY (array_agg(DISTINCT dfp.institucion_bancaria)) THEN 'SI' ELSE 'NO' END AS bandera_nota_credito
    FROM 
        g_financiero.orden_pago op
    INNER JOIN g_financiero.detalle_forma_pago dfp ON dfp.id_pago = op.id_pago
    WHERE 
        op.numero_establecimiento = p_numero_establecimiento
        AND op.numero_factura = p_numero_factura
        AND op.ruc_institucion = p_ruc
    GROUP BY op.total_pagar, op.identificador_operador, op.id_pago, op.estado, op.estado_sri, op.tipo_solicitud, op.utilizado INTO datos_factura;
            
    IF FOUND THEN
        
        IF(datos_factura.estado = 4 AND datos_factura.estado_sri = 'AUTORIZADO') THEN
            
            IF (datos_factura.tipo_solicitud = 'Otros') THEN
			
				IF (datos_factura.tiempo_vigencia <= 14) THEN
            
					IF (datos_factura.utilizado = false) THEN
					
						IF datos_factura.bandera_nota_credito = 'SI' THEN
							
							SELECT
								SUM(valor_deposito)
							FROM
								g_financiero.detalle_forma_pago 
							WHERE
								id_pago = datos_factura.id_pago
								AND institucion_bancaria NOT IN ('Pago en nota de credito') INTO v_valor_acreditar;
							
							FOR datos_deposito IN (SELECT * FROM g_financiero.detalle_forma_pago WHERE id_pago = datos_factura.id_pago AND institucion_bancaria IN ('Pago en nota de credito')) LOOP
								
								UPDATE 
									g_financiero.detalle_forma_pago
								SET 
									observacion = 'Nota de crédito con id ' || datos_deposito.id_nota_credito || ' eliminada por anulación GLPI # ' || p_numero_glpi
									, id_nota_credito = null
								WHERE 
									id_detalle_pago = datos_deposito.id_detalle_pago;
								
							END LOOP;

							RAISE NOTICE '% %', 'Si tiene nota credito', 'valor acreditar' || v_valor_acreditar;
						ELSE                        
							v_valor_acreditar := datos_factura.total_pagar;
							RAISE NOTICE '% %', 'No tiene nota credito', 'valor acreditar' || v_valor_acreditar;
						END IF;
						
						--Obtener saldo actual del operador
						SELECT 
							ts.saldo_disponible
						FROM 
							g_financiero.saldos ts
							INNER JOIN (SELECT 
							MAX(id_saldo) as id_saldo, identificador_operador
							FROM 
							g_financiero.saldos
							GROUP BY identificador_operador) tms ON tms.id_saldo = ts.id_saldo
						WHERE
							ts.identificador_operador = datos_factura.identificador_operador INTO v_saldo_actual;
							
						IF NOT FOUND THEN
							v_saldo_actual := 0;					
						END IF;
						
						--Sumar saldo actual mas total de la factura
						
						v_valor_total := ROUND(CAST((v_valor_acreditar + v_saldo_actual) AS NUMERIC), 2);
						
						RAISE NOTICE '% %', 'total', v_valor_total;
						
						INSERT INTO g_financiero.saldos(id_pago, fecha_deposito, valor_ingreso, saldo_disponible, identificador_operador, tipo_saldo, observacion_saldo)
									VALUES (datos_factura.id_pago, now(), v_valor_acreditar, v_valor_total, datos_factura.identificador_operador, 'saldoAgr', 'Saldo acreditado por anulación GLPI # ' || p_numero_glpi);
						
						INSERT INTO g_financiero.anulacion_factura(id_pago, identificador_usuario, numero_glpi, motivo_anulacion, fecha_anulacion_factura) VALUES (datos_factura.id_pago, p_identificador_usuario, p_numero_glpi, p_motivo_anulacion, now());
						
						UPDATE 
							g_financiero.orden_pago
						SET 
							estado = 9
							, estado_sri = 'ANULADO'
							, observacion_eliminacion = 'Anulación realizada en base a GLPI # ' || p_numero_glpi
						WHERE 
							id_pago = datos_factura.id_pago;

						resultado := 'Exito';
						mensaje:= 'Se realizó con éxito la anulación de la factura.';
					
					ELSE
						mensaje := 'La factura se encuentra en estado utilizada.';
					END IF;
					
				ELSE
					mensaje := 'La factura se encuentra fuera del rango de 15 días.';
				END IF;
                
            ELSE
                mensaje := 'Solo se pueden anular facturas de tipo "Otros"';
            END IF;        
            
        ELSE

            IF(datos_factura.estado = 9 AND datos_factura.estado_sri = 'ANULADO') THEN
                mensaje := 'La factura ya se encuentra ANULADA.';            
            ELSE
                mensaje := 'La factura no se encuentra autorizada por el SRI.';        
            END IF;

        END IF;
            
    ELSE
        mensaje := 'La factura no existe.';                
    END IF;
        
    RETURN jsonb_build_object('resultado', resultado, 'mensaje', mensaje);

END;
$$;

alter function anular_factura(text, text, text, integer, text, text) owner to postgres;

