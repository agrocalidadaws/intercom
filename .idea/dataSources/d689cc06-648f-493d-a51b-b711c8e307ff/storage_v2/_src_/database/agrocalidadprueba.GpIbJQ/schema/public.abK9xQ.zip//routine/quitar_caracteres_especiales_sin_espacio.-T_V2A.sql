create function quitar_caracteres_especiales_sin_espacio(character varying) returns text
    language sql
as
$$
SELECT TRANSLATE
($1,
'áàâãäéèêëíìïóòôõöúùûüÁÀÂÃÄÉÈÊËÍÌÏÓÒÔÕÖÚÙÛÜçÇñÑ',
'aaaaaeeeeiiiooooouuuuAAAAAEEEEIIIOOOOOUUUUcCnn');
$$;

alter function quitar_caracteres_especiales_sin_espacio(varchar) owner to postgres;

