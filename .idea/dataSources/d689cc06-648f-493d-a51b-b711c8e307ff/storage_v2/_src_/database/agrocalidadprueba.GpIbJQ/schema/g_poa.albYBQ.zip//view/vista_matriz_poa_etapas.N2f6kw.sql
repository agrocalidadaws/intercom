create view vista_matriz_poa_etapas
            (objetivo, id_objetivo, proceso, id_proceso, subproceso, id_subproceso, actividad, codigo_actividad,
             id_area, nombre, estado, anio)
as
SELECT ob.descripcion AS objetivo,
       pl.id_objetivo,
       pr.descripcion AS proceso,
       pl.id_proceso,
       su.descripcion AS subproceso,
       pl.id_subproceso,
       ac.descripcion AS actividad,
       pl.codigo_actividad,
       fu.id_area,
       ar.nombre,
       pl.estado,
       pl.anio
FROM g_poa.planta pl,
     g_poa.objetivos_estrategicos ob,
     g_poa.procesos pr,
     g_poa.subprocesos su,
     g_poa.actividades ac,
     g_estructura.funcionarios fu,
     g_estructura.area ar
WHERE pl.id_objetivo = ob.id_objetivo
  AND pl.id_proceso = pr.id_proceso
  AND pl.id_subproceso = su.id_subproceso
  AND pl.id_actividad = ac.id_actividad
  AND pl.identificar_usuario::text = fu.identificador::text
  AND fu.id_area::text = ar.id_area::text
  AND (pl.estado = ANY (ARRAY [1, 2, 3, 4]))
GROUP BY pl.id_item, ob.descripcion, pl.id_objetivo, pr.descripcion, pl.id_proceso, su.descripcion, pl.id_subproceso,
         ac.descripcion, pl.codigo_actividad, fu.id_area, ar.nombre;

alter table vista_matriz_poa_etapas
    owner to postgres;

