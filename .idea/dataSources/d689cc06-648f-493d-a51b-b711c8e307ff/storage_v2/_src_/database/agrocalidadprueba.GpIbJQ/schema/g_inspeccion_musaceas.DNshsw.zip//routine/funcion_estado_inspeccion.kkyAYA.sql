create function funcion_estado_inspeccion(_estado character varying, _id_solicitud_inspeccion integer, _identificador_registro character varying) returns void
    language plpgsql
as
$$
BEGIN
	INSERT INTO g_inspeccion_musaceas.detalle_estado_solicitud(estado,id_solicitud_inspeccion,identificador_registro)
		VALUES (_estado,_id_solicitud_inspeccion,_identificador_registro);
		
END;
$$;

alter function funcion_estado_inspeccion(varchar, integer, varchar) owner to postgres;

