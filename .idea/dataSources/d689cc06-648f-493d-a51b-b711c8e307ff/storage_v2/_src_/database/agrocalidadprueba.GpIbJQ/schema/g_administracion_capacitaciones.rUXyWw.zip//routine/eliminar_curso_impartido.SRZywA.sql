create function eliminar_curso_impartido(idcursointeger integer) returns character varying
    language plpgsql
as
$$

declare 
	mensaje character varying:='';
idCursoImpartido integer:=0;
BEGIN

idCursoImpartido = (Select id_curso_impartido From g_administracion_capacitaciones.cursos_impartidos Where id_curso_impartido = idCursointeger);

IF idCursoImpartido > 0 THEN
 	Delete From g_administracion_capacitaciones.temas_ejecutados Where id_curso_impartido = idCursoImpartido;
 	Delete From g_administracion_capacitaciones.capacitadores Where id_curso_impartido = idCursoImpartido;
 	Delete From g_administracion_capacitaciones.publico_asistente Where id_curso_impartido = idCursoImpartido;
 	Delete From g_administracion_capacitaciones.publico_meta Where id_curso_impartido = idCursoImpartido;
 	Delete From g_administracion_capacitaciones.cursos_impartidos Where id_curso_impartido = idCursoImpartido;
	mensaje = 'exito';
ELSE
	mensaje = 'error';
END IF;
		
return mensaje;

END;
$$;

alter function eliminar_curso_impartido(integer) owner to postgres;

