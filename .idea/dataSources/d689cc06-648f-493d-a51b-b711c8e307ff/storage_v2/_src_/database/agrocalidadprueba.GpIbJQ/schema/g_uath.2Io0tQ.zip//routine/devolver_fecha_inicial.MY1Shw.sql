create function devolver_fecha_inicial(_identificador text)
    returns TABLE(descripcion text, num double precision, fecha_inicial date, fecha_final date, direcc character varying, puesto character varying, remune double precision)
    language plpgsql
as
$$
DECLARE
	contador float;
	cont RECORD;
	fecha date;
	bandera text;
BEGIN

--crear tabla con fechas de inicio y fin de los contratos registrados   
CREATE TEMP TABLE tablay ON COMMIT DROP AS
SELECT
		dc.fecha_inicio,
		dc.fecha_fin
	    FROM
		g_uath.datos_contrato dc
	    WHERE
		identificador=$1 and
		tipo_contrato not in ('Subrogación','Encargo')
	    ORDER BY
		1 DESC;
		                   
CREATE TEMP SEQUENCE secuen2 start with 1;
CREATE TEMP TABLE tabla2 ON COMMIT DROP AS
SELECT
		fecha_inicio,
		fecha_fin,
		nextval('secuen2') AS contador2 
	    FROM
		tablay;
DROP SEQUENCE secuen2;
DROP TABLE tablay;

--crear tabla con infomacion de contrato actual
CREATE TEMP TABLE tablap ON COMMIT DROP AS
SELECT
		fecha_inicio,
		fecha_fin,
		direccion,
		nombre_puesto,
		remuneracion,
		estado
	    FROM
		g_uath.datos_contrato
	    WHERE
		identificador=$1 and
		
		estado = 1
	    ORDER BY
		1 DESC; 

--crear tabla con fechas de inicio y fin de contrato	
CREATE TEMP TABLE tablax ON COMMIT DROP AS
SELECT
		fecha_inicio,
		fecha_fin,
		estado
	    FROM
		g_uath.datos_contrato
	    WHERE
		identificador=$1 and
		tipo_contrato not in ('Subrogación','Encargo') and
		estado <> 1
	    ORDER BY
		1 DESC;  
	
CREATE TEMP SEQUENCE secuen1 start with 1;
CREATE TEMP TABLE tabla1 ON COMMIT DROP AS
SELECT
		fecha_inicio,
		fecha_fin,
		estado,
		nextval('secuen1') AS contador1
	    FROM
		tablax;   
DROP SEQUENCE secuen1;      
DROP TABLE tablax;
contador = (SELECT count(*) FROM tabla2); 

IF contador = 1 THEN
RETURN QUERY 
	select 
		'unico'::text as descripcion,
		'1'::double precision  as num,
		fecha_inicio as fecha_inicial,
		fecha_fin as fecha_final,
		direccion as direcc,
		nombre_puesto as puesto,
		remuneracion as remune
	 from 
		tablap; 
	
END IF;
IF contador = 2 THEN
        CREATE TEMP TABLE verificar ON COMMIT DROP AS
	select 
		(case when (extract(days from (tb2.fecha_inicio::timestamp  -  tb1.fecha_fin::timestamp))) <= 15 then 'continuo'
		when (extract(days from (tb2.fecha_inicio::timestamp  -  tb1.fecha_fin::timestamp))) > 15 then 'descontinuo' 
		end) as descripcion, tb1.fecha_inicio
	 from 
		tabla2 tb2, tabla1 tb1 
	 where 
		tb2.contador2 = tb1.contador1;
       --**************************************************************
	FOR cont IN select * from verificar LOOP
		IF cont.descripcion = 'continuo' THEN
			
			RETURN QUERY 
				select 
					'continuo 2'::text as descripcion,
					'1'::double precision  as num,
					cont.fecha_inicio as fecha_inicial,
					tbp.fecha_fin as fecha_final,
					tbp.direccion as direcc,
					tbp.nombre_puesto as puesto,
					tbp.remuneracion as remune
				 from 
					tablap tbp, tabla1 tb1;		
				
		ELSE 
			RETURN QUERY 
			select 
				'descontinuo 2'::text as descripcion,
				'2'::double precision  as num,
				fecha_inicio as fecha_inicial,
				fecha_fin as fecha_final,
				direccion as direcc,
				nombre_puesto as puesto,
				remuneracion as remune
			 from 
				tablap;	
				
		END IF;	
	END LOOP;
END IF;
IF contador > 2 THEN
	CREATE TEMP TABLE verificar ON COMMIT DROP AS
	select 
		(case when (extract(days from (tb2.fecha_inicio::timestamp  -  tb1.fecha_fin::timestamp))) <= 15 then 'continuo'
		when (extract(days from (tb2.fecha_inicio::timestamp  -  tb1.fecha_fin::timestamp))) > 15 then 'descontinuo' 
		end) as descripcion,
		tb2.fecha_inicio,
		tb1.fecha_inicio as fecha_tb1
	 from 
		tabla2 tb2, tabla1 tb1 
	 where 
		tb2.contador2= tb1.contador1;
		
	--***************************************************************************
	bandera = 'SI';
	FOR cont IN select * from verificar LOOP

		IF cont.descripcion = 'descontinuo' THEN
			bandera = 'NO';
			RETURN QUERY 
				select 
					'descontinuo 3'::text as descripcion,
					'1'::double precision  as num,
					cont.fecha_inicio as fecha_inicial,
					tbp.fecha_fin as fecha_final,
					tbp.direccion as direcc,
					tbp.nombre_puesto as puesto,
					tbp.remuneracion as remune
				 from 
					tablap tbp;	
				
				
			RETURN;				

		ELSE 
			fecha = cont.fecha_tb1; 
			
		END IF;	
	END LOOP;
	--***************************************************************************
	IF bandera = 'SI' THEN 
		RETURN QUERY 
			select 
				'continuo 3'::text as descripcion,
				'1'::double precision  as num,
				fecha as fecha_inicial,
				tbp.fecha_fin as fecha_final,
				tbp.direccion as direcc,
				tbp.nombre_puesto as puesto,
				tbp.remuneracion as remune
			 from 
				tablap tbp;
			
	END IF; 
	--***************************************************************************

END IF;

 	
END;
$$;

alter function devolver_fecha_inicial(text) owner to postgres;

