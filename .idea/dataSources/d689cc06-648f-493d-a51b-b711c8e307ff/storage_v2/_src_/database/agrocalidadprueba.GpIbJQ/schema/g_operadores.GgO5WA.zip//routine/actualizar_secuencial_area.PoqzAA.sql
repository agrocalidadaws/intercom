create function actualizar_secuencial_area() returns trigger
    language plpgsql
as
$$
DECLARE
  area record;
  _provincia character varying;
  _secuencial character varying;
  _identificador character varying;
  
BEGIN

UPDATE g_operadores.areas SET secuencial = null WHERE  id_sitio = NEW.id_sitio;

FOR area in (SELECT * FROM g_operadores.areas WHERE id_sitio = NEW.id_sitio) 
	LOOP
		_provincia = (SELECT provincia FROM g_operadores.sitios WHERE id_sitio = area.id_sitio);
		_identificador = (SELECT identificador_operador FROM g_operadores.sitios WHERE id_sitio = area.id_sitio);
		_secuencial = (SELECT COALESCE(MAX(CAST(secuencial as  numeric(5))),0)+1 as valor FROM g_operadores.sitios s, g_operadores.areas a WHERE a.id_sitio = s.id_sitio and s.identificador_operador = _identificador and rtrim(upper(s.provincia),' ') = rtrim(upper(_provincia),' ') and a.codigo = area.codigo);

		_secuencial = lpad(_secuencial,2,'0');
		  UPDATE g_operadores.areas SET secuencial = _secuencial WHERE id_area = area.id_area;
	END LOOP;
	RETURN NEW;
END
$$;

alter function actualizar_secuencial_area() owner to postgres;

