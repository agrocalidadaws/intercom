create function calcular_orden_siguiente(_tabla text, _campo text, _codigo integer) returns text
    language plpgsql
as
$$
	DECLARE
		valor text;
BEGIN

	EXECUTE 'SELECT max(orden)+1 as siguiente FROM ' || _tabla || ' WHERE ' || _campo || ' = ' || _codigo  INTO valor; 
	IF valor IS NOT NULL then
		RETURN valor;
	ELSE
		RETURN 1;
	END IF;

END;
$$;

alter function calcular_orden_siguiente(text, text, integer) owner to postgres;

