create function fs_retorna_reporte_operadores_parametrizado(pfecha_creacion1 date, pfecha_creacion2 date, pcaso_operacion character varying, OUT identificador character varying, OUT razon_social text, OUT nombre_representante text, OUT apellido_tecnico text, OUT direccion text, OUT telefonos text, OUT celulares text, OUT correo text, OUT id_tipo_operacion integer, OUT estado character varying, OUT observacion text, OUT id_producto integer, OUT id_vue character varying, OUT nombre_pais_operaciones character varying, OUT nombre_comun text, OUT subtipo_producto character varying, OUT tipo_producto character varying, OUT tipo_operacion text, OUT fecha_creacion timestamp without time zone, OUT fecha_modificacion timestamp without time zone, OUT fecha_aprobacion timestamp without time zone, OUT nombre_area text, OUT tipo_area text, OUT superficie_utilizada text, OUT estado_area character varying, OUT codigo_area_areas text, OUT codigo_mag character varying, OUT nombre_sitio text, OUT direccion_sitio text, OUT telefono text, OUT referencia text, OUT parroquia character varying, OUT canton character varying, OUT provincia character varying, OUT codigo_sitio_sitios text, OUT latitud character varying, OUT longitud character varying, OUT superficie_total text, OUT codigo_sitio text, OUT codigo_area text, OUT nombre_pais character varying) returns SETOF record
    language plpgsql
as
$$
declare
--VARIABLES--
	codigo_tipo_operacion integer[]:=null;
	codigo_tipo_producto integer[]:=null;
	codigo_subtipo_producto integer[]:=null;
	bandera character varying:= null;
	query1 Text;
BEGIN
	--'Operaciones '
	if('Empresas Fertilizantes'=$3) then 
		codigo_tipo_operacion:=array (SELECT * FROM (VALUES (87),(88),(89),(90),(94),(98),(101),(102)) AS tabla (id_opciones));
		bandera='todos';
	end if;
	if('RO Viveros'=$3) then 
		codigo_tipo_operacion:=array (SELECT * FROM (VALUES (42),(45),(57),(58),(93)) AS tabla (id_opciones));
		bandera='todos';
	end if;
	if('RO Ferias y Comercialización SA'=$3) then 
		codigo_tipo_operacion:=array (SELECT * FROM (VALUES (78),(19),(46),(51),(81)) AS tabla (id_opciones));
		bandera='todos';
	end if;
	--'REPORTE DE PRODUCTOR AVICOLAS Y PORCINOS'
	if('RO_Productor_Ave_Porcino'=$3) then 
		codigo_tipo_operacion:=array (SELECT * FROM (VALUES (26),(24)) AS tabla (id_opciones));
		codigo_tipo_producto:=array (SELECT * FROM (VALUES (184),(186)) AS tabla (id_tipo_producto));
		bandera:= 'REPORTE_DE_PRODUCTOR_AVICOLAS_PORCINOS';
	end if;
	if('RO Predios de Cuarentena SA'=$3) then 
		codigo_tipo_operacion:=array (SELECT * FROM (VALUES (47)) AS tabla (id_opciones));
		codigo_subtipo_producto:=array (SELECT * FROM (VALUES (736),(377),(770),(772),(783),(716)) AS tabla (id_opciones)); 
		bandera:='CUARENTENA_PORCINOS_AVES_GRANJAS_INCUBACIÓN';
	end if;
	if('CON FECHAS'=$3) then 
		codigo_tipo_operacion:=array (SELECT * FROM (VALUES (1), (2), (3)) AS tabla (id_opciones));
	end if;
	if('CON PITAHAYA'=$3) then 
		codigo_tipo_operacion:=array (SELECT * FROM (VALUES (2173),(31076)) AS tabla (id_opciones));
		bandera:='CON_PITAHAYA';
	end if;
	if('RO Apícola'=$3) then 
		codigo_tipo_operacion:=array (SELECT * FROM (VALUES (105),(106),(107)) AS tabla (id_opciones));
		bandera:='PRODUCTOR_APICOLA_SELECTOR_POLINIZADOR';
	end if;
	if('RO Material Reproductivo'=$3) then 
		codigo_tipo_operacion:=array (SELECT * FROM (VALUES (108),(109),(110),(111)) AS tabla (id_opciones));
	    bandera:='MATERIAL_REPRODUCTIVO';
	end if;
-- 	if('EMPRESAS FERTILIZANTES'=$3) then 
-- 		codigo_tipo_operacion:=array (SELECT * FROM (VALUES (1), (2), (3)) AS tabla (id_opciones));
-- 	end if;
	if('Empresas Agrícolas'=$3) then 
		codigo_tipo_operacion:=array (SELECT * FROM (VALUES (1),(2),(3),(4),(5),(6),(32),(33),(41),(84)) AS tabla (id_opciones));
		bandera:='todos';
	end if;
	if('Empresas Pecuarias'=$3) then 
		codigo_tipo_operacion:=array (SELECT * FROM (VALUES (38),(39),(34),(35),(36),(37),(40),(77)) AS tabla (id_opciones));
		bandera:='todos';
	end if;
	if('RO Centros de Faenamiento'=$3) then 
		codigo_tipo_operacion:=array (SELECT * FROM (VALUES (78)) AS tabla (id_opciones));
		bandera:='todos';
	end if;
	if('RO Industria Láctea'=$3) then 
		codigo_tipo_operacion:=array (SELECT * FROM (VALUES (119)) AS tabla (id_opciones));
		bandera:='todos';
	end if;
	if('RO Acopio de Leche Cruda'=$3) then 
		codigo_tipo_operacion:=array (SELECT * FROM (VALUES (103)) AS tabla (id_opciones));
		bandera:='todos';
	end if;
	if('RO Almacenistas RIA'=$3) then 
		codigo_tipo_operacion:=array (SELECT * FROM (VALUES (43),(44),(91),(115)) AS tabla (id_opciones));
		bandera:='todos';
	end if;
	if('RO Centros de Propagación de Especies Vegetales'=$3) then 
		codigo_tipo_operacion:=array (SELECT * FROM (VALUES (127),(128),(45),(57)) AS tabla (id_opciones));
	    bandera:='todos';
	end if;
	if('Exportación de Mercancías Pecuarias'=$3) then 
		codigo_tipo_operacion:=array (SELECT * FROM (VALUES (117),(118)) AS tabla (id_opciones));
	    bandera:='todos';
	end if;
	if('RO Ferias de Exposición Animal'=$3) then 
		codigo_tipo_operacion:=array (SELECT * FROM (VALUES (81)) AS tabla (id_opciones));
		bandera:='todos';
	end if;
	if('RO Predios de Cuarentena SV'=$3) then 
		codigo_tipo_operacion:=array (SELECT * FROM (VALUES (8)) AS tabla (id_opciones));
		bandera:='todos';
	end if;
	
	--de aqui es lo nuevo dependiendo del tipo de area

	if('IAF'=$3) then 
		codigo_tipo_operacion:=array (SELECT tp.id_tipo_operacion FROM g_catalogos.tipos_operacion tp	WHERE tp.id_area='IAF' order by tp.id_tipo_operacion asc );
	    bandera:='TipoArea';
	end if;
	if('AI'=$3) then 
		codigo_tipo_operacion:=array (SELECT tp.id_tipo_operacion FROM g_catalogos.tipos_operacion tp	WHERE tp.id_area='AI' order by tp.id_tipo_operacion asc);
	    bandera:='TipoArea';
	end if;
	if('LT'=$3) then 
		codigo_tipo_operacion:=array (SELECT tp.id_tipo_operacion FROM g_catalogos.tipos_operacion tp	WHERE tp.id_area='LT' order by tp.id_tipo_operacion asc);
	    bandera:='TipoArea';
	end if;
	if('SV'=$3) then 
		codigo_tipo_operacion:=array (SELECT tp.id_tipo_operacion FROM g_catalogos.tipos_operacion	tp WHERE tp.id_area='SV' order by tp.id_tipo_operacion asc);

	    bandera:='TipoArea';
	end if;
	if('CGRIA'=$3) then 
		codigo_tipo_operacion:=array (SELECT tp.id_tipo_operacion FROM g_catalogos.tipos_operacion	tp WHERE tp.id_area='CGRIA' order by tp.id_tipo_operacion asc);
	    bandera:='TipoArea';
	end if;
	if('SA'=$3) then 
		codigo_tipo_operacion:=array (SELECT tp.id_tipo_operacion FROM g_catalogos.tipos_operacion tp	WHERE tp.id_area='SA' order by tp.id_tipo_operacion asc);
	    bandera:='TipoArea';
	end if;
	if('IAP'=$3) then 
		codigo_tipo_operacion:=array (SELECT tp.id_tipo_operacion FROM g_catalogos.tipos_operacion tp	WHERE tp.id_area='IAP' order by tp.id_tipo_operacion asc);
	    bandera:='TipoArea';
	end if;
	
	if('IAV'=$3) then 
		codigo_tipo_operacion:=array (SELECT tp.id_tipo_operacion FROM g_catalogos.tipos_operacion tp	WHERE tp.id_area='IAV' order by tp.id_tipo_operacion asc);
	    bandera:='TipoArea';
	end if;
	
	
	
	
	--reporte con mas parametros de pendiendo del caso se aggrega mas clausulas en el where 
	if(bandera='REPORTE_DE_PRODUCTOR_AVICOLAS_PORCINOS') then 
			create table temp_consulta as(	SELECT 
			distinct o.identificador,
			RTRIM(REPLACE(REPLACE(REPLACE(o.razon_social,chr(9),''),chr(10),''),chr(13),'')) as razon_social,
			o.nombre_representante ||' '||o.apellido_representante as nombre_representante,
			o.nombre_tecnico||' '||o.apellido_tecnico as apellido_tecnico,
			REPLACE(REPLACE(REPLACE(o.direccion,chr(9),''),chr(10),''),chr(13),'') as direccion,
			o.telefono_uno ||'-'|| o.telefono_dos as telefonos,
			o.celular_uno ||'-'||o.celular_dos as celulares,
			REPLACE(REPLACE(REPLACE(o.correo,chr(9),''),chr(10),''),chr(13),'') as correo,
			op.id_tipo_operacion,
			op.estado, 
			REPLACE(REPLACE(REPLACE(op.observacion,chr(9),''),chr(10),''),chr(13),'') as observacion,
			op.id_producto,
			op.id_vue,
			op.nombre_pais as nombre_pais_operaciones,
			REPLACE(REPLACE(REPLACE(pr.nombre_comun,chr(9),''),chr(10),''),chr(13),'') as nombre_comun,
			stp.nombre as subtipo_producto,
			tpr.nombre as tipo_producto,
			REPLACE(REPLACE(REPLACE(tp.nombre,chr(9),''),chr(10),''),chr(13),'') as tipo_operacion,
			op.fecha_creacion,
			op.fecha_modificacion,
			CASE WHEN op.estado = 'registrado'  THEN op.fecha_aprobacion
			--WHEN op.estado = 'noHabilitado' THEN op.fecha_aprobacion
			--WHEN op.estado = 'porCaducar' THEN op.fecha_aprobacion
			END as fecha_aprobacion,
			--op.fecha_finalizacion,
			REPLACE(REPLACE(REPLACE(a.nombre_area,chr(9),''),chr(10),''),chr(13),'') as nombre_area,
			REPLACE(REPLACE(REPLACE(a.tipo_area,chr(9),''),chr(10),''),chr(13),'') as tipo_area,
			a.superficie_utilizada ||' '|| ap.unidad_medida as superficie_utilizada,
			a.estado as estado_area,
			a.codigo||a.secuencial as codigo_area_areas,
			a.codigo_transaccional as codigo_mag,
			REPLACE(REPLACE(REPLACE(s.nombre_lugar,chr(9),''),chr(10),''),chr(13),'') as nombre_sitio,
			REPLACE(REPLACE(REPLACE(s.direccion,chr(9),''),chr(10),''),chr(13),'') as direccion_sitio,
			REPLACE(REPLACE(REPLACE(s.telefono,chr(9),''),chr(10),''),chr(13),'') as telefono,
			REPLACE(REPLACE(REPLACE(s.referencia,chr(9),''),chr(10),''),chr(13),'') as referencia,
			s.parroquia,
			s.canton,
			s.provincia,
			s.codigo_provincia||s.codigo as codigo_sitio_sitios,
			s.latitud,
			s.longitud,
			s.superficie_total ||' '|| 'm2' as superficie_total,
			o.identificador||'.'||s.codigo_provincia||s.codigo as codigo_sitio,
			o.identificador||'.'||s.codigo_provincia||s.codigo||a.codigo||a.secuencial as codigo_area,
			op.nombre_pais
			--,CASE WHEN op.estado = 'registrado'  THEN 'CMR-'||CASE WHEN tp.codigo = 'PMR' THEN 'CPP' WHEN tp.codigo = 'CPM' THEN 'UCP' WHEN tp.codigo = 'DMR' THEN 'CAD' ELSE 'UIA' END ||'-'||LPAD(s.codigo_provincia,3,'0')||'-'||LPAD(dop.secuencial,3,'0') END as codigo --Material reproductivo
			--,CASE WHEN op.estado = 'registrado'  THEN LPAD(s.codigo_provincia,3,'0')||'-'||'AGC-'||CASE WHEN tp.codigo = 'MPA' THEN 'CAB`s' WHEN tp.codigo = 'ATM' THEN 'CH' WHEN tp.codigo = 'FEA' THEN 'FE' ELSE 'FC' END ||'-'||LPAD(dop.secuencial,3,'0') END as codigo --Centro de concentración
			--array_to_string(ARRAY(SELECT distinct nombre_representante ||'-'|| titulo_academico FROM g_operadores.representantes_tecnicos rt 
			--INNER JOIN g_operadores.detalle_representantes_tecnicos drt ON rt.id_representante_tecnico = drt.id_representante_tecnico 
			--WHERE rt.id_operador_tipo_operacion = op.id_operador_tipo_operacion),', ') as respresentante_tecnico_operacion
		FROM
			g_operadores.operadores o 
			INNER JOIN g_operadores.sitios s ON s.identificador_operador = o.identificador
			INNER JOIN g_operadores.areas a ON a.id_sitio = s.id_sitio
			INNER JOIN g_operadores.productos_areas_operacion pao ON pao.id_area = a.id_area
			INNER JOIN g_operadores.operaciones op ON op.id_operacion = pao.id_operacion
			INNER JOIN g_catalogos.tipos_operacion tp ON tp.id_tipo_operacion = op.id_tipo_operacion  
			INNER JOIN g_catalogos.areas_operacion ap ON ap.id_tipo_operacion = tp.id_tipo_operacion
			LEFT JOIN g_catalogos.productos pr ON pr.id_producto = op.id_producto
			LEFT JOIN g_catalogos.subtipo_productos stp ON stp.id_subtipo_producto = pr.id_subtipo_producto 
			LEFT JOIN g_catalogos.tipo_productos tpr ON tpr.id_tipo_producto = stp.id_tipo_producto
			--LEFT JOIN g_operadores.documentos_operador dop ON op.id_operador_tipo_operacion = dop.id_operador_tipo_operacion and dop.estado = 'activo'
		WHERE

				op.fecha_creacion >= $1
			and	op.fecha_creacion <= $2	
			and op.id_tipo_operacion =any(codigo_tipo_operacion) 
			and tpr.id_tipo_producto=any(codigo_tipo_producto)							  
			);
	end if;
	
	if (bandera='CUARENTENA_PORCINOS_AVES_GRANJAS_INCUBACIÓN')	then
		--por aqui dentra todos 
		create table temp_consulta as(	SELECT 
			distinct o.identificador,
			RTRIM(REPLACE(REPLACE(REPLACE(o.razon_social,chr(9),''),chr(10),''),chr(13),'')) as razon_social,
			o.nombre_representante ||' '||o.apellido_representante as nombre_representante,
			o.nombre_tecnico||' '||o.apellido_tecnico as apellido_tecnico,
			REPLACE(REPLACE(REPLACE(o.direccion,chr(9),''),chr(10),''),chr(13),'') as direccion,
			o.telefono_uno ||'-'|| o.telefono_dos as telefonos,
			o.celular_uno ||'-'||o.celular_dos as celulares,
			REPLACE(REPLACE(REPLACE(o.correo,chr(9),''),chr(10),''),chr(13),'') as correo,
			op.id_tipo_operacion,
			op.estado, 
			REPLACE(REPLACE(REPLACE(op.observacion,chr(9),''),chr(10),''),chr(13),'') as observacion,
			op.id_producto,
			op.id_vue,
			op.nombre_pais as nombre_pais_operaciones,
			REPLACE(REPLACE(REPLACE(pr.nombre_comun,chr(9),''),chr(10),''),chr(13),'') as nombre_comun,
			stp.nombre as subtipo_producto,
			tpr.nombre as tipo_producto,
			REPLACE(REPLACE(REPLACE(tp.nombre,chr(9),''),chr(10),''),chr(13),'') as tipo_operacion,
			op.fecha_creacion,
			op.fecha_modificacion,
			CASE WHEN op.estado = 'registrado'  THEN op.fecha_aprobacion
			--WHEN op.estado = 'noHabilitado' THEN op.fecha_aprobacion
			--WHEN op.estado = 'porCaducar' THEN op.fecha_aprobacion
			END as fecha_aprobacion,
			--op.fecha_finalizacion,
			REPLACE(REPLACE(REPLACE(a.nombre_area,chr(9),''),chr(10),''),chr(13),'') as nombre_area,
			REPLACE(REPLACE(REPLACE(a.tipo_area,chr(9),''),chr(10),''),chr(13),'') as tipo_area,
			a.superficie_utilizada ||' '|| ap.unidad_medida as superficie_utilizada,
			a.estado as estado_area,
			a.codigo||a.secuencial as codigo_area_areas,
			a.codigo_transaccional as codigo_mag,
			REPLACE(REPLACE(REPLACE(s.nombre_lugar,chr(9),''),chr(10),''),chr(13),'') as nombre_sitio,
			REPLACE(REPLACE(REPLACE(s.direccion,chr(9),''),chr(10),''),chr(13),'') as direccion_sitio,
			REPLACE(REPLACE(REPLACE(s.telefono,chr(9),''),chr(10),''),chr(13),'') as telefono,
			REPLACE(REPLACE(REPLACE(s.referencia,chr(9),''),chr(10),''),chr(13),'') as referencia,
			s.parroquia,
			s.canton,
			s.provincia,
			s.codigo_provincia||s.codigo as codigo_sitio_sitios,
			s.latitud,
			s.longitud,
			s.superficie_total ||' '|| 'm2' as superficie_total,
			o.identificador||'.'||s.codigo_provincia||s.codigo as codigo_sitio,
			o.identificador||'.'||s.codigo_provincia||s.codigo||a.codigo||a.secuencial as codigo_area,
			op.nombre_pais
			--,CASE WHEN op.estado = 'registrado'  THEN 'CMR-'||CASE WHEN tp.codigo = 'PMR' THEN 'CPP' WHEN tp.codigo = 'CPM' THEN 'UCP' WHEN tp.codigo = 'DMR' THEN 'CAD' ELSE 'UIA' END ||'-'||LPAD(s.codigo_provincia,3,'0')||'-'||LPAD(dop.secuencial,3,'0') END as codigo --Material reproductivo
			--,CASE WHEN op.estado = 'registrado'  THEN LPAD(s.codigo_provincia,3,'0')||'-'||'AGC-'||CASE WHEN tp.codigo = 'MPA' THEN 'CAB`s' WHEN tp.codigo = 'ATM' THEN 'CH' WHEN tp.codigo = 'FEA' THEN 'FE' ELSE 'FC' END ||'-'||LPAD(dop.secuencial,3,'0') END as codigo --Centro de concentración
			--array_to_string(ARRAY(SELECT distinct nombre_representante ||'-'|| titulo_academico FROM g_operadores.representantes_tecnicos rt 
			--INNER JOIN g_operadores.detalle_representantes_tecnicos drt ON rt.id_representante_tecnico = drt.id_representante_tecnico 
			--WHERE rt.id_operador_tipo_operacion = op.id_operador_tipo_operacion),', ') as respresentante_tecnico_operacion
		FROM
			g_operadores.operadores o 
			INNER JOIN g_operadores.sitios s ON s.identificador_operador = o.identificador
			INNER JOIN g_operadores.areas a ON a.id_sitio = s.id_sitio
			INNER JOIN g_operadores.productos_areas_operacion pao ON pao.id_area = a.id_area
			INNER JOIN g_operadores.operaciones op ON op.id_operacion = pao.id_operacion
			INNER JOIN g_catalogos.tipos_operacion tp ON tp.id_tipo_operacion = op.id_tipo_operacion  
			INNER JOIN g_catalogos.areas_operacion ap ON ap.id_tipo_operacion = tp.id_tipo_operacion
			LEFT JOIN g_catalogos.productos pr ON pr.id_producto = op.id_producto
			LEFT JOIN g_catalogos.subtipo_productos stp ON stp.id_subtipo_producto = pr.id_subtipo_producto 
			LEFT JOIN g_catalogos.tipo_productos tpr ON tpr.id_tipo_producto = stp.id_tipo_producto
			--LEFT JOIN g_operadores.documentos_operador dop ON op.id_operador_tipo_operacion = dop.id_operador_tipo_operacion and dop.estado = 'activo'
		WHERE

				
 				op.fecha_creacion >= $1
 			and	op.fecha_creacion <= $2	
 			and op.id_tipo_operacion =any(codigo_tipo_operacion) 
			and stp.id_subtipo_producto=any(codigo_subtipo_producto)	
			);
end if;
	--reporte para un caso todos
	 if (bandera='todos') then 
				create table temp_consulta as(	SELECT 
			distinct o.identificador,
			RTRIM(REPLACE(REPLACE(REPLACE(o.razon_social,chr(9),''),chr(10),''),chr(13),'')) as razon_social,
			o.nombre_representante ||' '||o.apellido_representante as nombre_representante,
			o.nombre_tecnico||' '||o.apellido_tecnico as apellido_tecnico,
			REPLACE(REPLACE(REPLACE(o.direccion,chr(9),''),chr(10),''),chr(13),'') as direccion,
			o.telefono_uno ||'-'|| o.telefono_dos as telefonos,
			o.celular_uno ||'-'||o.celular_dos as celulares,
			REPLACE(REPLACE(REPLACE(o.correo,chr(9),''),chr(10),''),chr(13),'') as correo,
			op.id_tipo_operacion,
			op.estado, 
			REPLACE(REPLACE(REPLACE(op.observacion,chr(9),''),chr(10),''),chr(13),'') as observacion,
			op.id_producto,
			op.id_vue,
			op.nombre_pais as nombre_pais_operaciones,
			REPLACE(REPLACE(REPLACE(pr.nombre_comun,chr(9),''),chr(10),''),chr(13),'') as nombre_comun,
			stp.nombre as subtipo_producto,
			tpr.nombre as tipo_producto,
			REPLACE(REPLACE(REPLACE(tp.nombre,chr(9),''),chr(10),''),chr(13),'') as tipo_operacion,
			op.fecha_creacion,
			op.fecha_modificacion,
			CASE WHEN op.estado = 'registrado'  THEN op.fecha_aprobacion
			--WHEN op.estado = 'noHabilitado' THEN op.fecha_aprobacion
			--WHEN op.estado = 'porCaducar' THEN op.fecha_aprobacion
			END as fecha_aprobacion,
			--op.fecha_finalizacion,
			REPLACE(REPLACE(REPLACE(a.nombre_area,chr(9),''),chr(10),''),chr(13),'') as nombre_area,
			REPLACE(REPLACE(REPLACE(a.tipo_area,chr(9),''),chr(10),''),chr(13),'') as tipo_area,
			a.superficie_utilizada ||' '|| ap.unidad_medida as superficie_utilizada,
			a.estado as estado_area,
			a.codigo||a.secuencial as codigo_area_areas,
			a.codigo_transaccional as codigo_mag,
			REPLACE(REPLACE(REPLACE(s.nombre_lugar,chr(9),''),chr(10),''),chr(13),'') as nombre_sitio,
			REPLACE(REPLACE(REPLACE(s.direccion,chr(9),''),chr(10),''),chr(13),'') as direccion_sitio,
			REPLACE(REPLACE(REPLACE(s.telefono,chr(9),''),chr(10),''),chr(13),'') as telefono,
			REPLACE(REPLACE(REPLACE(s.referencia,chr(9),''),chr(10),''),chr(13),'') as referencia,
			s.parroquia,
			s.canton,
			s.provincia,
			s.codigo_provincia||s.codigo as codigo_sitio_sitios,
			s.latitud,
			s.longitud,
			s.superficie_total ||' '|| 'm2' as superficie_total,
			o.identificador||'.'||s.codigo_provincia||s.codigo as codigo_sitio,
			o.identificador||'.'||s.codigo_provincia||s.codigo||a.codigo||a.secuencial as codigo_area,
			op.nombre_pais
			--,CASE WHEN op.estado = 'registrado'  THEN 'CMR-'||CASE WHEN tp.codigo = 'PMR' THEN 'CPP' WHEN tp.codigo = 'CPM' THEN 'UCP' WHEN tp.codigo = 'DMR' THEN 'CAD' ELSE 'UIA' END ||'-'||LPAD(s.codigo_provincia,3,'0')||'-'||LPAD(dop.secuencial,3,'0') END as codigo --Material reproductivo
			--,CASE WHEN op.estado = 'registrado'  THEN LPAD(s.codigo_provincia,3,'0')||'-'||'AGC-'||CASE WHEN tp.codigo = 'MPA' THEN 'CAB`s' WHEN tp.codigo = 'ATM' THEN 'CH' WHEN tp.codigo = 'FEA' THEN 'FE' ELSE 'FC' END ||'-'||LPAD(dop.secuencial,3,'0') END as codigo --Centro de concentración
			--array_to_string(ARRAY(SELECT distinct nombre_representante ||'-'|| titulo_academico FROM g_operadores.representantes_tecnicos rt 
			--INNER JOIN g_operadores.detalle_representantes_tecnicos drt ON rt.id_representante_tecnico = drt.id_representante_tecnico 
			--WHERE rt.id_operador_tipo_operacion = op.id_operador_tipo_operacion),', ') as respresentante_tecnico_operacion
		FROM
			g_operadores.operadores o 
			INNER JOIN g_operadores.sitios s ON s.identificador_operador = o.identificador
			INNER JOIN g_operadores.areas a ON a.id_sitio = s.id_sitio
			INNER JOIN g_operadores.productos_areas_operacion pao ON pao.id_area = a.id_area
			INNER JOIN g_operadores.operaciones op ON op.id_operacion = pao.id_operacion
			INNER JOIN g_catalogos.tipos_operacion tp ON tp.id_tipo_operacion = op.id_tipo_operacion  
			INNER JOIN g_catalogos.areas_operacion ap ON ap.id_tipo_operacion = tp.id_tipo_operacion
			LEFT JOIN g_catalogos.productos pr ON pr.id_producto = op.id_producto
			LEFT JOIN g_catalogos.subtipo_productos stp ON stp.id_subtipo_producto = pr.id_subtipo_producto 
			LEFT JOIN g_catalogos.tipo_productos tpr ON tpr.id_tipo_producto = stp.id_tipo_producto
			--LEFT JOIN g_operadores.documentos_operador dop ON op.id_operador_tipo_operacion = dop.id_operador_tipo_operacion and dop.estado = 'activo'
		WHERE

				op.fecha_creacion >= $1
			and	op.fecha_creacion <= $2	
			and op.id_tipo_operacion =any(codigo_tipo_operacion) 									  
			);
	 end if;
									  
	--reporte para dos casos								  
	 if (bandera='MATERIAL_REPRODUCTIVO'or bandera='PRODUCTOR_APICOLA_SELECTOR_POLINIZADOR') then 
				create table temp_consulta as(	SELECT 
			distinct o.identificador,
			RTRIM(REPLACE(REPLACE(REPLACE(o.razon_social,chr(9),''),chr(10),''),chr(13),'')) as razon_social,
			o.nombre_representante ||' '||o.apellido_representante as nombre_representante,
			o.nombre_tecnico||' '||o.apellido_tecnico as apellido_tecnico,
			REPLACE(REPLACE(REPLACE(o.direccion,chr(9),''),chr(10),''),chr(13),'') as direccion,
			o.telefono_uno ||'-'|| o.telefono_dos as telefonos,
			o.celular_uno ||'-'||o.celular_dos as celulares,
			REPLACE(REPLACE(REPLACE(o.correo,chr(9),''),chr(10),''),chr(13),'') as correo,
			op.id_tipo_operacion,
			op.estado, 
			REPLACE(REPLACE(REPLACE(op.observacion,chr(9),''),chr(10),''),chr(13),'') as observacion,
			op.id_producto,
			op.id_vue,
			op.nombre_pais as nombre_pais_operaciones,
			REPLACE(REPLACE(REPLACE(pr.nombre_comun,chr(9),''),chr(10),''),chr(13),'') as nombre_comun,
			stp.nombre as subtipo_producto,
			tpr.nombre as tipo_producto,
			REPLACE(REPLACE(REPLACE(tp.nombre,chr(9),''),chr(10),''),chr(13),'') as tipo_operacion,
			op.fecha_creacion,
			op.fecha_modificacion,
			CASE WHEN op.estado = 'registrado'  THEN op.fecha_aprobacion
			--WHEN op.estado = 'noHabilitado' THEN op.fecha_aprobacion
			--WHEN op.estado = 'porCaducar' THEN op.fecha_aprobacion
			END as fecha_aprobacion,
			--op.fecha_finalizacion,
			REPLACE(REPLACE(REPLACE(a.nombre_area,chr(9),''),chr(10),''),chr(13),'') as nombre_area,
			REPLACE(REPLACE(REPLACE(a.tipo_area,chr(9),''),chr(10),''),chr(13),'') as tipo_area,
			a.superficie_utilizada ||' '|| ap.unidad_medida as superficie_utilizada,
			a.estado as estado_area,
			a.codigo||a.secuencial as codigo_area_areas,
			a.codigo_transaccional as codigo_mag,
			REPLACE(REPLACE(REPLACE(s.nombre_lugar,chr(9),''),chr(10),''),chr(13),'') as nombre_sitio,
			REPLACE(REPLACE(REPLACE(s.direccion,chr(9),''),chr(10),''),chr(13),'') as direccion_sitio,
			REPLACE(REPLACE(REPLACE(s.telefono,chr(9),''),chr(10),''),chr(13),'') as telefono,
			REPLACE(REPLACE(REPLACE(s.referencia,chr(9),''),chr(10),''),chr(13),'') as referencia,
			s.parroquia,
			s.canton,
			s.provincia,
			s.codigo_provincia||s.codigo as codigo_sitio_sitios,
			s.latitud,
			s.longitud,
			s.superficie_total ||' '|| 'm2' as superficie_total,
			o.identificador||'.'||s.codigo_provincia||s.codigo as codigo_sitio,
			o.identificador||'.'||s.codigo_provincia||s.codigo||a.codigo||a.secuencial as codigo_area,
			op.nombre_pais
			--,CASE WHEN op.estado = 'registrado'  THEN 'CMR-'||CASE WHEN tp.codigo = 'PMR' THEN 'CPP' WHEN tp.codigo = 'CPM' THEN 'UCP' WHEN tp.codigo = 'DMR' THEN 'CAD' ELSE 'UIA' END ||'-'||LPAD(s.codigo_provincia,3,'0')||'-'||LPAD(dop.secuencial,3,'0') END as codigo --Material reproductivo
			--,CASE WHEN op.estado = 'registrado'  THEN LPAD(s.codigo_provincia,3,'0')||'-'||'AGC-'||CASE WHEN tp.codigo = 'MPA' THEN 'CAB`s' WHEN tp.codigo = 'ATM' THEN 'CH' WHEN tp.codigo = 'FEA' THEN 'FE' ELSE 'FC' END ||'-'||LPAD(dop.secuencial,3,'0') END as codigo --Centro de concentración
			--array_to_string(ARRAY(SELECT distinct nombre_representante ||'-'|| titulo_academico FROM g_operadores.representantes_tecnicos rt 
			--INNER JOIN g_operadores.detalle_representantes_tecnicos drt ON rt.id_representante_tecnico = drt.id_representante_tecnico 
			--WHERE rt.id_operador_tipo_operacion = op.id_operador_tipo_operacion),', ') as respresentante_tecnico_operacion
		FROM
			g_operadores.operadores o 
			INNER JOIN g_operadores.sitios s ON s.identificador_operador = o.identificador
			INNER JOIN g_operadores.areas a ON a.id_sitio = s.id_sitio
			INNER JOIN g_operadores.productos_areas_operacion pao ON pao.id_area = a.id_area
			INNER JOIN g_operadores.operaciones op ON op.id_operacion = pao.id_operacion
			INNER JOIN g_catalogos.tipos_operacion tp ON tp.id_tipo_operacion = op.id_tipo_operacion  
			INNER JOIN g_catalogos.areas_operacion ap ON ap.id_tipo_operacion = tp.id_tipo_operacion
			LEFT JOIN g_catalogos.productos pr ON pr.id_producto = op.id_producto
			LEFT JOIN g_catalogos.subtipo_productos stp ON stp.id_subtipo_producto = pr.id_subtipo_producto 
			LEFT JOIN g_catalogos.tipo_productos tpr ON tpr.id_tipo_producto = stp.id_tipo_producto
			--LEFT JOIN g_operadores.documentos_operador dop ON op.id_operador_tipo_operacion = dop.id_operador_tipo_operacion and dop.estado = 'activo'
		WHERE

				op.fecha_aprobacion >= $1
			and	op.fecha_aprobacion <= $2	
			and op.id_tipo_operacion =any(codigo_tipo_operacion) 									  
			);
	 end if;
						
	--reporte para pitahaya 
	 if (bandera='CON_PITAHAYA') then 
		create table temp_consulta as(	SELECT 
			distinct o.identificador,
			RTRIM(REPLACE(REPLACE(REPLACE(o.razon_social,chr(9),''),chr(10),''),chr(13),'')) as razon_social,
			o.nombre_representante ||' '||o.apellido_representante as nombre_representante,
			o.nombre_tecnico||' '||o.apellido_tecnico as apellido_tecnico,
			REPLACE(REPLACE(REPLACE(o.direccion,chr(9),''),chr(10),''),chr(13),'') as direccion,
			o.telefono_uno ||'-'|| o.telefono_dos as telefonos,
			o.celular_uno ||'-'||o.celular_dos as celulares,
			REPLACE(REPLACE(REPLACE(o.correo,chr(9),''),chr(10),''),chr(13),'') as correo,
			op.id_tipo_operacion,
			op.estado, 
			REPLACE(REPLACE(REPLACE(op.observacion,chr(9),''),chr(10),''),chr(13),'') as observacion,
			op.id_producto,
			op.id_vue,
			op.nombre_pais as nombre_pais_operaciones,
			REPLACE(REPLACE(REPLACE(pr.nombre_comun,chr(9),''),chr(10),''),chr(13),'') as nombre_comun,
			stp.nombre as subtipo_producto,
			tpr.nombre as tipo_producto,
			REPLACE(REPLACE(REPLACE(tp.nombre,chr(9),''),chr(10),''),chr(13),'') as tipo_operacion,
			op.fecha_creacion,
			op.fecha_modificacion,
			CASE WHEN op.estado = 'registrado'  THEN op.fecha_aprobacion
			--WHEN op.estado = 'noHabilitado' THEN op.fecha_aprobacion
			--WHEN op.estado = 'porCaducar' THEN op.fecha_aprobacion
			END as fecha_aprobacion,
			--op.fecha_finalizacion,
			REPLACE(REPLACE(REPLACE(a.nombre_area,chr(9),''),chr(10),''),chr(13),'') as nombre_area,
			REPLACE(REPLACE(REPLACE(a.tipo_area,chr(9),''),chr(10),''),chr(13),'') as tipo_area,
			a.superficie_utilizada ||' '|| ap.unidad_medida as superficie_utilizada,
			a.estado as estado_area,
			a.codigo||a.secuencial as codigo_area_areas,
			a.codigo_transaccional as codigo_mag,
			REPLACE(REPLACE(REPLACE(s.nombre_lugar,chr(9),''),chr(10),''),chr(13),'') as nombre_sitio,
			REPLACE(REPLACE(REPLACE(s.direccion,chr(9),''),chr(10),''),chr(13),'') as direccion_sitio,
			REPLACE(REPLACE(REPLACE(s.telefono,chr(9),''),chr(10),''),chr(13),'') as telefono,
			REPLACE(REPLACE(REPLACE(s.referencia,chr(9),''),chr(10),''),chr(13),'') as referencia,
			s.parroquia,
			s.canton,
			s.provincia,
			s.codigo_provincia||s.codigo as codigo_sitio_sitios,
			s.latitud,
			s.longitud,
			s.superficie_total ||' '|| 'm2' as superficie_total,
			o.identificador||'.'||s.codigo_provincia||s.codigo as codigo_sitio,
			o.identificador||'.'||s.codigo_provincia||s.codigo||a.codigo||a.secuencial as codigo_area,
			op.nombre_pais
			--,CASE WHEN op.estado = 'registrado'  THEN 'CMR-'||CASE WHEN tp.codigo = 'PMR' THEN 'CPP' WHEN tp.codigo = 'CPM' THEN 'UCP' WHEN tp.codigo = 'DMR' THEN 'CAD' ELSE 'UIA' END ||'-'||LPAD(s.codigo_provincia,3,'0')||'-'||LPAD(dop.secuencial,3,'0') END as codigo --Material reproductivo
			--,CASE WHEN op.estado = 'registrado'  THEN LPAD(s.codigo_provincia,3,'0')||'-'||'AGC-'||CASE WHEN tp.codigo = 'MPA' THEN 'CAB`s' WHEN tp.codigo = 'ATM' THEN 'CH' WHEN tp.codigo = 'FEA' THEN 'FE' ELSE 'FC' END ||'-'||LPAD(dop.secuencial,3,'0') END as codigo --Centro de concentración
			--array_to_string(ARRAY(SELECT distinct nombre_representante ||'-'|| titulo_academico FROM g_operadores.representantes_tecnicos rt 
			--INNER JOIN g_operadores.detalle_representantes_tecnicos drt ON rt.id_representante_tecnico = drt.id_representante_tecnico 
			--WHERE rt.id_operador_tipo_operacion = op.id_operador_tipo_operacion),', ') as respresentante_tecnico_operacion
		FROM
			g_operadores.operadores o 
			INNER JOIN g_operadores.sitios s ON s.identificador_operador = o.identificador
			INNER JOIN g_operadores.areas a ON a.id_sitio = s.id_sitio
			INNER JOIN g_operadores.productos_areas_operacion pao ON pao.id_area = a.id_area
			INNER JOIN g_operadores.operaciones op ON op.id_operacion = pao.id_operacion
			INNER JOIN g_catalogos.tipos_operacion tp ON tp.id_tipo_operacion = op.id_tipo_operacion  
			INNER JOIN g_catalogos.areas_operacion ap ON ap.id_tipo_operacion = tp.id_tipo_operacion
			LEFT JOIN g_catalogos.productos pr ON pr.id_producto = op.id_producto
			LEFT JOIN g_catalogos.subtipo_productos stp ON stp.id_subtipo_producto = pr.id_subtipo_producto 
			LEFT JOIN g_catalogos.tipo_productos tpr ON tpr.id_tipo_producto = stp.id_tipo_producto
			--LEFT JOIN g_operadores.documentos_operador dop ON op.id_operador_tipo_operacion = dop.id_operador_tipo_operacion and dop.estado = 'activo'
		WHERE

				op.fecha_creacion >= $1
			and	op.fecha_creacion <= $2	
			and op.id_producto =any(codigo_tipo_operacion) 									  
			);
	 end if;								  
									  
									  
	--Operaciones 
	
	if(bandera='TipoArea') then 
		
		create table temp_consulta as(	SELECT 
			distinct o.identificador,
			RTRIM(REPLACE(REPLACE(REPLACE(o.razon_social,chr(9),''),chr(10),''),chr(13),'')) as razon_social,
			o.nombre_representante ||' '||o.apellido_representante as nombre_representante,
			o.nombre_tecnico||' '||o.apellido_tecnico as apellido_tecnico,
			REPLACE(REPLACE(REPLACE(o.direccion,chr(9),''),chr(10),''),chr(13),'') as direccion,
			o.telefono_uno ||'-'|| o.telefono_dos as telefonos,
			o.celular_uno ||'-'||o.celular_dos as celulares,
			REPLACE(REPLACE(REPLACE(o.correo,chr(9),''),chr(10),''),chr(13),'') as correo,
			op.id_tipo_operacion,
			op.estado, 
			REPLACE(REPLACE(REPLACE(op.observacion,chr(9),''),chr(10),''),chr(13),'') as observacion,
			op.id_producto,
			op.id_vue,
			op.nombre_pais as nombre_pais_operaciones,
			REPLACE(REPLACE(REPLACE(pr.nombre_comun,chr(9),''),chr(10),''),chr(13),'') as nombre_comun,
			stp.nombre as subtipo_producto,
			tpr.nombre as tipo_producto,
			REPLACE(REPLACE(REPLACE(tp.nombre,chr(9),''),chr(10),''),chr(13),'') as tipo_operacion,
			op.fecha_creacion,
			op.fecha_modificacion,
			CASE WHEN op.estado = 'registrado'  THEN op.fecha_aprobacion
			--WHEN op.estado = 'noHabilitado' THEN op.fecha_aprobacion
			--WHEN op.estado = 'porCaducar' THEN op.fecha_aprobacion
			END as fecha_aprobacion,
			
			REPLACE(REPLACE(REPLACE(a.nombre_area,chr(9),''),chr(10),''),chr(13),'') as nombre_area,
			REPLACE(REPLACE(REPLACE(a.tipo_area,chr(9),''),chr(10),''),chr(13),'') as tipo_area,
			a.superficie_utilizada ||' '|| ap.unidad_medida as superficie_utilizada,
			a.estado as estado_area,
			a.codigo||a.secuencial as codigo_area_areas,
			a.codigo_transaccional as codigo_mag,
			REPLACE(REPLACE(REPLACE(s.nombre_lugar,chr(9),''),chr(10),''),chr(13),'') as nombre_sitio,
			REPLACE(REPLACE(REPLACE(s.direccion,chr(9),''),chr(10),''),chr(13),'') as direccion_sitio,
			REPLACE(REPLACE(REPLACE(s.telefono,chr(9),''),chr(10),''),chr(13),'') as telefono,
			REPLACE(REPLACE(REPLACE(s.referencia,chr(9),''),chr(10),''),chr(13),'') as referencia,
			s.parroquia,
			s.canton,
			s.provincia,
			s.codigo_provincia||s.codigo as codigo_sitio_sitios,
			s.latitud,
			s.longitud,
			s.superficie_total ||' '|| 'm2' as superficie_total,
			o.identificador||'.'||s.codigo_provincia||s.codigo as codigo_sitio,
			o.identificador||'.'||s.codigo_provincia||s.codigo||a.codigo||a.secuencial as codigo_area,
			op.nombre_pais
			--,CASE WHEN op.estado = 'registrado'  THEN 'CMR-'||CASE WHEN tp.codigo = 'PMR' THEN 'CPP' WHEN tp.codigo = 'CPM' THEN 'UCP' WHEN tp.codigo = 'DMR' THEN 'CAD' ELSE 'UIA' END ||'-'||LPAD(s.codigo_provincia,3,'0')||'-'||LPAD(dop.secuencial,3,'0') END as codigo --Material reproductivo
			--,CASE WHEN op.estado = 'registrado'  THEN LPAD(s.codigo_provincia,3,'0')||'-'||'AGC-'||CASE WHEN tp.codigo = 'MPA' THEN 'CAB`s' WHEN tp.codigo = 'ATM' THEN 'CH' WHEN tp.codigo = 'FEA' THEN 'FE' ELSE 'FC' END ||'-'||LPAD(dop.secuencial,3,'0') END as codigo --Centro de concentración
			--array_to_string(ARRAY(SELECT distinct nombre_representante ||'-'|| titulo_academico FROM g_operadores.representantes_tecnicos rt 
			--INNER JOIN g_operadores.detalle_representantes_tecnicos drt ON rt.id_representante_tecnico = drt.id_representante_tecnico 
			--WHERE rt.id_operador_tipo_operacion = op.id_operador_tipo_operacion),', ') as respresentante_tecnico_operacion
		FROM
			g_operadores.operadores o 
			INNER JOIN g_operadores.sitios s ON s.identificador_operador = o.identificador
			INNER JOIN g_operadores.areas a ON a.id_sitio = s.id_sitio
			INNER JOIN g_operadores.productos_areas_operacion pao ON pao.id_area = a.id_area
			INNER JOIN g_operadores.operaciones op ON op.id_operacion = pao.id_operacion
			INNER JOIN g_catalogos.tipos_operacion tp ON tp.id_tipo_operacion = op.id_tipo_operacion  
			INNER JOIN g_catalogos.areas_operacion ap ON ap.id_tipo_operacion = tp.id_tipo_operacion
			LEFT JOIN g_catalogos.productos pr ON pr.id_producto = op.id_producto
			LEFT JOIN g_catalogos.subtipo_productos stp ON stp.id_subtipo_producto = pr.id_subtipo_producto 
			LEFT JOIN g_catalogos.tipo_productos tpr ON tpr.id_tipo_producto = stp.id_tipo_producto
			--LEFT JOIN g_operadores.documentos_operador dop ON op.id_operador_tipo_operacion = dop.id_operador_tipo_operacion and dop.estado = 'activo'
		WHERE
			op.fecha_creacion >= $1
 			and	op.fecha_creacion <= $2	
			and tp.id_tipo_operacion =any(codigo_tipo_operacion) 			 			
			);
			
	end if;
	

 return QUERY select *from  temp_consulta;

 		DROP TABLE  temp_consulta;
 		--DROP TABLE  temp_Area;

END;
$$;

alter function fs_retorna_reporte_operadores_parametrizado(date, date, varchar, out varchar, out text, out text, out text, out text, out text, out text, out text, out integer, out varchar, out text, out integer, out varchar, out varchar, out text, out varchar, out varchar, out text, out timestamp, out timestamp, out timestamp, out text, out text, out text, out varchar, out text, out varchar, out text, out text, out text, out text, out varchar, out varchar, out varchar, out text, out varchar, out varchar, out text, out text, out text, out varchar) owner to postgres;

