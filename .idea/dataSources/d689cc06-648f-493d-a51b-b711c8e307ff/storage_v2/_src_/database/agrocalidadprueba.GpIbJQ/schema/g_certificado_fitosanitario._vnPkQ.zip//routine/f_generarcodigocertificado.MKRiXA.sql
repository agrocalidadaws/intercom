create function f_generarcodigocertificado(p_identificador_solicitante text, p_anio text, p_id_certificado_fitosanitario integer) returns text
    language plpgsql
as
$$
	DECLARE
		codigocertificadogenerado text;
		
		BEGIN	
			SELECT RPAD (p_identificador_solicitante, 13, '999') || p_anio || LPAD ((floor(random() * pow(10, 5)))::text, 5, '0') || 'P' INTO codigocertificadogenerado;

			LOOP
				BEGIN

					UPDATE g_certificado_fitosanitario.certificado_fitosanitario SET codigo_certificado = codigocertificadogenerado WHERE id_certificado_fitosanitario = p_id_certificado_fitosanitario;
					EXIT;

					EXCEPTION WHEN unique_violation THEN
					SELECT RPAD (p_identificador_solicitante, 13, '999') || p_anio || LPAD ((floor(random() * pow(10, 5)))::text, 5, '0') || 'P' INTO codigocertificadogenerado;

				END;
			END LOOP;

			RETURN codigocertificadogenerado;
		END
		
	$$;

alter function f_generarcodigocertificado(text, text, integer) owner to postgres;

