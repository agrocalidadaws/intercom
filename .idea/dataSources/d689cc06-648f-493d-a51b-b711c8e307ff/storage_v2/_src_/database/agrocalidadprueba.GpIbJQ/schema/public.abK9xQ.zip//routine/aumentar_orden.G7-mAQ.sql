create function aumentar_orden(_id_registro integer, _tabla text, _fk_campo text, _orden text, _pk_campo text) returns void
    language plpgsql
as
$$
	DECLARE
		_registro_anterior int;
		_ordinal_anterior int;
		_ordinal_registro int;
		_codigo_formulario int;
		_codigo_formulario2 text;
		
BEGIN
	
			
	BEGIN
		EXECUTE 'SELECT '|| _fk_campo ||', 
			'|| _orden ||' 
		FROM '|| _tabla ||' 
		WHERE '|| _pk_campo ||' = '|| _id_registro 
		INTO _codigo_formulario, _ordinal_registro;
		
		EXECUTE 'SELECT * FROM ( SELECT '|| _pk_campo ||',
						min(' ||_orden|| ') as menor 
					FROM '|| _tabla ||' 
					WHERE '|| _fk_campo ||' = ' || _codigo_formulario ||' 
						and '|| _orden ||' > ' ||_ordinal_registro|| ' 
					GROUP BY 1
					ORDER BY 2) res
					LIMIT 1' INTO _registro_anterior, _ordinal_anterior;	
	EXCEPTION WHEN OTHERS THEN

		EXECUTE 'SELECT '|| _fk_campo ||', 
			'|| _orden ||' 
		FROM '|| _tabla ||' 
		WHERE '|| _pk_campo ||' = '|| _id_registro 
		INTO _codigo_formulario2, _ordinal_registro;
	
		EXECUTE 'SELECT * FROM ( SELECT '|| _pk_campo ||',
						min(' ||_orden|| ') as menor 
					FROM '|| _tabla ||' 
					WHERE '|| _fk_campo ||' = ''' || _codigo_formulario2 ||'''
						and '|| _orden ||' > ' ||_ordinal_registro|| ' 
					GROUP BY 1
					ORDER BY 2) res
					LIMIT 1' INTO _registro_anterior, _ordinal_anterior;	

	END;
		

	EXECUTE ' UPDATE '|| _tabla ||' 
		  SET '|| _orden ||' = '|| _ordinal_anterior ||'
		  WHERE '|| _pk_campo ||' =' ||_id_registro;

	EXECUTE ' UPDATE '|| _tabla ||' 
		  SET '|| _orden ||' = '|| _ordinal_registro ||'
		  WHERE '|| _pk_campo ||' =' ||_registro_anterior;
	
END;
$$;

alter function aumentar_orden(integer, text, text, text, text) owner to postgres;

