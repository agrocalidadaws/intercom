create view vista_accion_personal
            (id_permiso_empleado, sub_tipo, descripcion_subtipo, fecha_inicio, fecha_fin, identificador,
             minutos_utilizados, fecha_maxima_presentar_justificacion, estado, ruta_archivo, periodos_tomados,
             fecha_suceso, fecha_solicitud, apellido, nombre, identificador_jefe_superior, id_area_jefe, estado_minutos,
             ruta_informe, oficina, nombre_puesto, remuneracion, tipo_contrato)
as
SELECT pe.id_permiso_empleado,
       pe.sub_tipo,
       sp.descripcion_subtipo,
       pe.fecha_inicio,
       pe.fecha_fin,
       pe.identificador,
       pe.minutos_utilizados,
       pe.fecha_maxima_presentar_justificacion,
       pe.estado,
       pe.ruta_archivo,
       pe.periodos_tomados,
       pe.fecha_suceso,
       pe.fecha_solicitud,
       em.apellido,
       em.nombre,
       pe.identificador_jefe_superior,
       pe.id_area_jefe,
       pe.estado_minutos,
       pe.ruta_informe,
       dc.oficina,
       dc.nombre_puesto,
       dc.remuneracion,
       dc.tipo_contrato
FROM g_vacaciones.permiso_empleado pe,
     g_uath.ficha_empleado em,
     g_uath.datos_contrato dc,
     g_catalogos.subtipo_permiso sp
WHERE pe.sub_tipo = sp.id_subtipo_permiso
  AND pe.identificador::text = em.identificador::text
  AND em.identificador::text = dc.identificador::text;

alter table vista_accion_personal
    owner to postgres;

