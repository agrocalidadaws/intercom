create view ic_v_requerimiento
            (programa, fuente_denuncia, pais_notificacion, provincia, origen_mercaderia, inspector, producto,
             tipo_requerimiento, programa_id, ic_requerimiento_id, ic_fuente_denuncia_id, ic_producto_id,
             pais_notificacion_id, provincia_id, inspector_id, origen_mercaderia_id, ic_tipo_requerimiento_id,
             fecha_solicitud, nombre_denunciante, datos_denunciante, descripcion_denuncia, observacion, numero_muestras,
             fecha_inspeccion, fecha_denuncia, fuente_denuncia_id, fecha_notificacion, cancelado, motivo_cancelacion,
             fecha_inspeccion_mes, ruta_archivo)
as
SELECT g_inocuidad.nombre_catalogo(req.programa_id)                    AS programa,
       g_inocuidad.nombre_catalogo(req.ic_fuente_denuncia_id)          AS fuente_denuncia,
       (SELECT loc.nombre
        FROM g_catalogos.localizacion loc
        WHERE loc.id_localizacion::numeric = req.pais_notificacion_id) AS pais_notificacion,
       (SELECT loc.nombre
        FROM g_catalogos.localizacion loc
        WHERE loc.id_localizacion::numeric = req.provincia_id)         AS provincia,
       g_inocuidad.nombre_catalogo(req.origen_mercaderia_id)           AS origen_mercaderia,
       (SELECT (op.apellido::text || ' '::text) || op.nombre::text
        FROM g_uath.ficha_empleado op
        WHERE op.identificador::text = req.inspector_id::text)         AS inspector,
       pro.nombre                                                      AS producto,
       tre.nombre                                                      AS tipo_requerimiento,
       req.programa_id,
       req.ic_requerimiento_id,
       req.ic_fuente_denuncia_id,
       req.ic_producto_id,
       req.pais_notificacion_id,
       req.provincia_id,
       req.inspector_id,
       req.origen_mercaderia_id,
       req.ic_tipo_requerimiento_id,
       req.fecha_solicitud,
       req.nombre_denunciante,
       req.datos_denunciante,
       req.descripcion_denuncia,
       req.observacion,
       req.numero_muestras,
       req.fecha_inspeccion,
       req.fecha_denuncia,
       req.fuente_denuncia_id,
       req.fecha_notificacion,
       req.cancelado,
       req.motivo_cancelacion,
       req.fecha_inspeccion_mes,
       req.ruta_archivo
FROM g_inocuidad.ic_requerimiento req
         JOIN g_inocuidad.ic_producto pro ON req.ic_producto_id = pro.ic_producto_id::numeric
         JOIN g_inocuidad.ic_tipo_requerimiento tre
              ON tre.ic_tipo_requerimiento_id = req.ic_tipo_requerimiento_id::numeric;

alter table ic_v_requerimiento
    owner to postgres;

