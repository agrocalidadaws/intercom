create function fs_secuencial_certificado_origen() returns character varying
    language plpgsql
as
$$
DECLARE
secuencial int:=0;
numero character varying:='';
maxIdEmison int:=0;
consulta int:=0;
anioactual text:='';
BEGIN

anioactual = (SELECT to_char(emi.fecha_creacion,'YYYY') as fecha
				FROM 
					g_emision_certificacion_origen.emision_certificado emi
					WHERE  to_char(emi.fecha_creacion,'YYYY') = to_char(now(),'YYYY')
					group by emi.id_emision_certificado order by emi.id_emision_certificado desc limit 1);
IF (anioactual::integer > 0) THEN
			
			maxIdEmison = (SELECT max (emi.id_emision_certificado)
				   			FROM g_emision_certificacion_origen.emision_certificado emi 
					 		WHERE  emi.numero_certificado is not null and emi.numero_certificado <> '');

			consulta = (SELECT LENGTH(emi.numero_certificado) as cantidad
				  		 FROM g_emision_certificacion_origen.emision_certificado emi 
				 		WHERE  id_emision_certificado = maxIdEmison);
					
				IF ((consulta >= 14) and (consulta <= 19)) THEN
					secuencial = 1;
					numero=trim(to_char(secuencial, '000000'));
				ELSE
					IF ((consulta >= 32) and (consulta <= 37)) THEN
						SELECT MAX(SUBSTRING (numero_certificado , (consulta-5) , 6)::integer) into secuencial
						FROM g_emision_certificacion_origen.emision_certificado
						WHERE id_emision_certificado = maxIdEmison;
						
						IF (secuencial IS NOT NULL) THEN
						   secuencial = secuencial + 1;	
						   numero=trim(to_char(secuencial, '000000'));
						ELSE
					    END IF;	
					ELSE
					    
					END IF;
				END IF;

ELSE

	secuencial = 1;
	numero=trim(to_char(secuencial, '000000'));
	
END IF;	

  return numero;
END 
		
$$;

alter function fs_secuencial_certificado_origen() owner to postgres;

