create function fs_reporte_importaciones_con_ingrediente_activo_registro(pfecha_inicio date, pfecha_inicio2 date, id_area character varying, OUT id_importacion integer, OUT razon_social character varying, OUT direccion character varying, OUT tipo_producto character varying, OUT subtipo_producto character varying, OUT nombre_producto character varying, OUT id_producto integer, OUT cantidad_producto double precision, OUT unidad_medida character varying, OUT peso double precision, OUT unida_peso character varying, OUT presentacion_producto character varying, OUT partida_producto_vue character varying, OUT pais_origen character varying, OUT razon_exportador character varying, OUT direccion_exportador character varying, OUT tipo_transporte character varying, OUT puerto_embarque character varying, OUT puerto_destino character varying, OUT id_vue character varying, OUT valor_fob double precision, OUT nombre_provincia character varying, OUT nombre_ciudad character varying, OUT fecha_creacion date, OUT aprobacion_revision_documental timestamp without time zone, OUT fecha_inicio date, OUT fecha_vigencia date, OUT nombre_tecnico text, OUT razon_social_producto character varying, OUT fecha_imposicion_tasa timestamp without time zone, OUT ingrediente_activo text, OUT pid_producto integer) returns SETOF record
    language plpgsql
as
$$
declare
--VARIABLES--
	codigo_id_area  character varying[]:=null;
	
BEGIN
					--reporte con id area 'IAV','IAP','IAF'
				if('IAV'=$3) then 
					codigo_id_area:=array (SELECT * FROM (VALUES ('IAV')) AS tabla (id_areas));	
				end if;
				if('IAP'=$3) then 
					codigo_id_area:=array (SELECT * FROM (VALUES ('IAP')) AS tabla (id_areas));
				end if;
				if('IAF'=$3) then 
					codigo_id_area:=array (SELECT * FROM (VALUES ('IAF')) AS tabla (id_areas));
				end if;
				if('TODAS'=$3) then 
					codigo_id_area:=array (SELECT * FROM (VALUES ('IAV'),('IAP'),('IAF')) AS tabla (id_opciones));
				end if;
			 	CREATE TABLE consulta_temporal AS(SELECT
				DISTINCT i.id_importacion,
				o.razon_social,
				o.direccion,
				tp.nombre AS tipo_producto,
				sp.nombre AS subtipo_prodcuto,
				p.nombre_comun AS nombre_producto,
				p.id_producto,				
				ip.unidad AS cantidad_producto,
				ip.unidad_medida,
				ip.peso,
				ip.unidad_peso,
				ip.presentacion_producto,
				ip.partida_producto_vue,
				i.pais_exportacion AS pais_origen,
				i.nombre_exportador AS razon_exportador,
				i.direccion_exportador,
				i.tipo_transporte,
				i.puerto_embarque,
				i.puerto_destino,
				i.id_vue,
				ip.valor_fob,
				i.nombre_provincia,
				i.nombre_ciudad,
				i.fecha_creacion,
				rd.fecha_inspeccion AS aprobacion_revision_documental,				
				i.fecha_inicio,
				i.fecha_vigencia,
				fe.apellido ||' '|| fe.nombre AS nombre_tecnico,
				(SELECT 
				 	CASE 
				 	WHEN o1.razon_social = '' 
				 		THEN o1.nombre_representante ||' '|| o1.apellido_representante 
				 		ELSE o1.razon_social 
				 	END nombre_operador 
				 FROM g_operadores.operadores o1 
				 WHERE o1.identificador = pi.id_operador) AS razon_social_producto
			FROM 
				g_importaciones.importaciones i
				INNER JOIN g_importaciones.importaciones_productos ip ON i.id_importacion = ip.id_importacion
				INNER JOIN g_catalogos.productos p ON ip.id_producto = p.id_producto
				INNER JOIN g_catalogos.productos_inocuidad pi ON p.id_producto = pi.id_producto
				INNER JOIN g_catalogos.subtipo_productos sp ON p.id_subtipo_producto = sp.id_subtipo_producto
				INNER JOIN g_catalogos.tipo_productos tp ON sp.id_tipo_producto = tp.id_tipo_producto
				INNER JOIN g_operadores.operadores o ON o.identificador = i.identificador_operador
				INNER JOIN g_revision_solicitudes.grupos_solicitudes gs ON i.id_importacion = gs.id_solicitud
				INNER JOIN g_revision_solicitudes.asignacion_inspector ai ON gs.id_grupo = ai.id_grupo
				INNER JOIN g_revision_solicitudes.revision_documental rd ON ai.id_grupo = rd.id_grupo 
				LEFT JOIN g_uath.ficha_empleado fe ON fe.identificador = ai.identificador_inspector
			WHERE
				i.estado IN ('aprobado','ampliado') AND
				ai.tipo_solicitud = 'Importación' AND
				ai.tipo_inspector = 'Documental' AND
				rd.estado = 'pago' AND
				--i.id_area IN ('IAV','IAP') AND 
				i.id_area =any(codigo_id_area)	and							  
				i.fecha_inicio >=$1 AND
				i.fecha_inicio <= $2
				);
	  
	  CREATE TABLE consulta_temporal1 AS(	
		SELECT  ctem1.*,(SELECT
		 MAX(f1.fecha_asignacion_monto) 
		 FROM  consulta_temporal ctem1 ,
			   g_revision_solicitudes.grupos_solicitudes gs1, 
			   g_revision_solicitudes.asignacion_inspector ai1, 
			   g_revision_solicitudes.financiero f1 
		 WHERE gs1.id_grupo = ai1.id_grupo
		 AND ai1.id_grupo = f1.id_grupo 
		 AND  ai1.tipo_solicitud = 'Importación' 
		 AND ai1.tipo_inspector = 'Financiero' 
		 AND gs1.id_solicitud = ctem1.id_importacion 
		 AND f1.estado = 'aprobado') AS fecha_imposicion_tasa 
		 FROM consulta_temporal ctem1);
		 
		 CREATE TABLE consulta_temporal2 AS(
			SELECT regexp_replace(string_agg(DISTINCT ci.ingrediente_activo,', '), chr(13)||chr(10),'')AS ingrediente_activo,	
	 				 ci.id_producto
    		FROM consulta_temporal1 ctem1 ,
 	  			g_catalogos.composicion_inocuidad ci  	 
   			where ctem1.id_producto = ci.id_producto  		
   			GROUP BY (ci.id_producto)
			);

return QUERY SELECT  * 
				FROM  consulta_temporal1 c_tem1
				LEFT JOIN  consulta_temporal2 c_tem2
				ON c_tem1.id_producto=c_tem2.id_producto;
			

		DROP TABLE consulta_temporal;
		DROP TABLE consulta_temporal1; 
		DROP TABLE consulta_temporal2;

END;
$$;

alter function fs_reporte_importaciones_con_ingrediente_activo_registro(date, date, varchar, out integer, out varchar, out varchar, out varchar, out varchar, out varchar, out integer, out double precision, out varchar, out double precision, out varchar, out varchar, out varchar, out varchar, out varchar, out varchar, out varchar, out varchar, out varchar, out varchar, out double precision, out varchar, out varchar, out date, out timestamp, out date, out date, out text, out varchar, out timestamp, out text, out integer) owner to postgres;

