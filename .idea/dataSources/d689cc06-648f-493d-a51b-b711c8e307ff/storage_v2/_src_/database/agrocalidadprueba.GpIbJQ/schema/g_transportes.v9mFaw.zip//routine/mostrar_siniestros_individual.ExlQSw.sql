create function mostrar_siniestros_individual(_placa text, _fecha_inicio date, _fecha_fin date, _localizacion text) returns SETOF g_transportes.siniestro_individual
    language plpgsql
as
$$
DECLARE
	query text;
BEGIN	
	return query EXECUTE '
			SELECT 
				s.id_siniestro,
				s.fecha_siniestro,
				s.tipo_siniestro,
				s.magnitud_danio_siniestro,
				s.observacion_siniestro,
				s.valor_total,
				s.monto_danio_terceros,
				s.documentacion_siniestro,
				s.estado,
				v.placa,
				v.modelo,
				v.marca,
				v.localizacion
			FROM
				g_transportes.siniestros s,
				g_transportes.vehiculos v 
			WHERE
				s.placa = v.placa and
				s.placa like $1 and
				($2 is NULL or  s.fecha_solicitud >= $2) and 
				($3 is NULL or  s.fecha_solicitud <= $3) and
				($4 is NULL or $4 = v.localizacion)
			GROUP BY 
				s.id_siniestro,
				s.fecha_siniestro,
				s.tipo_siniestro,
				s.magnitud_danio_siniestro,
				s.observacion_siniestro,
				s.valor_total,
				s.monto_danio_terceros,
				s.documentacion_siniestro,
				s.estado,
				v.placa,
				v.modelo,
				v.marca,
				v.localizacion'
			
		using _placa,_fecha_inicio,_fecha_fin,_localizacion;
	
END;
$$;

alter function mostrar_siniestros_individual(text, date, date, text) owner to postgres;

