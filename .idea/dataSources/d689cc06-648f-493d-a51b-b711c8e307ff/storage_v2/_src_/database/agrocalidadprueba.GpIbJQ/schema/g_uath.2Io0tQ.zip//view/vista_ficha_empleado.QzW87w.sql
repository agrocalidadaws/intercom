create view vista_ficha_empleado
            (identificador, nombre, apellido, id_datos_capacitacion, titulo_capacitacion, pais, institucion, horas,
             fecha_inicio_capacitacion, fecha_fin_capacitacion, archivo_capacitacion)
as
SELECT fe.identificador,
       fe.nombre,
       fe.apellido,
       dca.id_datos_capacitacion,
       dca.titulo_capacitacion,
       dca.pais,
       dca.institucion,
       dca.horas,
       dca.fecha_inicio AS fecha_inicio_capacitacion,
       dca.fecha_fin    AS fecha_fin_capacitacion,
       dca.archivo_capacitacion
FROM g_uath.ficha_empleado fe
         LEFT JOIN g_uath.datos_capacitacion dca ON fe.identificador::text = dca.identificador::text;

alter table vista_ficha_empleado
    owner to postgres;

