create function nombre_catalogo(v_id numeric) returns character varying
    strict
    language plpgsql
as
$$
DECLARE
  V_RESULT VARCHAR;
BEGIN
  SELECT NOMBRE INTO V_RESULT FROM G_INOCUIDAD.IC_CATALOGO WHERE IC_CATALOGO_ID = v_id;
  RETURN V_RESULT;
END;
$$;

alter function nombre_catalogo(numeric) owner to postgres;

