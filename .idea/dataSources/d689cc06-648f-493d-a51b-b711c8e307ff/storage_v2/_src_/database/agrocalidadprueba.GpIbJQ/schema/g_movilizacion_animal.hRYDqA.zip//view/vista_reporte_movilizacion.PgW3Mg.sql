create view vista_reporte_movilizacion
            (id_movilizacion_animal, numero_certificado, lugar_emision, identificador_emisor, nombre_emisor,
             lugar_movilizacion_origen, provincia_origen, sitio_origen, area_origen, lugar_movilizacion_destino,
             provincia_destino, sitio_destino, area_destino, identificador_autorizado, medio_transporte, placa,
             identificacion_conductor, descripcion_transporte, observacion, usuario_empresa, usuario_responsable,
             estado, fecha_movilizacion_desde, fecha_movilizacion_hasta, fecha_registro, fecha_anulacion, total)
as
SELECT m.id_movilizacion_animal,
       m.numero_certificado,
       m.lugar_emision,
       m.usuario_responsable         AS identificador_emisor,
       CASE
           WHEN o.razon_social::text = ''::text THEN ((o.nombre_representante::text || ' '::text) ||
                                                      o.apellido_representante::text)::character varying
           ELSE o.razon_social
           END                       AS nombre_emisor,
       tmo.lugar_movilizacion_animal AS lugar_movilizacion_origen,
       so.provincia                  AS provincia_origen,
       so.nombre_lugar               AS sitio_origen,
       ao.nombre_area                AS area_origen,
       tmd.lugar_movilizacion_animal AS lugar_movilizacion_destino,
       sd.provincia                  AS provincia_destino,
       sd.nombre_lugar               AS sitio_destino,
       ad.nombre_area                AS area_destino,
       m.identificador_autorizado,
       m.medio_transporte,
       m.placa,
       m.identificacion_conductor,
       m.descripcion_transporte,
       m.observacion,
       m.usuario_empresa,
       m.usuario_responsable,
       m.estado,
       m.fecha_movilizacion_desde,
       m.fecha_movilizacion_hasta,
       m.fecha_registro,
       m.fecha_anulacion,
       m.total
FROM g_movilizacion_animal.movilizacion_animales m,
     g_operadores.sitios so,
     g_operadores.areas ao,
     g_operadores.sitios sd,
     g_operadores.areas ad,
     g_catalogos.tipo_movilizacion_animales tmo,
     g_operadores.operadores o,
     g_catalogos.tipo_movilizacion_animales tmd
WHERE m.id_sitio_origen = so.id_sitio
  AND m.id_area_origen = ao.id_area
  AND m.id_sitio_destino = sd.id_sitio
  AND m.id_area_destino = ad.id_area
  AND m.id_tipo_movilizacion_origen = tmo.id_tipo_movilizacion_animales
  AND m.id_tipo_movilizacion_destino = tmd.id_tipo_movilizacion_animales
  AND m.usuario_responsable::text = o.identificador::text;

alter table vista_reporte_movilizacion
    owner to postgres;

