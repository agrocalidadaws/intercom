create view vista_busqueda_inspeccion_occs
            (id_inspeccion_occs, identificador, fecha_creacion, num_solicitud, fecha, nombre_predio, nombre_propietario,
             cedula_propietario, telefono, correo_electronico, nombre_asociacion, id_provincia, provincia, id_canton,
             canton, id_parroquia, parroquia, sector, utm_x, utm_y, utm_z, altitud, latitud, longitud, zona, estado,
             identificador_modificacion, fecha_modificacion, nueva_inspeccion, fecha_nueva_inspeccion,
             identificador_cierre, fecha_cierre, observaciones, imagen_mapa, ruta_informe)
as
SELECT DISTINCT ioccs.id_inspeccion_occs,
                ioccs.identificador,
                ioccs.fecha_creacion,
                ioccs.num_solicitud,
                ioccs.fecha,
                ioccs.nombre_predio,
                ioccs.nombre_propietario,
                ioccs.cedula_propietario,
                ioccs.telefono,
                ioccs.correo_electronico,
                ioccs.nombre_asociacion,
                ioccs.id_provincia,
                ioccs.provincia,
                ioccs.id_canton,
                ioccs.canton,
                ioccs.id_parroquia,
                ioccs.parroquia,
                ioccs.sector,
                ioccs.utm_x,
                ioccs.utm_y,
                ioccs.utm_z,
                ioccs.altitud,
                ioccs.latitud,
                ioccs.longitud,
                ioccs.zona,
                ioccs.estado,
                ioccs.identificador_modificacion,
                ioccs.fecha_modificacion,
                ioccs.nueva_inspeccion,
                ioccs.fecha_nueva_inspeccion,
                ioccs.identificador_cierre,
                ioccs.fecha_cierre,
                ioccs.observaciones,
                ioccs.imagen_mapa,
                ioccs.ruta_informe
FROM g_programas_control_oficial.inspeccion_occs ioccs;

alter table vista_busqueda_inspeccion_occs
    owner to postgres;

