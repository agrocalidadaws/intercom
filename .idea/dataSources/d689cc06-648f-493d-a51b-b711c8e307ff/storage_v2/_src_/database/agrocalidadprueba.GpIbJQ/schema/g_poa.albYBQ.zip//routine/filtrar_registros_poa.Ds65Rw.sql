create function filtrar_registros_poa(_subproceso integer, _asunto text, _fecha_inicio timestamp without time zone, _fecha_fin timestamp without time zone, _estado integer, _anio integer) returns SETOF g_poa.vista_registros_poa
    language plpgsql
as
$$
DECLARE
	query text;
BEGIN	
	return query EXECUTE '	
		SELECT
			*
		FROM 
			g_poa.vista_registros_poa
		WHERE 
		        
			($1 is NULL or id_subproceso = $1) and 
			($2 is NULL or descripcion ilike $2) and 
			($3 is NULL or fecha_creacion >= $3) and 
			($4 is NULL or fecha_creacion <= $4) and
			($5 is NULL or estado = $5) and
			($6 is NULL or anio = $6)
		ORDER BY
			fecha_creacion'
		using _subproceso,_asunto,_fecha_inicio,_fecha_fin, _estado, _anio;
	
END;
$$;

alter function filtrar_registros_poa(integer, text, timestamp, timestamp, integer, integer) owner to postgres;

