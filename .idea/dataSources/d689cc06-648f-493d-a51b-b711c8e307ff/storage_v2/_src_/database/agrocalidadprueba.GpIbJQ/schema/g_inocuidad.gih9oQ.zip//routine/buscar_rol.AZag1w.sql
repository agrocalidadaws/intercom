create function buscar_rol(v_rol character varying, v_identificador character varying) returns boolean
    strict
    language plpgsql
as
$$
DECLARE
  V_RESULT BOOLEAN;
  V_TOTAL NUMERIC;
BEGIN
  SELECT COUNT(1) INTO V_TOTAL
  FROM g_usuario.usuarios_perfiles UP
  WHERE UP.ID_PERFIL=(SELECT id_perfil FROM g_usuario.perfiles WHERE codificacion_perfil=v_rol)
        AND UP.IDENTIFICADOR = v_identificador;
  V_RESULT:=V_TOTAL>0;
  RETURN V_RESULT;
END;
$$;

alter function buscar_rol(varchar, varchar) owner to postgres;

