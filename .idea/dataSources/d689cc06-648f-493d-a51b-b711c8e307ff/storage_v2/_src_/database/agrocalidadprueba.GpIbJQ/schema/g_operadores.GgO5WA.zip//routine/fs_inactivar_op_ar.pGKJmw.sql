create function fs_inactivar_op_ar(identificador_operador text, alcances_cancelar text) returns text
    language plpgsql
as
$$
DECLARE
    videntificador text := identificador_operador;
    valcancesCancelar text := null;
    
    area text := null;
    area_anterior text := 'ANTERIOR';
    aareasinactivar int[] := null;

    rareas record;

BEGIN
    -- Prevenir bloqueos en concurrencia
    PERFORM pg_advisory_xact_lock(1);

    CASE WHEN alcances_cancelar = 'TODOS' THEN 
        valcancesCancelar := 'PRC,PRO,COM,REC';
    ELSE 
        valcancesCancelar := alcances_cancelar;
    END CASE;

    FOR rareas IN (
        SELECT
            pao.id_area,
            op.id_operacion,
            op.estado
        FROM
            g_operadores.operadores_area_operaciones pao
            INNER JOIN g_operadores.operaciones op ON pao.id_operador_tipo_operacion = op.id_operador_tipo_operacion
            INNER JOIN g_catalogos.tipos_operacion top ON op.id_tipo_operacion = top.id_tipo_operacion
        WHERE
            op.identificador_operador = videntificador
            AND op.estado != 'noHabilitado'
            AND top.id_area = 'AI'
            AND top.codigo IN (SELECT unnest(string_to_array(valcancesCancelar, ',')))
        ORDER BY
            top.codigo ASC
    )
    LOOP
        UPDATE g_operadores.productos_areas_operacion
        SET     
            estado = 'noHabilitado', 
            observacion = 'Cambio de estado realizado por la opción de cancelación del codigo POA'
        WHERE id_operacion = rareas.id_operacion;

        UPDATE g_operadores.operaciones
        SET
            estado = 'noHabilitado',
            observacion = 'Cambio de estado realizado por la opción de cancelación del codigo POA',
            observacion_tecnica = 'Cambio de estado realizado por la opción de cancelación del codigo POA',
            estado_anterior = rareas.estado,
            fecha_modificacion = now()
        WHERE id_operacion = rareas.id_operacion;

        area := rareas.id_area;
        IF area != area_anterior THEN
            aareasinactivar := array_append(aareasinactivar, rareas.id_area);
        END IF;
        area_anterior := rareas.id_area;
    END LOOP;

    IF (array_length(aareasinactivar, 1) > 0) THEN
        FOR i IN array_lower(aareasinactivar, 1) .. array_upper(aareasinactivar, 1) LOOP
            UPDATE g_operadores.areas SET estado = 'inactivo' WHERE id_area = aareasinactivar[i];    
        END LOOP;
    END IF;

    -- Actualizar codigos y subcodigos POA
    IF (alcances_cancelar = 'TODOS') THEN
        UPDATE g_operadores.subcodigos_poa SET estado = 'noHabilitado' 
        WHERE g_operadores.subcodigos_poa.estado= 'habilitado'
          AND  g_operadores.subcodigos_poa.id_codigo_poa = (
              SELECT g_operadores.codigos_poa.id_codigo_poa 
              FROM g_operadores.codigos_poa
              WHERE g_operadores.codigos_poa.identificador_operador = videntificador 
              AND g_operadores.codigos_poa.estado = 'activo');

        UPDATE g_operadores.codigos_poa SET estado = 'inactivo' 
          WHERE g_operadores.codigos_poa.identificador_operador = videntificador 
          AND g_operadores.codigos_poa.estado = 'activo';
    ELSE
        UPDATE g_operadores.subcodigos_poa SET estado = 'noHabilitado' 
          WHERE g_operadores.subcodigos_poa.estado= 'habilitado'
          AND g_operadores.subcodigos_poa.id_codigo_poa = (
              SELECT g_operadores.codigos_poa.id_codigo_poa 
              FROM g_operadores.codigos_poa 
              WHERE g_operadores.codigos_poa.identificador_operador = videntificador 
              AND g_operadores.codigos_poa.estado = 'activo')
          AND g_operadores.subcodigos_poa.id_tipo_operacion IN (
              SELECT g_catalogos.tipos_operacion.id_tipo_operacion 
              FROM g_catalogos.tipos_operacion
              WHERE g_catalogos.tipos_operacion.id_area = 'AI' 
              AND  g_catalogos.tipos_operacion.codigo IN (
                  SELECT unnest(string_to_array(valcancesCancelar, ','))));
    END IF;

    RETURN 'EXITO';

EXCEPTION
    WHEN others THEN
        RETURN 'FALLO';
END;
$$;

alter function fs_inactivar_op_ar(text, text) owner to postgres;

