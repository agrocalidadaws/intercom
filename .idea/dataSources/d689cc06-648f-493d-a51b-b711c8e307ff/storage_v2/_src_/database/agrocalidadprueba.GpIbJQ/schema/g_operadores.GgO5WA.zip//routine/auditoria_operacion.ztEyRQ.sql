create function auditoria_operacion() returns trigger
    language plpgsql
as
$$ 
BEGIN
	
		IF (TG_OP = 'INSERT') THEN	
			INSERT INTO g_operadores.auditoia_operaciones(identificador_operador, id_operador_tipo_operacion, id_historial_operacion, id_operacion, estado_actual, observacion, accion) VALUES (NEW.identificador_operador, NEW.id_operador_tipo_operacion, NEW.id_historial_operacion, NEW.id_operacion, NEW.estado, NEW.observacion, TG_OP);
		ELSIF(TG_OP = 'UPDATE') THEN
			IF (NEW.estado != OLD.estado) THEN
				INSERT INTO g_operadores.auditoia_operaciones(identificador_operador, id_operador_tipo_operacion, id_historial_operacion, id_operacion, estado_anterior, estado_actual, observacion, accion) VALUES (NEW.identificador_operador, NEW.id_operador_tipo_operacion, NEW.id_historial_operacion, NEW.id_operacion, OLD.estado, NEW.estado, NEW.observacion, TG_OP);
			END IF;
		ELSIF(TG_OP = 'DELETE') THEN
			INSERT INTO g_operadores.auditoia_operaciones(identificador_operador, id_operador_tipo_operacion, id_historial_operacion, id_operacion, estado_anterior, observacion, accion) VALUES (OLD.identificador_operador, OLD.id_operador_tipo_operacion, OLD.id_historial_operacion, OLD.id_operacion, OLD.estado, OLD.observacion, TG_OP);
		
	END IF;

	RETURN NEW;
END; 
	
$$;

alter function auditoria_operacion() owner to postgres;

