create function completar_encuesta() returns trigger
    language plpgsql
as
$$ 
DECLARE
	_opcion g_encuesta.opciones;
BEGIN
	SELECT 
		* 
	INTO 
		_opcion 
	FROM 
		g_encuesta.opciones o 
	WHERE 
		o.id_opcion = NEW.id_opcion and 
		o.id_pregunta = NEW.id_pregunta;
	NEW.id_encuesta = _opcion.id_encuesta;
	NEW.opcion_respuesta = _opcion.opcion;
	NEW.ponderacion = _opcion.ponderacion;
	RETURN NEW;
END;
$$;

alter function completar_encuesta() owner to postgres;

