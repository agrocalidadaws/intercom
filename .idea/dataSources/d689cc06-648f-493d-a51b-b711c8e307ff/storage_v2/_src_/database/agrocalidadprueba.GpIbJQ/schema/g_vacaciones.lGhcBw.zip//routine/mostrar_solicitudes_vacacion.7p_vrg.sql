create function mostrar_solicitudes_vacacion(_tipo_solicitud integer, _fecha_desde timestamp without time zone, _fecha_hasta timestamp without time zone, _id_solicitud integer, _identificador text, _id_director text, _estado text) returns SETOF g_vacaciones.vista_permisos_vacaciones
    language plpgsql
as
$$
DECLARE
	query text;
BEGIN	
	return query EXECUTE 'SELECT
			*
		FROM 
			g_vacaciones.vista_permisos_vacaciones
		WHERE 		        
			($1 is NULL or sub_tipo = $1) and 
			($2 is NULL or fecha_inicio between $2 and $3) and 
			($3 is NULL or fecha_fin between $2 and $3) and
			($4 is NULL or id_permiso_empleado = $4) and
			($5 is NULL or identificador = $5) and
			($6 is NULL or identificador_jefe_superior = $6) and
			($7 is NULL or estado = $7)' 
		using _tipo_solicitud,_fecha_desde,_fecha_hasta,_id_solicitud,_identificador,_id_director,_estado;
	
END;
$$;

alter function mostrar_solicitudes_vacacion(integer, timestamp, timestamp, integer, text, text, text) owner to postgres;

