create function mostrar_gasolineras_individual(_gasolinera integer, _fecha_inicio date, _fecha_fin date, _localizacion text) returns SETOF g_transportes.gasolineras_individual
    language plpgsql
as
$$
DECLARE
	query text;
BEGIN	
	return query EXECUTE '
			SELECT 
				COUNT(c.id_combustible) numero,
				(SELECT SUM(valor_liquidacion) FROM g_transportes.combustible WHERE gasolinera = $1 and ($2 is NULL or  fecha_solicitud >= $2) and 
				($3 is NULL or  fecha_solicitud <= $3) and tipo_combustible like ''%Super%'' and estado = 3) suma_super,
				(SELECT COUNT(id_combustible) FROM g_transportes.combustible WHERE gasolinera = $1 and ($2 is NULL or  fecha_solicitud >= $2) and 
				($3 is NULL or  fecha_solicitud <= $3) and tipo_combustible like ''%Super%'' and estado = 3) numero_super,
				(SELECT SUM(valor_liquidacion) FROM g_transportes.combustible WHERE gasolinera = $1 and ($2 is NULL or  fecha_solicitud >= $2) and 
				($3 is NULL or  fecha_solicitud <= $3) and tipo_combustible like ''%Diesel%'' and estado = 3) suma_diesel,
				(SELECT COUNT(id_combustible) FROM g_transportes.combustible WHERE gasolinera = $1 and ($2 is NULL or  fecha_solicitud >= $2) and 
				($3 is NULL or  fecha_solicitud <= $3) and tipo_combustible like ''%Diesel%'' and estado = 3) numero_diesel,
				(SELECT SUM(valor_liquidacion) FROM g_transportes.combustible WHERE gasolinera = $1 and ($2 is NULL or  fecha_solicitud >= $2) and 
				($3 is NULL or  fecha_solicitud <= $3) and tipo_combustible like ''%Extra%'' and estado = 3) suma_extra,
				(SELECT COUNT(id_combustible) FROM g_transportes.combustible WHERE gasolinera = $1 and ($2 is NULL or  fecha_solicitud >= $2) and 
				($3 is NULL or  fecha_solicitud <= $3) and tipo_combustible like ''%Extra%'' and estado = 3) numero_extra,

				(SELECT SUM(valor_liquidacion) FROM g_transportes.combustible WHERE gasolinera = $1 and ($2 is NULL or  fecha_solicitud >= $2) and 
				($3 is NULL or  fecha_solicitud <= $3) and tipo_combustible like ''%Ecopais%'' and estado = 3) suma_ecopais,
				(SELECT COUNT(id_combustible) FROM g_transportes.combustible WHERE gasolinera = $1 and ($2 is NULL or  fecha_solicitud >= $2) and 
				($3 is NULL or  fecha_solicitud <= $3) and tipo_combustible like ''%Ecopais%'' and estado = 3) numero_ecopais,



				(SELECT COUNT(id_combustible) FROM g_transportes.combustible WHERE gasolinera = $1 and ($2 is NULL or  fecha_solicitud >= $2) and 
				($3 is NULL or  fecha_solicitud <= $3) and estado in (1, 2)) numero_pendientes,
				(SELECT COUNT(id_combustible) FROM g_transportes.combustible WHERE gasolinera = $1 and ($2 is NULL or  fecha_solicitud >= $2) and 
				($3 is NULL or  fecha_solicitud <= $3) and estado = 9) numero_eliminados,
				g.nombre,
				g.direccion,
				g.telefono,
				g.localizacion
			FROM
				g_transportes.combustible c,
				g_transportes.gasolineras g
			WHERE
				c.gasolinera = g.id_gasolinera and
				g.id_gasolinera = $1 and
				($2 is NULL or  c.fecha_solicitud >= $2) and 
				($3 is NULL or  c.fecha_solicitud <= $3) and
				($4 is NULL or $4 = g.localizacion)
			GROUP BY 
				g.nombre,
				g.direccion,
				g.telefono,
				g.localizacion'
			
		using _gasolinera,_fecha_inicio,_fecha_fin,_localizacion;
	
END;
$$;

alter function mostrar_gasolineras_individual(integer, date, date, text) owner to postgres;

