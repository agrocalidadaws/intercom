create function quitar_caracteres_especiales(character varying) returns text
    language sql
as
$$
SELECT TRANSLATE
($1,
'áàâãäéèêëíìïóòôõöúùûüÁÀÂÃÄÉÈÊËÍÌÏÓÒÔÕÖÚÙÛÜçÇñÑ ',
'aaaaaeeeeiiiooooouuuuAAAAAEEEEIIIOOOOOUUUUcCnn');
$$;

alter function quitar_caracteres_especiales(varchar) owner to postgres;

