create function mostrar_movilizacion_general(_placa text, _fecha_inicio timestamp without time zone, _fecha_fin date, _localizacion text, _cantidad integer) returns SETOF g_transportes.movilizacion_general
    language plpgsql
as
$$
DECLARE
	query text;
BEGIN	
	return query EXECUTE '
			SELECT 
				MAX(m.kilometraje_final) -MIN(m.kilometraje_inicial) valor,
				v.placa,
				v.modelo,
				v.marca,
				v.localizacion
			FROM 
				g_transportes.movilizaciones m,
				g_transportes.vehiculos v 
			WHERE
				m.placa = v.placa and
				($1 is NULL or m.placa like $1) and 
				($2 is NULL or  m.fecha_solicitud >= $2) and 
				($3 is NULL or  m.fecha_solicitud <= $3) and
				($4 is NULL or $4 = v.localizacion) and
				m.estado = 4
			GROUP BY 
				v.placa,
				v.modelo,
				v.marca,
				v.localizacion
			ORDER BY valor desc
			LIMIT $5'
			
		using _placa,_fecha_inicio,_fecha_fin,_localizacion,_cantidad;
	
END;
$$;

alter function mostrar_movilizacion_general(text, timestamp, date, text, integer) owner to postgres;

