create function funcion_insertar_cantidad_suero(_id_produccion integer, _cantidad_suero_producido double precision) returns void
    language plpgsql
as
$$
DECLARE _suero INTEGER;
BEGIN
	INSERT INTO g_movilizacion_suero.detalle_cantidad_suero(id_produccion, cantidad_suero_producido,cantidad_suero_restante)
		VALUES (_id_produccion, _cantidad_suero_producido, _cantidad_suero_producido);
		
END;
$$;

alter function funcion_insertar_cantidad_suero(integer, double precision) owner to postgres;

