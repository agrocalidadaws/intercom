create function enviar_correo_certificado_firmado() returns trigger
    language plpgsql
as
$$
/*
-------------------------------------------------------------------------
--  [g_firma_documentos.enviar_correo_certificado_firmado() ]
--               
--  Esta funcion Permite ingresar en el esquema g_correos.correos los certificados firmados
--  de exportación de mascotas queda generico para cualquier tipo 
--
--  VERSION		AUTOR					FECHA			HU			                           CAMBIO
--	1			Kleber Armijos		17-03-2024			Actulizacion Exportacion Mascotas      
-------------------------------------------------------------------------
*/
DECLARE
vcorreo_exportador_usuario_final character varying;
vnombre_exportador character varying;
vid_correo integer;
vasunto character varying ;
vcuerpo character varying ;
BEGIN
	
    IF  NEW.estado IN ('Atendida')  AND NEW.razon_documento ='Certificacion Exportacion Mascota' THEN 
        SELECT  UPPER(nombre_propietario),correo_propietario 
        INTO vnombre_exportador,vcorreo_exportador_usuario_final
        FROM g_mercancias_valor_comercial.solicitudes WHERE id_solicitud=NEW.id_origen;
        vasunto:='Aprobación de Certificado zoosanitario de exportación de mascotas – Solicitud Nro. '||new.id_origen;
        vcuerpo:='<tr>
                    <td style="font-family:"Text Me One", 
                     "Segoe UI", "Tahoma", "Helvetica", "freesans", "sans-serif2; padding-top:25px; font-size:14px;color:#2a2a2a; width: 80%; text-align:justify;">'
                     ||'Estimado Sr. <font color="green">' || vnombre_exportador || '</font>,<br/><br/>'
                     ||'Por medio de la presente se comunica que el Certificado con, Nro. <font color="green">' ||NEW.id_origen ||'</font>'||
                     ' ha sido APROBADO .<br/><br/>' 
                     --||'se adjunta Documento.<br/><br/>'
                     ||'Saludos Cordiales.
                    </td>
                 </tr>';
         INSERT INTO g_correos.correos(
									   asunto,
									   cuerpo,
									   estado,
									   codigo_modulo,
									   tabla_modulo,
									   id_solicitud_tabla	   
									  )
        VALUES (vasunto, 
				vcuerpo,
			   	'Por enviar',
				'PRG_EXPO_IMPO_V2',
				'g_firma_documentos.documentos',
				NEW.id_documento
			   )
		RETURNING id_correo INTO vid_correo; 
		
		INSERT INTO g_correos.destinatarios(id_correo,destinatario_correo)
		VALUES(vid_correo,vcorreo_exportador_usuario_final);
        
       -- INSERT INTO  g_correos.documentos_adjuntos (id_correo,ruta_documento_adjunto)
       -- VALUES (vid_correo,NEW.archivo_salida);
        
    END IF;
RETURN NEW;
END;
$$;

alter function enviar_correo_certificado_firmado() owner to postgres;

