create function mostrar_vehiculosdebaja_general(_placa text, _localizacion text, _cantidad integer) returns SETOF g_transportes.mostrar_vehiculosdebaja_general
    language plpgsql
as
$$
DECLARE
	query text;
BEGIN	
	return query EXECUTE '
			SELECT 
				placa,
				localizacion
			FROM 
				g_transportes.vehiculos
			WHERE
				($1 is NULL or placa like $1) and 
				($2 is NULL or $2 = localizacion) and
				estado = 9
			LIMIT $3'
			
		using _placa,_localizacion,_cantidad;
	
END;
$$;

alter function mostrar_vehiculosdebaja_general(text, text, integer) owner to postgres;

