create view ic_v_analisis_muestra
            (ic_muestra_id, ic_analisis_muestra_id, activo, insumo, lmr, limite_minimo, limite_maximo, unidad_medida,
             valor, observaciones, obs, fecha_recepcion_muestra, fecha_analisis_muestra, numero_informe_lab,
             numero_memorando, observacion_rechazo)
as
SELECT am.ic_muestra_id,
       am.ic_analisis_muestra_id,
       am.activo,
       (SELECT productos.nombre_comun AS asingrediente_activo
        FROM g_catalogos.productos
        WHERE productos.id_producto::numeric = rv.ic_insumo_id::numeric) AS insumo,
       (SELECT ic_lmr.nombre
        FROM g_inocuidad.ic_lmr
        WHERE ic_lmr.ic_lmr_id::numeric = pi.ic_lmr_id::numeric)         AS lmr,
       pi.limite_minimo,
       pi.limite_maximo,
       rv.um                                                             AS unidad_medida,
       rv.valor,
       rv.observaciones,
       rv.observaciones                                                  AS obs,
       am.fecha_recepcion_muestra,
       am.fecha_analisis_muestra,
       am.numero_informe_lab,
       am.numero_memorando,
       am.observacion_rechazo
FROM g_inocuidad.ic_analisis_muestra am
         LEFT JOIN g_inocuidad.ic_registro_valor rv ON am.ic_analisis_muestra_id::numeric = rv.ic_analisis_muestra_id::numeric
         LEFT JOIN g_inocuidad.ic_producto_insumo pi
                   ON pi.ic_producto_id = rv.ic_producto_id AND pi.ic_insumo_id = rv.ic_insumo_id;

alter table ic_v_analisis_muestra
    owner to postgres;

