create function mostrar_vehiculos_filtrados(_localizacion text, _placa text, _anio integer, _marca text, _modelo text, _fecha_inicio timestamp without time zone, _fecha_fin timestamp without time zone, _estado integer) returns SETOF g_transportes.vehiculos
    language plpgsql
as
$$
DECLARE
	query text;
BEGIN	
	return query EXECUTE '	
		SELECT
			*
		FROM 
			g_transportes.vehiculos v
		WHERE 
			($1 is NULL or placa like $1) and 
			($2 is NULL or anio_fabricacion = $2) and 
			($3 is NULL or marca like $3) and 
			($4 is NULL or modelo like $4) and
			($5 is NULL or estado = $5) and
			($6 is NULL or fecha_compra >= $6) and 
			($7 is NULL or fecha_compra <= $7) and
			($8 is NULL or $8 = localizacion) 
			
		ORDER BY
			v.placa'
		using _placa,_anio,_marca,_modelo,_estado,_fecha_inicio,_fecha_fin,_localizacion;
	
END;
$$;

alter function mostrar_vehiculos_filtrados(text, text, integer, text, text, timestamp, timestamp, integer) owner to postgres;

