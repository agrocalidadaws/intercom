create function fs_reporte_importaciones_subsanacion(pfecha_inicio date, pfecha_inicio1 date, OUT id_importacion integer, OUT razon_social character varying, OUT direccion character varying, OUT tipo_producto character varying, OUT subtipo_producto character varying, OUT nombre_producto character varying, OUT cantidad_producto double precision, OUT unidad_medida character varying, OUT peso double precision, OUT unidad_peso character varying, OUT pais_origen character varying, OUT razon_exportador character varying, OUT direccion_exportador character varying, OUT tipo_transporte character varying, OUT puerto_embarque character varying, OUT puerto_destino character varying, OUT id_vue character varying, OUT valor_fob double precision, OUT nombre_provincia character varying, OUT nombre_ciudad character varying, OUT fecha_creacion date, OUT aprobacion_revision_documental timestamp without time zone, OUT fecha_aprobacion date, OUT fecha_vigencia date, OUT fecha_ampliacion date, OUT fecha_modificacion date, OUT nombre_tecnico text, OUT descripcion character varying, OUT fecha_imposicion_tasa timestamp without time zone, OUT subsanacion_revision_documental text) returns SETOF record
    language plpgsql
as
$$
BEGIN
			 	CREATE TABLE temp_importaciones AS (
					SELECT
						i.id_importacion,
						o.razon_social,
						o.direccion,
						tp.nombre AS tipo_producto,
						sp.nombre AS subtipo_prodcuto,
						p.nombre_comun AS nombre_producto,
						ip.unidad AS cantidad_producto,
						ip.unidad_medida,
						ip.peso,
						ip.unidad_peso,
						i.pais_exportacion AS pais_origen,
						i.nombre_exportador AS razon_exportador,
						i.direccion_exportador,
						i.tipo_transporte,
						i.puerto_embarque,
						i.puerto_destino,
						i.id_vue,
						ip.valor_fob,
						i.nombre_provincia,
						i.nombre_ciudad,
						i.fecha_creacion,			

						rd.fecha_inspeccion AS aprobacion_revision_documental,					
						i.fecha_inicio AS fecha_aprobacion,
						i.fecha_vigencia,
						i.fecha_ampliacion,
						i.fecha_modificacion,
						fe.apellido ||' '|| fe.nombre AS nombre_tecnico,
						ra.descripcion
					FROM 
						g_importaciones.importaciones i,
						g_importaciones.importaciones_productos ip,
						g_catalogos.productos p,
						g_catalogos.subtipo_productos sp,
						g_catalogos.tipo_productos tp,
						g_operadores.operadores o,
						g_revision_solicitudes.grupos_solicitudes gs,
						g_revision_solicitudes.asignacion_inspector ai,
						g_revision_solicitudes.revision_documental rd,
						g_uath.ficha_empleado fe,
						g_catalogos.regimen_aduanero ra
					WHERE
						i.id_importacion = ip.id_importacion AND
						ip.id_producto = p.id_producto AND
						p.id_subtipo_producto = sp.id_subtipo_producto AND
						sp.id_tipo_producto = tp.id_tipo_producto AND
						o.identificador = i.identificador_operador AND
						i.estado IN ('aprobado','ampliado') AND
						i.id_importacion = gs.id_solicitud AND
						gs.id_grupo = ai.id_grupo AND
						ai.tipo_solicitud = 'Importación' AND
						ai.tipo_inspector = 'Documental' AND
						ai.id_grupo = rd.id_grupo AND
						rd.estado = 'pago' AND
						fe.identificador = ai.identificador_inspector AND
						i.regimen_aduanero = ra.id_regimen AND
						i.id_area = 'SV' AND
						i.fecha_inicio >=$1 and
						i.fecha_inicio <=$2
					);

	  
	  CREATE  TABLE temp_fecha_imposicion AS(	 	
	 	SELECT 
	 	 temp_importacion.id_importacion,
		 temp_importacion.razon_social,
		 temp_importacion.direccion,
		 temp_importacion.tipo_producto,
		 temp_importacion.subtipo_prodcuto,
		 temp_importacion.nombre_producto,
		 temp_importacion.cantidad_producto,
		 temp_importacion.unidad_medida,
		 temp_importacion.peso,
		 temp_importacion.unidad_peso,
		 temp_importacion.pais_origen,
		 temp_importacion.razon_exportador,
		 temp_importacion.direccion_exportador,
		 temp_importacion.tipo_transporte,
		 temp_importacion.puerto_embarque,
		 temp_importacion.puerto_destino,
		 temp_importacion.id_vue,
	 	 temp_importacion.valor_fob,
	 	 temp_importacion.nombre_provincia,
	 	 temp_importacion.nombre_ciudad,
	 	 temp_importacion.fecha_creacion,
	 	 temp_importacion.aprobacion_revision_documental,
	  	 temp_importacion.fecha_aprobacion,
	  	 temp_importacion.fecha_vigencia,
	  	 temp_importacion.fecha_ampliacion,
	  	 temp_importacion.fecha_modificacion,
	  	 temp_importacion.nombre_tecnico,
	  	 temp_importacion.descripcion,	 
 	MAX(f1.fecha_asignacion_monto) AS fecha_imposicion_tasa
 	FROM  
	 	temp_importaciones temp_importacion,
 		g_revision_solicitudes.grupos_solicitudes gs1, 
 		g_revision_solicitudes.asignacion_inspector ai1, 
 		g_revision_solicitudes.financiero f1 
 	WHERE 
 		gs1.id_grupo = ai1.id_grupo AND 
 		ai1.id_grupo = f1.id_grupo AND  
 		ai1.tipo_solicitud = 'Importación' AND 
 		ai1.tipo_inspector = 'Financiero' AND
 		 gs1.id_solicitud =temp_importacion.id_importacion AND 
 		 f1.estado = 'aprobado'
        GROUP BY  
	     temp_importacion.id_importacion,
         temp_importacion.razon_social,
		 temp_importacion.direccion,
		 temp_importacion.tipo_producto,
		 temp_importacion.subtipo_prodcuto,
		 temp_importacion.nombre_producto,
		 temp_importacion.cantidad_producto,
		 temp_importacion.unidad_medida,
		 temp_importacion.peso,
		 temp_importacion.unidad_peso,
		 temp_importacion.pais_origen,
		 temp_importacion.razon_exportador,
		 temp_importacion.direccion_exportador,
		 temp_importacion.tipo_transporte,
		 temp_importacion.puerto_embarque,
		 temp_importacion.puerto_destino,
		 temp_importacion.id_vue,
		 temp_importacion.valor_fob,
		 temp_importacion.nombre_provincia,
		 temp_importacion.nombre_ciudad,
		 temp_importacion.fecha_creacion,
		 temp_importacion.aprobacion_revision_documental,
	     temp_importacion.fecha_aprobacion,
	     temp_importacion.fecha_vigencia,
	     temp_importacion.fecha_ampliacion,
	     temp_importacion.fecha_modificacion,
	     temp_importacion.nombre_tecnico,
	     temp_importacion.descripcion
         ORDER BY  
		  temp_importacion.id_importacion ASC );	
	
 RETURN QUERY SELECT
			tfi.*,
			-- as subsanacion_revision_documental
			STRING_AGG(cast(tfi.aprobacion_revision_documental as text) , ' subsanacion -> ') as aprobacion_revision_documental
			FROM
				temp_fecha_imposicion tfi,
			g_revision_solicitudes.grupos_solicitudes gs2,
			g_revision_solicitudes.asignacion_inspector ai2,
			g_revision_solicitudes.revision_documental rd2
			WHERE
			 tfi.id_importacion = gs2.id_solicitud and
			 gs2.id_grupo = ai2.id_grupo and
			 ai2.tipo_solicitud = 'Importación' and
			 ai2.tipo_inspector = 'Documental' and
			 ai2.id_grupo = rd2.id_grupo
			group by tfi.id_importacion,
					tfi.razon_social,
					tfi.direccion,
					tfi.tipo_producto,
					tfi.subtipo_prodcuto,
					tfi.nombre_producto,
					tfi.cantidad_producto,
					tfi.unidad_medida,
					tfi.peso,
					tfi.unidad_peso,
					tfi.pais_origen,
					tfi.razon_exportador,
					tfi.direccion_exportador,
					tfi.tipo_transporte,
					tfi.puerto_embarque,
					tfi.puerto_destino,
					tfi.id_vue,
					tfi.valor_fob,
					tfi.nombre_provincia,
					tfi.nombre_ciudad,
					tfi.fecha_creacion,
					tfi.aprobacion_revision_documental,
					tfi.fecha_aprobacion,
					tfi.fecha_vigencia,
					tfi.fecha_ampliacion,
					tfi.fecha_modificacion,
					tfi.nombre_tecnico,
					tfi.descripcion,
					tfi.fecha_imposicion_tasa;
				

		DROP TABLE temp_importaciones;
		DROP TABLE temp_fecha_imposicion; 
		

END;
$$;

alter function fs_reporte_importaciones_subsanacion(date, date, out integer, out varchar, out varchar, out varchar, out varchar, out varchar, out double precision, out varchar, out double precision, out varchar, out varchar, out varchar, out varchar, out varchar, out varchar, out varchar, out varchar, out double precision, out varchar, out varchar, out date, out timestamp, out date, out date, out date, out date, out text, out varchar, out timestamp, out text) owner to postgres;

