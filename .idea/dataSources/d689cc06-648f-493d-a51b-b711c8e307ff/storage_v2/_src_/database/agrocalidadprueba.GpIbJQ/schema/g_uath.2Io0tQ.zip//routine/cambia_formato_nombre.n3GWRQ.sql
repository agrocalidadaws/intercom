create function cambia_formato_nombre(_nombre text, _apellido text) returns text
    language plpgsql
as
$$

DECLARE _nombres TEXT;
DECLARE _apellido1 TEXT;

BEGIN

	_apellido1:= _apellido ;

	IF (strpos(_apellido,' ')!=0) THEN
		_apellido = substr(_apellido,1,strpos(_apellido,' ')-1);
	END IF;

	IF (strpos(_nombre,' ')!=0) THEN
		_nombre = substr(_nombre,1,strpos(_nombre,' ') -1);
	END IF;

	_nombres:=(_apellido || ' ' || substr(split_part(_apellido1,' ',2),1,1) || '. ' || _nombre);
	RETURN _nombres;
END;
$$;

alter function cambia_formato_nombre(text, text) owner to postgres;

