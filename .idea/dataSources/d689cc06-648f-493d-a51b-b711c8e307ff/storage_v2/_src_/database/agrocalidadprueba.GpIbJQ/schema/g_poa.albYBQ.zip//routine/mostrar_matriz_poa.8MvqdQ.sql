create function mostrar_matriz_poa(_area text, _objetivo integer, _proceso integer, _subproceso integer, _actividad text, _fecha_inicio timestamp without time zone, _fecha_fin timestamp without time zone, _cobertura text, _poblacion text, _responsables text, _verificacion text, _anio integer) returns SETOF g_poa.vista_matriz_poa
    language plpgsql
as
$$
DECLARE
	query text;
BEGIN	
	_area=replace(_area, '-', ''',''');
	return query EXECUTE '	
		SELECT
			*
		FROM 
			g_poa.vista_matriz_poa
		WHERE 
		        
			($1 is NULL or id_area in ('''|| $1 ||''')) and 
			($2 is NULL or id_objetivo = $2) and 
			($3 is NULL or id_proceso = $3) and 
			($4 is NULL or id_subproceso = $4) and  
			($5 is NULL or codigo_actividad like $5) and 
			($6 is NULL or fecha_creacion >= $6) and 
			($7 is NULL or fecha_creacion <= $7) and
			($8 is NULL or cobertura like $8) and
			($9 is NULL or poblacion like $9) and
			($10 is NULL or responsable like $10) and
			($11 is NULL or medios_verificacion like $11) and
			($12 is NULL or anio = $12) 
			
		ORDER BY
			fecha_creacion'
		using _area,_objetivo,_proceso, _subproceso,_actividad, _fecha_inicio,_fecha_fin, _cobertura,_poblacion, _responsables,_verificacion, _anio ;
	
END;
$$;

alter function mostrar_matriz_poa(text, integer, integer, integer, text, timestamp, timestamp, text, text, text, text, integer) owner to postgres;

