create function f_guardar_transaccion(p_id_inspeccion_fitosanitaria integer) returns void
    language plpgsql
as
$$

	DECLARE
	
	v_fecha_inspeccion date;

	BEGIN
		
		---Inicio borrado de datos de total y transaccion---
		WITH total_inspeccion AS (DELETE FROM 
									g_inspeccion_fitosanitaria.total_inspeccion_fitosanitaria tif
								WHERE 
									tif.id_inspeccion_fitosanitaria = p_id_inspeccion_fitosanitaria
								RETURNING id_total_inspeccion_fitosanitaria
		)
		DELETE FROM 
			g_inspeccion_fitosanitaria.transaccion_inspeccion_fitosanitaria ttf
		WHERE 
			id_total_inspeccion_fitosanitaria IN (SELECT id_total_inspeccion_fitosanitaria FROM total_inspeccion);			
		---Fin borrado de datos de total y transaccion---
				
		SELECT fecha_inspeccion FROM g_inspeccion_fitosanitaria.inspeccion_fitosanitaria WHERE id_inspeccion_fitosanitaria = p_id_inspeccion_fitosanitaria INTO v_fecha_inspeccion;

		---Inicio insercion en tabla de total de inspeccion---
		INSERT INTO 
		g_inspeccion_fitosanitaria.total_inspeccion_fitosanitaria (id_inspeccion_fitosanitaria, id_subtipo_producto, id_producto, nombre_producto, cantidad_aprobada_ingreso, cantidad_aprobada_egreso
																	, total_cantidad_aprobada, peso_aprobado_ingreso, peso_aprobado_egreso, total_peso_aprobado, cantidad_aprobada, id_unidad_cantidad_producto
																	, peso_aprobado, id_unidad_peso_producto, id_tipo_tratamiento, id_tratamiento, id_duracion, duracion, id_temperatura, temperatura
																	, fecha_tratamiento, producto_quimico, id_concentracion, concentracion, fecha_inspeccion)
			SELECT 
				tpif.id_inspeccion_fitosanitaria, tpif.id_subtipo_producto, tpif.id_producto, pif.nombre_producto , tpif.cantidad_aprobada AS cantidad_aprobada_ingreso, 0::double precision AS cantidad_aprobada_egreso
				, tpif.cantidad_aprobada AS total_cantidad_aprobada, tpif.peso_aprobado AS peso_aprobado_ingreso, 0::double precision AS peso_aprobado_egreso, tpif.peso_aprobado AS total_peso_aprobado, tpif.cantidad_aprobada, pif.id_unidad_cantidad_producto
				, tpif.peso_aprobado, pif.id_unidad_peso_producto, pif.id_tipo_tratamiento, pif.id_tratamiento, pif.id_duracion, pif.duracion, pif.id_temperatura, pif.temperatura
				, pif.fecha_tratamiento, pif.producto_quimico, pif.id_concentracion, pif.concentracion, v_fecha_inspeccion
			FROM
				g_inspeccion_fitosanitaria.productos_inspeccion_fitosanitaria pif
			INNER JOIN (SELECT
							MIN(id_producto_inspeccion_fitosanitaria) as id_producto_inspeccion_fitosanitaria
							, id_inspeccion_fitosanitaria
							, id_subtipo_producto
							, id_producto
							, SUM(cantidad_aprobada) as cantidad_aprobada
							, SUM(peso_aprobado) as peso_aprobado
						FROM 
							g_inspeccion_fitosanitaria.productos_inspeccion_fitosanitaria
						GROUP BY
							id_inspeccion_fitosanitaria, id_subtipo_producto, id_producto) tpif ON tpif.id_producto_inspeccion_fitosanitaria = pif.id_producto_inspeccion_fitosanitaria
			WHERE
				tpif.id_inspeccion_fitosanitaria = p_id_inspeccion_fitosanitaria;
		---Fin insercion en tabla de total de inspeccion---	
	END;
	
$$;

alter function f_guardar_transaccion(integer) owner to postgres;

