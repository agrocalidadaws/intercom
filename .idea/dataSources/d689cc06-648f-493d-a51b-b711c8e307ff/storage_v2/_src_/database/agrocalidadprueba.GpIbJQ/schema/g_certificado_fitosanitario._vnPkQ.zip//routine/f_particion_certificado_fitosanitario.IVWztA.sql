create function f_particion_certificado_fitosanitario(p_id_certificado_fitosanitario integer, p_motivo_reemplazo text, p_datos_particion jsonb) returns jsonb
    language plpgsql
as
$$

	DECLARE

		p_id_certificado_fitosanitario INTEGER := p_id_certificado_fitosanitario;
		p_motivo_reemplazo TEXT = p_motivo_reemplazo;
		p_datos_particion JSONB:= p_datos_particion;
		--p_datos_particion JSONB:= '{"1":{"datosPuertosDestino":[{"idPuerto":"43651"}],"datosIdioma":[{"idIdioma":"1"}],"datosProductos":[{"idProducto":2160,"cantidadComercial":"0.5","pesoNeto":"3"},{"idProducto":16690,"cantidadComercial":"40","pesoNeto":"200"}]},"2":{"datosPuertosDestino":[{"idPuerto":"83"}],"datosIdioma":[{"idIdioma":"2"}],"datosProductos":[{"idProducto":2160,"cantidadComercial":"0.5","pesoNeto":"3"},{"idProducto":16690,"cantidadComercial":"6","pesoNeto":"76"}]}}';
		
		--RECORRER JSON--	
		v_numero_pais INTEGER;
		a_paises JSONB;
		v_id_puerto INTEGER;
		v_id_idioma INTEGER;
		a_datos_puertos JSONB;
		a_datos_idioma JSONB;
		a_datos_productos JSONB;
		
		--VALORES PAIS--
		v_id_pais_destino_origen INTEGER;
		
		--VALORES PRODUCTOS--
		v_id_producto INTEGER;
		v_cantidad_comercial NUMERIC; -- Variable para almacenar la cantidadComercial
		v_peso_neto NUMERIC; -- Variable para almacenar el pesoNeto
		v_peso_bruto NUMERIC; -- Variable para almacenar el pesoBruto

		--VALIDAR INFORMACION--
		r_tmp_productos_cantidades RECORD;
		r_datos_cantidad_cfe_origen RECORD;

		--BANDERAS--	
		v_bandera_validar_registro BOOLEAN := true;
		a_validar_registro VARCHAR [];
		
		-- RETORNAR --
		a_resultado JSONB;
		resultado TEXT := 'Exito';
		mensaje TEXT := 'Los datos fueron registrados con éxito';
		clase TEXT := '';
		
		--REGISTRO CFE--
		r_datos_generales_cfe RECORD;
		r_cfe_cabecera RECORD;
		r_cfe_productos RECORD;
		n_id_certificado_fitosanitario INTEGER;
		r_datos_pais_cfe RECORD;
		r_datos_puerto_cfe RECORD;
		r_documentos_adjuntos_cfe RECORD;
		
	BEGIN

	---------------------CFE ORIGINAL---------------------------------------------

	SELECT
		DISTINCT id_pais_destino
	FROM
		g_certificado_fitosanitario.certificado_fitosanitario cf
	INNER JOIN g_certificado_fitosanitario.paises_puertos_destino ppd ON ppd.id_certificado_fitosanitario = cf.id_certificado_fitosanitario
	WHERE
		cf.id_certificado_fitosanitario = p_id_certificado_fitosanitario
		AND cf.estado_certificado = 'Aprobado'
	INTO v_id_pais_destino_origen;

	IF FOUND THEN

		-- Inicio creacion de tabla temporal de la solicitud original (padre) --
		
		CREATE TEMPORARY TABLE tmp_solicitud_origen (
							id_certificado_fitosanitario INTEGER
							, identificador_exportador TEXT
							, codigo_poa TEXT
							, id_subtipo_producto INTEGER
							, nombre_subtipo_producto TEXT
							, id_producto INTEGER
							, nombre_producto TEXT
							, cantidad_comercial NUMERIC
							, id_unidad_cantidad_comercial INTEGER
							, codigo_unidad_cantidad_comercial TEXT
							, peso_neto NUMERIC
							, id_unidad_peso_neto INTEGER
							, codigo_unidad_peso_neto TEXT
							, peso_bruto NUMERIC
							, id_unidad_peso_bruto INTEGER
							, codigo_unidad_peso_bruto TEXT
							, id_tipo_tratamiento INTEGER
							, codigo_tipo_tratamiento TEXT
							, id_tratamiento NUMERIC
							, codigo_tratamiento TEXT
							, id_duracion INTEGER
							, codigo_unidad_duracion TEXT
							, duracion NUMERIC
							, id_temperatura INTEGER
							, codigo_unidad_temperatura TEXT
							, temperatura NUMERIC
							, fecha_tratamiento TIMESTAMP WITHOUT TIME ZONE
							, producto_quimico TEXT
							, id_concentracion INTEGER
							, codigo_unidad_concentracion TEXT
							, concentracion NUMERIC
							, fecha_inspeccion TIMESTAMP WITHOUT TIME ZONE) ON COMMIT DROP;

			INSERT INTO tmp_solicitud_origen (SELECT	
							cfp.id_certificado_fitosanitario
							, cfp.identificador_exportador
							, cfp.codigo_poa
							, cfp.id_subtipo_producto
							, cfp.nombre_subtipo_producto
							, cfp.id_producto
							, cfp.nombre_producto
							, tcfp.cantidad_comercial
							, cfp.id_unidad_cantidad_comercial
							, cfp.codigo_unidad_cantidad_comercial
							, tcfp.peso_neto
							, cfp.id_unidad_peso_neto
							, cfp.codigo_unidad_peso_neto
							, tcfp.peso_bruto
							, cfp.id_unidad_peso_bruto
							, cfp.codigo_unidad_peso_bruto
							, cfp.id_tipo_tratamiento
							, cfp.codigo_tipo_tratamiento
							, cfp.id_tratamiento
							, cfp.codigo_tratamiento
							, cfp.id_duracion
							, cfp.codigo_unidad_duracion
							, cfp.duracion
							, cfp.id_temperatura
							, cfp.codigo_unidad_temperatura
							, cfp.temperatura
							, cfp.fecha_tratamiento
							, cfp.producto_quimico
							, cfp.id_concentracion
							, cfp.codigo_unidad_concentracion
							, cfp.concentracion
							, cfp.fecha_inspeccion
							FROM
								g_certificado_fitosanitario.certificado_fitosanitario cf
							INNER JOIN g_certificado_fitosanitario.certificado_fitosanitario_productos cfp ON cf.id_certificado_fitosanitario = cfp.id_certificado_fitosanitario
							INNER JOIN (SELECT
								MIN(id_certificado_fitosanitario_producto) AS id_certificado_fitosanitario_producto
								, id_subtipo_producto
								, id_producto
								, CASE WHEN (SUM (cantidad_comercial)::numeric) % 1 = 0 THEN ROUND(CAST(SUM (cantidad_comercial) AS NUMERIC), 0) ELSE ROUND(CAST(SUM (cantidad_comercial) AS NUMERIC), 2) END AS cantidad_comercial
                                , CASE WHEN (SUM (peso_neto)::numeric) % 1 = 0 THEN ROUND(CAST(SUM (peso_neto) AS NUMERIC), 0) ELSE ROUND(CAST(SUM (peso_neto) AS NUMERIC), 2) END AS peso_neto
                                , CASE WHEN (SUM (peso_bruto)::numeric) % 1 = 0 THEN ROUND(CAST(SUM (peso_bruto) AS NUMERIC), 0) ELSE ROUND(CAST(SUM (peso_bruto) AS NUMERIC), 2) END AS peso_bruto
								FROM
								g_certificado_fitosanitario.certificado_fitosanitario_productos
								GROUP BY id_certificado_fitosanitario, id_subtipo_producto, id_producto) tcfp ON tcfp.id_certificado_fitosanitario_producto = cfp.id_certificado_fitosanitario_producto
								WHERE
								cfp.id_certificado_fitosanitario = p_id_certificado_fitosanitario
								ORDER BY cfp.id_certificado_fitosanitario_producto ASC);
				
		-- Fin creacion de tabla temporal de la solicitud original (padre) --

		-- Inicio creacion de tabla temporal para registro de CFE reemplazo --
		CREATE TEMPORARY TABLE tmp_productos (
				id_valor_pais INTEGER
				, id_puerto INTEGER
				, id_idioma INTEGER
				, identificador_exportador TEXT
				, codigo_poa TEXT
				, id_subtipo_producto INTEGER
				, nombre_subtipo_producto TEXT
				, id_producto INTEGER
				, nombre_producto TEXT
				, cantidad_comercial NUMERIC
				, id_unidad_cantidad_comercial INTEGER
				, codigo_unidad_cantidad_comercial TEXT
				, peso_neto NUMERIC
				, id_unidad_peso_neto INTEGER
				, codigo_unidad_peso_neto TEXT
				, peso_bruto NUMERIC
				, id_unidad_peso_bruto INTEGER
				, codigo_unidad_peso_bruto TEXT
				, id_tipo_tratamiento INTEGER
				, codigo_tipo_tratamiento TEXT
				, id_tratamiento INTEGER
				, codigo_tratamiento TEXT
				, id_duracion INTEGER
				, codigo_unidad_duracion TEXT
				, duracion NUMERIC
				, id_temperatura INTEGER
				, codigo_unidad_temperatura TEXT
				, temperatura NUMERIC
				, fecha_tratamiento TIMESTAMP WITHOUT TIME ZONE
				, producto_quimico TEXT
				, id_concentracion INTEGER
				, codigo_unidad_concentracion TEXT
				, concentracion NUMERIC
				, fecha_inspeccion TIMESTAMP WITHOUT TIME ZONE
			) ON COMMIT DROP;
		-- Fin creacion de tabla temporal para registro de CFE reemplazo --

		-- Inicio recorrer las claves del objeto principal para obtener puertos, idioma y productos --       
		FOR v_numero_pais, a_paises IN SELECT * FROM jsonb_each(p_datos_particion)
		LOOP

			-- Verificar si existe datosPuertosDestino
			IF a_paises ? 'datosPuertosDestino' THEN
				-- Recorrer los elementos dentro de datosPuertosDestino
				FOR a_datos_puertos IN SELECT * FROM jsonb_array_elements(a_paises->'datosPuertosDestino')
				LOOP
					v_id_puerto := a_datos_puertos->>'idPuerto'; 
				END LOOP;
			END IF;

			-- Verificar si existe datosIdioma
			IF a_paises ? 'datosIdioma' THEN
				-- Recorrer los elementos dentro de datosPuertosDestino
				FOR a_datos_idioma IN SELECT * FROM jsonb_array_elements(a_paises->'datosIdioma')
				LOOP
					v_id_idioma := a_datos_idioma->>'idIdioma'; 
				END LOOP;
			END IF;

			-- Verificar si existe datosProductos
			IF a_paises ? 'datosProductos' THEN
				-- Recorrer los elementos dentro de datosProductos
				FOR a_datos_productos IN SELECT * FROM jsonb_array_elements(a_paises->'datosProductos')
				LOOP

					v_id_producto := a_datos_productos->>'idProducto';						
					v_cantidad_comercial := COALESCE((a_datos_productos->>'cantidadComercial')::NUMERIC, null);
					v_peso_neto := COALESCE((a_datos_productos->>'pesoNeto')::NUMERIC, null);
					v_peso_bruto := COALESCE((a_datos_productos->>'pesoBruto')::NUMERIC, null);

					INSERT INTO tmp_productos (id_valor_pais, id_puerto, id_idioma, id_producto, cantidad_comercial, peso_neto, peso_bruto) VALUES (v_numero_pais, v_id_puerto, v_id_idioma, v_id_producto, v_cantidad_comercial, v_peso_neto, v_peso_bruto);	

				END LOOP;
			END IF;

		END LOOP;
		-- Fin recorrer las claves del objeto principal para obtener puertos, idioma y productos --
		
		
		-- Inicio recorrer totales por producto de la tabla temporal de productos, para validar los totales ingresados en la particion --
		FOR r_tmp_productos_cantidades IN SELECT id_producto, SUM(cantidad_comercial) AS cantidad_comercial, SUM(peso_neto) AS peso_neto, SUM(peso_bruto) AS peso_bruto FROM tmp_productos GROUP BY id_producto
		LOOP

			SELECT 
				id_producto
				, nombre_producto
				, cantidad_comercial
				, peso_neto
				, peso_bruto
			FROM
				tmp_solicitud_origen
			WHERE
				id_producto = r_tmp_productos_cantidades.id_producto INTO r_datos_cantidad_cfe_origen;

			IF (r_datos_cantidad_cfe_origen.cantidad_comercial < r_tmp_productos_cantidades.cantidad_comercial) THEN
				v_bandera_validar_registro := false;
				resultado := 'Fallo';
				mensaje := 'La cantidad del producto ' || r_datos_cantidad_cfe_origen.nombre_producto || ' es mayor a la del CFE original ' || r_tmp_productos_cantidades.cantidad_comercial || ' > ' || r_datos_cantidad_cfe_origen.cantidad_comercial;
				clase := 'cantidadComercial' || r_tmp_productos_cantidades.id_producto;
				EXIT;
			END IF;

			IF (r_datos_cantidad_cfe_origen.peso_neto < r_tmp_productos_cantidades.peso_neto) THEN
				v_bandera_validar_registro := false;
				resultado := 'Fallo';
				mensaje := 'El peso neto del producto ' || r_datos_cantidad_cfe_origen.nombre_producto || ' es mayor a la del CFE original '|| r_tmp_productos_cantidades.peso_neto || ' > ' || r_datos_cantidad_cfe_origen.peso_neto;
				clase := 'pesoNeto' || r_tmp_productos_cantidades.id_producto;
				EXIT;
			END IF;

			IF (r_datos_cantidad_cfe_origen.peso_bruto < r_tmp_productos_cantidades.peso_bruto) THEN
				v_bandera_validar_registro := false;
				resultado := 'Fallo';
				mensaje := 'El peso bruto del producto ' || r_datos_cantidad_cfe_origen.nombre_producto || ' es mayor a la del CFE original '|| r_tmp_productos_cantidades.peso_bruto || ' > ' || r_datos_cantidad_cfe_origen.peso_bruto;
				clase := 'pesoBruto' || r_tmp_productos_cantidades.id_producto;
				EXIT;
			END IF;

		END LOOP;	
		-- Fin recorrer totales por producto de la tabla temporal de productos, para validar los totales ingresados en la particion --
		
		IF (v_bandera_validar_registro = true) THEN
		
			--Inicio actualizar datos adicionales tmp_productos con la tabla original--
			UPDATE 
				tmp_productos
			SET
				identificador_exportador = tmp_solicitud_origen.identificador_exportador,
				codigo_poa = tmp_solicitud_origen.codigo_poa,
				id_subtipo_producto = tmp_solicitud_origen.id_subtipo_producto,
				nombre_subtipo_producto = tmp_solicitud_origen.nombre_subtipo_producto,
				nombre_producto = tmp_solicitud_origen.nombre_producto,
				id_unidad_cantidad_comercial = tmp_solicitud_origen.id_unidad_cantidad_comercial,
				codigo_unidad_cantidad_comercial = tmp_solicitud_origen.codigo_unidad_cantidad_comercial,
				id_unidad_peso_neto = tmp_solicitud_origen.id_unidad_peso_neto,
				codigo_unidad_peso_neto = tmp_solicitud_origen.codigo_unidad_peso_neto,
				id_unidad_peso_bruto = tmp_solicitud_origen.id_unidad_peso_bruto,
				codigo_unidad_peso_bruto = tmp_solicitud_origen.codigo_unidad_peso_bruto,
				id_tipo_tratamiento = tmp_solicitud_origen.id_tipo_tratamiento,
				codigo_tipo_tratamiento = tmp_solicitud_origen.codigo_tipo_tratamiento,
				id_tratamiento = tmp_solicitud_origen.id_tratamiento,
				codigo_tratamiento = tmp_solicitud_origen.codigo_tratamiento,
				id_duracion = tmp_solicitud_origen.id_duracion,
				codigo_unidad_duracion = tmp_solicitud_origen.codigo_unidad_duracion,
				duracion = tmp_solicitud_origen.duracion,
				id_temperatura = tmp_solicitud_origen.id_temperatura,
				codigo_unidad_temperatura = tmp_solicitud_origen.codigo_unidad_temperatura,
				temperatura = tmp_solicitud_origen.temperatura,
				fecha_tratamiento = tmp_solicitud_origen.fecha_tratamiento,
				producto_quimico = tmp_solicitud_origen.producto_quimico,
				id_concentracion = tmp_solicitud_origen.id_concentracion,
				codigo_unidad_concentracion = tmp_solicitud_origen.codigo_unidad_concentracion,
				concentracion = tmp_solicitud_origen.concentracion,
				fecha_inspeccion = tmp_solicitud_origen.fecha_inspeccion
			FROM 
				tmp_solicitud_origen
			WHERE 
				tmp_productos.id_producto = tmp_solicitud_origen.id_producto;
			--Fin actualizar datos adicionales tmp_productos con la tabla original--
			
			--Inicio obtener datos generales del certificado origen--
			SELECT 
				identificador_solicitante
				, tipo_solicitud
				, id_idioma
				, id_tipo_produccion
				, id_pais_origen
				, fecha_embarque
				, id_medio_transporte
				, id_puerto_embarque
				, id_provincia_puerto_embarque
				, nombre_marca
				, informacion_adicional
				, codigo_certificado_importacion
				, nombre_consignatario
				, direccion_consignatario
			FROM
				g_certificado_fitosanitario.certificado_fitosanitario
			WHERE 
				id_certificado_fitosanitario = p_id_certificado_fitosanitario
			INTO r_datos_generales_cfe;
			--Fin obtener datos generales del certificado origen--
		
			--Inicio recorrer pais para registrar cada cfe--
			FOR r_cfe_cabecera IN SELECT id_valor_pais, id_puerto, id_idioma FROM tmp_productos GROUP BY id_valor_pais, id_puerto, id_idioma
			LOOP
			
				--Inicio insercion de tabla cabecera--
				INSERT INTO g_certificado_fitosanitario.certificado_fitosanitario(identificador_solicitante, tipo_solicitud, id_idioma, estado_certificado
																				, id_tipo_produccion, id_pais_origen, fecha_embarque, id_medio_transporte, id_puerto_embarque, id_provincia_puerto_embarque, nombre_marca
																				, informacion_adicional, codigo_certificado_importacion, nombre_consignatario, direccion_consignatario, es_reemplazo, id_certificado_reemplazo)
				VALUES (r_datos_generales_cfe.identificador_solicitante
						, r_datos_generales_cfe.tipo_solicitud
						, r_cfe_cabecera.id_idioma
						, 'Creado'
						, r_datos_generales_cfe.id_tipo_produccion
						, r_datos_generales_cfe.id_pais_origen
						, r_datos_generales_cfe.fecha_embarque
						, r_datos_generales_cfe.id_medio_transporte
						, r_datos_generales_cfe.id_puerto_embarque
						, r_datos_generales_cfe.id_provincia_puerto_embarque
						, r_datos_generales_cfe.nombre_marca
						, r_datos_generales_cfe.informacion_adicional
						, r_datos_generales_cfe.codigo_certificado_importacion
						, r_datos_generales_cfe.nombre_consignatario
						, r_datos_generales_cfe.direccion_consignatario
						, 'Si'
						, p_id_certificado_fitosanitario) RETURNING id_certificado_fitosanitario INTO n_id_certificado_fitosanitario;
				--Fin insercion de tabla cabecera--
				
				--Inicio insercion de pais destino cfe particiones--
				--Datos de pais destino
				SELECT 
					CASE WHEN i.codigo_idioma = 'SPA' THEN l.nombre ELSE l.nombre_ingles END AS nombre_pais
				FROM 
					g_catalogos.localizacion l
					, g_catalogos.idiomas i
				WHERE
					l.id_localizacion = v_id_pais_destino_origen
					AND i.id_idioma = r_cfe_cabecera.id_idioma
				INTO r_datos_pais_cfe;

				--Datos de puerto destino
				SELECT 
					nombre_puerto 
				FROM 
					g_catalogos.puertos
				WHERE
					id_puerto = r_cfe_cabecera.id_puerto
				INTO r_datos_puerto_cfe;

				--Inicio insertar pais destino--
				INSERT INTO 
					g_certificado_fitosanitario.paises_puertos_destino(id_certificado_fitosanitario, id_pais_destino, nombre_pais_destino, id_puerto_destino, nombre_puerto_destino)
				VALUES (n_id_certificado_fitosanitario, v_id_pais_destino_origen, r_datos_pais_cfe.nombre_pais, r_cfe_cabecera.id_puerto, r_datos_puerto_cfe.nombre_puerto);
				--Fin insertar pais destino--
				
				--Inicio recorrer tabla de documentos adjuntos para realizar la inserciones de los nuevos cfe particiones--
				FOR r_documentos_adjuntos_cfe IN SELECT tipo_adjunto, ruta_adjunto, ruta_enlace_adjunto
											FROM 
												g_certificado_fitosanitario.documentos_adjuntos
											WHERE
												id_certificado_fitosanitario = p_id_certificado_fitosanitario
												and tipo_adjunto IN ('Documento')
				LOOP

					--Inicio insertar documentos adjuntos--
					INSERT INTO g_certificado_fitosanitario.documentos_adjuntos(id_certificado_fitosanitario, tipo_adjunto, ruta_adjunto, ruta_enlace_adjunto, estado_adjunto, fecha_creacion_adjunto)
					VALUES (n_id_certificado_fitosanitario, r_documentos_adjuntos_cfe.tipo_adjunto, r_documentos_adjuntos_cfe.ruta_adjunto, r_documentos_adjuntos_cfe.ruta_enlace_adjunto, 'Activo', 'now()');
					--Fin insertar documentos adjuntos--
					
				END LOOP;
				--Fin recorrer tabla de documentos adjuntos para realizar la inserciones de los nuevos cfe particiones--                
			
				--Inicio recorrer tabla temporal de productos para realizar la inserciones de los nuevos cfe particiones--
				FOR r_cfe_productos IN SELECT id_valor_pais, identificador_exportador, codigo_poa, id_subtipo_producto, nombre_subtipo_producto, id_producto, nombre_producto, cantidad_comercial, id_unidad_cantidad_comercial, codigo_unidad_cantidad_comercial, peso_neto, id_unidad_peso_neto, codigo_unidad_peso_neto, peso_bruto, id_unidad_peso_bruto, codigo_unidad_peso_bruto,
											id_tipo_tratamiento, codigo_tipo_tratamiento, id_tratamiento, codigo_tratamiento, id_duracion, codigo_unidad_duracion, duracion, id_temperatura, codigo_unidad_temperatura, temperatura, fecha_tratamiento, producto_quimico, id_concentracion, codigo_unidad_concentracion, concentracion, fecha_inspeccion
										FROM
										tmp_productos
										WHERE id_valor_pais = r_cfe_cabecera.id_valor_pais                                                                                
				LOOP
				
					--Inicio insercion de productos--
					INSERT INTO g_certificado_fitosanitario.certificado_fitosanitario_productos(id_certificado_fitosanitario, identificador_exportador, codigo_poa, id_subtipo_producto, nombre_subtipo_producto, id_producto, nombre_producto, cantidad_comercial, id_unidad_cantidad_comercial, codigo_unidad_cantidad_comercial
																								, peso_neto, id_unidad_peso_neto, codigo_unidad_peso_neto, peso_bruto, id_unidad_peso_bruto, codigo_unidad_peso_bruto, id_tipo_tratamiento, codigo_tipo_tratamiento, id_tratamiento, codigo_tratamiento
																								, id_duracion, codigo_unidad_duracion, duracion, id_temperatura, codigo_unidad_temperatura, temperatura, fecha_tratamiento, producto_quimico, id_concentracion, fecha_inspeccion, codigo_unidad_concentracion, concentracion)
					VALUES (n_id_certificado_fitosanitario, r_cfe_productos.identificador_exportador, r_cfe_productos.codigo_poa, r_cfe_productos.id_subtipo_producto, r_cfe_productos.nombre_subtipo_producto, r_cfe_productos.id_producto, r_cfe_productos.nombre_producto, r_cfe_productos.cantidad_comercial, r_cfe_productos.id_unidad_cantidad_comercial, r_cfe_productos.codigo_unidad_cantidad_comercial
																								, r_cfe_productos.peso_neto, r_cfe_productos.id_unidad_peso_neto, r_cfe_productos.codigo_unidad_peso_neto, r_cfe_productos.peso_bruto, r_cfe_productos.id_unidad_peso_bruto, r_cfe_productos.codigo_unidad_peso_bruto, r_cfe_productos.id_tipo_tratamiento, r_cfe_productos.codigo_tipo_tratamiento, r_cfe_productos.id_tratamiento, r_cfe_productos.codigo_tratamiento
																								, r_cfe_productos.id_duracion, r_cfe_productos.codigo_unidad_duracion, r_cfe_productos.duracion, r_cfe_productos.id_temperatura, r_cfe_productos.codigo_unidad_temperatura, r_cfe_productos.temperatura, r_cfe_productos.fecha_tratamiento, r_cfe_productos.producto_quimico, r_cfe_productos.id_concentracion, r_cfe_productos.fecha_inspeccion, r_cfe_productos.codigo_unidad_concentracion, r_cfe_productos.concentracion);
					--Fin insercion de productos--
				
				END LOOP;
				--Fin recorrer tabla temporal de productos para realizar la inserciones de los nuevos cfe particiones--
			
			END LOOP;
			--Fin recorrer pais para registrar cada cfe--
		
			--Inicio actualizacion de estado de la solicitud origen particionada--
			UPDATE 
				g_certificado_fitosanitario.certificado_fitosanitario
			SET 
				estado_certificado = 'Anulado'
				, motivo_reemplazo = p_motivo_reemplazo
				, fecha_reemplazo_certificado = now()
				, certificado = 'No'
				, estado_ephyto = null
			WHERE 
				id_certificado_fitosanitario = p_id_certificado_fitosanitario
				AND estado_certificado = 'Aprobado';
			--Fin actualizacion de estado de la solicitud origen particionada--
		
		END IF;
		
	ELSE
	
		resultado := 'Fallo';
		mensaje := 'El certificado no puede ser anulado/reemplazado.';
		
	END IF;
	
	-- Devolver el resultado (puede ser un JSONB con éxito o error)
	RETURN jsonb_build_object('resultado', resultado, 'mensaje', mensaje);
		
	END;

$$;

alter function f_particion_certificado_fitosanitario(integer, text, jsonb) owner to postgres;

