create function f_auditoria_solicitudes() returns trigger
    security definer
    language plpgsql
as
$$
DECLARE
hs_new hstore = NULL;
hs_old hstore = NULL;
BEGIN
-- Check that the trigger for the logger should be AFTER and FOR EACH ROW
IF TG_WHEN = 'BEFORE' THEN
RAISE EXCEPTION 'Trigger for logger should be AFTER';
END IF;
IF TG_LEVEL = 'STATEMENT' AND TG_OP <> 'TRUNCATE' THEN
RAISE EXCEPTION 'Trigger for logger should be FOR EACH ROW';
END IF;
-- Obtain the hstore versions of NEW and OLD, when appropiate
IF TG_OP = 'INSERT' OR TG_OP = 'UPDATE' THEN
SELECT hstore(new.*) INTO hs_new;
END IF;
IF TG_OP = 'DELETE' OR TG_OP = 'UPDATE' THEN
SELECT hstore(old.*) INTO hs_old;
END IF;
INSERT INTO g_certificacion_bpa.auditoria_solicitudes(log_relid, log_schema, log_table, log_client_addr, log_operation, log_old_values, log_new_values,log_old_all,log_new_all)
WITH t_old(key, value) as (SELECT * FROM each(hs_old)),
t_new(key, value) as (SELECT * FROM each(hs_new))
SELECT TG_RELID,TG_TABLE_SCHEMA,TG_TABLE_NAME, inet_client_addr(), TG_OP,
(SELECT hstore(array_agg(key), array_agg(value)) FROM t_old WHERE (key, value) NOT IN (SELECT key, value FROM t_new)),
(SELECT hstore(array_agg(key), array_agg(value)) FROM t_new WHERE (key, value) NOT IN (SELECT key, value FROM t_old)),
(SELECT hstore(array_agg(key), array_agg(value)) FROM t_old WHERE (key, value)  IN (SELECT key, value FROM t_old)),
(SELECT hstore(array_agg(key), array_agg(value)) FROM t_old WHERE (key, value)  IN (SELECT key, value FROM t_new));
RETURN NULL;
END;
$$;

alter function f_auditoria_solicitudes() owner to postgres;

