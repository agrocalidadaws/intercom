create function f_reporte_estado_solicitudes()
    returns TABLE(codigo_poa_actual character varying, nombre_razon_social character varying, tipo_operador character varying, representante_legal text, cedula_ruc character varying, identificador_miembro character varying, nombre_miembro text, celular character varying, telefono_fijo character varying, correo_electronico character varying, nombre_tipo_operacion character varying, exportador_importador_nacional character varying, producto_primario_producto_elaborado character varying, estatus_organico_t1_t2_t3_producido_organico text, organismo_certificacion text, produccion_anual_estimada double precision, superficie_ha double precision, area character varying, nombre_unidad_produccion character varying, codigo_mag character varying, provincia character varying, canton character varying, parroquia_sector character varying, direccion character varying, localizacion_longitud character varying, localizacion_latitud character varying, estado character varying, fecha_envio_usuario text, fecha_atencion text, id_operacion integer, estado_operacion character varying, observacion character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    WITH fecha_envio_usuario AS (
    SELECT 
        aop1.id_operacion,
        to_char(MAX(aop1.fecha), 'YYYY-MM-DD') AS fecha_envio_usuario
    FROM 
        g_operadores.auditoia_operaciones aop1
    WHERE 
        aop1.estado_anterior in ('cargarAdjunto', 'cargarICertificados')
        AND aop1.estado_actual = 'documental'
    GROUP BY 
        aop1.id_operacion
),
fecha_atencion AS (
    SELECT 
        aop1.id_operacion,
        to_char(MAX(aop1.fecha), 'YYYY-MM-DD') AS fecha_atencion
    FROM 
        g_operadores.auditoia_operaciones aop1
    WHERE 
        (aop1.estado_anterior = 'documental' AND aop1.estado_actual IN ('subsanacion', 'subsanacionProducto', 'registrado')) 
        OR (aop1.estado_anterior IN ('documental', 'registrado') AND aop1.estado_actual = 'noHabilitado')
    GROUP BY 
        aop1.id_operacion
),
rendimiento AS (
   SELECT 
        dma.id_operacion,
        ma.identificador_miembro_asociacion,
        ma.apellido_miembro_asociacion || ' ' || ma.nombre_miembro_asociacion AS nombre_miembro,
        ma.codigo_magap AS codigo_mag,
        dma.rendimiento AS produccion_anual_estimada,
        dma.superficie_miembro AS superficie_ha
    FROM 
        g_operadores.miembros_asociacion ma
    INNER JOIN 
        g_operadores.detalle_miembros_asociacion dma ON ma.id_miembro_asociacion = dma.id_miembro_asociacion
),
organicos AS (
        SELECT 
            copo.codigo_poa,
            oo.id_historial_operacion,
            oo.id_subcodigo_poa,
            oo.id_operacion,
            oo.alcance,
            string_agg(DISTINCT tt.nombre_tipo_transicion, ',') AS estatus, 
            rtrim(array_to_string(array_agg(DISTINCT ac.nombre_agencia_certificadora), ', '), ', ') AS agencia
        FROM 
            g_operadores.operaciones_organico oo
        INNER JOIN 
            g_catalogos.tipo_transicion tt ON oo.id_tipo_transicion = tt.id_tipo_transicion
        INNER JOIN 
            g_catalogos.agencia_certificadora ac ON oo.id_agencia_certificadora = ac.id_agencia_certificadora
        INNER JOIN 
            g_operadores.subcodigos_poa subco ON subco.id_subcodigo_poa = oo.id_subcodigo_poa
        INNER JOIN 
            g_operadores.codigos_poa copo ON copo.id_codigo_poa = subco.id_codigo_poa 
        GROUP BY 
            oo.id_historial_operacion, oo.id_subcodigo_poa,oo.id_operacion,oo.alcance,copo.codigo_poa
    )
SELECT
    org.codigo_poa AS codigo_poa_actual,
    CASE 
        WHEN o.razon_social = '' THEN o.nombre_representante || ' ' || o.apellido_representante 
        ELSE o.razon_social 
    END AS nombre_razon_social,
    o.tipo_actividad AS tipo_operador,
    CASE 
        WHEN o.apellido_representante = 'NULL' THEN '' 
        ELSE o.nombre_representante || ' ' || o.apellido_representante 
    END AS representante_legal,
    op.identificador_operador AS cedula_ruc,
    ren.identificador_miembro_asociacion,
    ren.nombre_miembro,
    o.celular_uno AS celular,
    o.telefono_uno AS telefono_fijo,    
    o.correo AS correo_electronico,
    t.nombre AS nombre_tipo_operacion,
    org.alcance AS exportador_importador_nacional,
    op.nombre_producto AS producto_primario_producto_elaborado,
    CASE 
        WHEN org.estatus = 'NULL' THEN '' 
        ELSE org.estatus 
    END AS estatus_organico_t1_t2_t3_producido_organico,
    CASE 
        WHEN org.agencia = 'NULL' THEN '' 
        ELSE org.agencia 
    END AS organismo_certificacion,
    ren.produccion_anual_estimada,
    ren.superficie_ha,
    a.nombre_area AS area,
    st.nombre_lugar AS nombre_unidad_produccion,
    ren.codigo_mag, 
    st.provincia AS provincia,
    st.canton AS canton,
    st.parroquia AS parroquia_sector,   
    o.direccion AS direccion,   
    st.longitud AS localizacion_longitud,
    st.latitud AS localizacion_latitud,
    CASE 
        WHEN (op.estado = 'subsanacion' OR op.estado = 'subsanacionProducto') THEN 'subsanacion' 
        ELSE op.estado 
    END AS estado,
    fe.fecha_envio_usuario,
    CASE 
        WHEN (op.estado = 'subsanacion' OR op.estado = 'subsanacionProducto') THEN fa.fecha_atencion
        ELSE NULL
    END AS fecha_atencion,
    op.id_operacion,
    op.estado,
	op.observacion_tecnica
FROM
    g_operadores.operadores o
    INNER JOIN g_operadores.sitios st ON st.identificador_operador = o.identificador
    INNER JOIN g_operadores.areas a ON a.id_sitio = st.id_sitio
    INNER JOIN g_operadores.productos_areas_operacion pao ON pao.id_area = a.id_area 
    INNER JOIN g_operadores.operaciones op ON op.id_operacion = pao.id_operacion
    INNER JOIN g_catalogos.tipos_operacion t ON  t.id_tipo_operacion = op.id_tipo_operacion AND t.id_area || '-' || t.codigo  IN ('AI-PRO', 'AI-PRC', 'AI-COM', 'AI-REC')
    LEFT JOIN rendimiento ren ON ren.id_operacion = op.id_operacion
    LEFT JOIN organicos org ON org.id_operacion = op.id_operacion   
    LEFT JOIN fecha_envio_usuario fe ON fe.id_operacion = op.id_operacion
    LEFT JOIN fecha_atencion fa ON fa.id_operacion = op.id_operacion
ORDER BY op.identificador_operador, op.estado ASC;
END;
$$;

alter function f_reporte_estado_solicitudes() owner to postgres;

