create function funcion_actualizar_cantidad_suero(_cantidad_suero_utilizado double precision, _cantidad_suero_restante double precision, _id_detalle_consumo_suero integer, _id_movilizacion integer) returns void
    language plpgsql
as
$$
DECLARE _suero double precision;
BEGIN
	_suero = _cantidad_suero_restante - _cantidad_suero_utilizado;

	UPDATE 
		g_movilizacion_suero.detalle_cantidad_suero
        SET 
		cantidad_suero_restante=_suero, 
		fecha_modificacion = now()
        WHERE 
		id_detalle_consumo_suero = _id_detalle_consumo_suero;
		

	INSERT INTO g_movilizacion_suero.historico_detalle_consumo(id_detalle_consumo_suero, cantidad_suero_utilizado,id_movilizacion)
		VALUES (_id_detalle_consumo_suero, _cantidad_suero_utilizado, _id_movilizacion);
	
	
		
END;
$$;

alter function funcion_actualizar_cantidad_suero(double precision, double precision, integer, integer) owner to postgres;

