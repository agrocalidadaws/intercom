create function insertaroactualizaraplicantes(_identificador text, _id_evaluacion integer, _nombre text, _apellido text, _estado boolean) returns void
    language plpgsql
as
$$
BEGIN
    IF EXISTS(SELECT id_evaluacion
  FROM g_evaluacion.aplicantes where identificador=_identificador and id_evaluacion=_id_evaluacion)
        THEN
            UPDATE g_evaluacion.aplicantes
		SET  estado=_estado, fecha_inicio=null, fecha_fin=null
		WHERE identificador=_identificador and id_evaluacion=_id_evaluacion;
        RETURN;
    ELSE
         INSERT INTO g_evaluacion.aplicantes(
            identificador, id_evaluacion, estado,nombre, apellido)
			VALUES (_identificador, _id_evaluacion, _estado,_nombre, _apellido);
        RETURN;
    END IF;
END;
$$;

alter function insertaroactualizaraplicantes(text, integer, text, text, boolean) owner to postgres;

