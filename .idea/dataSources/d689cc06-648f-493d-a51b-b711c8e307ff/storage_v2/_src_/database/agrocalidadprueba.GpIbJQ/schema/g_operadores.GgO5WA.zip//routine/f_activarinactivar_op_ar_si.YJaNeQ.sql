create function f_activarinactivar_op_ar_si(pglpi text, procedimiento text, poperaciones integer[], pareas text[], psitios text[]) returns text
    language plpgsql
as
$$
DECLARE

	--DATOS GLPI--
	glpi text := pglpi; --'2562235';
	procedimiento text := procedimiento; --'activar'; --'activar'; 'inactivar';

	--DATOS OPERACIONES--
	aoperaciones int[] := poperaciones; --'{2051546, 2051547}'; --null; '{2051546, 2051547}';

	--DATOS AREAS--
	aareas text[] := pareas; --null; --null; '{"0702884826.17025801", "0702884826.17025801"}';

	--DATOS SITIOS--
	asitios text[] := psitios; --null; '{"0702884826.1702", "0702884826.1702"}';

	--VARIABLES--
	aareasactualizacertificado text[] := '{"AICOM", "AIREC", "AIPRO", "AIPRC"}';
	actualizarcertificado text := null;
	roperaciones record;
	aoperacionesinactivar int[] := null;
	rareas record;
	aareasinactivar int[] := null;
	rsitios record;
	asitiosinactivar int[] := null;
	estadoareasitio text := null;
	aresultado text[] := null;
	resultado text := null;

	BEGIN

	IF (procedimiento = 'inactivar') THEN
		estadoareasitio := 'inactivo';
	ELSE
		estadoareasitio := 'creado';
	END IF;
	
	aoperaciones := ARRAY (SELECT DISTINCT UNNEST(aoperaciones));
	aareas := ARRAY (SELECT DISTINCT UNNEST(aareas));
	asitios := ARRAY (SELECT DISTINCT UNNEST(asitios));
	
	---INICIO PROCESO ACTIVAR INACTIVAR OPERACIONES---
	IF (array_length(aoperaciones, 1) > 0) THEN

		RAISE NOTICE '% % %', 'Inicio de proceso para "', procedimiento, '" operaciones';

		FOR roperaciones IN (SELECT
						op.id_operacion, op.estado, op.id_vue, top.id_area || top.codigo AS codigo_area_tematica, CASE WHEN (procedimiento = 'inactivar') THEN 'noHabilitado'::text ELSE op.estado_anterior END AS estado_actual, 'Cambio de estado realizado en base a GLPI # ' || glpi || ', estado anterior ' || op.estado ::text AS observacion_tecnica
						FROM g_operadores.operaciones op 
						INNER JOIN g_catalogos.tipos_operacion top ON op.id_tipo_operacion = top.id_tipo_operacion
						WHERE						
						op.id_operacion = ANY (aoperaciones) and CASE WHEN (procedimiento = 'inactivar') THEN op.estado NOT IN ('noHabilitado') ELSE NULL is NULL END) LOOP

			IF (roperaciones.codigo_area_tematica = ANY (aareasactualizacertificado)) THEN
				actualizarcertificado := 'SI';
			END IF;
			
			RAISE NOTICE '% %', 'operacion ->', roperaciones.id_operacion;
			aresultado := array_append(aresultado, roperaciones.id_vue::text); 							
							

			UPDATE g_operadores.productos_areas_operacion SET estado = roperaciones.estado_actual, observacion = roperaciones.observacion_tecnica WHERE id_operacion = roperaciones.id_operacion;	 	
			UPDATE g_operadores.operaciones SET estado = roperaciones.estado_actual/*, actualizar_certificado = actualizarcertificado*/, observacion = roperaciones.observacion_tecnica, observacion_tecnica = roperaciones.observacion_tecnica, estado_anterior = roperaciones.estado WHERE id_operacion = roperaciones.id_operacion;

		END LOOP;
		
		IF(actualizarcertificado = 'SI') THEN		
			UPDATE g_operadores.operaciones SET actualizar_certificado = actualizarcertificado WHERE id_operacion = roperaciones.id_operacion;
		END IF;
			
		RAISE NOTICE '% % %', 'Fin de proceso para "', procedimiento, '" operaciones';
		
	END IF;
	---FIN PROCESO ACTIVAR INACTIVAR OPERACIONES---

	---INICIO PROCESO ACTIVAR INACTIVAR AREAS---
	IF (array_length(aareas, 1) > 0) THEN

		RAISE NOTICE '% % %', 'Inicio de proceso para "', procedimiento, '" areas';

		FOR rareas IN (SELECT 
			a.id_area, otop.id_operacion, otop.estado, otop.id_vue, otop.id_area || otop.codigo AS codigo_area_tematica, CASE WHEN (procedimiento = 'inactivar') THEN 'noHabilitado'::text ELSE otop.estado_anterior END AS estado_actual, 'Cambio de estado realizado en base a GLPI # ' || glpi || ', estado anterior ' || otop.estado ::text AS observacion_tecnica
			FROM g_operadores.sitios s
			INNER JOIN g_operadores.areas a ON s.id_sitio = a.id_sitio
			LEFT JOIN (SELECT 
							pao.id_area AS id_area_operacion, op.id_operacion, op.estado, op.id_vue, op.estado_anterior, top.id_area, top.codigo
						FROM 
							g_operadores.productos_areas_operacion pao
						INNER JOIN g_operadores.operaciones op ON pao.id_operacion = op.id_operacion
						INNER JOIN g_catalogos.tipos_operacion top ON op.id_tipo_operacion = top.id_tipo_operacion
						WHERE
							CASE WHEN (procedimiento = 'inactivar') THEN op.estado NOT IN ('noHabilitado') ELSE NULL is NULL  END) otop ON otop.id_area_operacion = a.id_area
			WHERE 
			s.identificador_operador||'.'||s.codigo_provincia || s.codigo ||a.codigo||a.secuencial = ANY (aareas)) LOOP

			IF (rareas.codigo_area_tematica = ANY (aareasactualizacertificado)) THEN
				actualizarcertificado := 'SI';
			END IF;
			
			aareasinactivar := array_append(aareasinactivar, rareas.id_area);

			RAISE NOTICE '% %', 'operacion ->', rareas.id_operacion;
			aresultado := array_append(aresultado, rareas.id_vue::text);

			UPDATE g_operadores.productos_areas_operacion SET estado = rareas.estado_actual, observacion = rareas.observacion_tecnica WHERE id_operacion = rareas.id_operacion;	 	
			UPDATE g_operadores.operaciones SET estado = rareas.estado_actual/*, actualizar_certificado = actualizarcertificado*/, observacion = rareas.observacion_tecnica, observacion_tecnica = rareas.observacion_tecnica, estado_anterior = rareas.estado WHERE id_operacion = rareas.id_operacion;

		END LOOP;
		
		IF(actualizarcertificado = 'SI') THEN		
			UPDATE g_operadores.operaciones SET actualizar_certificado = actualizarcertificado WHERE id_operacion = rareas.id_operacion;
		END IF;

		aareasinactivar := ARRAY (SELECT DISTINCT UNNEST(aareasinactivar));
		
		IF (array_length(aareasinactivar, 1) > 0) THEN

			  FOR i IN array_lower(aareasinactivar, 1) .. array_upper(aareasinactivar, 1) LOOP
				RAISE NOTICE '% % ', 'area ->', aareasinactivar[i];
				UPDATE g_operadores.areas SET estado = estadoareasitio WHERE id_area = aareasinactivar[i];	 
			  END LOOP;

		END IF;
		
		RAISE NOTICE '% % %', 'Fin de proceso para "', procedimiento, '" areas';
		
	END IF;
	---FIN PROCESO ACTIVAR INACTIVAR AREAS---
	
	---INICIO PROCESO ACTIVAR INACTIVAR SITIOS---
	IF (array_length(asitios, 1) > 0) THEN

		RAISE NOTICE '% % %', 'Inicio de proceso para "', procedimiento, '" sitios';

		FOR rsitios IN (SELECT 
			a.id_sitio, a.id_area, otop.id_operacion, otop.estado, otop.id_vue, otop.id_area || otop.codigo AS codigo_area_tematica, CASE WHEN (procedimiento = 'inactivar') THEN 'noHabilitado'::text ELSE otop.estado_anterior END AS estado_actual, 'Cambio de estado realizado en base a GLPI # ' || glpi || ', estado anterior ' || otop.estado ::text AS observacion_tecnica
			FROM g_operadores.sitios s
			LEFT JOIN g_operadores.areas a ON s.id_sitio = a.id_sitio
			LEFT JOIN (SELECT 
							pao.id_area AS id_area_operacion, op.id_operacion, op.estado, op.id_vue, op.estado_anterior, top.id_area, top.codigo
						FROM 
							g_operadores.productos_areas_operacion pao
						INNER JOIN g_operadores.operaciones op ON pao.id_operacion = op.id_operacion
						INNER JOIN g_catalogos.tipos_operacion top ON op.id_tipo_operacion = top.id_tipo_operacion
						WHERE
							CASE WHEN (procedimiento = 'inactivar') THEN op.estado NOT IN ('noHabilitado') ELSE NULL is NULL END) otop ON otop.id_area_operacion = a.id_area
			WHERE 
			s.identificador_operador||'.'||s.codigo_provincia || s.codigo = ANY (asitios)) LOOP

			IF (rsitios.codigo_area_tematica = ANY (aareasactualizacertificado)) THEN
				actualizarcertificado := 'SI';
			END IF;
			
			asitiosinactivar := array_append(asitiosinactivar, rsitios.id_sitio);
			aareasinactivar := array_append(aareasinactivar, rsitios.id_area);

			RAISE NOTICE '% %', 'operacion ->', rsitios.id_operacion;
			aresultado := array_append(aresultado, rsitios.id_vue::text);

			UPDATE g_operadores.productos_areas_operacion SET estado = rsitios.estado_actual, observacion = rsitios.observacion_tecnica WHERE id_operacion = rsitios.id_operacion;	 	
			UPDATE g_operadores.operaciones SET estado = rsitios.estado_actual/*, actualizar_certificado = actualizarcertificado*/, observacion = rsitios.observacion_tecnica, observacion_tecnica = rsitios.observacion_tecnica, estado_anterior = rsitios.estado WHERE id_operacion = rsitios.id_operacion;

		END LOOP;
		
		IF(actualizarcertificado = 'SI') THEN		
			UPDATE g_operadores.operaciones SET actualizar_certificado = actualizarcertificado WHERE id_operacion = rsitios.id_operacion;
		END IF;

		asitiosinactivar := ARRAY (SELECT DISTINCT UNNEST(asitiosinactivar));
		aareasinactivar := ARRAY (SELECT DISTINCT UNNEST(aareasinactivar));
		
		IF (array_length(asitiosinactivar, 1) > 0) THEN

			  FOR i IN array_lower(asitiosinactivar, 1) .. array_upper(asitiosinactivar, 1) LOOP
				RAISE NOTICE '% % ', 'sitio ->', asitiosinactivar[i];
				UPDATE g_operadores.sitios SET estado = estadoareasitio WHERE id_sitio = asitiosinactivar[i];	 
			  END LOOP;

		END IF;
		
		IF (array_length(aareasinactivar, 1) > 0) THEN

			  FOR i IN array_lower(aareasinactivar, 1) .. array_upper(aareasinactivar, 1) LOOP
				RAISE NOTICE '% % ', 'area ->', aareasinactivar[i];
				UPDATE g_operadores.areas SET estado = estadoareasitio WHERE id_area = aareasinactivar[i];	 
			  END LOOP;

		END IF;
		
		RAISE NOTICE '% % %', 'Fin de proceso para "', procedimiento, '" sitios';
		
	END IF;
	---FIN PROCESO ACTIVAR INACTIVAR SITIOS---
	
	resultado := array_to_string(aresultado, ', ');
	
	RETURN resultado;

    END;
$$;

alter function f_activarinactivar_op_ar_si(text, text, integer[], text[], text[]) owner to postgres;

