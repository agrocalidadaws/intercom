create function anular_factura(p_numero_establecimiento text, p_numero_factura text, p_numero_glpi text) returns void
    language plpgsql
as
$$

DECLARE

datos_factura record;
v_saldo_actual double precision;
v_valor_total double precision;

BEGIN

p_numero_glpi := '23446';

SELECT 
DISTINCT (op.total_pagar) AS total_pagar, op.identificador_operador, op.id_pago
FROM 
g_financiero.orden_pago op
INNER JOIN g_financiero.detalle_forma_pago dfp ON dfp.id_pago = op.id_pago
WHERE 
		numero_establecimiento = p_numero_establecimiento
        AND numero_factura = p_numero_factura
        AND op.estado = 4
        AND op.estado_sri = 'AUTORIZADO'
		AND op.ruc_institucion = '1768188830001'
		AND op.tipo_solicitud = 'Otros'
		AND op.id_pago in (1036404)
		AND dfp.institucion_bancaria NOT IN ('Pago en nota de credito') INTO datos_factura;
		
IF FOUND THEN
	RAISE NOTICE '% %', 'Si hay', datos_factura.total_pagar;
	
	
	SELECT 
						ts.saldo_disponible
					FROM 
						g_financiero.saldos ts
						INNER JOIN (SELECT 
						MAX(id_saldo) as id_saldo, identificador_operador
						FROM 
						g_financiero.saldos
						GROUP BY identificador_operador) tms ON tms.id_saldo = ts.id_saldo
				WHERE
				ts.identificador_operador = datos_factura.identificador_operador INTO v_saldo_actual;
	
	RAISE NOTICE '% %', 'saldo actual', v_saldo_actual;
	
	v_valor_total := ROUND(CAST((datos_factura.total_pagar + v_saldo_actual) AS NUMERIC), 2);
	
	RAISE NOTICE '% %', 'valor total', v_valor_total;
	
	INSERT INTO g_financiero.saldos(id_pago, fecha_deposito, valor_ingreso, saldo_disponible, identificador_operador, tipo_saldo, observacion_saldo)
				VALUES (datos_factura.id_pago, now(), datos_factura.total_pagar, v_valor_total, datos_factura.identificador_operador, 'saldoAgr', 'Saldo acreditado por anulación GLPI # ' || p_numero_glpi);
	
	UPDATE 
				g_financiero.orden_pago
				SET estado = 9, estado_sri = 'ANULADO', observacion_eliminacion = 'Anulación realizada en base a GLPI # ' || p_numero_glpi
				WHERE id_pago = datos_factura.id_pago;
	
ELSE
	RAISE NOTICE '% %', 'No hay', datos_factura.total_pagar;
END IF;
		
END;
$$;

alter function anular_factura(text, text, text) owner to postgres;

