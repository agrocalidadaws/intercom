create function f_generar_numero_solicitud() returns text
    language plpgsql
as
$$
			DECLARE
				secuencial int;
				codigo_solicitud text;
				BEGIN
					SELECT 
						MAX(SUBSTRING (numero_solicitud , 9 , 4)::integer) INTO secuencial
					FROM 
						g_ensayo_eficacia_mvc.solicitudes;
						
					IF FOUND THEN
						IF (secuencial IS NULL) THEN
							secuencial = 1;
						ELSE
							secuencial = secuencial + 1;
						END IF;
					ELSE
						secuencial = 1;
					END IF;
					
					codigo_solicitud := 'EE-' || (SELECT to_char(now(), 'YYYY')) || '-' || trim(to_char(secuencial, '0000'));
					
					RETURN codigo_solicitud;
				END
				
			
		
	$$;

alter function f_generar_numero_solicitud() owner to postgres;

