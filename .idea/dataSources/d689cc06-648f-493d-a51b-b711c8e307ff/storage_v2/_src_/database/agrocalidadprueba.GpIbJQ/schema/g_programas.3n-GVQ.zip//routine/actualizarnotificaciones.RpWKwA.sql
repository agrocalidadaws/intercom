create function actualizarnotificaciones(_incremento integer, _identificador text, _aplicacion integer) returns void
    language plpgsql
as
$$
DECLARE
BEGIN
	UPDATE g_programas.aplicaciones_registradas ar
	SET cantidad_notificacion=cantidad_notificacion+_incremento
	WHERE ar.identificador=_identificador and
		ar.id_aplicacion=_aplicacion;
END;
$$;

alter function actualizarnotificaciones(integer, text, integer) owner to postgres;

