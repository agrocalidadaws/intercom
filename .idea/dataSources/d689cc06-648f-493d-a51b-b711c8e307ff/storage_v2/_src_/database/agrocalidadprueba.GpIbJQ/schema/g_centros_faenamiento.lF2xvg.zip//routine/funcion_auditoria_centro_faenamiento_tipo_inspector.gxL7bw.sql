create function funcion_auditoria_centro_faenamiento_tipo_inspector() returns trigger
    language plpgsql
as
$$ 
BEGIN
	
	PERFORM g_centros_faenamiento.funcion_insertar_auditoria_centro_faenamiento_tipo_inspector(NEW.id_centro_faenamiento_tipo_inspector, NEW.id_centro_faenamiento, NEW.id_tipo_inspector, NEW.identificador_registro, NEW.estado);	
	
RETURN NEW;
END; 

	
$$;

alter function funcion_auditoria_centro_faenamiento_tipo_inspector() owner to postgres;

