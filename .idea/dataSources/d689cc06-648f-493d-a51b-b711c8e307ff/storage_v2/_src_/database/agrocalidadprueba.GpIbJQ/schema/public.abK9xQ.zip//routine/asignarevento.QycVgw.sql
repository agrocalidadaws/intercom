create function asignarevento() returns void
    language plpgsql
as
$$
DECLARE
  funcionarios record;
BEGIN
 FOR funcionarios in (SELECT distinct identificador FROM g_estructura.funcionarios) 
  LOOP
   insert into g_programas.aplicaciones_registradas values(21,funcionarios.identificador,1,'Evento');
   
   insert into g_inscripciones.inscripciones(id_evento, identificador) values(1,funcionarios.identificador);
  END LOOP;
END;
$$;

alter function asignarevento() owner to postgres;

