create function fs_interconexion_dinarp_operadores_leche(pidentificador character varying) returns json
    language plpgsql
as
$$

/*
-------------------------------------------------------------------------
--  [g_operadores.fs_interconexion_dinarp_operadores_leche]
--               
--  Esta funcion retorna un json con los campos seleccionados de los operadores de leche cruda que esten en estado registrado
--  Cabe recalcar que esta funcion es fundamental para la compartision de datos mediante ws a la dinarp
--
--  VERSION		AUTOR					FECHA			HU	
--	1			Kleber Armijos		05-08-2024	  Funcion retorna json de un operador en especifico 
--												  
-------------------------------------------------------------------------
*/
declare 
operadores_leche_cruda json;
vid_producto integer :=33827; --para el producto leche

BEGIN	
        SELECT json_agg(row_to_json(t))
        INTO operadores_leche_cruda
        FROM (
            SELECT DISTINCT
                o.identificador,
                RTRIM(REPLACE(REPLACE(REPLACE(o.razon_social,chr(9),''),chr(10),''),chr(13),'')) as razon_social,
                tp_pro.id_tipo_producto,
                tp_pro.nombre as tipo_producto,
                sub_pro.id_subtipo_producto,
                sub_pro.nombre as subtipo_producto,
                pr.id_producto,
                REPLACE(REPLACE(REPLACE(pr.nombre_comun,chr(9),''),chr(10),''),chr(13),'') as nombre_producto,
                op.estado as estado_operacion, 
                o.identificador||'.'||s.codigo_provincia||s.codigo||a.codigo||a.secuencial as codigo_area,    
                CASE WHEN op.estado = 'registrado' THEN op.fecha_aprobacion END as fecha_aprobacion,
                op.fecha_finalizacion as fecha_caducidad,
                loc_prov.id_localizacion as id_provincia,
                loc_prov.nombre as provincia,
                loc_cant.id_localizacion as id_canton,
                loc_cant.nombre as canton,
                loc_parr.id_localizacion as id_parroquia,
                loc_parr.nombre as parroquia,
                REPLACE(REPLACE(REPLACE(a.nombre_area,chr(9),''),chr(10),''),chr(13),'') as nombre_area,  
                REPLACE(REPLACE(REPLACE(o.direccion,chr(9),''),chr(10),''),chr(13),'') as direccion,
                o.telefono_uno as telefono,
                o.nombre_representante ||' '||o.apellido_representante as nombre_representante,
                a.superficie_utilizada  as superficie_utilizada,
                ar_op.unidad_medida as unidad_superficie,
                REPLACE(REPLACE(REPLACE(o.correo,chr(9),''),chr(10),''),chr(13),'') as correo
            FROM
                g_operadores.operadores o 
                INNER JOIN g_operadores.sitios s ON s.identificador_operador = o.identificador
                INNER JOIN g_operadores.areas a ON a.id_sitio = s.id_sitio
                INNER JOIN g_operadores.productos_areas_operacion pao ON pao.id_area = a.id_area
                INNER JOIN g_operadores.operaciones op ON op.id_operacion = pao.id_operacion
                LEFT JOIN  g_catalogos.areas_operacion ar_op ON op.id_tipo_operacion = ar_op.id_tipo_operacion
                LEFT JOIN g_catalogos.productos pr ON pr.id_producto = op.id_producto
                LEFT JOIN g_catalogos.subtipo_productos sub_pro ON sub_pro.id_subtipo_producto = pr.id_subtipo_producto
                LEFT JOIN g_catalogos.tipo_productos tp_pro ON tp_pro.id_tipo_producto = sub_pro.id_tipo_producto
                LEFT JOIN g_catalogos.localizacion loc_prov ON loc_prov.nombre = s.provincia AND loc_prov.id_localizacion_padre = 66
                LEFT JOIN g_catalogos.localizacion loc_cant ON loc_cant.nombre = s.canton AND loc_cant.id_localizacion_padre = loc_prov.id_localizacion
                LEFT JOIN g_catalogos.localizacion loc_parr ON loc_parr.nombre = s.parroquia AND loc_parr.id_localizacion_padre = loc_cant.id_localizacion
            WHERE
                o.identificador = $1
                AND op.id_tipo_operacion IN (103)
                AND op.estado = 'registrado'
                AND pr.id_producto = vid_producto
        ) t;
return operadores_leche_cruda;
END;
$$;

alter function fs_interconexion_dinarp_operadores_leche(varchar) owner to postgres;

