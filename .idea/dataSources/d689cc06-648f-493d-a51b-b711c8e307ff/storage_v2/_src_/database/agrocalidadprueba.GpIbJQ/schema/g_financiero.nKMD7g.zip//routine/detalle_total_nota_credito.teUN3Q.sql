create function detalle_total_nota_credito(_orden integer) returns SETOF g_financiero.detalles_nota_credito
    language plpgsql
as
$$
DECLARE
	query text;
BEGIN	
	return query EXECUTE '
		SELECT
			distinct (id_nota_credito),
			(select sum(total)::numeric(8,2) from g_financiero.detalle_nota_credito where id_nota_credito  = $1 and iva = 0) as total_sin_iva, 
			(select sum(total)::numeric(8,2) - sum(iva)::numeric(8,2) from g_financiero.detalle_nota_credito where id_nota_credito  = $1 and iva != 0) as total_con_iva,
			(select sum(iva)::numeric(8,2) from g_financiero.detalle_nota_credito where id_nota_credito  = $1) as suma_iva, 
			(select sum(descuento)::numeric(8,2) from g_financiero.detalle_nota_credito where id_nota_credito  = $1 and iva = 0) as descuento_sin_iva,
			(select sum(descuento)::numeric(8,2) from g_financiero.detalle_nota_credito where id_nota_credito  = $1 and iva != 0) as descuento_con_iva
		FROM

			g_financiero.detalle_nota_credito d	
			
		WHERE
			d.id_nota_credito = $1'
			
		using _orden;
			
END;
$$;

alter function detalle_total_nota_credito(integer) owner to postgres;

