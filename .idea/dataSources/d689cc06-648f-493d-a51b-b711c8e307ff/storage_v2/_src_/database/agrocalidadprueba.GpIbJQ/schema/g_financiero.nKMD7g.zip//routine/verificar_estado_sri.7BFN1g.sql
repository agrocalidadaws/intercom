create function verificar_estado_sri(_numero_orden_pago text, _fecha_inicio timestamp without time zone, _fecha_fin timestamp without time zone, _estado_sri text, _localizacion text, _tipo_solicitud text) returns SETOF g_financiero.orden_pago
    language plpgsql
as
$$
DECLARE
	query text;
BEGIN	
	return query EXECUTE '	
		SELECT
			*
		FROM 
			g_financiero.orden_pago o
		WHERE 
			($1 is NULL or $1 = numero_solicitud) and
			($2 is NULL or fecha_facturacion >= $2) and
			($3 is NULL or fecha_facturacion <= $3) and
			($4 is NULL or $4 = estado_sri) and 
			($5 is NULL or $5 = nombre_provincia) and
			($6 is NULL or $6 = tipo_solicitud) and
			estado = 4
		ORDER BY
			o.fecha_orden_pago'
		using _numero_orden_pago,_fecha_inicio,_fecha_fin,_estado_sri,_localizacion,_tipo_solicitud;
	
END;
$$;

alter function verificar_estado_sri(text, timestamp, timestamp, text, text, text) owner to postgres;

