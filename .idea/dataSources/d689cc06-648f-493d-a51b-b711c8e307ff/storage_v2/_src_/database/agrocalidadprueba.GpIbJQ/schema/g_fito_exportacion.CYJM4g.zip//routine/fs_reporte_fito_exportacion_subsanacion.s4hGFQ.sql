create function fs_reporte_fito_exportacion_subsanacion(pfecha_inicio date, pfecha_inicio2 date, OUT id_fito_exportacion_fe integer, OUT fecha_inicio date, OUT fecha_vigencia date, OUT puerto_destino character varying, OUT pais_destino character varying, OUT razon_social character varying, OUT nombre_importador character varying, OUT direccion_importador character varying, OUT puerto_embarque character varying, OUT transporte character varying, OUT lugar_inspeccion character varying, OUT nombre_marcas character varying, OUT tipo_producto character varying, OUT subtipo_producto character varying, OUT partida_arancelaria character varying, OUT codigo_producto character varying, OUT nombre_cientifico character varying, OUT id_fito_exp_operador_producto integer, OUT id_fito_exportacion integer, OUT identificador_operador character varying, OUT id_producto integer, OUT nombre_producto character varying, OUT numero_bultos double precision, OUT unidad_bultos character varying, OUT cantidad_producto double precision, OUT unidad_cantidad_producto character varying, OUT permiso_musaceas character varying, OUT estado character varying, OUT observacion character varying, OUT ruta_archivo character varying, OUT subpartida_producto_vue character varying, OUT codigo_producto_vue character varying, OUT declaracion_adicional character varying, OUT fecha_tratamiento date, OUT tratamiento_realizado character varying, OUT quimico_tratamiento character varying, OUT duracion_tratamiento character varying, OUT temperatura_tratamiento double precision, OUT concentracion_producto character varying, OUT reporte_inspeccion character varying, OUT id_vue character varying, OUT fecha_creacion timestamp without time zone, OUT nombre_aprobacion_documental text, OUT producto_organico text, OUT numero_producto_organico character varying, OUT id_fito_exportacion2 integer, OUT aprobacion_revision_documental text, OUT fecha_imposicion_tasa_financiero text) returns SETOF record
    language plpgsql
as
$$
BEGIN
			 	CREATE TABLE temp_fito AS(
			SELECT
					distinct fe.id_fito_exportacion as id_fito_exportacion_fe,
					fe.fecha_inicio,
					fe.fecha_vigencia,
					fe.puerto_destino,
					fe.pais_destino,
					op.razon_social,
					fe.nombre_importador,
					fe.direccion_importador,
					fe.puerto_embarque,
					fe.transporte,
					fe.lugar_inspeccion,
					fe.nombre_marcas,
					tp.nombre as tipo_producto,
					sp.nombre as subtipo_producto,
					p.partida_arancelaria,
					p.codigo_producto,
					p.nombre_cientifico,
					fep.*,
					fe.observacion_operador as declaracion_adicional,
					fe.fecha_tratamiento,
					fe.tratamiento_realizado,
					fe.quimico_tratamiento,
					fe.duracion_tratamiento,
					fe.temperatura_tratamiento,
					fe.concentracion_producto,
					fe.reporte_inspeccion,
					fe.id_vue,
					fe.fecha_creacion,			
					fec.apellido ||' '|| fec.nombre as nombre_aprobacion_documental,
					CASE WHEN fe.producto_organico= 'S' THEN 'SI'
							 WHEN fe.producto_organico='N' THEN 'NO'
					END as producto_organico,
					fe.numero_producto_organico			
				FROM
					g_fito_exportacion.fito_exportaciones fe,
					g_fito_exportacion.fito_exportaciones_operadores_productos fep,
					g_operadores.operadores op,
					g_catalogos.productos p,
					g_catalogos.subtipo_productos sp,
					g_catalogos.tipo_productos tp,
					g_revision_solicitudes.grupos_solicitudes gs,
					g_revision_solicitudes.asignacion_inspector ai,
					g_revision_solicitudes.revision_documental rd,
					g_uath.ficha_empleado fec
				WHERE 
					fe.id_fito_exportacion = fep.id_fito_exportacion and
					fep.identificador_operador = op.identificador and
					p.id_producto = fep.id_producto and
					p.id_subtipo_producto =  sp.id_subtipo_producto and
					sp.id_tipo_producto = tp.id_tipo_producto and
					fe.estado = 'aprobado' and	
					fe.id_fito_exportacion = gs.id_solicitud and
					gs.id_grupo = ai.id_grupo and
					ai.tipo_solicitud = 'Fitosanitario' and
					ai.tipo_inspector = 'Documental' and
					ai.id_grupo = rd.id_grupo and
					rd.estado = 'pago' and
					fec.identificador = ai.identificador_inspector and	
					fe.fecha_inicio >= $1 and
					fe.fecha_inicio <= $2
				ORDER BY 
					fe.id_fito_exportacion
				);

	  CREATE  TABLE tem_fecha AS (
		   SELECT
				fe.id_fito_exportacion ,
				STRING_AGG(cast(rd.fecha_inspeccion as text) , ' subsanacion -> ') as aprobacion_revision_documental
				FROM
				g_fito_exportacion.fito_exportaciones fe,
				g_revision_solicitudes.grupos_solicitudes gs,
				g_revision_solicitudes.asignacion_inspector ai,
				g_revision_solicitudes.revision_documental rd
				WHERE
				 fe.id_fito_exportacion = gs.id_solicitud and
				 gs.id_grupo = ai.id_grupo and
				 ai.tipo_solicitud = 'Fitosanitario' and
				 ai.tipo_inspector = 'Documental' and
				 ai.id_grupo = rd.id_grupo
				group by  fe.id_fito_exportacion		  		
				 );
	
		 CREATE  TABLE temp_pago as (
				SELECT DISTINCT ON (temp1.id_fito_exportacion )
							temp1.*,
							orp.fecha_orden_pago ||'adwert'|| orp.fecha_facturacion ||'adwert'|| orp.total_pagar  AS fecha_imposicion_tasa_financiero
							 FROM tem_fecha temp1
							 left JOIN  g_financiero.orden_pago orp 
							 ON orp.id_solicitud = temp1.id_fito_exportacion::text 
							 AND orp.tipo_solicitud = 'Fitosanitario' 
							 AND orp.estado = 4
		);
		
 RETURN QUERY select *from temp_fito temp_f 
			inner join temp_pago temp_p 
			on temp_f.id_fito_exportacion_fe=temp_p.id_fito_exportacion;

		DROP TABLE temp_fito;
		DROP TABLE tem_fecha; 
		DROP TABLE temp_pago;		

END;
$$;

alter function fs_reporte_fito_exportacion_subsanacion(date, date, out integer, out date, out date, out varchar, out varchar, out varchar, out varchar, out varchar, out varchar, out varchar, out varchar, out varchar, out varchar, out varchar, out varchar, out varchar, out varchar, out integer, out integer, out varchar, out integer, out varchar, out double precision, out varchar, out double precision, out varchar, out varchar, out varchar, out varchar, out varchar, out varchar, out varchar, out varchar, out date, out varchar, out varchar, out varchar, out double precision, out varchar, out varchar, out varchar, out timestamp, out text, out text, out varchar, out integer, out text, out text) owner to postgres;

