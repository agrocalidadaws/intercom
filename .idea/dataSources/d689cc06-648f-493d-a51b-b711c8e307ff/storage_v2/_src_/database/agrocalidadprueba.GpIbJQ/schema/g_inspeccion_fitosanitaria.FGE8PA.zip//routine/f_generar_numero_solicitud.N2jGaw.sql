create function f_generar_numero_solicitud(p_id_provincia_area text) returns text
    language plpgsql
as
$$
					DECLARE
						secuencial int;
						codigo_solicitud text;
						letra text;
						
						BEGIN

						SELECT 
							MAX(SUBSTRING (numero_solicitud, 9, 7)::integer)
						FROM 
							g_inspeccion_fitosanitaria.inspeccion_fitosanitaria
							WHERE
							anio_solicitud = date_part('year'::text, CURRENT_DATE) INTO secuencial;

						IF FOUND THEN
							IF (secuencial IS NULL) THEN
								secuencial = 1;
							ELSE
								secuencial = secuencial + 1;
							END IF;
						ELSE
							secuencial = 1;
						END IF;

						codigo_solicitud := p_id_provincia_area || '-' || (SELECT to_char(now(), 'MM')) || (SELECT to_char(now(), 'YY')) || '-' || trim(to_char(secuencial, '0000000'));

						RETURN codigo_solicitud;
	END	
		
	
$$;

alter function f_generar_numero_solicitud(text) owner to postgres;

