create function f_estado_importacion_vue() returns trigger
    language plpgsql
as
$$ 
DECLARE _id_solicitud INTEGER;
BEGIN

	_id_solicitud:= (SELECT id_estado_solicitud_vue FROM g_vue.estados_solicitudes_vue WHERE id_vue = NEW.id_vue);

	IF (_id_solicitud IS NULL) THEN
		INSERT INTO g_vue.estados_solicitudes_vue(tipo_solicitud, id_vue, fecha_registro, cantidad_dia, estado_solicitud) VALUES ('Importación', NEW.id_vue, 'now()', 0, NEW.estado);
	ELSE
		IF (TG_OP = 'INSERT') THEN
			UPDATE g_vue.estados_solicitudes_vue SET fecha_registro = 'now()', cantidad_dia = 0, estado_solicitud = NEW.estado, estado_solicitud_anterior = NEW.estado WHERE id_vue = NEW.id_vue;
		ELSE
			UPDATE g_vue.estados_solicitudes_vue SET fecha_registro = 'now()', cantidad_dia = 0, estado_solicitud = NEW.estado, estado_solicitud_anterior = OLD.estado WHERE id_vue = NEW.id_vue;
		END IF;
	END IF;	
		
	RETURN NEW;
END; 
	
$$;

alter function f_estado_importacion_vue() owner to postgres;

