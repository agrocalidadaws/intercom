create function migracion_vacunacion() returns integer
    language plpgsql
as
$$
DECLARE
   identificadores record;
   contador INTEGER:=0;
   registro INTEGER:=0;

BEGIN

   CREATE TEMP TABLE tmp_detalle_vacunacion (t_fecha_vacunacion date, t_id_vacunacion integer, t_id_detalle_vacunacion integer) ON COMMIT DROP;
   CREATE INDEX index_t_fecha ON tmp_detalle_vacunacion USING btree (t_fecha_vacunacion);
   INSERT INTO tmp_detalle_vacunacion 
       select v.fecha_vacunacion, v.id_vacunacion, dv.id_detalle_vacunacion  from g_vacunacion.vacunacion v 
       INNER JOIN g_vacunacion.detalle_vacunacion dv ON v.id_vacunacion = dv.id_vacunacion
       where to_char(v.fecha_vacunacion,'YYYY-MM-DD')::date < (current_date - interval '180 days') 
       and v.estado <> 'vigente';

   select count(*) into registro from tmp_detalle_vacunacion;
   RAISE NOTICE 'CANTIDAD DE CUV´S Y DETALLES DE VACUNACION CON MAS DE 180 DIAS DE ANTIGUEDAD: %', registro;

   
   CREATE TEMP TABLE tmp_identificadores (t_identificador character varying(32)) on commit drop;
   insert into tmp_identificadores select distinct(identificador) 
		from g_vacunacion.detalle_identificadores di, tmp_detalle_vacunacion tdv
		where di.id_detalle_vacunacion = tdv.t_id_detalle_vacunacion;

   UPDATE g_catastro.detalle_catastros
            SET estado_registro = 'inactivo', observacion = 'caducidad vacunación 180 días'
            WHERE identificador_unico_producto in (select ti.t_identificador from g_catastro.detalle_catastros dc 
                                                   inner join tmp_identificadores ti on dc.identificador_unico_producto = ti.t_identificador);

   UPDATE g_catastro.detalle_catastros
            SET estado_registro = 'inactivo', observacion = 'caducidad vacunación 180 días'
            WHERE identificador_producto in (select ti.t_identificador from g_catastro.detalle_catastros dc 
                                                   inner join tmp_identificadores ti on dc.identificador_producto = ti.t_identificador);

    select count(*) into registro from g_catastro.detalle_catastros where estado_registro = 'inactivo';
    RAISE NOTICE 'CANTIDAD DE IDENTIFICADORES EN ESTADO INACTIVO: %', registro;


    select count(*) into registro from g_catastro.detalle_catastros where estado_registro = 'activo';
    RAISE NOTICE 'CANTIDAD DE IDENTIFICADORES EN ESTADO ACTIVO: %', registro;
 
   RETURN contador;
END;
$$;

alter function migracion_vacunacion() owner to postgres;

