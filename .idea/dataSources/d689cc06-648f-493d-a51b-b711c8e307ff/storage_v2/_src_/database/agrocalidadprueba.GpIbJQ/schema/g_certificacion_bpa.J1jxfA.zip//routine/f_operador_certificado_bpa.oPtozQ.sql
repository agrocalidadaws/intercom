create function f_operador_certificado_bpa(pfecha_desde date, OUT razon_social character varying, OUT provincia character varying, OUT canton character varying, OUT parroquia character varying, OUT tipo_certificado character varying, OUT nombre_producto character varying, OUT nombre_area character varying, OUT nombre_operacion character varying, OUT estado character varying, OUT numero_hectareas double precision) returns SETOF record
    language plpgsql
as
$$
/*
-------------------------------------------------------------------------
--  [g_certificacion_bpa.f_operador_certificado_bpa]
--               
--  Esta funcion retorna records de los operadores con certificacion BPA 
--
--  VERSION		AUTOR					FECHA			HU			                           CAMBIO
--	1			Kleber Armijos		25-07-2023			compartir datos mag           seleccionar los operadores con certificados BPA
-------------------------------------------------------------------------
*/
DECLARE
	
BEGIN	
CREATE TABLE  temp_certificado_operadores_bpa AS(
	SELECT aso.razon_social, aso.provincia, aso.canton , aso.parroquia ,sol.tipo_certificado,sit_ar_pro.nombre_producto,sit_ar_pro.nombre_area, 
	sit_ar_pro.nombre_operacion ,sol.estado, sol.num_hectareas
	FROM  g_certificacion_bpa.asociaciones aso
	INNER JOIN g_certificacion_bpa.solicitudes sol 
	ON aso.identificador=sol.identificador 
	INNER JOIN g_certificacion_bpa.sitios_areas_productos sit_ar_pro 
	ON sol.id_solicitud=sit_ar_pro.id_solicitud

	WHERE 
	aso.estado= 'Activo' 

	AND sol.estado='Aprobado'
	AND sol.fecha_inicio_vigencia>= $1
	AND sol.fecha_fin_vigencia >now()::date
		
);
 RETURN QUERY select *from temp_certificado_operadores_bpa;
  drop table temp_certificado_operadores_bpa;
	
END;
$$;

alter function f_operador_certificado_bpa(date, out varchar, out varchar, out varchar, out varchar, out varchar, out varchar, out varchar, out varchar, out varchar, out double precision) owner to postgres;

