create function fs_validacion_firma_digital(pidentificador_usuario character varying) returns json
    language plpgsql
as
$$

/*
-------------------------------------------------------------------------
--  [g_firma_documentos.fs_validacion_firma_digital]
--               
--  Esta funcion retorna json mismo que contiene error,mensaje,detalle
--
--  VERSION		AUTOR					FECHA			HU	
--	1			Kleber Armijos		25-01-2024	  Funcion generica valida la existencia de firma digital por parte de 
--												  los funcionarios y su vigencia del pfx
--												  
-------------------------------------------------------------------------
*/
DECLARE
	v_resultado json;
BEGIN	
		
WITH cte_usuarios_pfx(identificador, fecha_caducidad_certificado) AS (
  SELECT identificador, fecha_caducidad_certificado 
  FROM g_firma_documentos.firmantes
  WHERE identificador =$1
) 
SELECT  
  CASE
    WHEN NOT EXISTS (SELECT *FROM cte_usuarios_pfx) THEN 
		json_build_object('error', '1',
						  'mensaje','Usuario no posee Firma Registrada en el Sistema Guia',
						  'detalle','Favor Registrar Su Firma Digital.'
						 )
    WHEN (SELECT fecha_caducidad_certificado::date FROM cte_usuarios_pfx) <= (select now()::date )THEN
		  json_build_object('error', '1',
							'mensaje','Usuario Posee Firma Digital',
							'detalle', 'Pfx Caducado')
	ELSE
	json_build_object('error', '0',
					  'mensaje','Usuario Posee Firma valida',
					 'detalle', 'Firma Valida'
					 )
  END into  v_resultado ;
  return v_resultado;

END;
$$;

alter function fs_validacion_firma_digital(varchar) owner to postgres;

