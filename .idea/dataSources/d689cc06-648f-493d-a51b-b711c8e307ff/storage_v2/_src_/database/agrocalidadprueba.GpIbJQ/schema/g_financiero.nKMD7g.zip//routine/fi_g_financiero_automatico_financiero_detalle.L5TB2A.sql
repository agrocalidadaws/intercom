create function fi_g_financiero_automatico_financiero_detalle() returns trigger
    language plpgsql
as
$$
/*
-------------------------------------------------------------------------
--  [g_financiero.fi_g_financiero_automatico_financiero_detalle ]
--               
--  Esta funcion permite ingresar mediante tigers ciertos campos de g_financiero.detalle_pago a g_financiero_automatico.financiero_detalle
--  con la finalidad de poder pagar mediante el uso de banred,
--
--  VERSION		AUTOR					FECHA			HU			                           CAMBIO
--	1			Kleber Armijos		15-08-2024			PRY-BANRED      
                Milton Nivelo
-------------------------------------------------------------------------
*/
DECLARE
   
     vid_financiero_cabecera INTEGER;
	
BEGIN

	

    IF TG_OP = 'INSERT' THEN
       
        SELECT id_financiero_cabecera INTO vid_financiero_cabecera
        FROM g_financiero_automatico.financiero_cabecera
        WHERE id_orden_pago=new.id_pago;
        IF vid_financiero_cabecera is not null THEN 
            INSERT INTO g_financiero_automatico.financiero_detalle(
                    id_financiero_cabecera,
                    id_servicio,
                    concepto_orden,
                    cantidad,
                    precio_unitario,
                    descuento,
                    iva,
                    total
                )VALUES (
                    vid_financiero_cabecera,
                    NEW.id_servicio,
                    NEW.concepto_orden,
                    NEW.cantidad,
                    NEW.precio_unitario,
                    NEW.descuento,
                    NEW.iva,
                    NEW.total
                );
                RETURN NEW;
             
            END IF;
    END IF;
    RETURN new;
    
END;
$$;

alter function fi_g_financiero_automatico_financiero_detalle() owner to postgres;

