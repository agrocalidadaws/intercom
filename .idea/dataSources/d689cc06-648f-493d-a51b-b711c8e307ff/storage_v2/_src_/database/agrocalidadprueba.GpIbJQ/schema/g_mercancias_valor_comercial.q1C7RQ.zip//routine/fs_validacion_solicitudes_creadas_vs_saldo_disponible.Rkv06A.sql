create function fs_validacion_solicitudes_creadas_vs_saldo_disponible(pidentificador_usuario character varying, parea character varying, pcodigotarifario character varying, ptiposolicitudes character varying) returns json
    language plpgsql
as
$$

/*
-------------------------------------------------------------------------
--  [g_mercancias_valor_comercial.fs_validacion_cliente_facturacion_saldo_disponible]
--               
--  Esta funcion retorna json mismo que contiene mensaje,cantidad, detalle
--
--  VERSION		AUTOR					FECHA			HU	
--	1			Kleber Armijos		25-01-2024	  Funcion generica que verifica la cantidad de solicitudes en estado pago 
--												  vs la cantidad que permitiria facturar con el saldo disponible
--											
-------------------------------------------------------------------------
*/
DECLARE
	resultado_json json;
	cantidad_solicitudes_pago integer;
	valor_total_solicitudes_pago  DECIMAL;
BEGIN	

	IF $2='SA' THEN 
		IF $4 ='TODAS' THEN
			SELECT COUNT(estado)
			INTO cantidad_solicitudes_pago
			FROM g_mercancias_valor_comercial.solicitudes
			WHERE identificador_operador = $1
            AND tipo_solicitud='Exportacion'
			AND estado = 'pago';
			
			valor_total_solicitudes_pago := cantidad_solicitudes_pago * (
				SELECT valor
				FROM g_financiero.servicios
				WHERE id_area = $2 AND codigo = $3
			);
			resultado_json := CASE
			WHEN valor_total_solicitudes_pago <= (
				SELECT saldo_disponible
				FROM (
					SELECT saldo_disponible, ROW_NUMBER() OVER (ORDER BY id_saldo DESC) as row_num
					FROM g_financiero.saldos
					WHERE identificador_operador = $1
				) AS subquery
				WHERE row_num = 1)	 
			THEN
				json_build_object('mensaje', concat('tienes ', cantidad_solicitudes_pago, ' solicitudes en estado Pago'),
                          'detalle', 'Posee saldo Suficiente',
						  'alerta',0,
                          'cantidadSolicitudePago', cantidad_solicitudes_pago)
			ELSE
				json_build_object('mensaje', concat('Tiene ', cantidad_solicitudes_pago, ' solicitudes por pagar, '),
                          'detalle', 'por favor asegúrate de tener saldo suficiente!!',
						  'alerta',1,
                          'cantidadSolicitudePago', cantidad_solicitudes_pago)
			END;
			ELSE
			resultado_json:=json_build_object('mensaje', 'Tipo Solicitud no Existe',
                          'detalle', 'Revisar Tipo Solicitud',
						  'alerta',-1,
                          'cantidadSolicitudePago',-1);
		END IF;
		
	ELSE
		resultado_json:=json_build_object('mensaje', 'Area no existe',
                          'detalle', 'Revisar el codigo de area',
						  'alerta',-1,
                          'cantidadSolicitudePago',-1);
	END IF;
	
	return resultado_json;
		
END;
$$;

alter function fs_validacion_solicitudes_creadas_vs_saldo_disponible(varchar, varchar, varchar, varchar) owner to postgres;

