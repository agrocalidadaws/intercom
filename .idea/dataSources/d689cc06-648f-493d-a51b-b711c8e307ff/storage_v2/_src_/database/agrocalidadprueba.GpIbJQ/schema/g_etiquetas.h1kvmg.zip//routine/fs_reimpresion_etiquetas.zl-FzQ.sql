create function fs_reimpresion_etiquetas(pglpi text, pidentificador character varying, pnumero_solicitud character varying, pnumero_etiquetas_serie text[], petiquetas_faltantes integer, psaldo_etiquetas integer) returns text
    language plpgsql
as
$$
/*
-------------------------------------------------------------------------
--  [g_etiquetas.fs_reimpresion_etiquetas]
--               
--  Esta funcion se encarga de reimprimir  y devolviendo las faltantes
--
--  VERSION		AUTOR					FECHA			HU			         CAMBIO
--	1			Kleber Armijos		23-02-2023			optimizacion GLPI	se devuelven las etiquetas faltantes en las tablas etiquetas sitios y etiquetas.
-------------------------------------------------------------------------
*/
DECLARE
 	saldo_etiquetas int:=psaldo_etiquetas; 	
	saldo_etiqueta_consulta int:=0;
	glpi int:=pglpi;
	BEGIN

	
	IF(saldo_etiquetas>=0) then
	saldo_etiqueta_consulta:=(SELECT g_et_et_inicio.saldo_etiqueta FROM g_etiquetas.etiquetas g_et_et_inicio
							  WHERE g_et_et_inicio.identificador_operador= $2 --'1723262315001' 
		  					  AND g_et_et_inicio.numero_solicitud= $3 --'2018-00002'
							 );	
			IF(saldo_etiquetas=saldo_etiqueta_consulta) THEN 
			
				RAISE NOTICE '% %','su saldo de etiquetas actualinicial es:', saldo_etiqueta_consulta;		
				CREATE   TABLE temp_etiquetas_impresas as(
				SELECT DISTINCT id_etiqueta_detalle 
					FROM g_etiquetas.etiquetas_impresas 
					--where lower(numero_etiqueta) like any('{%0016374379%,%0016374377%}'));
					WHERE LOWER(numero_etiqueta) LIKE ANY(pnumero_etiquetas_serie));

				RAISE NOTICE '%','cree la tabla: temp_etiquetas_impresas';

				CREATE  TABLE temp_etiquetas_detalle as(
				SELECT et_de.* FROM temp_etiquetas_impresas tmp_e_imp 
							   INNER JOIN g_etiquetas.etiquetas_detalle et_de on tmp_e_imp.id_etiqueta_detalle=et_de.id_etiqueta_detalle );

				RAISE NOTICE '%','cree la tabla: temp_etiquetas_detalle';

				--aqui eempiezo a actualizar
				UPDATE g_etiquetas.etiquetas_detalle ed
					SET estado ='anulado',
					--set ed.observacion='anulado en base a GLPI#'||glpi
					 observacion='anulado en base a GLPI#'||pglpi
					FROM temp_etiquetas_detalle tmp_ed
					WHERE ed.id_etiqueta_detalle=tmp_ed.id_etiqueta_detalle;
				
					 RAISE NOTICE '%','actulice tabla etiquetas_detalle:';
				--aqui termino de actualizar en la tabla etiquetas_detalles
				
				--anicia la devolucion en la table etiquetas_sitios
				UPDATE g_etiquetas.etiquetas_sitios es 
						SET saldo_etiqueta =es.saldo_etiqueta+petiquetas_faltantes
						FROM temp_etiquetas_detalle tmp_ed_s
						WHERE es.id_etiqueta_sitio=tmp_ed_s.id_etiqueta_sitio;
						
					 RAISE NOTICE '%','actulice etiquetas_sitio:';			
				--devolucion en etiquetas_sitios		
				UPDATE g_etiquetas.etiquetas e
					   SET saldo_etiqueta=(SELECT g_es.saldo_etiqueta 
										   FROM temp_etiquetas_detalle tmp_ed_e 
										   INNER JOIN g_etiquetas.etiquetas_sitios g_es 
										   ON tmp_ed_e.id_etiqueta_sitio=g_es.id_etiqueta_sitio)--  where id_etiqueta_sitio=3365
						WHERE  e.identificador_operador=$2 AND  e.numero_solicitud=$3;
					 RAISE NOTICE '%','actulice etiquetas:';

					saldo_etiqueta_consulta:=(SELECT d_et_total.saldo_etiqueta 
											  FROM g_etiquetas.etiquetas d_et_total
											  WHERE d_et_total.identificador_operador=$2 
											  AND d_et_total.numero_solicitud=$3
											 );
						DROP TABLE temp_etiquetas_impresas;
						DROP TABLE temp_etiquetas_detalle;

					RAISE NOTICE '% %','su saldo de etiquetas actual es', saldo_etiqueta_consulta;
			END IF;
	
END IF;
			
	RETURN saldo_etiqueta_consulta;
           
			RAISE NOTICE '% %','su saldo de etiquetas actual es', saldo_etiqueta_consulta;
			
    END;
$$;

alter function fs_reimpresion_etiquetas(text, varchar, varchar, text[], integer, integer) owner to postgres;

