create view vista_reporte_sitios
            (id_vacuna_animal, id_sitio, codigo_catastral, provincia, canton, parroquia, codigo_area,
             identificador_operador, representante, nombre_sitio, nombre_area, direccion, telefono, lugar_referencia)
as
SELECT DISTINCT max(va.id_vacuna_animal)                                                               AS id_vacuna_animal,
                s.id_sitio,
                (((((((s.identificador_operador::text || '.'::text) || s.codigo_provincia::text) || ''::text) ||
                    s.codigo::text) || ''::text) || a.codigo::text) || ''::text) ||
                a.secuencial::text                                                                     AS codigo_catastral,
                s.provincia,
                s.canton,
                s.parroquia,
                (((((s.codigo_provincia::text || ''::text) || s.codigo::text) || ''::text) || a.codigo::text) ||
                 ''::text) || a.secuencial::text                                                       AS codigo_area,
                s.identificador_operador::text                                                         AS identificador_operador,
                (o.nombre_representante::text || ' '::text) || o.apellido_representante::text          AS representante,
                s.nombre_lugar                                                                         AS nombre_sitio,
                a.nombre_area,
                s.direccion,
                s.telefono,
                s.referencia                                                                           AS lugar_referencia
FROM g_operadores.operadores o,
     g_operadores.sitios s,
     g_operadores.areas a,
     g_operadores.operaciones op,
     g_catalogos.tipos_operacion t,
     g_vacunacion_animal.vacuna_animales va
WHERE o.identificador::text = s.identificador_operador::text
  AND o.identificador::text = op.identificador_operador::text
  AND s.identificador_operador::text = op.identificador_operador::text
  AND op.id_tipo_operacion = t.id_tipo_operacion
  AND s.id_sitio = a.id_sitio
  AND va.id_sitio = s.id_sitio
  AND va.id_vacuna_animal = va.id_vacuna_animal
  AND t.nombre::text = 'Productor'::text
  AND t.id_area::text = 'SA'::text
  AND a.tipo_area::text = 'Lugar de producción'::text
GROUP BY s.id_sitio, a.codigo, a.secuencial, o.nombre_representante, o.apellido_representante, a.nombre_area;

alter table vista_reporte_sitios
    owner to postgres;

