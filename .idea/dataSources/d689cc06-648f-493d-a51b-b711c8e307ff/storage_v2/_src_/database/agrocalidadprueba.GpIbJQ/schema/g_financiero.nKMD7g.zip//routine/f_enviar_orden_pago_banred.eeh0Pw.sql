create function f_enviar_orden_pago_banred() returns trigger
    language plpgsql
as
$$
/*
-------------------------------------------------------------------------
--  [g_financiero.f_enviar_orden_pago_banred]
--               
--  Esta funcion Permite ingresar en el esquema g_correos.correos las ordenes de pagos generadas por el sistema 
--  cualqueir tipo de orden de pago 
--
--  VERSION		AUTOR					FECHA			HU			                          
--	1			Kleber Armijos		09-02-2024			esta funcion se crea para el envio de los correos de las ordenes de pagos   
--  2           Milto Nivelo        09-02-2024          para el proyecto banred
-------------------------------------------------------------------------
*/
DECLARE
v_correo_operador_usuario_final character varying;
v_nombre_operador character varying;
v_id_correo integer;
v_asunto character varying ;
v_cuerpo character varying ;
v_path character varying default '/var/www/html/agrodbPrueba/';
BEGIN
	
   IF TG_OP = 'INSERT' AND NEW.estado in(3,5) AND NEW.tipo_solicitud not in('certificadoZooExportacion') THEN 
        SELECT  UPPER(razon_social),correo 
        INTO v_nombre_operador,v_correo_operador_usuario_final
        FROM g_financiero.clientes WHERE identificador=NEW.identificador_operador;
        v_asunto:='Orden de Pago '||new.numero_solicitud;
        v_cuerpo:='<tr>
                    <td style="font-family:"Text Me One", 
                     "Segoe UI", "Tahoma", "Helvetica", "freesans", "sans-serif2; padding-top:25px; font-size:14px;color:#2a2a2a; width: 80%; text-align:justify;">'
                     ||'Estimado Sr. <font color="green">' || v_nombre_operador || '</font>,<br/><br/>'
                     ||'Por medio de la presente se comunica que la orden de pago con, Nro. <font color="green">' ||NEW.numero_solicitud ||'</font>'||
                     ' ha sido Generada .<br/><br/>' 
                     --||'se adjunta Documento.<br/><br/>'
                     ||'Saludos Cordiales.
                    </td>
                 </tr>';
         INSERT INTO g_correos.correos(
									   asunto,
									   cuerpo,
									   estado,
									   codigo_modulo,
									   tabla_modulo,
									   id_solicitud_tabla	   
									  )
        VALUES (v_asunto, 
				v_cuerpo,
			   	'Por enviar',
				'PRG_FINANCIERO',
				'g_financiero.orden_pago',
				NEW.id_pago
			   )
		RETURNING id_correo INTO v_id_correo; 
		
		INSERT INTO g_correos.destinatarios(id_correo,destinatario_correo)
		VALUES(v_id_correo,v_correo_operador_usuario_final);
        
        INSERT INTO  g_correos.documentos_adjuntos (id_correo,ruta_documento_adjunto)
        VALUES (v_id_correo,v_path||NEW.orden_pago);
        
    END IF;
RETURN NEW;
END;
$$;

alter function f_enviar_orden_pago_banred() owner to postgres;

