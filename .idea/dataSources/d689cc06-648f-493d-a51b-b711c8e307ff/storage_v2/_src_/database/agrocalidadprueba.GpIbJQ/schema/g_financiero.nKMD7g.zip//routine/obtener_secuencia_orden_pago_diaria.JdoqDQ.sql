create function obtener_secuencia_orden_pago_diaria() returns bigint
    language plpgsql
as
$$
/*
-------------------------------------------------------------------------
--  [g_financiero.obetener_secuencia_orden_pago_diaria]
--               
--  Esta función retorna un bigint como secuencia diaria
--
--  VERSION		AUTOR					FECHA			HU	
--	1			Kleber Armijos		27-08-2024	  función para generar secuencial orden de pago 
--				Milton Nivelo		27-08-2024	  diarias para el proyecto Banred
--												
-------------------------------------------------------------------------
*/
DECLARE
    fecha_actual date;
    valor_actual bigint;
BEGIN
    fecha_actual := CURRENT_DATE;
    
    -- Intentar actualizar el registro existente para la fecha actual
    UPDATE g_financiero.secuencia_diaria_orden_pago
    SET ultimo_valor_secuencia = ultimo_valor_secuencia + 1,
        ultimo_valor_actuliazado = CURRENT_TIMESTAMP
    WHERE fecha_secuencia = fecha_actual
    RETURNING ultimo_valor_secuencia INTO valor_actual;
    
    -- Si no se encuentra un registro para la fecha actual, insertar uno nuevo
    IF NOT FOUND THEN
        INSERT INTO g_financiero.secuencia_diaria_orden_pago (fecha_secuencia, ultimo_valor_secuencia, ultimo_valor_actuliazado)
        VALUES (fecha_actual, 1, CURRENT_TIMESTAMP)
        RETURNING ultimo_valor_secuencia INTO valor_actual;
         DELETE FROM g_financiero.secuencia_diaria_orden_pago
        WHERE  fecha_secuencia =  CURRENT_DATE - INTERVAL '1 day';
    END IF;
    
    RETURN valor_actual;
END;
$$;

alter function obtener_secuencia_orden_pago_diaria() owner to postgres;

