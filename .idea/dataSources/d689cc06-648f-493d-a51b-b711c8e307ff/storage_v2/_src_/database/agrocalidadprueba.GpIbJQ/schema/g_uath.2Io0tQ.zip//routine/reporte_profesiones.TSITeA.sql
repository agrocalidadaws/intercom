create function reporte_profesiones(_regimen_laboral text, _provincia text, _coordinacion text, _direccion text, _gestion text, _nivel_instruccion text, _titulo text, _carrera text, _estado text) returns SETOF g_uath.vista_funcionario_profesion
    language plpgsql
as
$$
DECLARE
	query text;
BEGIN	
	return query EXECUTE 'SELECT
			*
		FROM 
			g_uath.vista_funcionario_profesion
		WHERE 
		        
			($1 is NULL or regimen_laboral = $1) and 
			($2 is NULL or provincia = $2) and
			($3 is NULL or coordinacion = $3) and 
			($4 is NULL or direccion = $4) and 
			($5 is NULL or gestion = $5) and 
			($6 is NULL or nivel_instruccion = $6) and 
			($7 is NULL or titulo = $7) and 
			($8 is NULL or carrera = $8) and
			($9 is NULL or estado = $9)' 

		using _regimen_laboral,_provincia,_coordinacion,_direccion,_gestion,_nivel_instruccion, _titulo, _carrera, _estado;
	
END;
$$;

alter function reporte_profesiones(text, text, text, text, text, text, text, text, text) owner to postgres;

