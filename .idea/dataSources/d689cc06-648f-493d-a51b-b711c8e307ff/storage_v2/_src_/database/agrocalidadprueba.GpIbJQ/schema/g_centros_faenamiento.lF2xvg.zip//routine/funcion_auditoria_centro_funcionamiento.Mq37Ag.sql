create function funcion_auditoria_centro_funcionamiento() returns trigger
    language plpgsql
as
$$ 
BEGIN
	
	PERFORM g_centros_faenamiento.funcion_insertar_auditoria_centro_funcionamiento(NEW.criterio_funcionamiento, NEW.observacion, NEW.identificador_registro, NEW.id_centro_faenamiento);	
	
RETURN NEW;
END; 

	
$$;

alter function funcion_auditoria_centro_funcionamiento() owner to postgres;

