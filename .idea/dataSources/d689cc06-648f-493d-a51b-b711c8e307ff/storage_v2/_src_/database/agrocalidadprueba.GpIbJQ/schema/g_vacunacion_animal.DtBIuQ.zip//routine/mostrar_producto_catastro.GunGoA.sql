create function mostrar_producto_catastro(id_sitio integer, id_area integer, id_especie integer) returns SETOF g_vacunacion_animal.mostrar_producto_catastro
    language plpgsql
as
$$
DECLARE
	query text;
BEGIN	
	return query EXECUTE '
			select distinct c.id_catastro
			, c.id_producto
			, p.nombre_comun producto
			, c.total total_existencias
			, (date (current_date) - date (c.fecha_nacimiento)) edad_producto
			, c.fecha_nacimiento
			, a.orden
			,a.codigo
			from g_vacunacion_animal.catastros c
			, g_catalogos.productos p
			, g_catalogos.productos_animales a
			where c.id_producto = p.id_producto
			and c.id_producto = a.id_producto
			and p.id_producto = a.id_producto
			and a.estado=''activo''
			and id_catastro in (select max(id_catastro)
			from g_vacunacion_animal.catastros c
				where total is not null
				and id_sitio = $1
				and id_area = $2
				and id_especie = $3
				group by c.id_producto)
			union
			select distinct 0 id_catastro
			, p.id_producto
			, p.nombre_comun producto
			, 0 total_existencias
			, 0 edad_producto
			, current_date fecha_nacimiento
			, a.orden
			,a.codigo
			from g_catalogos.productos p
			, g_catalogos.productos_animales a
			where p.id_producto = a.id_producto
			and a.estado=''activo''
				and p.id_producto not in (select distinct id_producto 
				from g_vacunacion_animal.catastros 				
				where id_sitio = $1
				and id_area = $2
				and id_especie = $3)
			'			
		using id_sitio,id_area,id_especie;
	
END;
$$;

alter function mostrar_producto_catastro(integer, integer, integer) owner to postgres;

