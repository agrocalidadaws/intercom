create function mostrar_siniestro_general(_placa text, _fecha_inicio timestamp without time zone, _fecha_fin date, _localizacion text, _cantidad integer) returns SETOF g_transportes.siniestro_general
    language plpgsql
as
$$
DECLARE
	query text;
BEGIN	
	return query EXECUTE '
			SELECT 
				v.placa,
				v.modelo,
				v.marca,
				v.localizacion,
				s.valor_total,
				s.estado
			FROM 
				g_transportes.siniestros s,
				g_transportes.vehiculos v 
			WHERE
				s.placa = v.placa and
				($1 is NULL or s.placa like $1) and 
				($2 is NULL or  s.fecha_solicitud >= $2) and 
				($3 is NULL or  s.fecha_solicitud <= $3) and
				($4 is NULL or $4 = v.localizacion)
			GROUP BY 
				v.placa,
				v.modelo,
				v.marca,
				v.localizacion,
				s.valor_total,
				s.estado
			ORDER BY valor_total asc
			LIMIT $5'
			
		using _placa,_fecha_inicio,_fecha_fin,_localizacion,_cantidad;
	
END;
$$;

alter function mostrar_siniestro_general(text, timestamp, date, text, integer) owner to postgres;

