create function separar_nombre_completo(nombre_completo text)
    returns TABLE(primer_nombre text, segundo_nombre text)
    language plpgsql
as
$$
DECLARE
    palabras TEXT[];
    preposiciones TEXT[] := ARRAY['DE', 'DEL', 'LOS', 'LAS', 'Y', 'LA', 'DI', 'VAN'];
    primer_nombre1 TEXT;
    primer_nombre TEXT;
    segundo_nombre TEXT;
    palabra_actual TEXT;
    bandera BOOLEAN;
BEGIN
    -- Convertir el nombre completo a mayúsculas y quitar espacios al inicio y fin
    nombre_completo := TRIM(UPPER(nombre_completo));
    -- Separar el nombre completo en palabras
    palabras := string_to_array(nombre_completo, ' ');

    -- Si el nombre completo tiene solo una palabra, se considera el primer nombre
    IF array_length(palabras, 1) = 1 THEN
        primer_nombre := palabras[1];
        segundo_nombre := '';
    ELSE
        -- Obtener el primer nombre
        primer_nombre1 := palabras[1];
        primer_nombre := '';
        segundo_nombre := '';
        bandera := FALSE;

        IF primer_nombre1 = ANY(preposiciones) THEN
            FOREACH palabra_actual IN ARRAY palabras LOOP
                IF palabra_actual = ANY(preposiciones) THEN
                    primer_nombre := primer_nombre || ' ' || palabra_actual;
                ELSE
                    IF bandera THEN
                        primer_nombre := primer_nombre || ' ' || palabra_actual;
                        bandera := FALSE;
                    ELSE
                        segundo_nombre := segundo_nombre || ' ' || palabra_actual;
                    END IF;
                END IF;
            END LOOP;
        ELSE
            -- Obtener el último nombre, que será el segundo nombre
            primer_nombre := palabras[1];
            segundo_nombre := TRIM(ARRAY_TO_STRING(palabras[2:], ' '));

            IF segundo_nombre = ANY(preposiciones) THEN
                -- Si es una preposición común, se considera parte del primer nombre
                primer_nombre := primer_nombre || ' ' || segundo_nombre;
                segundo_nombre := '';
            END IF;
        END IF;
    END IF;

    RETURN QUERY SELECT primer_nombre, segundo_nombre;
END;
$$;

alter function separar_nombre_completo(text) owner to postgres;

