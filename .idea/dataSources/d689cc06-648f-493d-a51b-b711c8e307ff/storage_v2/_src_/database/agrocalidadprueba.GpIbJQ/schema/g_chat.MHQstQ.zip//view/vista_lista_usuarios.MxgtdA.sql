create view vista_lista_usuarios(identificador, nombres, direccion, fotografia) as
SELECT DISTINCT fe.identificador,
                (fe.nombre::text || ' '::text) || fe.apellido::text AS nombres,
                dc.direccion,
                fe.fotografia
FROM g_uath.ficha_empleado fe,
     g_uath.datos_contrato dc,
     g_usuario.usuarios u,
     g_estructura.funcionarios fu
WHERE fe.identificador::text = dc.identificador::text
  AND dc.estado = 1
  AND fe.estado_empleado::text = 'activo'::text
  AND u.identificador::text = fe.identificador::text
  AND u.estado = 1
  AND fu.identificador::text = dc.identificador::text
ORDER BY dc.direccion;

alter table vista_lista_usuarios
    owner to postgres;

